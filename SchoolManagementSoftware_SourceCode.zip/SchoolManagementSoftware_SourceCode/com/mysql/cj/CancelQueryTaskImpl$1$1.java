package com.mysql.cj;

class CancelQueryTaskImpl$1$1
  implements TransactionEventHandler
{
  CancelQueryTaskImpl$1$1(CancelQueryTaskImpl.1 this$1) {}
  
  public void transactionCompleted() {}
  
  public void transactionBegun() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.CancelQueryTaskImpl.1.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */