package com.mysql.cj;

public abstract interface DataStoreMetadata
{
  public abstract boolean schemaExists(String paramString);
  
  public abstract boolean tableExists(String paramString1, String paramString2);
  
  public abstract long getTableRowCount(String paramString1, String paramString2);
}

/* Location:
 * Qualified Name:     com.mysql.cj.DataStoreMetadata
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */