package com.mysql.cj;

import java.util.List;

public class ClientPreparedQuery
  extends AbstractPreparedQuery<ClientPreparedQueryBindings>
{
  public ClientPreparedQuery(NativeSession sess)
  {
    super(sess);
  }
  
  protected long[] computeMaxParameterSetSizeAndBatchSize(int numBatchedArgs)
  {
    long sizeOfEntireBatch = 0L;
    long maxSizeOfParameterSet = 0L;
    for (int i = 0; i < numBatchedArgs; i++)
    {
      ClientPreparedQueryBindings qBindings = (ClientPreparedQueryBindings)batchedArgs.get(i);
      
      BindValue[] bindValues = qBindings.getBindValues();
      
      long sizeOfParameterSet = 0L;
      for (int j = 0; j < bindValues.length; j++) {
        if (!bindValues[j].isNull())
        {
          if (bindValues[j].isStream())
          {
            long streamLength = bindValues[j].getStreamLength();
            if (streamLength != -1L)
            {
              sizeOfParameterSet += streamLength * 2L;
            }
            else
            {
              int paramLength = ((ClientPreparedQueryBindValue[])qBindings.getBindValues())[j].getByteValue().length;
              sizeOfParameterSet += paramLength;
            }
          }
          else
          {
            sizeOfParameterSet += ((ClientPreparedQueryBindValue[])qBindings.getBindValues())[j].getByteValue().length;
          }
        }
        else {
          sizeOfParameterSet += 4L;
        }
      }
      if (parseInfo.getValuesClause() != null) {
        sizeOfParameterSet += parseInfo.getValuesClause().length() + 1;
      } else {
        sizeOfParameterSet += originalSql.length() + 1;
      }
      sizeOfEntireBatch += sizeOfParameterSet;
      if (sizeOfParameterSet > maxSizeOfParameterSet) {
        maxSizeOfParameterSet = sizeOfParameterSet;
      }
    }
    return new long[] { maxSizeOfParameterSet, sizeOfEntireBatch };
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.ClientPreparedQuery
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */