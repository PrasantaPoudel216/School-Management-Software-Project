package com.mysql.cj;

public abstract interface CacheAdapterFactory<K, V>
{
  public abstract CacheAdapter<K, V> getInstance(Object paramObject, String paramString, int paramInt1, int paramInt2);
}

/* Location:
 * Qualified Name:     com.mysql.cj.CacheAdapterFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */