package com.mysql.cj;

import com.mysql.cj.util.StringUtils;
import java.util.LinkedList;

public class AppendingBatchVisitor
  implements BatchVisitor
{
  LinkedList<byte[]> statementComponents = new LinkedList();
  
  public BatchVisitor append(byte[] values)
  {
    statementComponents.addLast(values);
    
    return this;
  }
  
  public BatchVisitor increment()
  {
    return this;
  }
  
  public BatchVisitor decrement()
  {
    statementComponents.removeLast();
    
    return this;
  }
  
  public BatchVisitor merge(byte[] front, byte[] back)
  {
    int mergedLength = front.length + back.length;
    byte[] merged = new byte[mergedLength];
    System.arraycopy(front, 0, merged, 0, front.length);
    System.arraycopy(back, 0, merged, front.length, back.length);
    statementComponents.addLast(merged);
    return this;
  }
  
  public BatchVisitor mergeWithLast(byte[] values)
  {
    if (statementComponents.isEmpty()) {
      return append(values);
    }
    return merge((byte[])statementComponents.removeLast(), values);
  }
  
  public byte[][] getStaticSqlStrings()
  {
    byte[][] asBytes = new byte[statementComponents.size()][];
    statementComponents.toArray(asBytes);
    
    return asBytes;
  }
  
  public String toString()
  {
    StringBuilder sb = new StringBuilder();
    for (byte[] comp : statementComponents) {
      sb.append(StringUtils.toString(comp));
    }
    return sb.toString();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.AppendingBatchVisitor
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */