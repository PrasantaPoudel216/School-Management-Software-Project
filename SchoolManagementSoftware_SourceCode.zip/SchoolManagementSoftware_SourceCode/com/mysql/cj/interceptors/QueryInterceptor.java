package com.mysql.cj.interceptors;

import com.mysql.cj.MysqlConnection;
import com.mysql.cj.Query;
import com.mysql.cj.log.Log;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.ServerSession;
import java.util.Properties;
import java.util.function.Supplier;

public abstract interface QueryInterceptor
{
  public abstract QueryInterceptor init(MysqlConnection paramMysqlConnection, Properties paramProperties, Log paramLog);
  
  public abstract <T extends Resultset> T preProcess(Supplier<String> paramSupplier, Query paramQuery);
  
  public <M extends Message> M preProcess(M queryPacket)
  {
    return null;
  }
  
  public abstract boolean executeTopLevelOnly();
  
  public abstract void destroy();
  
  public abstract <T extends Resultset> T postProcess(Supplier<String> paramSupplier, Query paramQuery, T paramT, ServerSession paramServerSession);
  
  public <M extends Message> M postProcess(M queryPacket, M originalResponsePacket)
  {
    return null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.interceptors.QueryInterceptor
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */