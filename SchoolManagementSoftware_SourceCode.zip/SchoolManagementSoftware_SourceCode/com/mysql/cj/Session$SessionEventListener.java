package com.mysql.cj;

public abstract interface Session$SessionEventListener
{
  public abstract void handleNormalClose();
  
  public abstract void handleReconnect();
  
  public abstract void handleCleanup(Throwable paramThrowable);
}

/* Location:
 * Qualified Name:     com.mysql.cj.Session.SessionEventListener
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */