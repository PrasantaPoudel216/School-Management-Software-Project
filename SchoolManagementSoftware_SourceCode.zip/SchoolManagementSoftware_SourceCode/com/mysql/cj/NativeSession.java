package com.mysql.cj;

import com.mysql.cj.conf.HostInfo;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ConnectionIsClosedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.ExceptionInterceptorChain;
import com.mysql.cj.exceptions.OperationCancelledException;
import com.mysql.cj.exceptions.PasswordExpiredException;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.interceptors.QueryInterceptor;
import com.mysql.cj.log.BaseMetricsHolder;
import com.mysql.cj.log.Log;
import com.mysql.cj.protocol.AuthenticationProvider;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.NetworkResources;
import com.mysql.cj.protocol.Protocol;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.Resultset.Type;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.SocketConnection;
import com.mysql.cj.protocol.SocketFactory;
import com.mysql.cj.protocol.a.NativeMessageBuilder;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.protocol.a.NativeProtocol;
import com.mysql.cj.protocol.a.NativeServerSession;
import com.mysql.cj.protocol.a.NativeSocketConnection;
import com.mysql.cj.protocol.a.ResultsetFactory;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.IntegerValueFactory;
import com.mysql.cj.result.LongValueFactory;
import com.mysql.cj.result.Row;
import com.mysql.cj.result.StringValueFactory;
import com.mysql.cj.result.ValueFactory;
import com.mysql.cj.util.StringUtils;
import java.io.IOException;
import java.io.InputStream;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.net.Socket;
import java.net.SocketAddress;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.nio.charset.CharsetEncoder;
import java.nio.charset.UnsupportedCharsetException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.Timer;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collector;

public class NativeSession
  extends CoreSession
  implements Serializable
{
  private static final long serialVersionUID = 5323638898749073419L;
  private CacheAdapter<String, Map<String, String>> serverConfigCache;
  private static final Map<String, Map<Integer, String>> customIndexToCharsetMapByUrl = new HashMap();
  private static final Map<String, Map<String, Integer>> customCharsetToMblenMapByUrl = new HashMap();
  private boolean requiresEscapingEncoder;
  private long lastQueryFinishedTime = 0L;
  private boolean needsPing = false;
  private NativeMessageBuilder commandBuilder = new NativeMessageBuilder();
  private boolean isClosed = true;
  private Throwable forceClosedReason;
  private CopyOnWriteArrayList<WeakReference<Session.SessionEventListener>> listeners = new CopyOnWriteArrayList();
  private transient Timer cancelTimer;
  private static final String SERVER_VERSION_STRING_VAR_NAME = "server_version_string";
  
  public NativeSession(HostInfo hostInfo, PropertySet propSet)
  {
    super(hostInfo, propSet);
  }
  
  public void connect(HostInfo hi, String user, String password, String database, int loginTimeout, TransactionEventHandler transactionManager)
    throws IOException
  {
    hostInfo = hi;
    
    setSessionMaxRows(-1);
    
    SocketConnection socketConnection = new NativeSocketConnection();
    socketConnection.connect(hostInfo.getHost(), hostInfo.getPort(), propertySet, getExceptionInterceptor(), log, loginTimeout);
    if (protocol == null) {
      protocol = NativeProtocol.getInstance(this, socketConnection, propertySet, log, transactionManager);
    } else {
      protocol.init(this, socketConnection, propertySet, transactionManager);
    }
    protocol.connect(user, password, database);
    
    protocol.getServerSession().setErrorMessageEncoding(protocol.getAuthenticationProvider().getEncodingForHandshake());
    
    isClosed = false;
  }
  
  public NativeProtocol getProtocol()
  {
    return (NativeProtocol)protocol;
  }
  
  public void quit()
  {
    if (protocol != null) {
      try
      {
        ((NativeProtocol)protocol).quit();
      }
      catch (Exception localException) {}
    }
    synchronized (this)
    {
      if (cancelTimer != null)
      {
        cancelTimer.cancel();
        cancelTimer = null;
      }
    }
    isClosed = true;
    super.quit();
  }
  
  public void forceClose()
  {
    if (protocol != null) {
      try
      {
        protocol.getSocketConnection().forceClose();
        ((NativeProtocol)protocol).releaseResources();
      }
      catch (Throwable localThrowable) {}
    }
    synchronized (this)
    {
      if (cancelTimer != null)
      {
        cancelTimer.cancel();
        cancelTimer = null;
      }
    }
    isClosed = true;
    super.forceClose();
  }
  
  public void enableMultiQueries()
  {
    sendCommand(commandBuilder.buildComSetOption(((NativeProtocol)protocol).getSharedSendPacket(), 0), false, 0);
    ((NativeServerSession)getServerSession()).preserveOldTransactionState();
  }
  
  public void disableMultiQueries()
  {
    sendCommand(commandBuilder.buildComSetOption(((NativeProtocol)protocol).getSharedSendPacket(), 1), false, 0);
    ((NativeServerSession)getServerSession()).preserveOldTransactionState();
  }
  
  public boolean isSetNeededForAutoCommitMode(boolean autoCommitFlag)
  {
    return ((NativeServerSession)protocol.getServerSession()).isSetNeededForAutoCommitMode(autoCommitFlag, false);
  }
  
  public int getSessionMaxRows()
  {
    return sessionMaxRows;
  }
  
  public void setSessionMaxRows(int sessionMaxRows)
  {
    this.sessionMaxRows = sessionMaxRows;
  }
  
  public void setQueryInterceptors(List<QueryInterceptor> queryInterceptors)
  {
    ((NativeProtocol)protocol).setQueryInterceptors(queryInterceptors);
  }
  
  public boolean isServerLocal(Session sess)
  {
    SocketFactory factory = protocol.getSocketConnection().getSocketFactory();
    return factory.isLocallyConnected(sess);
  }
  
  public void shutdownServer()
  {
    if (versionMeetsMinimum(5, 7, 9)) {
      sendCommand(commandBuilder.buildComQuery(getSharedSendPacket(), "SHUTDOWN"), false, 0);
    } else {
      sendCommand(commandBuilder.buildComShutdown(getSharedSendPacket()), false, 0);
    }
  }
  
  public void setSocketTimeout(int milliseconds)
  {
    getPropertySet().getProperty(PropertyKey.socketTimeout).setValue(Integer.valueOf(milliseconds));
    ((NativeProtocol)protocol).setSocketTimeout(milliseconds);
  }
  
  public int getSocketTimeout()
  {
    RuntimeProperty<Integer> sto = getPropertySet().getProperty(PropertyKey.socketTimeout);
    return ((Integer)sto.getValue()).intValue();
  }
  
  public void checkForCharsetMismatch()
  {
    ((NativeProtocol)protocol).checkForCharsetMismatch();
  }
  
  public NativePacketPayload getSharedSendPacket()
  {
    return ((NativeProtocol)protocol).getSharedSendPacket();
  }
  
  public void dumpPacketRingBuffer()
  {
    ((NativeProtocol)protocol).dumpPacketRingBuffer();
  }
  
  public <T extends Resultset> T invokeQueryInterceptorsPre(Supplier<String> sql, Query interceptedQuery, boolean forceExecute)
  {
    return ((NativeProtocol)protocol).invokeQueryInterceptorsPre(sql, interceptedQuery, forceExecute);
  }
  
  public <T extends Resultset> T invokeQueryInterceptorsPost(Supplier<String> sql, Query interceptedQuery, T originalResultSet, boolean forceExecute)
  {
    return ((NativeProtocol)protocol).invokeQueryInterceptorsPost(sql, interceptedQuery, originalResultSet, forceExecute);
  }
  
  public boolean shouldIntercept()
  {
    return ((NativeProtocol)protocol).getQueryInterceptors() != null;
  }
  
  public long getCurrentTimeNanosOrMillis()
  {
    return ((NativeProtocol)protocol).getCurrentTimeNanosOrMillis();
  }
  
  public final NativePacketPayload sendCommand(NativePacketPayload queryPacket, boolean skipCheck, int timeoutMillis)
  {
    return (NativePacketPayload)protocol.sendCommand(queryPacket, skipCheck, timeoutMillis);
  }
  
  public long getSlowQueryThreshold()
  {
    return ((NativeProtocol)protocol).getSlowQueryThreshold();
  }
  
  public boolean hadWarnings()
  {
    return ((NativeProtocol)protocol).hadWarnings();
  }
  
  public void clearInputStream()
  {
    ((NativeProtocol)protocol).clearInputStream();
  }
  
  public NetworkResources getNetworkResources()
  {
    return protocol.getSocketConnection().getNetworkResources();
  }
  
  public boolean isSSLEstablished()
  {
    return protocol.getSocketConnection().isSSLEstablished();
  }
  
  public int getCommandCount()
  {
    return ((NativeProtocol)protocol).getCommandCount();
  }
  
  public SocketAddress getRemoteSocketAddress()
  {
    try
    {
      return protocol.getSocketConnection().getMysqlSocket().getRemoteSocketAddress();
    }
    catch (IOException e)
    {
      throw new CJCommunicationsException(e);
    }
  }
  
  public InputStream getLocalInfileInputStream()
  {
    return protocol.getLocalInfileInputStream();
  }
  
  public void setLocalInfileInputStream(InputStream stream)
  {
    protocol.setLocalInfileInputStream(stream);
  }
  
  private void configureCharsetProperties()
  {
    if (characterEncoding.getValue() != null) {
      try
      {
        String testString = "abc";
        StringUtils.getBytes(testString, (String)characterEncoding.getValue());
      }
      catch (WrongArgumentException waEx)
      {
        String oldEncoding = (String)characterEncoding.getValue();
        
        characterEncoding.setValue(CharsetMapping.getJavaEncodingForMysqlCharset(oldEncoding));
        if (characterEncoding.getValue() == null) {
          throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Connection.5", new Object[] { oldEncoding }), 
            getExceptionInterceptor()));
        }
        String testString = "abc";
        StringUtils.getBytes(testString, (String)characterEncoding.getValue());
      }
    }
  }
  
  public boolean configureClientCharacterSet(boolean dontCheckServerMatch)
  {
    String realJavaEncoding = (String)characterEncoding.getValue();
    RuntimeProperty<String> characterSetResults = getPropertySet().getProperty(PropertyKey.characterSetResults);
    boolean characterSetAlreadyConfigured = false;
    try
    {
      characterSetAlreadyConfigured = true;
      
      configureCharsetProperties();
      realJavaEncoding = (String)characterEncoding.getValue();
      
      String connectionCollationSuffix = "";
      String connectionCollationCharset = null;
      
      String connectionCollation = getPropertySet().getStringProperty(PropertyKey.connectionCollation).getStringValue();
      if (connectionCollation != null) {
        for (int i = 1; i < CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME.length; i++) {
          if (CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME[i].equals(connectionCollation))
          {
            connectionCollationSuffix = " COLLATE " + CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME[i];
            connectionCollationCharset = COLLATION_INDEX_TO_CHARSETcharsetName;
            realJavaEncoding = CharsetMapping.getJavaEncodingForCollationIndex(Integer.valueOf(i));
          }
        }
      }
      try
      {
        serverEncodingToSet = CharsetMapping.getJavaEncodingForCollationIndex(Integer.valueOf(protocol.getServerSession().getServerDefaultCollationIndex()));
        if ((serverEncodingToSet == null) || (serverEncodingToSet.length() == 0)) {
          if (realJavaEncoding != null) {
            characterEncoding.setValue(realJavaEncoding);
          } else {
            throw ExceptionFactory.createException(
              Messages.getString("Connection.6", new Object[] {Integer.valueOf(protocol.getServerSession().getServerDefaultCollationIndex()) }), 
              getExceptionInterceptor());
          }
        }
        if ("ISO8859_1".equalsIgnoreCase(serverEncodingToSet)) {
          serverEncodingToSet = "Cp1252";
        }
        if (("UnicodeBig".equalsIgnoreCase(serverEncodingToSet)) || ("UTF-16".equalsIgnoreCase(serverEncodingToSet)) || 
          ("UTF-16LE".equalsIgnoreCase(serverEncodingToSet)) || ("UTF-32".equalsIgnoreCase(serverEncodingToSet))) {
          serverEncodingToSet = "UTF-8";
        }
      }
      catch (ArrayIndexOutOfBoundsException outOfBoundsEx)
      {
        String serverEncodingToSet;
        if (realJavaEncoding != null) {
          characterEncoding.setValue(realJavaEncoding);
        } else {
          throw ExceptionFactory.createException(
            Messages.getString("Connection.6", new Object[] {Integer.valueOf(protocol.getServerSession().getServerDefaultCollationIndex()) }), 
            getExceptionInterceptor());
        }
      }
      if (characterEncoding.getValue() == null) {
        characterEncoding.setValue("ISO8859_1");
      }
      if (realJavaEncoding != null)
      {
        if ((realJavaEncoding.equalsIgnoreCase("UTF-8")) || (realJavaEncoding.equalsIgnoreCase("UTF8")))
        {
          String utf8CharsetName = connectionCollationSuffix.length() > 0 ? connectionCollationCharset : "utf8mb4";
          if ((dontCheckServerMatch) || (!protocol.getServerSession().characterSetNamesMatches("utf8")) || 
            (!protocol.getServerSession().characterSetNamesMatches("utf8mb4")) || ((connectionCollationSuffix.length() > 0) && 
            (!connectionCollation.equalsIgnoreCase(protocol.getServerSession().getServerVariable("collation_server")))))
          {
            sendCommand(commandBuilder.buildComQuery(null, "SET NAMES " + utf8CharsetName + connectionCollationSuffix), false, 0);
            
            protocol.getServerSession().getServerVariables().put("character_set_client", utf8CharsetName);
            protocol.getServerSession().getServerVariables().put("character_set_connection", utf8CharsetName);
          }
          characterEncoding.setValue(realJavaEncoding);
        }
        else
        {
          String mysqlCharsetName = connectionCollationSuffix.length() > 0 ? connectionCollationCharset : CharsetMapping.getMysqlCharsetForJavaEncoding(realJavaEncoding.toUpperCase(Locale.ENGLISH), 
            getServerSession().getServerVersion());
          if (mysqlCharsetName != null) {
            if ((dontCheckServerMatch) || (!protocol.getServerSession().characterSetNamesMatches(mysqlCharsetName)))
            {
              sendCommand(commandBuilder.buildComQuery(null, "SET NAMES " + mysqlCharsetName + connectionCollationSuffix), false, 0);
              
              protocol.getServerSession().getServerVariables().put("character_set_client", mysqlCharsetName);
              protocol.getServerSession().getServerVariables().put("character_set_connection", mysqlCharsetName);
            }
          }
          characterEncoding.setValue(realJavaEncoding);
        }
      }
      else if (characterEncoding.getValue() != null)
      {
        String mysqlCharsetName = connectionCollationSuffix.length() > 0 ? connectionCollationCharset : getServerSession().getServerDefaultCharset();
        
        boolean ucs2 = false;
        if (("ucs2".equalsIgnoreCase(mysqlCharsetName)) || ("utf16".equalsIgnoreCase(mysqlCharsetName)) || ("utf16le".equalsIgnoreCase(mysqlCharsetName)) || 
          ("utf32".equalsIgnoreCase(mysqlCharsetName)))
        {
          mysqlCharsetName = "utf8";
          ucs2 = true;
          if (characterSetResults.getValue() == null) {
            characterSetResults.setValue("UTF-8");
          }
        }
        if ((dontCheckServerMatch) || (!protocol.getServerSession().characterSetNamesMatches(mysqlCharsetName)) || (ucs2)) {
          try
          {
            sendCommand(commandBuilder.buildComQuery(null, "SET NAMES " + mysqlCharsetName + connectionCollationSuffix), false, 0);
            
            protocol.getServerSession().getServerVariables().put("character_set_client", mysqlCharsetName);
            protocol.getServerSession().getServerVariables().put("character_set_connection", mysqlCharsetName);
          }
          catch (PasswordExpiredException ex)
          {
            if (((Boolean)disconnectOnExpiredPasswords.getValue()).booleanValue()) {
              throw ex;
            }
          }
        }
        realJavaEncoding = (String)characterEncoding.getValue();
      }
      String onServer = protocol.getServerSession().getServerVariable("character_set_results");
      if (characterSetResults.getValue() == null)
      {
        if ((onServer != null) && (onServer.length() > 0) && (!"NULL".equalsIgnoreCase(onServer)))
        {
          try
          {
            sendCommand(commandBuilder.buildComQuery(null, "SET character_set_results = NULL"), false, 0);
          }
          catch (PasswordExpiredException ex)
          {
            if (((Boolean)disconnectOnExpiredPasswords.getValue()).booleanValue()) {
              throw ex;
            }
          }
          protocol.getServerSession().getServerVariables().put("local.character_set_results", null);
        }
        else
        {
          protocol.getServerSession().getServerVariables().put("local.character_set_results", onServer);
        }
      }
      else
      {
        String charsetResults = (String)characterSetResults.getValue();
        String mysqlEncodingName = null;
        if (("UTF-8".equalsIgnoreCase(charsetResults)) || ("UTF8".equalsIgnoreCase(charsetResults))) {
          mysqlEncodingName = "utf8";
        } else if ("null".equalsIgnoreCase(charsetResults)) {
          mysqlEncodingName = "NULL";
        } else {
          mysqlEncodingName = CharsetMapping.getMysqlCharsetForJavaEncoding(charsetResults.toUpperCase(Locale.ENGLISH), 
            getServerSession().getServerVersion());
        }
        if (mysqlEncodingName == null) {
          throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Connection.7", new Object[] { charsetResults }), 
            getExceptionInterceptor()));
        }
        if (!mysqlEncodingName.equalsIgnoreCase(protocol.getServerSession().getServerVariable("character_set_results")))
        {
          StringBuilder setBuf = new StringBuilder("SET character_set_results = ".length() + mysqlEncodingName.length());
          setBuf.append("SET character_set_results = ").append(mysqlEncodingName);
          try
          {
            sendCommand(commandBuilder.buildComQuery(null, setBuf.toString()), false, 0);
          }
          catch (PasswordExpiredException ex)
          {
            if (((Boolean)disconnectOnExpiredPasswords.getValue()).booleanValue()) {
              throw ex;
            }
          }
          protocol.getServerSession().getServerVariables().put("local.character_set_results", mysqlEncodingName);
          
          protocol.getServerSession().setErrorMessageEncoding(charsetResults);
        }
        else
        {
          protocol.getServerSession().getServerVariables().put("local.character_set_results", onServer);
        }
      }
    }
    finally
    {
      characterEncoding.setValue(realJavaEncoding);
    }
    try
    {
      CharsetEncoder enc = Charset.forName((String)characterEncoding.getValue()).newEncoder();
      CharBuffer cbuf = CharBuffer.allocate(1);
      ByteBuffer bbuf = ByteBuffer.allocate(1);
      
      cbuf.put("¥");
      cbuf.position(0);
      enc.encode(cbuf, bbuf, true);
      if (bbuf.get(0) == 92)
      {
        requiresEscapingEncoder = true;
      }
      else
      {
        cbuf.clear();
        bbuf.clear();
        
        cbuf.put("?");
        cbuf.position(0);
        enc.encode(cbuf, bbuf, true);
        if (bbuf.get(0) == 92) {
          requiresEscapingEncoder = true;
        }
      }
    }
    catch (UnsupportedCharsetException ucex)
    {
      byte[] bbuf = StringUtils.getBytes("¥", (String)characterEncoding.getValue());
      if (bbuf[0] == 92)
      {
        requiresEscapingEncoder = true;
      }
      else
      {
        bbuf = StringUtils.getBytes("?", (String)characterEncoding.getValue());
        if (bbuf[0] == 92) {
          requiresEscapingEncoder = true;
        }
      }
    }
    return characterSetAlreadyConfigured;
  }
  
  public boolean getRequiresEscapingEncoder()
  {
    return requiresEscapingEncoder;
  }
  
  private void createConfigCacheIfNeeded(Object syncMutex)
  {
    synchronized (syncMutex)
    {
      if (serverConfigCache != null) {
        return;
      }
      try
      {
        Class<?> factoryClass = Class.forName(getPropertySet().getStringProperty(PropertyKey.serverConfigCacheFactory).getStringValue());
        
        CacheAdapterFactory<String, Map<String, String>> cacheFactory = (CacheAdapterFactory)factoryClass.newInstance();
        
        serverConfigCache = cacheFactory.getInstance(syncMutex, hostInfo.getDatabaseUrl(), Integer.MAX_VALUE, Integer.MAX_VALUE);
        
        ExceptionInterceptor evictOnCommsError = new ExceptionInterceptor()
        {
          public ExceptionInterceptor init(Properties config, Log log1)
          {
            return this;
          }
          
          public void destroy() {}
          
          public Exception interceptException(Exception sqlEx)
          {
            if (((sqlEx instanceof SQLException)) && (((SQLException)sqlEx).getSQLState() != null) && 
              (((SQLException)sqlEx).getSQLState().startsWith("08"))) {
              serverConfigCache.invalidate(hostInfo.getDatabaseUrl());
            }
            return null;
          }
        };
        if (exceptionInterceptor == null) {
          exceptionInterceptor = evictOnCommsError;
        } else {
          ((ExceptionInterceptorChain)exceptionInterceptor).addRingZero(evictOnCommsError);
        }
      }
      catch (ClassNotFoundException e)
      {
        throw ExceptionFactory.createException(Messages.getString("Connection.CantFindCacheFactory", new Object[] {
          getPropertySet().getStringProperty(PropertyKey.parseInfoCacheFactory).getValue(), PropertyKey.parseInfoCacheFactory }), e, 
          getExceptionInterceptor());
      }
      catch (InstantiationException|IllegalAccessException|CJException e)
      {
        throw ExceptionFactory.createException(Messages.getString("Connection.CantLoadCacheFactory", new Object[] {
          getPropertySet().getStringProperty(PropertyKey.parseInfoCacheFactory).getValue(), PropertyKey.parseInfoCacheFactory }), e, 
          getExceptionInterceptor());
      }
    }
  }
  
  public void loadServerVariables(Object syncMutex, String version)
  {
    if (((Boolean)cacheServerConfiguration.getValue()).booleanValue())
    {
      createConfigCacheIfNeeded(syncMutex);
      
      Map<String, String> cachedVariableMap = (Map)serverConfigCache.get(hostInfo.getDatabaseUrl());
      if (cachedVariableMap != null)
      {
        String cachedServerVersion = (String)cachedVariableMap.get("server_version_string");
        if ((cachedServerVersion != null) && (getServerSession().getServerVersion() != null) && 
          (cachedServerVersion.equals(getServerSession().getServerVersion().toString())))
        {
          protocol.getServerSession().setServerVariables(cachedVariableMap);
          
          return;
        }
        serverConfigCache.invalidate(hostInfo.getDatabaseUrl());
      }
    }
    try
    {
      if ((version != null) && (version.indexOf('*') != -1))
      {
        StringBuilder buf = new StringBuilder(version.length() + 10);
        for (int i = 0; i < version.length(); i++)
        {
          char c = version.charAt(i);
          buf.append(c == '*' ? "[star]" : Character.valueOf(c));
        }
        version = buf.toString();
      }
      String versionComment = "/* " + version + " */";
      
      protocol.getServerSession().setServerVariables(new HashMap());
      if (versionMeetsMinimum(5, 1, 0))
      {
        StringBuilder queryBuf = new StringBuilder(versionComment).append("SELECT");
        queryBuf.append("  @@session.auto_increment_increment AS auto_increment_increment");
        queryBuf.append(", @@character_set_client AS character_set_client");
        queryBuf.append(", @@character_set_connection AS character_set_connection");
        queryBuf.append(", @@character_set_results AS character_set_results");
        queryBuf.append(", @@character_set_server AS character_set_server");
        queryBuf.append(", @@collation_server AS collation_server");
        queryBuf.append(", @@collation_connection AS collation_connection");
        queryBuf.append(", @@init_connect AS init_connect");
        queryBuf.append(", @@interactive_timeout AS interactive_timeout");
        if (!versionMeetsMinimum(5, 5, 0)) {
          queryBuf.append(", @@language AS language");
        }
        queryBuf.append(", @@license AS license");
        queryBuf.append(", @@lower_case_table_names AS lower_case_table_names");
        queryBuf.append(", @@max_allowed_packet AS max_allowed_packet");
        queryBuf.append(", @@net_write_timeout AS net_write_timeout");
        queryBuf.append(", @@performance_schema AS performance_schema");
        if (!versionMeetsMinimum(8, 0, 3))
        {
          queryBuf.append(", @@query_cache_size AS query_cache_size");
          queryBuf.append(", @@query_cache_type AS query_cache_type");
        }
        queryBuf.append(", @@sql_mode AS sql_mode");
        queryBuf.append(", @@system_time_zone AS system_time_zone");
        queryBuf.append(", @@time_zone AS time_zone");
        if ((versionMeetsMinimum(8, 0, 3)) || ((versionMeetsMinimum(5, 7, 20)) && (!versionMeetsMinimum(8, 0, 0)))) {
          queryBuf.append(", @@transaction_isolation AS transaction_isolation");
        } else {
          queryBuf.append(", @@tx_isolation AS transaction_isolation");
        }
        queryBuf.append(", @@wait_timeout AS wait_timeout");
        
        NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(null, queryBuf.toString()), false, 0);
        Resultset rs = ((NativeProtocol)protocol).readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
        
        Field[] f = rs.getColumnDefinition().getFields();
        if (f.length > 0)
        {
          ValueFactory<String> vf = new StringValueFactory(propertySet);
          Row r;
          if ((r = (Row)rs.getRows().next()) != null) {
            for (int i = 0; i < f.length; i++) {
              protocol.getServerSession().getServerVariables().put(f[i].getColumnLabel(), r.getValue(i, vf));
            }
          }
        }
      }
      else
      {
        NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(null, versionComment + "SHOW VARIABLES"), false, 0);
        Resultset rs = ((NativeProtocol)protocol).readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
        
        ValueFactory<String> vf = new StringValueFactory(propertySet);
        Row r;
        while ((r = (Row)rs.getRows().next()) != null) {
          protocol.getServerSession().getServerVariables().put(r.getValue(0, vf), r.getValue(1, vf));
        }
      }
    }
    catch (PasswordExpiredException ex)
    {
      if (((Boolean)disconnectOnExpiredPasswords.getValue()).booleanValue()) {
        throw ex;
      }
    }
    catch (IOException e)
    {
      throw ExceptionFactory.createException(e.getMessage(), e);
    }
    if (((Boolean)cacheServerConfiguration.getValue()).booleanValue())
    {
      protocol.getServerSession().getServerVariables().put("server_version_string", getServerSession().getServerVersion().toString());
      serverConfigCache.put(hostInfo.getDatabaseUrl(), protocol.getServerSession().getServerVariables());
    }
  }
  
  public void setSessionVariables()
  {
    String sessionVariables = (String)getPropertySet().getStringProperty(PropertyKey.sessionVariables).getValue();
    if (sessionVariables != null)
    {
      List<String> variablesToSet = new ArrayList();
      for (String part : StringUtils.split(sessionVariables, ",", "\"'(", "\"')", "\"'", true)) {
        variablesToSet.addAll(StringUtils.split(part, ";", "\"'(", "\"')", "\"'", true));
      }
      if (!variablesToSet.isEmpty())
      {
        StringBuilder query = new StringBuilder("SET ");
        String separator = "";
        for (String variableToSet : variablesToSet) {
          if (variableToSet.length() > 0)
          {
            query.append(separator);
            if (!variableToSet.startsWith("@")) {
              query.append("SESSION ");
            }
            query.append(variableToSet);
            separator = ",";
          }
        }
        sendCommand(commandBuilder.buildComQuery(null, query.toString()), false, 0);
      }
    }
  }
  
  public void buildCollationMapping()
  {
    Map<Integer, String> customCharset = null;
    Map<String, Integer> customMblen = null;
    
    String databaseURL = hostInfo.getDatabaseUrl();
    if (((Boolean)cacheServerConfiguration.getValue()).booleanValue()) {
      synchronized (customIndexToCharsetMapByUrl)
      {
        customCharset = (Map)customIndexToCharsetMapByUrl.get(databaseURL);
        customMblen = (Map)customCharsetToMblenMapByUrl.get(databaseURL);
      }
    }
    if ((customCharset == null) && (((Boolean)getPropertySet().getBooleanProperty(PropertyKey.detectCustomCollations).getValue()).booleanValue()))
    {
      customCharset = new HashMap();
      customMblen = new HashMap();
      
      ValueFactory<Integer> ivf = new IntegerValueFactory(getPropertySet());
      try
      {
        NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(null, "SHOW COLLATION"), false, 0);
        Resultset rs = ((NativeProtocol)protocol).readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
        
        ValueFactory<String> svf = new StringValueFactory(propertySet);
        Row r;
        while ((r = (Row)rs.getRows().next()) != null)
        {
          int collationIndex = ((Number)r.getValue(2, ivf)).intValue();
          String charsetName = (String)r.getValue(1, svf);
          if ((collationIndex >= 2048) || (!charsetName.equals(CharsetMapping.getMysqlCharsetNameForCollationIndex(Integer.valueOf(collationIndex))))) {
            customCharset.put(Integer.valueOf(collationIndex), charsetName);
          }
          if (!CharsetMapping.CHARSET_NAME_TO_CHARSET.containsKey(charsetName)) {
            customMblen.put(charsetName, null);
          }
        }
      }
      catch (PasswordExpiredException ex)
      {
        if (((Boolean)disconnectOnExpiredPasswords.getValue()).booleanValue()) {
          throw ex;
        }
      }
      catch (IOException e)
      {
        throw ExceptionFactory.createException(e.getMessage(), e, exceptionInterceptor);
      }
      if (customMblen.size() > 0) {
        try
        {
          NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(null, "SHOW CHARACTER SET"), false, 0);
          Resultset rs = ((NativeProtocol)protocol).readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
          
          int charsetColumn = ((Integer)rs.getColumnDefinition().getColumnNameToIndex().get("Charset")).intValue();
          int maxlenColumn = ((Integer)rs.getColumnDefinition().getColumnNameToIndex().get("Maxlen")).intValue();
          
          ValueFactory<String> svf = new StringValueFactory(propertySet);
          Row r;
          while ((r = (Row)rs.getRows().next()) != null)
          {
            String charsetName = (String)r.getValue(charsetColumn, svf);
            if (customMblen.containsKey(charsetName)) {
              customMblen.put(charsetName, r.getValue(maxlenColumn, ivf));
            }
          }
        }
        catch (PasswordExpiredException ex)
        {
          if (((Boolean)disconnectOnExpiredPasswords.getValue()).booleanValue()) {
            throw ex;
          }
        }
        catch (IOException e)
        {
          throw ExceptionFactory.createException(e.getMessage(), e, exceptionInterceptor);
        }
      }
      if (((Boolean)cacheServerConfiguration.getValue()).booleanValue()) {
        synchronized (customIndexToCharsetMapByUrl)
        {
          customIndexToCharsetMapByUrl.put(databaseURL, customCharset);
          customCharsetToMblenMapByUrl.put(databaseURL, customMblen);
        }
      }
    }
    if (customCharset != null) {
      protocol.getServerSession()).indexToCustomMysqlCharset = Collections.unmodifiableMap(customCharset);
    }
    if (customMblen != null) {
      protocol.getServerSession()).mysqlCharsetToCustomMblen = Collections.unmodifiableMap(customMblen);
    }
    if (protocol.getServerSession().getServerDefaultCollationIndex() == 0)
    {
      String collationServer = protocol.getServerSession().getServerVariable("collation_server");
      if (collationServer != null) {
        for (int i = 1; i < CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME.length; i++) {
          if (CharsetMapping.COLLATION_INDEX_TO_COLLATION_NAME[i].equals(collationServer))
          {
            protocol.getServerSession().setServerDefaultCollationIndex(i);
            break;
          }
        }
      } else {
        protocol.getServerSession().setServerDefaultCollationIndex(45);
      }
    }
  }
  
  public String getProcessHost()
  {
    try
    {
      long threadId = getThreadId();
      String processHost = findProcessHost(threadId);
      if (processHost == null)
      {
        log.logWarn(String.format("Connection id %d not found in \"SHOW PROCESSLIST\", assuming 32-bit overflow, using SELECT CONNECTION_ID() instead", new Object[] {
          Long.valueOf(threadId) }));
        
        NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(null, "SELECT CONNECTION_ID()"), false, 0);
        Resultset rs = ((NativeProtocol)protocol).readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
        
        ValueFactory<Long> lvf = new LongValueFactory(getPropertySet());
        Row r;
        if ((r = (Row)rs.getRows().next()) != null)
        {
          threadId = ((Long)r.getValue(0, lvf)).longValue();
          processHost = findProcessHost(threadId);
        }
        else
        {
          log.logError("No rows returned for statement \"SELECT CONNECTION_ID()\", local connection check will most likely be incorrect");
        }
      }
      if (processHost == null) {
        log.logWarn(String.format("Cannot find process listing for connection %d in SHOW PROCESSLIST output, unable to determine if locally connected", new Object[] {
          Long.valueOf(threadId) }));
      }
      return processHost;
    }
    catch (IOException e)
    {
      throw ExceptionFactory.createException(e.getMessage(), e);
    }
  }
  
  private String findProcessHost(long threadId)
  {
    try
    {
      String processHost = null;
      
      String ps = protocol.getServerSession().getServerVariable("performance_schema");
      
      NativePacketPayload resultPacket = (versionMeetsMinimum(5, 6, 0)) && (ps != null) && (("1".contentEquals(ps)) || ("ON".contentEquals(ps))) ? sendCommand(commandBuilder.buildComQuery(null, "select PROCESSLIST_ID, PROCESSLIST_USER, PROCESSLIST_HOST from performance_schema.threads where PROCESSLIST_ID=" + threadId), false, 0) : sendCommand(commandBuilder.buildComQuery(null, "SHOW PROCESSLIST"), false, 0);
      
      Resultset rs = ((NativeProtocol)protocol).readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
      
      ValueFactory<Long> lvf = new LongValueFactory(getPropertySet());
      ValueFactory<String> svf = new StringValueFactory(propertySet);
      Row r;
      while ((r = (Row)rs.getRows().next()) != null)
      {
        long id = ((Long)r.getValue(0, lvf)).longValue();
        if (threadId == id)
        {
          processHost = (String)r.getValue(2, svf);
          break;
        }
      }
      return processHost;
    }
    catch (IOException e)
    {
      throw ExceptionFactory.createException(e.getMessage(), e);
    }
  }
  
  public String queryServerVariable(String varName)
  {
    try
    {
      NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(null, "SELECT " + varName), false, 0);
      Resultset rs = ((NativeProtocol)protocol).readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
      
      ValueFactory<String> svf = new StringValueFactory(propertySet);
      Row r;
      if ((r = (Row)rs.getRows().next()) != null)
      {
        String s = (String)r.getValue(0, svf);
        if (s != null) {
          return s;
        }
      }
      return null;
    }
    catch (IOException e)
    {
      throw ExceptionFactory.createException(e.getMessage(), e);
    }
  }
  
  public <T extends Resultset> T execSQL(Query callingQuery, String query, int maxRows, NativePacketPayload packet, boolean streamResults, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory, ColumnDefinition cachedMetadata, boolean isBatch)
  {
    long queryStartTime = ((Boolean)gatherPerfMetrics.getValue()).booleanValue() ? System.currentTimeMillis() : 0L;
    int endOfQueryPacketPosition = packet != null ? packet.getPosition() : 0;
    
    lastQueryFinishedTime = 0L;
    if ((((Boolean)autoReconnect.getValue()).booleanValue()) && ((getServerSession().isAutoCommit()) || (((Boolean)autoReconnectForPools.getValue()).booleanValue())) && (needsPing) && (!isBatch)) {
      try
      {
        ping(false, 0);
        needsPing = false;
      }
      catch (Exception Ex)
      {
        invokeReconnectListeners();
      }
    }
    try
    {
      return packet == null ? ((NativeProtocol)protocol)
        .sendQueryString(callingQuery, query, (String)characterEncoding.getValue(), maxRows, streamResults, cachedMetadata, resultSetFactory) : ((NativeProtocol)protocol)
        
        .sendQueryPacket(callingQuery, packet, maxRows, streamResults, cachedMetadata, resultSetFactory);
    }
    catch (CJException sqlE)
    {
      if (((Boolean)getPropertySet().getBooleanProperty(PropertyKey.dumpQueriesOnException).getValue()).booleanValue())
      {
        String extractedSql = NativePacketPayload.extractSqlFromPacket(query, packet, endOfQueryPacketPosition, 
          ((Integer)getPropertySet().getIntegerProperty(PropertyKey.maxQuerySizeToLog).getValue()).intValue());
        StringBuilder messageBuf = new StringBuilder(extractedSql.length() + 32);
        messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
        messageBuf.append(extractedSql);
        messageBuf.append("\n\n");
        sqlE.appendMessage(messageBuf.toString());
      }
      if (((Boolean)autoReconnect.getValue()).booleanValue())
      {
        if ((sqlE instanceof CJCommunicationsException)) {
          protocol.getSocketConnection().forceClose();
        }
        needsPing = true;
      }
      else if ((sqlE instanceof CJCommunicationsException))
      {
        invokeCleanupListeners(sqlE);
      }
      throw sqlE;
    }
    catch (Throwable ex)
    {
      if (((Boolean)autoReconnect.getValue()).booleanValue())
      {
        if ((ex instanceof IOException)) {
          protocol.getSocketConnection().forceClose();
        } else if ((ex instanceof IOException)) {
          invokeCleanupListeners(ex);
        }
        needsPing = true;
      }
      throw ExceptionFactory.createException(ex.getMessage(), ex, exceptionInterceptor);
    }
    finally
    {
      if (((Boolean)maintainTimeStats.getValue()).booleanValue()) {
        lastQueryFinishedTime = System.currentTimeMillis();
      }
      if (((Boolean)gatherPerfMetrics.getValue()).booleanValue()) {
        ((NativeProtocol)protocol).getMetricsHolder().registerQueryExecutionTime(System.currentTimeMillis() - queryStartTime);
      }
    }
  }
  
  public long getIdleFor()
  {
    return lastQueryFinishedTime == 0L ? 0L : System.currentTimeMillis() - lastQueryFinishedTime;
  }
  
  public boolean isNeedsPing()
  {
    return needsPing;
  }
  
  public void setNeedsPing(boolean needsPing)
  {
    this.needsPing = needsPing;
  }
  
  public void ping(boolean checkForClosedConnection, int timeoutMillis)
  {
    if (checkForClosedConnection) {
      checkClosed();
    }
    long pingMillisLifetime = ((Integer)getPropertySet().getIntegerProperty(PropertyKey.selfDestructOnPingSecondsLifetime).getValue()).intValue();
    int pingMaxOperations = ((Integer)getPropertySet().getIntegerProperty(PropertyKey.selfDestructOnPingMaxOperations).getValue()).intValue();
    if (((pingMillisLifetime > 0L) && (System.currentTimeMillis() - connectionCreationTimeMillis > pingMillisLifetime)) || ((pingMaxOperations > 0) && 
      (pingMaxOperations <= getCommandCount())))
    {
      invokeNormalCloseListeners();
      
      throw ExceptionFactory.createException(Messages.getString("Connection.exceededConnectionLifetime"), "08S01", 0, false, null, exceptionInterceptor);
    }
    sendCommand(commandBuilder.buildComPing(null), false, timeoutMillis);
  }
  
  public long getConnectionCreationTimeMillis()
  {
    return connectionCreationTimeMillis;
  }
  
  public void setConnectionCreationTimeMillis(long connectionCreationTimeMillis)
  {
    this.connectionCreationTimeMillis = connectionCreationTimeMillis;
  }
  
  public boolean isClosed()
  {
    return isClosed;
  }
  
  public void checkClosed()
  {
    if (isClosed)
    {
      if ((forceClosedReason != null) && (forceClosedReason.getClass().equals(OperationCancelledException.class))) {
        throw ((OperationCancelledException)forceClosedReason);
      }
      throw ((ConnectionIsClosedException)ExceptionFactory.createException(ConnectionIsClosedException.class, Messages.getString("Connection.2"), forceClosedReason, 
        getExceptionInterceptor()));
    }
  }
  
  public Throwable getForceClosedReason()
  {
    return forceClosedReason;
  }
  
  public void setForceClosedReason(Throwable forceClosedReason)
  {
    this.forceClosedReason = forceClosedReason;
  }
  
  public void addListener(Session.SessionEventListener l)
  {
    listeners.addIfAbsent(new WeakReference(l));
  }
  
  public void removeListener(Session.SessionEventListener listener)
  {
    for (WeakReference<Session.SessionEventListener> wr : listeners)
    {
      Session.SessionEventListener l = (Session.SessionEventListener)wr.get();
      if (l == listener)
      {
        listeners.remove(wr);
        break;
      }
    }
  }
  
  protected void invokeNormalCloseListeners()
  {
    for (WeakReference<Session.SessionEventListener> wr : listeners)
    {
      Session.SessionEventListener l = (Session.SessionEventListener)wr.get();
      if (l != null) {
        l.handleNormalClose();
      } else {
        listeners.remove(wr);
      }
    }
  }
  
  protected void invokeReconnectListeners()
  {
    for (WeakReference<Session.SessionEventListener> wr : listeners)
    {
      Session.SessionEventListener l = (Session.SessionEventListener)wr.get();
      if (l != null) {
        l.handleReconnect();
      } else {
        listeners.remove(wr);
      }
    }
  }
  
  public void invokeCleanupListeners(Throwable whyCleanedUp)
  {
    for (WeakReference<Session.SessionEventListener> wr : listeners)
    {
      Session.SessionEventListener l = (Session.SessionEventListener)wr.get();
      if (l != null) {
        l.handleCleanup(whyCleanedUp);
      } else {
        listeners.remove(wr);
      }
    }
  }
  
  public String getIdentifierQuoteString()
  {
    return (protocol != null) && (protocol.getServerSession().useAnsiQuotedIdentifiers()) ? "\"" : "`";
  }
  
  public synchronized Timer getCancelTimer()
  {
    if (cancelTimer == null) {
      cancelTimer = new Timer("MySQL Statement Cancellation Timer", Boolean.TRUE.booleanValue());
    }
    return cancelTimer;
  }
  
  public <M extends Message, RES_T, R> RES_T query(M message, Predicate<Row> filterRow, Function<Row, R> mapRow, Collector<R, ?, RES_T> collector)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.NativeSession
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */