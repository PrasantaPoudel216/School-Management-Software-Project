package com.mysql.cj.result;

import com.mysql.cj.Messages;
import com.mysql.cj.WarningListener;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.DataReadException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.InternalDate;
import com.mysql.cj.protocol.InternalTime;
import com.mysql.cj.protocol.InternalTimestamp;
import java.sql.Date;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class SqlDateValueFactory
  extends AbstractDateTimeValueFactory<Date>
{
  private WarningListener warningListener;
  private Calendar cal;
  
  public SqlDateValueFactory(PropertySet pset, Calendar calendar, TimeZone tz)
  {
    super(pset);
    if (calendar != null)
    {
      cal = ((Calendar)calendar.clone());
    }
    else
    {
      cal = Calendar.getInstance(tz, Locale.US);
      cal.set(14, 0);
      cal.setLenient(false);
    }
  }
  
  public SqlDateValueFactory(PropertySet pset, Calendar calendar, TimeZone tz, WarningListener warningListener)
  {
    this(pset, calendar, tz);
    this.warningListener = warningListener;
  }
  
  public Date localCreateFromDate(InternalDate idate)
  {
    synchronized (cal)
    {
      try
      {
        if (idate.isZero()) {
          throw new DataReadException(Messages.getString("ResultSet.InvalidZeroDate"));
        }
        cal.clear();
        cal.set(idate.getYear(), idate.getMonth() - 1, idate.getDay());
        long ms = cal.getTimeInMillis();
        return new Date(ms);
      }
      catch (IllegalArgumentException e)
      {
        throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e));
      }
    }
  }
  
  public Date localCreateFromTime(InternalTime it)
  {
    if (warningListener != null) {
      warningListener.warningEncountered(Messages.getString("ResultSet.ImplicitDatePartWarning", new Object[] { "java.sql.Date" }));
    }
    synchronized (cal)
    {
      try
      {
        Calendar c1 = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.US);
        c1.set(1970, 0, 1, it.getHours(), it.getMinutes(), it.getSeconds());
        c1.set(14, 0);
        long ms = it.getNanos() / 1000000 + c1.getTimeInMillis();
        return new Date(ms);
      }
      catch (IllegalArgumentException e)
      {
        throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e));
      }
    }
  }
  
  public Date localCreateFromTimestamp(InternalTimestamp its)
  {
    if (warningListener != null) {
      warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { "java.sql.Date" }));
    }
    return (Date)createFromDate(its);
  }
  
  public String getTargetTypeName()
  {
    return Date.class.getName();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.result.SqlDateValueFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */