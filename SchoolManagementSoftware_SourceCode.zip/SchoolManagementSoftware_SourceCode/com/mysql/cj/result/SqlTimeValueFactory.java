package com.mysql.cj.result;

import com.mysql.cj.Messages;
import com.mysql.cj.WarningListener;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.DataReadException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.InternalDate;
import com.mysql.cj.protocol.InternalTime;
import com.mysql.cj.protocol.InternalTimestamp;
import java.sql.Time;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class SqlTimeValueFactory
  extends AbstractDateTimeValueFactory<Time>
{
  private WarningListener warningListener;
  private Calendar cal;
  
  public SqlTimeValueFactory(PropertySet pset, Calendar calendar, TimeZone tz)
  {
    super(pset);
    if (calendar != null)
    {
      cal = ((Calendar)calendar.clone());
    }
    else
    {
      cal = Calendar.getInstance(tz, Locale.US);
      cal.setLenient(false);
    }
  }
  
  public SqlTimeValueFactory(PropertySet pset, Calendar calendar, TimeZone tz, WarningListener warningListener)
  {
    this(pset, calendar, tz);
    this.warningListener = warningListener;
  }
  
  Time localCreateFromDate(InternalDate idate)
  {
    return (Time)unsupported("DATE");
  }
  
  public Time localCreateFromTime(InternalTime it)
  {
    if ((it.getHours() < 0) || (it.getHours() >= 24)) {
      throw new DataReadException(Messages.getString("ResultSet.InvalidTimeValue", new Object[] {"" + it.getHours() + ":" + it.getMinutes() + ":" + it.getSeconds() }));
    }
    synchronized (cal)
    {
      try
      {
        cal.set(1970, 0, 1, it.getHours(), it.getMinutes(), it.getSeconds());
        cal.set(14, 0);
        long ms = it.getNanos() / 1000000 + cal.getTimeInMillis();
        return new Time(ms);
      }
      catch (IllegalArgumentException e)
      {
        throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, e.getMessage(), e));
      }
    }
  }
  
  public Time localCreateFromTimestamp(InternalTimestamp its)
  {
    if (warningListener != null) {
      warningListener.warningEncountered(Messages.getString("ResultSet.PrecisionLostWarning", new Object[] { "java.sql.Time" }));
    }
    return (Time)createFromTime(new InternalTime(its.getHours(), its.getMinutes(), its.getSeconds(), its.getNanos()));
  }
  
  public Time createFromYear(long year)
  {
    return (Time)unsupported("YEAR");
  }
  
  public String getTargetTypeName()
  {
    return Time.class.getName();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.result.SqlTimeValueFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */