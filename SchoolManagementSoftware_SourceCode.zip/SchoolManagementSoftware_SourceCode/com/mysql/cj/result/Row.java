package com.mysql.cj.result;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ProtocolEntity;

public abstract interface Row
  extends ProtocolEntity
{
  public abstract <T> T getValue(int paramInt, ValueFactory<T> paramValueFactory);
  
  public Row setMetadata(ColumnDefinition columnDefinition)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public byte[] getBytes(int columnIndex)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public void setBytes(int columnIndex, byte[] value)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public abstract boolean getNull(int paramInt);
  
  public abstract boolean wasNull();
}

/* Location:
 * Qualified Name:     com.mysql.cj.result.Row
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */