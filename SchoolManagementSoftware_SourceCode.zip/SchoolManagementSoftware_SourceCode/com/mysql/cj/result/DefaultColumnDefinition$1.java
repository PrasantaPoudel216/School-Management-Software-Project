package com.mysql.cj.result;

class DefaultColumnDefinition$1 {}

/* Location:
 * Qualified Name:     com.mysql.cj.result.DefaultColumnDefinition.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */