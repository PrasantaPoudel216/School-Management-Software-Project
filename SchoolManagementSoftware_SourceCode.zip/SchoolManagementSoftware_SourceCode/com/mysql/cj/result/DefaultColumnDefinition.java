package com.mysql.cj.result;

import com.mysql.cj.protocol.ColumnDefinition;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

public class DefaultColumnDefinition
  implements ColumnDefinition
{
  protected Field[] fields;
  private Map<String, Integer> columnLabelToIndex = null;
  private Map<String, Integer> columnToIndexCache = new HashMap();
  private Map<String, Integer> fullColumnNameToIndex = null;
  private Map<String, Integer> columnNameToIndex = null;
  private boolean builtIndexMapping = false;
  
  public DefaultColumnDefinition() {}
  
  public DefaultColumnDefinition(Field[] fields)
  {
    this.fields = fields;
  }
  
  public Field[] getFields()
  {
    return fields;
  }
  
  public void setFields(Field[] fields)
  {
    this.fields = fields;
  }
  
  public void buildIndexMapping()
  {
    int numFields = fields.length;
    columnLabelToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
    fullColumnNameToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
    columnNameToIndex = new TreeMap(String.CASE_INSENSITIVE_ORDER);
    for (int i = numFields - 1; i >= 0; i--)
    {
      Integer index = Integer.valueOf(i);
      String columnName = fields[i].getOriginalName();
      String columnLabel = fields[i].getName();
      String fullColumnName = fields[i].getFullName();
      if (columnLabel != null) {
        columnLabelToIndex.put(columnLabel, index);
      }
      if (fullColumnName != null) {
        fullColumnNameToIndex.put(fullColumnName, index);
      }
      if (columnName != null) {
        columnNameToIndex.put(columnName, index);
      }
    }
    builtIndexMapping = true;
  }
  
  public boolean hasBuiltIndexMapping()
  {
    return builtIndexMapping;
  }
  
  public Map<String, Integer> getColumnLabelToIndex()
  {
    return columnLabelToIndex;
  }
  
  public void setColumnLabelToIndex(Map<String, Integer> columnLabelToIndex)
  {
    this.columnLabelToIndex = columnLabelToIndex;
  }
  
  public Map<String, Integer> getFullColumnNameToIndex()
  {
    return fullColumnNameToIndex;
  }
  
  public void setFullColumnNameToIndex(Map<String, Integer> fullColNameToIndex)
  {
    fullColumnNameToIndex = fullColNameToIndex;
  }
  
  public Map<String, Integer> getColumnNameToIndex()
  {
    return columnNameToIndex;
  }
  
  public void setColumnNameToIndex(Map<String, Integer> colNameToIndex)
  {
    columnNameToIndex = colNameToIndex;
  }
  
  public Map<String, Integer> getColumnToIndexCache()
  {
    return columnToIndexCache;
  }
  
  public void setColumnToIndexCache(Map<String, Integer> columnToIndexCache)
  {
    this.columnToIndexCache = columnToIndexCache;
  }
  
  public void initializeFrom(ColumnDefinition columnDefinition)
  {
    fields = columnDefinition.getFields();
    columnLabelToIndex = columnDefinition.getColumnNameToIndex();
    fullColumnNameToIndex = columnDefinition.getFullColumnNameToIndex();
    builtIndexMapping = true;
  }
  
  public void exportTo(ColumnDefinition columnDefinition)
  {
    columnDefinition.setFields(fields);
    columnDefinition.setColumnNameToIndex(columnLabelToIndex);
    columnDefinition.setFullColumnNameToIndex(fullColumnNameToIndex);
  }
  
  public int findColumn(String columnName, boolean useColumnNamesInFindColumn, int indexBase)
  {
    if (!hasBuiltIndexMapping()) {
      buildIndexMapping();
    }
    Integer index = (Integer)columnToIndexCache.get(columnName);
    if (index != null) {
      return index.intValue() + indexBase;
    }
    index = (Integer)columnLabelToIndex.get(columnName);
    if ((index == null) && (useColumnNamesInFindColumn)) {
      index = (Integer)columnNameToIndex.get(columnName);
    }
    if (index == null) {
      index = (Integer)fullColumnNameToIndex.get(columnName);
    }
    if (index != null)
    {
      columnToIndexCache.put(columnName, index);
      
      return index.intValue() + indexBase;
    }
    for (int i = 0; i < fields.length; i++)
    {
      if (fields[i].getName().equalsIgnoreCase(columnName)) {
        return i + indexBase;
      }
      if (fields[i].getFullName().equalsIgnoreCase(columnName)) {
        return i + indexBase;
      }
    }
    return -1;
  }
  
  public boolean hasLargeFields()
  {
    if (fields != null) {
      for (int i = 0; i < fields.length; i++) {
        switch (fields[i].getMysqlType())
        {
        case BLOB: 
        case MEDIUMBLOB: 
        case LONGBLOB: 
        case TEXT: 
        case MEDIUMTEXT: 
        case LONGTEXT: 
        case JSON: 
          return true;
        }
      }
    }
    return false;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.result.DefaultColumnDefinition
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */