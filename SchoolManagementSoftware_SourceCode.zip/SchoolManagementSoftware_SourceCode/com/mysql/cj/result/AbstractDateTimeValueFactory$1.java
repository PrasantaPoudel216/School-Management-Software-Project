package com.mysql.cj.result;

class AbstractDateTimeValueFactory$1 {}

/* Location:
 * Qualified Name:     com.mysql.cj.result.AbstractDateTimeValueFactory.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */