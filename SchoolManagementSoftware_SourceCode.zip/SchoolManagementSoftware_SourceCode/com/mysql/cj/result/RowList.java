package com.mysql.cj.result;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import java.util.Iterator;

public abstract interface RowList
  extends Iterator<Row>
{
  public static final int RESULT_SET_SIZE_UNKNOWN = -1;
  
  public Row previous()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public Row get(int n)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public int getPosition()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public int size()
  {
    return -1;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.result.RowList
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */