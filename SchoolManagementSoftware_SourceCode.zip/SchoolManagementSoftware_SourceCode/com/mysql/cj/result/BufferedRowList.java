package com.mysql.cj.result;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Spliterators;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import java.util.stream.StreamSupport;

public class BufferedRowList
  implements RowList
{
  private List<Row> rowList;
  private int position = -1;
  
  public BufferedRowList(List<Row> rowList)
  {
    this.rowList = rowList;
  }
  
  public BufferedRowList(Iterator<Row> ris)
  {
    rowList = ((List)StreamSupport.stream(Spliterators.spliteratorUnknownSize(ris, 0), false).collect(Collectors.toList()));
  }
  
  public Row next()
  {
    if (position + 1 == rowList.size()) {
      throw new NoSuchElementException("Can't next() when position=" + position + " and size=" + rowList.size());
    }
    return (Row)rowList.get(++position);
  }
  
  public Row previous()
  {
    if (position < 1) {
      throw new NoSuchElementException("Can't previous() when position=" + position);
    }
    return (Row)rowList.get(--position);
  }
  
  public Row get(int n)
  {
    if ((n < 0) || (n >= rowList.size())) {
      throw new NoSuchElementException("Can't get(" + n + ") when size=" + rowList.size());
    }
    return (Row)rowList.get(n);
  }
  
  public int getPosition()
  {
    return position;
  }
  
  public int size()
  {
    return rowList.size();
  }
  
  public boolean hasNext()
  {
    return position + 1 < rowList.size();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.result.BufferedRowList
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */