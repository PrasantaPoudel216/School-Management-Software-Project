package com.mysql.cj.result;

import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.protocol.InternalDate;
import com.mysql.cj.protocol.InternalTime;
import com.mysql.cj.protocol.InternalTimestamp;
import java.math.BigDecimal;
import java.math.BigInteger;

public abstract interface ValueFactory<T>
{
  public abstract void setPropertySet(PropertySet paramPropertySet);
  
  public abstract T createFromDate(InternalDate paramInternalDate);
  
  public abstract T createFromTime(InternalTime paramInternalTime);
  
  public abstract T createFromTimestamp(InternalTimestamp paramInternalTimestamp);
  
  public abstract T createFromLong(long paramLong);
  
  public abstract T createFromBigInteger(BigInteger paramBigInteger);
  
  public abstract T createFromDouble(double paramDouble);
  
  public abstract T createFromBigDecimal(BigDecimal paramBigDecimal);
  
  public abstract T createFromBytes(byte[] paramArrayOfByte, int paramInt1, int paramInt2, Field paramField);
  
  public abstract T createFromBit(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
  
  public abstract T createFromYear(long paramLong);
  
  public abstract T createFromNull();
  
  public abstract String getTargetTypeName();
}

/* Location:
 * Qualified Name:     com.mysql.cj.result.ValueFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */