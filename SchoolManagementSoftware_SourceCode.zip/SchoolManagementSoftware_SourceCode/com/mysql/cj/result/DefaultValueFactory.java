package com.mysql.cj.result;

import com.mysql.cj.Messages;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.DataConversionException;
import com.mysql.cj.protocol.InternalDate;
import com.mysql.cj.protocol.InternalTime;
import com.mysql.cj.protocol.InternalTimestamp;
import java.math.BigDecimal;
import java.math.BigInteger;

public abstract class DefaultValueFactory<T>
  implements ValueFactory<T>
{
  protected boolean jdbcCompliantTruncationForReads = true;
  
  public DefaultValueFactory(PropertySet pset)
  {
    this.pset = pset;
    
    jdbcCompliantTruncationForReads = ((Boolean)this.pset.getBooleanProperty(PropertyKey.jdbcCompliantTruncation).getInitialValue()).booleanValue();
  }
  
  protected PropertySet pset = null;
  
  public void setPropertySet(PropertySet pset)
  {
    this.pset = pset;
  }
  
  protected T unsupported(String sourceType)
  {
    throw new DataConversionException(Messages.getString("ResultSet.UnsupportedConversion", new Object[] { sourceType, getTargetTypeName() }));
  }
  
  public T createFromDate(InternalDate idate)
  {
    return (T)unsupported("DATE");
  }
  
  public T createFromTime(InternalTime it)
  {
    return (T)unsupported("TIME");
  }
  
  public T createFromTimestamp(InternalTimestamp its)
  {
    return (T)unsupported("TIMESTAMP");
  }
  
  public T createFromLong(long l)
  {
    return (T)unsupported("LONG");
  }
  
  public T createFromBigInteger(BigInteger i)
  {
    return (T)unsupported("BIGINT");
  }
  
  public T createFromDouble(double d)
  {
    return (T)unsupported("DOUBLE");
  }
  
  public T createFromBigDecimal(BigDecimal d)
  {
    return (T)unsupported("DECIMAL");
  }
  
  public T createFromBit(byte[] bytes, int offset, int length)
  {
    return (T)unsupported("BIT");
  }
  
  public T createFromYear(long l)
  {
    return (T)unsupported("YEAR");
  }
  
  public T createFromNull()
  {
    return null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.result.DefaultValueFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */