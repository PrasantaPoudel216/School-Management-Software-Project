package com.mysql.cj;

import com.mysql.cj.protocol.Message;

public abstract interface PreparedQuery<T extends QueryBindings<?>>
  extends Query
{
  public abstract ParseInfo getParseInfo();
  
  public abstract void setParseInfo(ParseInfo paramParseInfo);
  
  public abstract void checkNullOrEmptyQuery(String paramString);
  
  public abstract String getOriginalSql();
  
  public abstract void setOriginalSql(String paramString);
  
  public abstract int getParameterCount();
  
  public abstract void setParameterCount(int paramInt);
  
  public abstract T getQueryBindings();
  
  public abstract void setQueryBindings(T paramT);
  
  public abstract int computeBatchSize(int paramInt);
  
  public abstract int getBatchCommandIndex();
  
  public abstract void setBatchCommandIndex(int paramInt);
  
  public abstract String asSql();
  
  public abstract String asSql(boolean paramBoolean);
  
  public abstract <M extends Message> M fillSendPacket();
  
  public abstract <M extends Message> M fillSendPacket(QueryBindings<?> paramQueryBindings);
}

/* Location:
 * Qualified Name:     com.mysql.cj.PreparedQuery
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */