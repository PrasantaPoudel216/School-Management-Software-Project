package com.mysql.cj;

public class ServerVersion
  implements Comparable<ServerVersion>
{
  private String completeVersion;
  private Integer major;
  private Integer minor;
  private Integer subminor;
  
  public ServerVersion(String completeVersion, int major, int minor, int subminor)
  {
    this.completeVersion = completeVersion;
    this.major = Integer.valueOf(major);
    this.minor = Integer.valueOf(minor);
    this.subminor = Integer.valueOf(subminor);
  }
  
  public ServerVersion(int major, int minor, int subminor)
  {
    this(null, major, minor, subminor);
  }
  
  public int getMajor()
  {
    return major.intValue();
  }
  
  public int getMinor()
  {
    return minor.intValue();
  }
  
  public int getSubminor()
  {
    return subminor.intValue();
  }
  
  public String toString()
  {
    if (completeVersion != null) {
      return completeVersion;
    }
    return String.format("%d.%d.%d", new Object[] { major, minor, subminor });
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj) {
      return true;
    }
    if ((obj == null) || (!ServerVersion.class.isAssignableFrom(obj.getClass()))) {
      return false;
    }
    ServerVersion another = (ServerVersion)obj;
    if ((getMajor() != another.getMajor()) || (getMinor() != another.getMinor()) || (getSubminor() != another.getSubminor())) {
      return false;
    }
    return true;
  }
  
  public int hashCode()
  {
    int hash = 23;
    hash += 19 * hash + major.intValue();
    hash += 19 * hash + minor.intValue();
    hash += 19 * hash + subminor.intValue();
    return hash;
  }
  
  public int compareTo(ServerVersion other)
  {
    int c;
    if ((c = major.compareTo(Integer.valueOf(other.getMajor()))) != 0) {
      return c;
    }
    if ((c = minor.compareTo(Integer.valueOf(other.getMinor()))) != 0) {
      return c;
    }
    return subminor.compareTo(Integer.valueOf(other.getSubminor()));
  }
  
  public boolean meetsMinimum(ServerVersion min)
  {
    return compareTo(min) >= 0;
  }
  
  public static ServerVersion parseVersion(String versionString)
  {
    int point = versionString.indexOf('.');
    if (point != -1) {
      try
      {
        int serverMajorVersion = Integer.parseInt(versionString.substring(0, point));
        
        String remaining = versionString.substring(point + 1, versionString.length());
        point = remaining.indexOf('.');
        if (point != -1)
        {
          int serverMinorVersion = Integer.parseInt(remaining.substring(0, point));
          
          remaining = remaining.substring(point + 1, remaining.length());
          
          int pos = 0;
          while ((pos < remaining.length()) && 
            (remaining.charAt(pos) >= '0') && (remaining.charAt(pos) <= '9')) {
            pos++;
          }
          int serverSubminorVersion = Integer.parseInt(remaining.substring(0, pos));
          
          return new ServerVersion(versionString, serverMajorVersion, serverMinorVersion, serverSubminorVersion);
        }
      }
      catch (NumberFormatException localNumberFormatException) {}
    }
    return new ServerVersion(0, 0, 0);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.ServerVersion
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */