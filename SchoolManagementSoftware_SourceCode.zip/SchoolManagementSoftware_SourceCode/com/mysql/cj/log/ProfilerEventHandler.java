package com.mysql.cj.log;

import com.mysql.cj.Query;
import com.mysql.cj.Session;
import com.mysql.cj.protocol.Resultset;

public abstract interface ProfilerEventHandler
{
  public abstract void init(Log paramLog);
  
  public abstract void destroy();
  
  public abstract void consumeEvent(ProfilerEvent paramProfilerEvent);
  
  public abstract void processEvent(byte paramByte, Session paramSession, Query paramQuery, Resultset paramResultset, long paramLong, Throwable paramThrowable, String paramString);
}

/* Location:
 * Qualified Name:     com.mysql.cj.log.ProfilerEventHandler
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */