package com.mysql.cj.log;

public class BaseMetricsHolder
{
  private static final int HISTOGRAM_BUCKETS = 20;
  private long longestQueryTimeMs = 0L;
  private long maximumNumberTablesAccessed = 0L;
  private long minimumNumberTablesAccessed = Long.MAX_VALUE;
  private long numberOfPreparedExecutes = 0L;
  private long numberOfPrepares = 0L;
  private long numberOfQueriesIssued = 0L;
  private long numberOfResultSetsCreated = 0L;
  private long[] numTablesMetricsHistBreakpoints;
  private int[] numTablesMetricsHistCounts;
  private long[] oldHistBreakpoints = null;
  private int[] oldHistCounts = null;
  private long shortestQueryTimeMs = Long.MAX_VALUE;
  private double totalQueryTimeMs = 0.0D;
  private long[] perfMetricsHistBreakpoints;
  private int[] perfMetricsHistCounts;
  private long queryTimeCount;
  private double queryTimeSum;
  private double queryTimeSumSquares;
  private double queryTimeMean;
  
  private void createInitialHistogram(long[] breakpoints, long lowerBound, long upperBound)
  {
    double bucketSize = (upperBound - lowerBound) / 20.0D * 1.25D;
    if (bucketSize < 1.0D) {
      bucketSize = 1.0D;
    }
    for (int i = 0; i < 20; i++)
    {
      breakpoints[i] = lowerBound;
      lowerBound = (lowerBound + bucketSize);
    }
  }
  
  private void addToHistogram(int[] histogramCounts, long[] histogramBreakpoints, long value, int numberOfTimes, long currentLowerBound, long currentUpperBound)
  {
    if (histogramCounts == null) {
      createInitialHistogram(histogramBreakpoints, currentLowerBound, currentUpperBound);
    } else {
      for (int i = 0; i < 20; i++) {
        if (histogramBreakpoints[i] >= value)
        {
          histogramCounts[i] += numberOfTimes;
          
          break;
        }
      }
    }
  }
  
  private void addToPerformanceHistogram(long value, int numberOfTimes)
  {
    checkAndCreatePerformanceHistogram();
    
    addToHistogram(perfMetricsHistCounts, perfMetricsHistBreakpoints, value, numberOfTimes, shortestQueryTimeMs == Long.MAX_VALUE ? 0L : shortestQueryTimeMs, longestQueryTimeMs);
  }
  
  private void addToTablesAccessedHistogram(long value, int numberOfTimes)
  {
    checkAndCreateTablesAccessedHistogram();
    
    addToHistogram(numTablesMetricsHistCounts, numTablesMetricsHistBreakpoints, value, numberOfTimes, minimumNumberTablesAccessed == Long.MAX_VALUE ? 0L : minimumNumberTablesAccessed, maximumNumberTablesAccessed);
  }
  
  private void checkAndCreatePerformanceHistogram()
  {
    if (perfMetricsHistCounts == null) {
      perfMetricsHistCounts = new int[20];
    }
    if (perfMetricsHistBreakpoints == null) {
      perfMetricsHistBreakpoints = new long[20];
    }
  }
  
  private void checkAndCreateTablesAccessedHistogram()
  {
    if (numTablesMetricsHistCounts == null) {
      numTablesMetricsHistCounts = new int[20];
    }
    if (numTablesMetricsHistBreakpoints == null) {
      numTablesMetricsHistBreakpoints = new long[20];
    }
  }
  
  public void registerQueryExecutionTime(long queryTimeMs)
  {
    if (queryTimeMs > longestQueryTimeMs)
    {
      longestQueryTimeMs = queryTimeMs;
      
      repartitionPerformanceHistogram();
    }
    addToPerformanceHistogram(queryTimeMs, 1);
    if (queryTimeMs < shortestQueryTimeMs) {
      shortestQueryTimeMs = (queryTimeMs == 0L ? 1L : queryTimeMs);
    }
    numberOfQueriesIssued += 1L;
    
    totalQueryTimeMs += queryTimeMs;
  }
  
  private void repartitionHistogram(int[] histCounts, long[] histBreakpoints, long currentLowerBound, long currentUpperBound)
  {
    if (oldHistCounts == null)
    {
      oldHistCounts = new int[histCounts.length];
      oldHistBreakpoints = new long[histBreakpoints.length];
    }
    System.arraycopy(histCounts, 0, oldHistCounts, 0, histCounts.length);
    
    System.arraycopy(histBreakpoints, 0, oldHistBreakpoints, 0, histBreakpoints.length);
    
    createInitialHistogram(histBreakpoints, currentLowerBound, currentUpperBound);
    for (int i = 0; i < 20; i++) {
      addToHistogram(histCounts, histBreakpoints, oldHistBreakpoints[i], oldHistCounts[i], currentLowerBound, currentUpperBound);
    }
  }
  
  private void repartitionPerformanceHistogram()
  {
    checkAndCreatePerformanceHistogram();
    
    repartitionHistogram(perfMetricsHistCounts, perfMetricsHistBreakpoints, shortestQueryTimeMs == Long.MAX_VALUE ? 0L : shortestQueryTimeMs, longestQueryTimeMs);
  }
  
  private void repartitionTablesAccessedHistogram()
  {
    checkAndCreateTablesAccessedHistogram();
    
    repartitionHistogram(numTablesMetricsHistCounts, numTablesMetricsHistBreakpoints, minimumNumberTablesAccessed == Long.MAX_VALUE ? 0L : minimumNumberTablesAccessed, maximumNumberTablesAccessed);
  }
  
  public void reportMetrics(Log log)
  {
    StringBuilder logMessage = new StringBuilder(256);
    
    logMessage.append("** Performance Metrics Report **\n");
    logMessage.append("\nLongest reported query: " + longestQueryTimeMs + " ms");
    logMessage.append("\nShortest reported query: " + shortestQueryTimeMs + " ms");
    logMessage.append("\nAverage query execution time: " + totalQueryTimeMs / numberOfQueriesIssued + " ms");
    logMessage.append("\nNumber of statements executed: " + numberOfQueriesIssued);
    logMessage.append("\nNumber of result sets created: " + numberOfResultSetsCreated);
    logMessage.append("\nNumber of statements prepared: " + numberOfPrepares);
    logMessage.append("\nNumber of prepared statement executions: " + numberOfPreparedExecutes);
    if (perfMetricsHistBreakpoints != null)
    {
      logMessage.append("\n\n\tTiming Histogram:\n");
      int maxNumPoints = 20;
      int highestCount = Integer.MIN_VALUE;
      for (int i = 0; i < 20; i++) {
        if (perfMetricsHistCounts[i] > highestCount) {
          highestCount = perfMetricsHistCounts[i];
        }
      }
      if (highestCount == 0) {
        highestCount = 1;
      }
      for (int i = 0; i < 19; i++)
      {
        if (i == 0) {
          logMessage.append("\n\tless than " + perfMetricsHistBreakpoints[(i + 1)] + " ms: \t" + perfMetricsHistCounts[i]);
        } else {
          logMessage.append("\n\tbetween " + perfMetricsHistBreakpoints[i] + " and " + perfMetricsHistBreakpoints[(i + 1)] + " ms: \t" + perfMetricsHistCounts[i]);
        }
        logMessage.append("\t");
        
        int numPointsToGraph = (int)(maxNumPoints * (perfMetricsHistCounts[i] / highestCount));
        for (int j = 0; j < numPointsToGraph; j++) {
          logMessage.append("*");
        }
        if (longestQueryTimeMs < perfMetricsHistCounts[(i + 1)]) {
          break;
        }
      }
      if (perfMetricsHistBreakpoints[18] < longestQueryTimeMs)
      {
        logMessage.append("\n\tbetween ");
        logMessage.append(perfMetricsHistBreakpoints[18]);
        logMessage.append(" and ");
        logMessage.append(perfMetricsHistBreakpoints[19]);
        logMessage.append(" ms: \t");
        logMessage.append(perfMetricsHistCounts[19]);
      }
    }
    if (numTablesMetricsHistBreakpoints != null)
    {
      logMessage.append("\n\n\tTable Join Histogram:\n");
      int maxNumPoints = 20;
      int highestCount = Integer.MIN_VALUE;
      for (int i = 0; i < 20; i++) {
        if (numTablesMetricsHistCounts[i] > highestCount) {
          highestCount = numTablesMetricsHistCounts[i];
        }
      }
      if (highestCount == 0) {
        highestCount = 1;
      }
      for (int i = 0; i < 19; i++)
      {
        if (i == 0) {
          logMessage.append("\n\t" + numTablesMetricsHistBreakpoints[(i + 1)] + " tables or less: \t\t" + numTablesMetricsHistCounts[i]);
        } else {
          logMessage.append("\n\tbetween " + numTablesMetricsHistBreakpoints[i] + " and " + numTablesMetricsHistBreakpoints[(i + 1)] + " tables: \t" + numTablesMetricsHistCounts[i]);
        }
        logMessage.append("\t");
        
        int numPointsToGraph = (int)(maxNumPoints * (numTablesMetricsHistCounts[i] / highestCount));
        for (int j = 0; j < numPointsToGraph; j++) {
          logMessage.append("*");
        }
        if (maximumNumberTablesAccessed < numTablesMetricsHistBreakpoints[(i + 1)]) {
          break;
        }
      }
      if (numTablesMetricsHistBreakpoints[18] < maximumNumberTablesAccessed)
      {
        logMessage.append("\n\tbetween ");
        logMessage.append(numTablesMetricsHistBreakpoints[18]);
        logMessage.append(" and ");
        logMessage.append(numTablesMetricsHistBreakpoints[19]);
        logMessage.append(" tables: ");
        logMessage.append(numTablesMetricsHistCounts[19]);
      }
    }
    log.logInfo(logMessage);
  }
  
  public void reportNumberOfTablesAccessed(int numTablesAccessed)
  {
    if (numTablesAccessed < minimumNumberTablesAccessed) {
      minimumNumberTablesAccessed = numTablesAccessed;
    }
    if (numTablesAccessed > maximumNumberTablesAccessed)
    {
      maximumNumberTablesAccessed = numTablesAccessed;
      
      repartitionTablesAccessedHistogram();
    }
    addToTablesAccessedHistogram(numTablesAccessed, 1);
  }
  
  public void incrementNumberOfPreparedExecutes()
  {
    numberOfPreparedExecutes += 1L;
    
    numberOfQueriesIssued += 1L;
  }
  
  public void incrementNumberOfPrepares()
  {
    numberOfPrepares += 1L;
  }
  
  public void incrementNumberOfResultSetsCreated()
  {
    numberOfResultSetsCreated += 1L;
  }
  
  public void reportQueryTime(long millisOrNanos)
  {
    queryTimeCount += 1L;
    queryTimeSum += millisOrNanos;
    queryTimeSumSquares += millisOrNanos * millisOrNanos;
    queryTimeMean = ((queryTimeMean * (queryTimeCount - 1L) + millisOrNanos) / queryTimeCount);
  }
  
  public boolean checkAbonormallyLongQuery(long millisOrNanos)
  {
    boolean res = false;
    if (queryTimeCount > 14L)
    {
      double stddev = Math.sqrt((queryTimeSumSquares - queryTimeSum * queryTimeSum / queryTimeCount) / (queryTimeCount - 1L));
      res = millisOrNanos > queryTimeMean + 5.0D * stddev;
    }
    reportQueryTime(millisOrNanos);
    return res;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.log.BaseMetricsHolder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */