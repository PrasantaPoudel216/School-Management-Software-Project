package com.mysql.cj.exceptions;

import com.mysql.cj.log.Log;
import java.util.Properties;

public abstract interface ExceptionInterceptor
{
  public abstract ExceptionInterceptor init(Properties paramProperties, Log paramLog);
  
  public abstract void destroy();
  
  public abstract Exception interceptException(Exception paramException);
}

/* Location:
 * Qualified Name:     com.mysql.cj.exceptions.ExceptionInterceptor
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */