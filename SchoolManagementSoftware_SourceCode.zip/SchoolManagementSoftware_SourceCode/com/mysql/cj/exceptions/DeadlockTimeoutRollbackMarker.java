package com.mysql.cj.exceptions;

public abstract interface DeadlockTimeoutRollbackMarker {}

/* Location:
 * Qualified Name:     com.mysql.cj.exceptions.DeadlockTimeoutRollbackMarker
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */