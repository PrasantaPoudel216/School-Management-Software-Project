package com.mysql.cj.exceptions;

public class DataConversionException
  extends DataReadException
{
  private static final long serialVersionUID = -863576663404236982L;
  
  public DataConversionException(String msg)
  {
    super(msg);
    setSQLState("22018");
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.exceptions.DataConversionException
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */