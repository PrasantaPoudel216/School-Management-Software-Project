package com.mysql.cj.exceptions;

public abstract interface StreamingNotifiable
{
  public abstract void setWasStreamingResults();
}

/* Location:
 * Qualified Name:     com.mysql.cj.exceptions.StreamingNotifiable
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */