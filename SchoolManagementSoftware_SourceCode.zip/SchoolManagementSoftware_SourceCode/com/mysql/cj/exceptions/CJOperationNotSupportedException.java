package com.mysql.cj.exceptions;

public class CJOperationNotSupportedException
  extends CJException
{
  private static final long serialVersionUID = 2619184100062994443L;
  
  public CJOperationNotSupportedException() {}
  
  public CJOperationNotSupportedException(String message)
  {
    super(message);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.exceptions.CJOperationNotSupportedException
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */