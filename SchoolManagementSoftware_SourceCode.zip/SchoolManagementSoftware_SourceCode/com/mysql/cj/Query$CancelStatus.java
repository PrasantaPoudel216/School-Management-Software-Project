package com.mysql.cj;

public enum Query$CancelStatus
{
  NOT_CANCELED,  CANCELED_BY_USER,  CANCELED_BY_TIMEOUT;
  
  private Query$CancelStatus() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.Query.CancelStatus
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */