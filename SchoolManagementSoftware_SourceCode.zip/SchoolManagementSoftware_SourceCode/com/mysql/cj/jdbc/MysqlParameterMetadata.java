package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.Session;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import com.mysql.cj.result.Field;
import java.sql.ParameterMetaData;
import java.sql.SQLException;

public class MysqlParameterMetadata
  implements ParameterMetaData
{
  boolean returnSimpleMetadata = false;
  ResultSetMetaData metadata = null;
  int parameterCount = 0;
  private ExceptionInterceptor exceptionInterceptor;
  
  public MysqlParameterMetadata(Session session, Field[] fieldInfo, int parameterCount, ExceptionInterceptor exceptionInterceptor)
  {
    metadata = new ResultSetMetaData(session, fieldInfo, false, true, exceptionInterceptor);
    
    this.parameterCount = parameterCount;
    this.exceptionInterceptor = exceptionInterceptor;
  }
  
  MysqlParameterMetadata(int count)
  {
    parameterCount = count;
    returnSimpleMetadata = true;
  }
  
  public int getParameterCount()
    throws SQLException
  {
    try
    {
      return parameterCount;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int isNullable(int arg0)
    throws SQLException
  {
    try
    {
      checkAvailable();
      
      return metadata.isNullable(arg0);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  private void checkAvailable()
    throws SQLException
  {
    if ((metadata == null) || (metadata.getFields() == null)) {
      throw SQLError.createSQLException(Messages.getString("MysqlParameterMetadata.0"), "S1C00", exceptionInterceptor);
    }
  }
  
  public boolean isSigned(int arg0)
    throws SQLException
  {
    try
    {
      if (returnSimpleMetadata)
      {
        checkBounds(arg0);
        
        return false;
      }
      checkAvailable();
      
      return metadata.isSigned(arg0);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getPrecision(int arg0)
    throws SQLException
  {
    try
    {
      if (returnSimpleMetadata)
      {
        checkBounds(arg0);
        
        return 0;
      }
      checkAvailable();
      
      return metadata.getPrecision(arg0);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getScale(int arg0)
    throws SQLException
  {
    try
    {
      if (returnSimpleMetadata)
      {
        checkBounds(arg0);
        
        return 0;
      }
      checkAvailable();
      
      return metadata.getScale(arg0);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getParameterType(int arg0)
    throws SQLException
  {
    try
    {
      if (returnSimpleMetadata)
      {
        checkBounds(arg0);
        
        return MysqlType.VARCHAR.getJdbcType();
      }
      checkAvailable();
      
      return metadata.getColumnType(arg0);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public String getParameterTypeName(int arg0)
    throws SQLException
  {
    try
    {
      if (returnSimpleMetadata)
      {
        checkBounds(arg0);
        
        return MysqlType.VARCHAR.getName();
      }
      checkAvailable();
      
      return metadata.getColumnTypeName(arg0);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public String getParameterClassName(int arg0)
    throws SQLException
  {
    try
    {
      if (returnSimpleMetadata)
      {
        checkBounds(arg0);
        
        return "java.lang.String";
      }
      checkAvailable();
      
      return metadata.getColumnClassName(arg0);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getParameterMode(int arg0)
    throws SQLException
  {
    try
    {
      return 1;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  private void checkBounds(int paramNumber)
    throws SQLException
  {
    if (paramNumber < 1) {
      throw SQLError.createSQLException(Messages.getString("MysqlParameterMetadata.1", new Object[] { Integer.valueOf(paramNumber) }), "S1009", exceptionInterceptor);
    }
    if (paramNumber > parameterCount) {
      throw SQLError.createSQLException(Messages.getString("MysqlParameterMetadata.2", new Object[] { Integer.valueOf(paramNumber), Integer.valueOf(parameterCount) }), "S1009", exceptionInterceptor);
    }
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    try
    {
      return iface.isInstance(this);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      try
      {
        return (T)iface.cast(this);
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", exceptionInterceptor);
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.MysqlParameterMetadata
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */