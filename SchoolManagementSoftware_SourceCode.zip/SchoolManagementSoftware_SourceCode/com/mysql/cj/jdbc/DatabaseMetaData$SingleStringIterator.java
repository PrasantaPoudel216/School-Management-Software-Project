package com.mysql.cj.jdbc;

import java.sql.SQLException;

public class DatabaseMetaData$SingleStringIterator
  extends DatabaseMetaData.IteratorWithCleanup<String>
{
  boolean onFirst = true;
  String value;
  
  DatabaseMetaData$SingleStringIterator(DatabaseMetaData this$0, String s)
  {
    super(this$0);
    value = s;
  }
  
  void close()
    throws SQLException
  {}
  
  boolean hasNext()
    throws SQLException
  {
    return onFirst;
  }
  
  String next()
    throws SQLException
  {
    onFirst = false;
    return value;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.SingleStringIterator
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */