package com.mysql.cj.jdbc;

import com.mysql.cj.MysqlType;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.util.StringUtils;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.StringTokenizer;

class DatabaseMetaData$1
  extends IterateBlock<String>
{
  DatabaseMetaData$1(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, String paramString, Statement paramStatement, ArrayList paramArrayList)
  {
    super(i);
  }
  
  void forEach(String dbStr)
    throws SQLException
  {
    ResultSet results = null;
    try
    {
      StringBuilder queryBuf = new StringBuilder("SHOW COLUMNS FROM ");
      queryBuf.append(StringUtils.quoteIdentifier(val$table, this$0.quotedId, this$0.pedantic));
      queryBuf.append(" FROM ");
      queryBuf.append(StringUtils.quoteIdentifier(dbStr, this$0.quotedId, this$0.pedantic));
      try
      {
        results = val$stmt.executeQuery(queryBuf.toString());
      }
      catch (SQLException sqlEx)
      {
        String sqlState = sqlEx.getSQLState();
        int errorCode = sqlEx.getErrorCode();
        if ((!"42S02".equals(sqlState)) && (errorCode != 1146) && (errorCode != 1049)) {
          throw sqlEx;
        }
      }
      while ((results != null) && (results.next()))
      {
        String keyType = results.getString("Key");
        if ((keyType != null) && 
          (StringUtils.startsWithIgnoreCase(keyType, "PRI")))
        {
          byte[][] rowVal = new byte[8][];
          rowVal[0] = Integer.toString(2).getBytes();
          rowVal[1] = results.getBytes("Field");
          
          String type = results.getString("Type");
          int size = val$stmt.getMaxFieldSize();
          int decimals = 0;
          if (type.indexOf("enum") != -1)
          {
            String temp = type.substring(type.indexOf("("), type.indexOf(")"));
            StringTokenizer tokenizer = new StringTokenizer(temp, ",");
            int maxLength = 0;
            while (tokenizer.hasMoreTokens()) {
              maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
            }
            size = maxLength;
            decimals = 0;
            type = "enum";
          }
          else if (type.indexOf("(") != -1)
          {
            if (type.indexOf(",") != -1)
            {
              size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(",")));
              decimals = Integer.parseInt(type.substring(type.indexOf(",") + 1, type.indexOf(")")));
            }
            else
            {
              size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(")")));
            }
            type = type.substring(0, type.indexOf("("));
          }
          MysqlType ft = MysqlType.getByName(type.toUpperCase());
          rowVal[2] = this$0.s2b(String.valueOf(ft.getJdbcType()));
          rowVal[3] = this$0.s2b(type);
          rowVal[4] = Integer.toString(size + decimals).getBytes();
          rowVal[5] = Integer.toString(size + decimals).getBytes();
          rowVal[6] = Integer.toString(decimals).getBytes();
          rowVal[7] = Integer.toString(1).getBytes();
          
          val$rows.add(new ByteArrayRow(rowVal, this$0.getExceptionInterceptor()));
        }
      }
    }
    catch (SQLException sqlEx)
    {
      if (!"42S02".equals(sqlEx.getSQLState())) {
        throw sqlEx;
      }
    }
    finally
    {
      if (results != null)
      {
        try
        {
          results.close();
        }
        catch (Exception localException2) {}
        results = null;
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */