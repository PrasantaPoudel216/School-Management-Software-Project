package com.mysql.cj.jdbc;

import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.util.StringUtils;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.SortedMap;

class DatabaseMetaData$9
  extends IterateBlock<String>
{
  DatabaseMetaData$9(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, String paramString, Statement paramStatement, String[] paramArrayOfString, boolean paramBoolean, SortedMap paramSortedMap)
  {
    super(i);
  }
  
  void forEach(String dbPattern)
    throws SQLException
  {
    boolean operatingOnSystemDB = ("information_schema".equalsIgnoreCase(dbPattern)) || ("mysql".equalsIgnoreCase(dbPattern)) || ("performance_schema".equalsIgnoreCase(dbPattern));
    
    ResultSet results = null;
    try
    {
      try
      {
        StringBuilder sqlBuf = new StringBuilder("SHOW FULL TABLES FROM ");
        sqlBuf.append(StringUtils.quoteIdentifier(dbPattern, this$0.quotedId, this$0.pedantic));
        if (val$tableNamePat != null)
        {
          sqlBuf.append(" LIKE ");
          sqlBuf.append(StringUtils.quoteIdentifier(val$tableNamePat, "'", true));
        }
        results = val$stmt.executeQuery(sqlBuf.toString());
      }
      catch (SQLException sqlEx)
      {
        if ("08S01".equals(sqlEx.getSQLState())) {
          throw sqlEx;
        }
        return;
      }
      boolean shouldReportTables = false;
      boolean shouldReportViews = false;
      boolean shouldReportSystemTables = false;
      boolean shouldReportSystemViews = false;
      boolean shouldReportLocalTemporaries = false;
      if ((val$types == null) || (val$types.length == 0))
      {
        shouldReportTables = true;
        shouldReportViews = true;
        shouldReportSystemTables = true;
        shouldReportSystemViews = true;
        shouldReportLocalTemporaries = true;
      }
      else
      {
        for (int i = 0; i < val$types.length; i++) {
          if (DatabaseMetaData.TableType.TABLE.equalsTo(val$types[i])) {
            shouldReportTables = true;
          } else if (DatabaseMetaData.TableType.VIEW.equalsTo(val$types[i])) {
            shouldReportViews = true;
          } else if (DatabaseMetaData.TableType.SYSTEM_TABLE.equalsTo(val$types[i])) {
            shouldReportSystemTables = true;
          } else if (DatabaseMetaData.TableType.SYSTEM_VIEW.equalsTo(val$types[i])) {
            shouldReportSystemViews = true;
          } else if (DatabaseMetaData.TableType.LOCAL_TEMPORARY.equalsTo(val$types[i])) {
            shouldReportLocalTemporaries = true;
          }
        }
      }
      int typeColumnIndex = 0;
      boolean hasTableTypes = false;
      try
      {
        typeColumnIndex = results.findColumn("table_type");
        hasTableTypes = true;
      }
      catch (SQLException sqlEx)
      {
        try
        {
          typeColumnIndex = results.findColumn("Type");
          hasTableTypes = true;
        }
        catch (SQLException sqlEx2)
        {
          hasTableTypes = false;
        }
      }
      while (results.next())
      {
        byte[][] row = new byte[10][];
        row[0] = (val$dbMapsToSchema ? this$0.s2b("def") : this$0.s2b(dbPattern));
        row[1] = (val$dbMapsToSchema ? this$0.s2b(dbPattern) : null);
        row[2] = results.getBytes(1);
        row[4] = new byte[0];
        row[5] = null;
        row[6] = null;
        row[7] = null;
        row[8] = null;
        row[9] = null;
        if (hasTableTypes)
        {
          String tableType = results.getString(typeColumnIndex);
          switch (DatabaseMetaData.11.$SwitchMap$com$mysql$cj$jdbc$DatabaseMetaData$TableType[DatabaseMetaData.TableType.getTableTypeCompliantWith(tableType).ordinal()])
          {
          case 1: 
            boolean reportTable = false;
            DatabaseMetaData.TableMetaDataKey tablesKey = null;
            if ((operatingOnSystemDB) && (shouldReportSystemTables))
            {
              row[3] = DatabaseMetaData.TableType.SYSTEM_TABLE.asBytes();
              tablesKey = new DatabaseMetaData.TableMetaDataKey(this$0, DatabaseMetaData.TableType.SYSTEM_TABLE.getName(), dbPattern, null, results.getString(1));
              reportTable = true;
            }
            else if ((!operatingOnSystemDB) && (shouldReportTables))
            {
              row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
              tablesKey = new DatabaseMetaData.TableMetaDataKey(this$0, DatabaseMetaData.TableType.TABLE.getName(), dbPattern, null, results.getString(1));
              reportTable = true;
            }
            if (reportTable) {
              val$sortedRows.put(tablesKey, new ByteArrayRow(row, this$0.getExceptionInterceptor()));
            }
            break;
          case 2: 
            if (shouldReportViews)
            {
              row[3] = DatabaseMetaData.TableType.VIEW.asBytes();
              val$sortedRows.put(new DatabaseMetaData.TableMetaDataKey(this$0, DatabaseMetaData.TableType.VIEW.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, this$0
                .getExceptionInterceptor()));
            }
            break;
          case 3: 
            if (shouldReportSystemTables)
            {
              row[3] = DatabaseMetaData.TableType.SYSTEM_TABLE.asBytes();
              val$sortedRows.put(new DatabaseMetaData.TableMetaDataKey(this$0, DatabaseMetaData.TableType.SYSTEM_TABLE.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, this$0
                .getExceptionInterceptor()));
            }
            break;
          case 4: 
            if (shouldReportSystemViews)
            {
              row[3] = DatabaseMetaData.TableType.SYSTEM_VIEW.asBytes();
              val$sortedRows.put(new DatabaseMetaData.TableMetaDataKey(this$0, DatabaseMetaData.TableType.SYSTEM_VIEW.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, this$0
                .getExceptionInterceptor()));
            }
            break;
          case 5: 
            if (shouldReportLocalTemporaries)
            {
              row[3] = DatabaseMetaData.TableType.LOCAL_TEMPORARY.asBytes();
              val$sortedRows.put(new DatabaseMetaData.TableMetaDataKey(this$0, DatabaseMetaData.TableType.LOCAL_TEMPORARY.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, this$0
                .getExceptionInterceptor()));
            }
            break;
          default: 
            row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
            val$sortedRows.put(new DatabaseMetaData.TableMetaDataKey(this$0, DatabaseMetaData.TableType.TABLE.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, this$0
              .getExceptionInterceptor()));
          }
        }
        else if (shouldReportTables)
        {
          row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
          val$sortedRows.put(new DatabaseMetaData.TableMetaDataKey(this$0, DatabaseMetaData.TableType.TABLE.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, this$0
            .getExceptionInterceptor()));
        }
      }
    }
    finally
    {
      if (results != null)
      {
        try
        {
          results.close();
        }
        catch (Exception localException2) {}
        results = null;
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.9
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */