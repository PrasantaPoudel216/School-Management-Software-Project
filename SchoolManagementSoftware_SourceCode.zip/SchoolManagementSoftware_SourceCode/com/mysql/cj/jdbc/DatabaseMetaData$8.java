package com.mysql.cj.jdbc;

import com.mysql.cj.result.Field;
import java.util.List;

class DatabaseMetaData$8
  extends IterateBlock<String>
{
  DatabaseMetaData$8(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, List paramList, Field[] paramArrayOfField)
  {
    super(i);
  }
  
  /* Error */
  void forEach(String dbPattern)
    throws java.sql.SQLException
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_2
    //   2: new 9	java/lang/StringBuilder
    //   5: dup
    //   6: invokespecial 10	java/lang/StringBuilder:<init>	()V
    //   9: astore_3
    //   10: aload_3
    //   11: ldc 11
    //   13: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   16: pop
    //   17: aload_0
    //   18: getfield 2	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnProcedures	Z
    //   21: ifeq +20 -> 41
    //   24: aload_0
    //   25: getfield 3	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnFunctions	Z
    //   28: ifne +13 -> 41
    //   31: aload_3
    //   32: ldc 13
    //   34: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   37: pop
    //   38: goto +24 -> 62
    //   41: aload_0
    //   42: getfield 2	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnProcedures	Z
    //   45: ifne +17 -> 62
    //   48: aload_0
    //   49: getfield 3	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnFunctions	Z
    //   52: ifeq +10 -> 62
    //   55: aload_3
    //   56: ldc 14
    //   58: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   61: pop
    //   62: aload_3
    //   63: aload_0
    //   64: getfield 4	com/mysql/cj/jdbc/DatabaseMetaData$8:val$dbMapsToSchema	Z
    //   67: ifeq +8 -> 75
    //   70: ldc 15
    //   72: goto +5 -> 77
    //   75: ldc 16
    //   77: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   80: pop
    //   81: aload_0
    //   82: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   85: ifnull +20 -> 105
    //   88: aload_0
    //   89: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   92: invokevirtual 17	java/lang/String:length	()I
    //   95: ifle +10 -> 105
    //   98: aload_3
    //   99: ldc 18
    //   101: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   104: pop
    //   105: aload_3
    //   106: ldc 19
    //   108: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   111: pop
    //   112: aload_0
    //   113: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
    //   116: aload_3
    //   117: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   120: invokevirtual 21	com/mysql/cj/jdbc/DatabaseMetaData:prepareMetaDataSafeStatement	(Ljava/lang/String;)Ljava/sql/PreparedStatement;
    //   123: astore 4
    //   125: aload_0
    //   126: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
    //   129: getfield 22	com/mysql/cj/jdbc/DatabaseMetaData:conn	Lcom/mysql/cj/jdbc/JdbcConnection;
    //   132: invokeinterface 23 1 0
    //   137: ifeq +8 -> 145
    //   140: aload_1
    //   141: invokevirtual 24	java/lang/String:toLowerCase	()Ljava/lang/String;
    //   144: astore_1
    //   145: aload 4
    //   147: iconst_1
    //   148: aload_1
    //   149: invokeinterface 25 3 0
    //   154: aload_0
    //   155: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   158: ifnull +25 -> 183
    //   161: aload_0
    //   162: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   165: invokevirtual 17	java/lang/String:length	()I
    //   168: ifle +15 -> 183
    //   171: aload 4
    //   173: iconst_2
    //   174: aload_0
    //   175: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   178: invokeinterface 25 3 0
    //   183: aload 4
    //   185: invokeinterface 26 1 0
    //   190: astore_2
    //   191: aload_0
    //   192: getfield 2	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnProcedures	Z
    //   195: ifeq +16 -> 211
    //   198: aload_0
    //   199: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
    //   202: iconst_1
    //   203: aload_2
    //   204: aload_0
    //   205: getfield 6	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureRowsToSort	Ljava/util/List;
    //   208: invokevirtual 27	com/mysql/cj/jdbc/DatabaseMetaData:convertToJdbcProcedureList	(ZLjava/sql/ResultSet;Ljava/util/List;)V
    //   211: aload_0
    //   212: getfield 3	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnFunctions	Z
    //   215: ifeq +19 -> 234
    //   218: aload_0
    //   219: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
    //   222: aload_2
    //   223: aload_0
    //   224: getfield 6	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureRowsToSort	Ljava/util/List;
    //   227: aload_0
    //   228: getfield 7	com/mysql/cj/jdbc/DatabaseMetaData$8:val$fields	[Lcom/mysql/cj/result/Field;
    //   231: invokevirtual 28	com/mysql/cj/jdbc/DatabaseMetaData:convertToJdbcFunctionList	(Ljava/sql/ResultSet;Ljava/util/List;[Lcom/mysql/cj/result/Field;)V
    //   234: goto +322 -> 556
    //   237: astore 5
    //   239: aload_0
    //   240: getfield 3	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnFunctions	Z
    //   243: ifeq +156 -> 399
    //   246: aload 4
    //   248: invokeinterface 30 1 0
    //   253: new 9	java/lang/StringBuilder
    //   256: dup
    //   257: invokespecial 10	java/lang/StringBuilder:<init>	()V
    //   260: ldc 31
    //   262: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   265: aload_0
    //   266: getfield 4	com/mysql/cj/jdbc/DatabaseMetaData$8:val$dbMapsToSchema	Z
    //   269: ifeq +8 -> 277
    //   272: ldc 32
    //   274: goto +5 -> 279
    //   277: ldc 33
    //   279: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   282: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   285: astore 6
    //   287: aload_0
    //   288: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   291: ifnull +35 -> 326
    //   294: aload_0
    //   295: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   298: invokevirtual 17	java/lang/String:length	()I
    //   301: ifle +25 -> 326
    //   304: new 9	java/lang/StringBuilder
    //   307: dup
    //   308: invokespecial 10	java/lang/StringBuilder:<init>	()V
    //   311: aload 6
    //   313: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   316: ldc 34
    //   318: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   321: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   324: astore 6
    //   326: aload_0
    //   327: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
    //   330: aload 6
    //   332: invokevirtual 21	com/mysql/cj/jdbc/DatabaseMetaData:prepareMetaDataSafeStatement	(Ljava/lang/String;)Ljava/sql/PreparedStatement;
    //   335: astore 4
    //   337: aload 4
    //   339: iconst_1
    //   340: aload_1
    //   341: invokeinterface 25 3 0
    //   346: aload_0
    //   347: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   350: ifnull +25 -> 375
    //   353: aload_0
    //   354: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   357: invokevirtual 17	java/lang/String:length	()I
    //   360: ifle +15 -> 375
    //   363: aload 4
    //   365: iconst_2
    //   366: aload_0
    //   367: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   370: invokeinterface 25 3 0
    //   375: aload 4
    //   377: invokeinterface 26 1 0
    //   382: astore_2
    //   383: aload_0
    //   384: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
    //   387: aload_2
    //   388: aload_0
    //   389: getfield 6	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureRowsToSort	Ljava/util/List;
    //   392: aload_0
    //   393: getfield 7	com/mysql/cj/jdbc/DatabaseMetaData$8:val$fields	[Lcom/mysql/cj/result/Field;
    //   396: invokevirtual 28	com/mysql/cj/jdbc/DatabaseMetaData:convertToJdbcFunctionList	(Ljava/sql/ResultSet;Ljava/util/List;[Lcom/mysql/cj/result/Field;)V
    //   399: aload_0
    //   400: getfield 2	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnProcedures	Z
    //   403: ifeq +153 -> 556
    //   406: aload 4
    //   408: invokeinterface 30 1 0
    //   413: new 9	java/lang/StringBuilder
    //   416: dup
    //   417: invokespecial 10	java/lang/StringBuilder:<init>	()V
    //   420: ldc 35
    //   422: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   425: aload_0
    //   426: getfield 4	com/mysql/cj/jdbc/DatabaseMetaData$8:val$dbMapsToSchema	Z
    //   429: ifeq +8 -> 437
    //   432: ldc 32
    //   434: goto +5 -> 439
    //   437: ldc 33
    //   439: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   442: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   445: astore 6
    //   447: aload_0
    //   448: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   451: ifnull +35 -> 486
    //   454: aload_0
    //   455: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   458: invokevirtual 17	java/lang/String:length	()I
    //   461: ifle +25 -> 486
    //   464: new 9	java/lang/StringBuilder
    //   467: dup
    //   468: invokespecial 10	java/lang/StringBuilder:<init>	()V
    //   471: aload 6
    //   473: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   476: ldc 34
    //   478: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   481: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   484: astore 6
    //   486: aload_0
    //   487: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
    //   490: aload 6
    //   492: invokevirtual 21	com/mysql/cj/jdbc/DatabaseMetaData:prepareMetaDataSafeStatement	(Ljava/lang/String;)Ljava/sql/PreparedStatement;
    //   495: astore 4
    //   497: aload 4
    //   499: iconst_1
    //   500: aload_1
    //   501: invokeinterface 25 3 0
    //   506: aload_0
    //   507: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   510: ifnull +25 -> 535
    //   513: aload_0
    //   514: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   517: invokevirtual 17	java/lang/String:length	()I
    //   520: ifle +15 -> 535
    //   523: aload 4
    //   525: iconst_2
    //   526: aload_0
    //   527: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
    //   530: invokeinterface 25 3 0
    //   535: aload 4
    //   537: invokeinterface 26 1 0
    //   542: astore_2
    //   543: aload_0
    //   544: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
    //   547: iconst_0
    //   548: aload_2
    //   549: aload_0
    //   550: getfield 6	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureRowsToSort	Ljava/util/List;
    //   553: invokevirtual 27	com/mysql/cj/jdbc/DatabaseMetaData:convertToJdbcProcedureList	(ZLjava/sql/ResultSet;Ljava/util/List;)V
    //   556: aconst_null
    //   557: astore 5
    //   559: aload_2
    //   560: ifnull +18 -> 578
    //   563: aload_2
    //   564: invokeinterface 36 1 0
    //   569: goto +9 -> 578
    //   572: astore 6
    //   574: aload 6
    //   576: astore 5
    //   578: aload 4
    //   580: ifnull +19 -> 599
    //   583: aload 4
    //   585: invokeinterface 30 1 0
    //   590: goto +9 -> 599
    //   593: astore 6
    //   595: aload 6
    //   597: astore 5
    //   599: aload 5
    //   601: ifnull +6 -> 607
    //   604: aload 5
    //   606: athrow
    //   607: goto +59 -> 666
    //   610: astore 7
    //   612: aconst_null
    //   613: astore 8
    //   615: aload_2
    //   616: ifnull +18 -> 634
    //   619: aload_2
    //   620: invokeinterface 36 1 0
    //   625: goto +9 -> 634
    //   628: astore 9
    //   630: aload 9
    //   632: astore 8
    //   634: aload 4
    //   636: ifnull +19 -> 655
    //   639: aload 4
    //   641: invokeinterface 30 1 0
    //   646: goto +9 -> 655
    //   649: astore 9
    //   651: aload 9
    //   653: astore 8
    //   655: aload 8
    //   657: ifnull +6 -> 663
    //   660: aload 8
    //   662: athrow
    //   663: aload 7
    //   665: athrow
    //   666: return
    // Line number table:
    //   Java source line #3205	-> byte code offset #0
    //   Java source line #3207	-> byte code offset #2
    //   Java source line #3209	-> byte code offset #10
    //   Java source line #3210	-> byte code offset #17
    //   Java source line #3211	-> byte code offset #31
    //   Java source line #3212	-> byte code offset #41
    //   Java source line #3213	-> byte code offset #55
    //   Java source line #3216	-> byte code offset #62
    //   Java source line #3218	-> byte code offset #81
    //   Java source line #3219	-> byte code offset #98
    //   Java source line #3222	-> byte code offset #105
    //   Java source line #3224	-> byte code offset #112
    //   Java source line #3229	-> byte code offset #125
    //   Java source line #3230	-> byte code offset #140
    //   Java source line #3232	-> byte code offset #145
    //   Java source line #3234	-> byte code offset #154
    //   Java source line #3235	-> byte code offset #171
    //   Java source line #3239	-> byte code offset #183
    //   Java source line #3241	-> byte code offset #191
    //   Java source line #3242	-> byte code offset #198
    //   Java source line #3245	-> byte code offset #211
    //   Java source line #3246	-> byte code offset #218
    //   Java source line #3288	-> byte code offset #234
    //   Java source line #3249	-> byte code offset #237
    //   Java source line #3254	-> byte code offset #239
    //   Java source line #3255	-> byte code offset #246
    //   Java source line #3257	-> byte code offset #253
    //   Java source line #3258	-> byte code offset #287
    //   Java source line #3259	-> byte code offset #304
    //   Java source line #3261	-> byte code offset #326
    //   Java source line #3262	-> byte code offset #337
    //   Java source line #3263	-> byte code offset #346
    //   Java source line #3264	-> byte code offset #363
    //   Java source line #3266	-> byte code offset #375
    //   Java source line #3268	-> byte code offset #383
    //   Java source line #3272	-> byte code offset #399
    //   Java source line #3273	-> byte code offset #406
    //   Java source line #3275	-> byte code offset #413
    //   Java source line #3276	-> byte code offset #447
    //   Java source line #3277	-> byte code offset #464
    //   Java source line #3279	-> byte code offset #486
    //   Java source line #3280	-> byte code offset #497
    //   Java source line #3281	-> byte code offset #506
    //   Java source line #3282	-> byte code offset #523
    //   Java source line #3284	-> byte code offset #535
    //   Java source line #3286	-> byte code offset #543
    //   Java source line #3291	-> byte code offset #556
    //   Java source line #3293	-> byte code offset #559
    //   Java source line #3295	-> byte code offset #563
    //   Java source line #3298	-> byte code offset #569
    //   Java source line #3296	-> byte code offset #572
    //   Java source line #3297	-> byte code offset #574
    //   Java source line #3301	-> byte code offset #578
    //   Java source line #3303	-> byte code offset #583
    //   Java source line #3306	-> byte code offset #590
    //   Java source line #3304	-> byte code offset #593
    //   Java source line #3305	-> byte code offset #595
    //   Java source line #3309	-> byte code offset #599
    //   Java source line #3310	-> byte code offset #604
    //   Java source line #3312	-> byte code offset #607
    //   Java source line #3291	-> byte code offset #610
    //   Java source line #3293	-> byte code offset #615
    //   Java source line #3295	-> byte code offset #619
    //   Java source line #3298	-> byte code offset #625
    //   Java source line #3296	-> byte code offset #628
    //   Java source line #3297	-> byte code offset #630
    //   Java source line #3301	-> byte code offset #634
    //   Java source line #3303	-> byte code offset #639
    //   Java source line #3306	-> byte code offset #646
    //   Java source line #3304	-> byte code offset #649
    //   Java source line #3305	-> byte code offset #651
    //   Java source line #3309	-> byte code offset #655
    //   Java source line #3310	-> byte code offset #660
    //   Java source line #3312	-> byte code offset #663
    //   Java source line #3313	-> byte code offset #666
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	667	0	this	8
    //   0	667	1	dbPattern	String
    //   1	619	2	proceduresRs	java.sql.ResultSet
    //   9	108	3	selectFromMySQLProcSQL	StringBuilder
    //   123	517	4	proceduresStmt	java.sql.PreparedStatement
    //   237	3	5	sqlEx	java.sql.SQLException
    //   557	48	5	rethrowSqlEx	java.sql.SQLException
    //   285	46	6	sql	String
    //   445	46	6	sql	String
    //   572	3	6	sqlEx	java.sql.SQLException
    //   593	3	6	sqlEx	java.sql.SQLException
    //   610	54	7	localObject	Object
    //   613	48	8	rethrowSqlEx	java.sql.SQLException
    //   628	3	9	sqlEx	java.sql.SQLException
    //   649	3	9	sqlEx	java.sql.SQLException
    // Exception table:
    //   from	to	target	type
    //   183	234	237	java/sql/SQLException
    //   563	569	572	java/sql/SQLException
    //   583	590	593	java/sql/SQLException
    //   125	556	610	finally
    //   610	612	610	finally
    //   619	625	628	java/sql/SQLException
    //   639	646	649	java/sql/SQLException
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.8
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */