package com.mysql.cj.jdbc;

import com.mysql.cj.MysqlConnection;
import com.mysql.cj.ServerVersion;
import com.mysql.cj.TransactionEventHandler;
import com.mysql.cj.interceptors.QueryInterceptor;
import com.mysql.cj.jdbc.result.CachedResultSetMetaData;
import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

public abstract interface JdbcConnection
  extends Connection, MysqlConnection, TransactionEventHandler
{
  public abstract JdbcPropertySet getPropertySet();
  
  public abstract void changeUser(String paramString1, String paramString2)
    throws SQLException;
  
  @Deprecated
  public abstract void clearHasTriedMaster();
  
  public abstract PreparedStatement clientPrepareStatement(String paramString)
    throws SQLException;
  
  public abstract PreparedStatement clientPrepareStatement(String paramString, int paramInt)
    throws SQLException;
  
  public abstract PreparedStatement clientPrepareStatement(String paramString, int paramInt1, int paramInt2)
    throws SQLException;
  
  public abstract PreparedStatement clientPrepareStatement(String paramString, int[] paramArrayOfInt)
    throws SQLException;
  
  public abstract PreparedStatement clientPrepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws SQLException;
  
  public abstract PreparedStatement clientPrepareStatement(String paramString, String[] paramArrayOfString)
    throws SQLException;
  
  public abstract int getActiveStatementCount();
  
  public abstract long getIdleFor();
  
  public abstract String getStatementComment();
  
  @Deprecated
  public abstract boolean hasTriedMaster();
  
  public abstract boolean isInGlobalTx();
  
  public abstract void setInGlobalTx(boolean paramBoolean);
  
  public abstract boolean isMasterConnection();
  
  public abstract boolean isSameResource(JdbcConnection paramJdbcConnection);
  
  public abstract boolean lowerCaseTableNames();
  
  public abstract void ping()
    throws SQLException;
  
  public abstract void resetServerState()
    throws SQLException;
  
  public abstract PreparedStatement serverPrepareStatement(String paramString)
    throws SQLException;
  
  public abstract PreparedStatement serverPrepareStatement(String paramString, int paramInt)
    throws SQLException;
  
  public abstract PreparedStatement serverPrepareStatement(String paramString, int paramInt1, int paramInt2)
    throws SQLException;
  
  public abstract PreparedStatement serverPrepareStatement(String paramString, int paramInt1, int paramInt2, int paramInt3)
    throws SQLException;
  
  public abstract PreparedStatement serverPrepareStatement(String paramString, int[] paramArrayOfInt)
    throws SQLException;
  
  public abstract PreparedStatement serverPrepareStatement(String paramString, String[] paramArrayOfString)
    throws SQLException;
  
  public abstract void setFailedOver(boolean paramBoolean);
  
  public abstract void setStatementComment(String paramString);
  
  public abstract void shutdownServer()
    throws SQLException;
  
  public abstract int getAutoIncrementIncrement();
  
  public abstract boolean hasSameProperties(JdbcConnection paramJdbcConnection);
  
  public abstract String getHost();
  
  public abstract String getHostPortPair();
  
  public abstract void setProxy(JdbcConnection paramJdbcConnection);
  
  public abstract boolean isServerLocal()
    throws SQLException;
  
  public abstract int getSessionMaxRows();
  
  public abstract void setSessionMaxRows(int paramInt)
    throws SQLException;
  
  public abstract void abortInternal()
    throws SQLException;
  
  public abstract boolean isProxySet();
  
  public abstract CachedResultSetMetaData getCachedMetaData(String paramString);
  
  public abstract String getCharacterSetMetadata();
  
  public abstract Statement getMetadataSafeStatement()
    throws SQLException;
  
  public abstract ServerVersion getServerVersion();
  
  public abstract List<QueryInterceptor> getQueryInterceptorsInstances();
  
  public abstract void initializeResultsMetadataFromCache(String paramString, CachedResultSetMetaData paramCachedResultSetMetaData, ResultSetInternalMethods paramResultSetInternalMethods)
    throws SQLException;
  
  public abstract void initializeSafeQueryInterceptors()
    throws SQLException;
  
  public abstract boolean isReadOnly(boolean paramBoolean)
    throws SQLException;
  
  public abstract void pingInternal(boolean paramBoolean, int paramInt)
    throws SQLException;
  
  public abstract void realClose(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, Throwable paramThrowable)
    throws SQLException;
  
  public abstract void recachePreparedStatement(JdbcPreparedStatement paramJdbcPreparedStatement)
    throws SQLException;
  
  public abstract void decachePreparedStatement(JdbcPreparedStatement paramJdbcPreparedStatement)
    throws SQLException;
  
  public abstract void registerStatement(JdbcStatement paramJdbcStatement);
  
  public abstract void setReadOnlyInternal(boolean paramBoolean)
    throws SQLException;
  
  public abstract boolean storesLowerCaseTableName();
  
  public abstract void throwConnectionClosedException()
    throws SQLException;
  
  public abstract void unregisterStatement(JdbcStatement paramJdbcStatement);
  
  public abstract void unSafeQueryInterceptors()
    throws SQLException;
  
  public abstract JdbcConnection getMultiHostSafeProxy();
  
  public abstract JdbcConnection getActiveMySQLConnection();
  
  public abstract ClientInfoProvider getClientInfoProviderImpl()
    throws SQLException;
  
  public abstract void setDatabase(String paramString)
    throws SQLException;
  
  public abstract String getDatabase()
    throws SQLException;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.JdbcConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */