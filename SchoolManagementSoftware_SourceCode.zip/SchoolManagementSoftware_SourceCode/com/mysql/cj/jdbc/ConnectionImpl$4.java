package com.mysql.cj.jdbc;

import com.mysql.cj.jdbc.interceptors.ConnectionLifecycleInterceptor;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.Iterator;

class ConnectionImpl$4
  extends IterateBlock<ConnectionLifecycleInterceptor>
{
  ConnectionImpl$4(ConnectionImpl this$0, Iterator i, Savepoint paramSavepoint)
  {
    super(i);
  }
  
  void forEach(ConnectionLifecycleInterceptor each)
    throws SQLException
  {
    if (!each.rollback(val$savepoint)) {
      stopIterating = true;
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionImpl.4
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */