package com.mysql.cj.jdbc;

public class DatabaseMetaData$IndexMetaDataKey
  implements Comparable<IndexMetaDataKey>
{
  Boolean columnNonUnique;
  Short columnType;
  String columnIndexName;
  Short columnOrdinalPosition;
  
  DatabaseMetaData$IndexMetaDataKey(DatabaseMetaData this$0, boolean columnNonUnique, short columnType, String columnIndexName, short columnOrdinalPosition)
  {
    this.columnNonUnique = Boolean.valueOf(columnNonUnique);
    this.columnType = Short.valueOf(columnType);
    this.columnIndexName = columnIndexName;
    this.columnOrdinalPosition = Short.valueOf(columnOrdinalPosition);
  }
  
  public int compareTo(IndexMetaDataKey indexInfoKey)
  {
    int compareResult;
    if ((compareResult = columnNonUnique.compareTo(columnNonUnique)) != 0) {
      return compareResult;
    }
    if ((compareResult = columnType.compareTo(columnType)) != 0) {
      return compareResult;
    }
    if ((compareResult = columnIndexName.compareTo(columnIndexName)) != 0) {
      return compareResult;
    }
    return columnOrdinalPosition.compareTo(columnOrdinalPosition);
  }
  
  public boolean equals(Object obj)
  {
    if (obj == null) {
      return false;
    }
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof IndexMetaDataKey)) {
      return false;
    }
    return compareTo((IndexMetaDataKey)obj) == 0;
  }
  
  public int hashCode()
  {
    if (!$assertionsDisabled) {
      throw new AssertionError("hashCode not designed");
    }
    return 0;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.IndexMetaDataKey
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */