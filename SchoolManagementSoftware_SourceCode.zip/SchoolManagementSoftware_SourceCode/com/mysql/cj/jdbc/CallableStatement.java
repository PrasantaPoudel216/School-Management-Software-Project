package com.mysql.cj.jdbc;

import com.mysql.cj.BindValue;
import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.NativeSession;
import com.mysql.cj.PreparedQuery;
import com.mysql.cj.Session;
import com.mysql.cj.conf.PropertyDefinitions.DatabaseTerm;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.FeatureNotAvailableException;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.jdbc.result.ResultSetFactory;
import com.mysql.cj.jdbc.result.ResultSetImpl;
import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
import com.mysql.cj.result.DefaultColumnDefinition;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.Row;
import com.mysql.cj.util.StringUtils;
import com.mysql.cj.util.Util;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.JDBCType;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Wrapper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CallableStatement
  extends ClientPreparedStatement
  implements java.sql.CallableStatement
{
  private static final int NOT_OUTPUT_PARAMETER_INDICATOR = Integer.MIN_VALUE;
  private static final String PARAMETER_NAMESPACE_PREFIX = "@com_mysql_jdbc_outparam_";
  
  protected static class CallableStatementParam
  {
    int index;
    int inOutModifier;
    boolean isIn;
    boolean isOut;
    int jdbcType;
    short nullability;
    String paramName;
    int precision;
    int scale;
    String typeName;
    MysqlType desiredMysqlType = MysqlType.UNKNOWN;
    
    CallableStatementParam(String name, int idx, boolean in, boolean out, int jdbcType, String typeName, int precision, int scale, short nullability, int inOutModifier)
    {
      paramName = name;
      isIn = in;
      isOut = out;
      index = idx;
      
      this.jdbcType = jdbcType;
      this.typeName = typeName;
      this.precision = precision;
      this.scale = scale;
      this.nullability = nullability;
      this.inOutModifier = inOutModifier;
    }
    
    protected Object clone()
      throws CloneNotSupportedException
    {
      return super.clone();
    }
  }
  
  public class CallableStatementParamInfo
    implements ParameterMetaData
  {
    String dbInUse;
    boolean isFunctionCall;
    String nativeSql;
    int numParameters;
    List<CallableStatement.CallableStatementParam> parameterList;
    Map<String, CallableStatement.CallableStatementParam> parameterMap;
    boolean isReadOnlySafeProcedure = false;
    boolean isReadOnlySafeChecked = false;
    
    CallableStatementParamInfo(CallableStatementParamInfo fullParamInfo)
    {
      nativeSql = ((PreparedQuery)query).getOriginalSql();
      dbInUse = getCurrentDatabase();
      isFunctionCall = isFunctionCall;
      
      int[] localParameterMap = placeholderToParameterIndexMap;
      int parameterMapLength = localParameterMap.length;
      
      isReadOnlySafeProcedure = isReadOnlySafeProcedure;
      isReadOnlySafeChecked = isReadOnlySafeChecked;
      parameterList = new ArrayList(numParameters);
      parameterMap = new HashMap(numParameters);
      if (isFunctionCall) {
        parameterList.add(parameterList.get(0));
      }
      int offset = isFunctionCall ? 1 : 0;
      for (int i = 0; i < parameterMapLength; i++) {
        if (localParameterMap[i] != 0)
        {
          CallableStatement.CallableStatementParam param = (CallableStatement.CallableStatementParam)parameterList.get(localParameterMap[i] + offset);
          
          parameterList.add(param);
          parameterMap.put(paramName, param);
        }
      }
      numParameters = parameterList.size();
    }
    
    CallableStatementParamInfo(ResultSet paramTypesRs)
      throws SQLException
    {
      boolean hadRows = paramTypesRs.last();
      
      nativeSql = ((PreparedQuery)query).getOriginalSql();
      dbInUse = getCurrentDatabase();
      isFunctionCall = callingStoredFunction;
      if (hadRows)
      {
        numParameters = paramTypesRs.getRow();
        
        parameterList = new ArrayList(numParameters);
        parameterMap = new HashMap(numParameters);
        
        paramTypesRs.beforeFirst();
        
        addParametersFromDBMD(paramTypesRs);
      }
      else
      {
        numParameters = 0;
      }
      if (isFunctionCall) {
        numParameters += 1;
      }
    }
    
    private void addParametersFromDBMD(ResultSet paramTypesRs)
      throws SQLException
    {
      int i = 0;
      while (paramTypesRs.next())
      {
        String paramName = paramTypesRs.getString(4);
        int inOutModifier;
        int inOutModifier;
        int inOutModifier;
        int inOutModifier;
        switch (paramTypesRs.getInt(5))
        {
        case 1: 
          inOutModifier = 1;
          break;
        case 2: 
          inOutModifier = 2;
          break;
        case 4: 
        case 5: 
          inOutModifier = 4;
          break;
        case 3: 
        default: 
          inOutModifier = 0;
        }
        boolean isOutParameter = false;
        boolean isInParameter = false;
        if ((i == 0) && (isFunctionCall))
        {
          isOutParameter = true;
          isInParameter = false;
        }
        else if (inOutModifier == 2)
        {
          isOutParameter = true;
          isInParameter = true;
        }
        else if (inOutModifier == 1)
        {
          isOutParameter = false;
          isInParameter = true;
        }
        else if (inOutModifier == 4)
        {
          isOutParameter = true;
          isInParameter = false;
        }
        int jdbcType = paramTypesRs.getInt(6);
        String typeName = paramTypesRs.getString(7);
        int precision = paramTypesRs.getInt(8);
        int scale = paramTypesRs.getInt(10);
        short nullability = paramTypesRs.getShort(12);
        
        CallableStatement.CallableStatementParam paramInfoToAdd = new CallableStatement.CallableStatementParam(paramName, i++, isInParameter, isOutParameter, jdbcType, typeName, precision, scale, nullability, inOutModifier);
        
        parameterList.add(paramInfoToAdd);
        parameterMap.put(paramName, paramInfoToAdd);
      }
    }
    
    protected void checkBounds(int paramIndex)
      throws SQLException
    {
      int localParamIndex = paramIndex - 1;
      if ((paramIndex < 0) || (localParamIndex >= numParameters)) {
        throw SQLError.createSQLException(Messages.getString("CallableStatement.11", new Object[] { Integer.valueOf(paramIndex), Integer.valueOf(numParameters) }), "S1009", 
          getExceptionInterceptor());
      }
    }
    
    protected Object clone()
      throws CloneNotSupportedException
    {
      return super.clone();
    }
    
    CallableStatement.CallableStatementParam getParameter(int index)
    {
      return (CallableStatement.CallableStatementParam)parameterList.get(index);
    }
    
    CallableStatement.CallableStatementParam getParameter(String name)
    {
      return (CallableStatement.CallableStatementParam)parameterMap.get(name);
    }
    
    public String getParameterClassName(int arg0)
      throws SQLException
    {
      try
      {
        String mysqlTypeName = getParameterTypeName(arg0);
        
        MysqlType mysqlType = MysqlType.getByName(mysqlTypeName);
        switch (CallableStatement.1.$SwitchMap$com$mysql$cj$MysqlType[mysqlType.ordinal()])
        {
        case 1: 
          if (!((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue()) {
            return Short.class.getName();
          }
          return mysqlType.getClassName();
        }
        return mysqlType.getClassName();
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public int getParameterCount()
      throws SQLException
    {
      try
      {
        if (parameterList == null) {
          return 0;
        }
        return parameterList.size();
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public int getParameterMode(int arg0)
      throws SQLException
    {
      try
      {
        checkBounds(arg0);
        
        return getParameter1inOutModifier;
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public int getParameterType(int arg0)
      throws SQLException
    {
      try
      {
        checkBounds(arg0);
        
        return getParameter1jdbcType;
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public String getParameterTypeName(int arg0)
      throws SQLException
    {
      try
      {
        checkBounds(arg0);
        
        return getParameter1typeName;
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public int getPrecision(int arg0)
      throws SQLException
    {
      try
      {
        checkBounds(arg0);
        
        return getParameter1precision;
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public int getScale(int arg0)
      throws SQLException
    {
      try
      {
        checkBounds(arg0);
        
        return getParameter1scale;
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public int isNullable(int arg0)
      throws SQLException
    {
      try
      {
        checkBounds(arg0);
        
        return getParameter1nullability;
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public boolean isSigned(int arg0)
      throws SQLException
    {
      try
      {
        checkBounds(arg0);
        
        return false;
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    Iterator<CallableStatement.CallableStatementParam> iterator()
    {
      return parameterList.iterator();
    }
    
    int numberOfParameters()
    {
      return numParameters;
    }
    
    public boolean isWrapperFor(Class<?> iface)
      throws SQLException
    {
      try
      {
        checkClosed();
        
        return iface.isInstance(this);
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
    
    public <T> T unwrap(Class<T> iface)
      throws SQLException
    {
      try
      {
        try
        {
          return (T)iface.cast(this);
        }
        catch (ClassCastException cce)
        {
          throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", 
            getExceptionInterceptor());
        }
      }
      catch (CJException localCJException)
      {
        throw SQLExceptionsMapping.translateException(localCJException);
      }
    }
  }
  
  private static String mangleParameterName(String origParameterName)
  {
    if (origParameterName == null) {
      return null;
    }
    int offset = 0;
    if ((origParameterName.length() > 0) && (origParameterName.charAt(0) == '@')) {
      offset = 1;
    }
    StringBuilder paramNameBuf = new StringBuilder("@com_mysql_jdbc_outparam_".length() + origParameterName.length());
    paramNameBuf.append("@com_mysql_jdbc_outparam_");
    paramNameBuf.append(origParameterName.substring(offset));
    
    return paramNameBuf.toString();
  }
  
  private boolean callingStoredFunction = false;
  private ResultSetInternalMethods functionReturnValueResults;
  private boolean hasOutputParams = false;
  private ResultSetInternalMethods outputParameterResults;
  protected boolean outputParamWasNull = false;
  private int[] parameterIndexToRsIndex;
  protected CallableStatementParamInfo paramInfo;
  private CallableStatementParam returnValueParam;
  private boolean noAccessToProcedureBodies;
  private int[] placeholderToParameterIndexMap;
  
  public CallableStatement(JdbcConnection conn, CallableStatementParamInfo paramInfo)
    throws SQLException
  {
    super(conn, nativeSql, dbInUse);
    
    this.paramInfo = paramInfo;
    callingStoredFunction = paramInfoisFunctionCall;
    if (callingStoredFunction) {
      ((PreparedQuery)query).setParameterCount(((PreparedQuery)query).getParameterCount() + 1);
    }
    retrieveGeneratedKeys = true;
    
    noAccessToProcedureBodies = ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.noAccessToProcedureBodies).getValue()).booleanValue();
  }
  
  protected static CallableStatement getInstance(JdbcConnection conn, String sql, String db, boolean isFunctionCall)
    throws SQLException
  {
    return new CallableStatement(conn, sql, db, isFunctionCall);
  }
  
  protected static CallableStatement getInstance(JdbcConnection conn, CallableStatementParamInfo paramInfo)
    throws SQLException
  {
    return new CallableStatement(conn, paramInfo);
  }
  
  private void generateParameterMap()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (paramInfo == null) {
          return;
        }
        int parameterCountFromMetaData = paramInfo.getParameterCount();
        if (callingStoredFunction) {
          parameterCountFromMetaData--;
        }
        PreparedQuery<?> q = (PreparedQuery)query;
        if ((paramInfo != null) && (q.getParameterCount() != parameterCountFromMetaData))
        {
          placeholderToParameterIndexMap = new int[q.getParameterCount()];
          
          int startPos = callingStoredFunction ? StringUtils.indexOfIgnoreCase(q.getOriginalSql(), "SELECT") : StringUtils.indexOfIgnoreCase(q.getOriginalSql(), "CALL");
          if (startPos != -1)
          {
            int parenOpenPos = q.getOriginalSql().indexOf('(', startPos + 4);
            if (parenOpenPos != -1)
            {
              int parenClosePos = StringUtils.indexOfIgnoreCase(parenOpenPos, q.getOriginalSql(), ")", "'", "'", StringUtils.SEARCH_MODE__ALL);
              if (parenClosePos != -1)
              {
                List<?> parsedParameters = StringUtils.split(q.getOriginalSql().substring(parenOpenPos + 1, parenClosePos), ",", "'\"", "'\"", true);
                
                int numParsedParameters = parsedParameters.size();
                if (numParsedParameters != q.getParameterCount()) {}
                int placeholderCount = 0;
                for (int i = 0; i < numParsedParameters; i++) {
                  if (((String)parsedParameters.get(i)).equals("?")) {
                    placeholderToParameterIndexMap[(placeholderCount++)] = i;
                  }
                }
              }
            }
          }
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public CallableStatement(JdbcConnection conn, String sql, String db, boolean isFunctionCall)
    throws SQLException
  {
    super(conn, sql, db);
    
    callingStoredFunction = isFunctionCall;
    if (!callingStoredFunction)
    {
      if (!StringUtils.startsWithIgnoreCaseAndWs(sql, "CALL")) {
        fakeParameterTypes(false);
      } else {
        determineParameterTypes();
      }
      generateParameterMap();
    }
    else
    {
      determineParameterTypes();
      generateParameterMap();
      
      ((PreparedQuery)query).setParameterCount(((PreparedQuery)query).getParameterCount() + 1);
    }
    retrieveGeneratedKeys = true;
    noAccessToProcedureBodies = ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.noAccessToProcedureBodies).getValue()).booleanValue();
  }
  
  public void addBatch()
    throws SQLException
  {
    try
    {
      setOutParams();
      
      super.addBatch();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private CallableStatementParam checkIsOutputParam(int paramIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (callingStoredFunction)
        {
          if (paramIndex == 1)
          {
            if (returnValueParam == null) {
              returnValueParam = new CallableStatementParam("", 0, false, true, MysqlType.VARCHAR.getJdbcType(), "VARCHAR", 0, 0, (short)2, 5);
            }
            return returnValueParam;
          }
          paramIndex--;
        }
        checkParameterIndexBounds(paramIndex);
        
        int localParamIndex = paramIndex - 1;
        if (placeholderToParameterIndexMap != null) {
          localParamIndex = placeholderToParameterIndexMap[localParamIndex];
        }
        CallableStatementParam paramDescriptor = paramInfo.getParameter(localParamIndex);
        if (noAccessToProcedureBodies)
        {
          isOut = true;
          isIn = true;
          inOutModifier = 2;
        }
        else if (!isOut)
        {
          throw SQLError.createSQLException(Messages.getString("CallableStatement.9", new Object[] { Integer.valueOf(paramIndex) }), "S1009", 
            getExceptionInterceptor());
        }
        hasOutputParams = true;
        
        return paramDescriptor;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void checkParameterIndexBounds(int paramIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        paramInfo.checkBounds(paramIndex);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void checkStreamability()
    throws SQLException
  {
    if ((hasOutputParams) && (createStreamingResultSet())) {
      throw SQLError.createSQLException(Messages.getString("CallableStatement.14"), "S1C00", 
        getExceptionInterceptor());
    }
  }
  
  /* Error */
  public void clearParameters()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 34	com/mysql/cj/jdbc/CallableStatement:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 35 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: invokespecial 87	com/mysql/cj/jdbc/ClientPreparedStatement:clearParameters	()V
    //   16: aload_0
    //   17: getfield 88	com/mysql/cj/jdbc/CallableStatement:outputParameterResults	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   20: ifnull +12 -> 32
    //   23: aload_0
    //   24: getfield 88	com/mysql/cj/jdbc/CallableStatement:outputParameterResults	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   27: invokeinterface 89 1 0
    //   32: aload_0
    //   33: aconst_null
    //   34: putfield 88	com/mysql/cj/jdbc/CallableStatement:outputParameterResults	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   37: goto +11 -> 48
    //   40: astore_2
    //   41: aload_0
    //   42: aconst_null
    //   43: putfield 88	com/mysql/cj/jdbc/CallableStatement:outputParameterResults	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   46: aload_2
    //   47: athrow
    //   48: aload_1
    //   49: monitorexit
    //   50: goto +8 -> 58
    //   53: astore_3
    //   54: aload_1
    //   55: monitorexit
    //   56: aload_3
    //   57: athrow
    //   58: return
    //   59: astore 4
    //   61: aload 4
    //   63: aload_0
    //   64: invokevirtual 1438	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   67: invokestatic 1444	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   70: athrow
    // Line number table:
    //   Java source line #683	-> byte code offset #0
    //   Java source line #684	-> byte code offset #12
    //   Java source line #687	-> byte code offset #16
    //   Java source line #688	-> byte code offset #23
    //   Java source line #691	-> byte code offset #32
    //   Java source line #692	-> byte code offset #37
    //   Java source line #691	-> byte code offset #40
    //   Java source line #692	-> byte code offset #46
    //   Java source line #693	-> byte code offset #48
    //   Java source line #694	-> byte code offset #58
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	64	0	this	CallableStatement
    //   10	45	1	Ljava/lang/Object;	Object
    //   40	7	2	localObject1	Object
    //   53	4	3	localObject2	Object
    //   59	3	4	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   16	32	40	finally
    //   12	50	53	finally
    //   53	56	53	finally
    //   0	59	59	com/mysql/cj/exceptions/CJException
  }
  
  private void fakeParameterTypes(boolean isReallyProcedure)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        String encoding = connection.getSession().getServerSession().getCharacterSetMetadata();
        int collationIndex = connection.getSession().getServerSession().getMetadataCollationIndex();
        Field[] fields = new Field[13];
        
        fields[0] = new Field("", "PROCEDURE_CAT", collationIndex, encoding, MysqlType.CHAR, 0);
        fields[1] = new Field("", "PROCEDURE_SCHEM", collationIndex, encoding, MysqlType.CHAR, 0);
        fields[2] = new Field("", "PROCEDURE_NAME", collationIndex, encoding, MysqlType.CHAR, 0);
        fields[3] = new Field("", "COLUMN_NAME", collationIndex, encoding, MysqlType.CHAR, 0);
        fields[4] = new Field("", "COLUMN_TYPE", collationIndex, encoding, MysqlType.CHAR, 0);
        fields[5] = new Field("", "DATA_TYPE", collationIndex, encoding, MysqlType.SMALLINT, 0);
        fields[6] = new Field("", "TYPE_NAME", collationIndex, encoding, MysqlType.CHAR, 0);
        fields[7] = new Field("", "PRECISION", collationIndex, encoding, MysqlType.INT, 0);
        fields[8] = new Field("", "LENGTH", collationIndex, encoding, MysqlType.INT, 0);
        fields[9] = new Field("", "SCALE", collationIndex, encoding, MysqlType.SMALLINT, 0);
        fields[10] = new Field("", "RADIX", collationIndex, encoding, MysqlType.SMALLINT, 0);
        fields[11] = new Field("", "NULLABLE", collationIndex, encoding, MysqlType.SMALLINT, 0);
        fields[12] = new Field("", "REMARKS", collationIndex, encoding, MysqlType.CHAR, 0);
        
        String procName = isReallyProcedure ? extractProcedureName() : null;
        
        byte[] procNameAsBytes = null;
        
        procNameAsBytes = procName == null ? null : StringUtils.getBytes(procName, "UTF-8");
        
        ArrayList<Row> resultRows = new ArrayList();
        for (int i = 0; i < ((PreparedQuery)query).getParameterCount(); i++)
        {
          byte[][] row = new byte[13][];
          row[0] = null;
          row[1] = null;
          row[2] = procNameAsBytes;
          row[3] = s2b(String.valueOf(i));
          
          row[4] = s2b(String.valueOf(1));
          
          row[5] = s2b(String.valueOf(MysqlType.VARCHAR.getJdbcType()));
          row[6] = s2b(MysqlType.VARCHAR.getName());
          row[7] = s2b(Integer.toString(65535));
          row[8] = s2b(Integer.toString(65535));
          row[9] = s2b(Integer.toString(0));
          row[10] = s2b(Integer.toString(10));
          
          row[11] = s2b(Integer.toString(2));
          
          row[12] = null;
          
          resultRows.add(new ByteArrayRow(row, getExceptionInterceptor()));
        }
        ResultSet paramTypesRs = resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(resultRows, new DefaultColumnDefinition(fields)));
        
        convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void determineParameterTypes()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSet paramTypesRs = null;
        try
        {
          String procName = extractProcedureName();
          String quotedId = session.getIdentifierQuoteString();
          
          List<?> parseList = StringUtils.splitDBdotName(procName, "", quotedId, session.getServerSession().isNoBackslashEscapesSet());
          String tmpDb = "";
          if (parseList.size() == 2)
          {
            tmpDb = (String)parseList.get(0);
            procName = (String)parseList.get(1);
          }
          DatabaseMetaData dbmd = connection.getMetaData();
          
          boolean useDb = false;
          if (tmpDb.length() <= 0) {
            useDb = true;
          }
          paramTypesRs = session.getPropertySet().getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? dbmd.getProcedureColumns(null, useDb ? getCurrentDatabase() : tmpDb, procName, "%") : dbmd.getProcedureColumns(useDb ? getCurrentDatabase() : tmpDb, null, procName, "%");
          
          boolean hasResults = false;
          try
          {
            if (paramTypesRs.next())
            {
              paramTypesRs.previous();
              hasResults = true;
            }
          }
          catch (Exception localException) {}
          if (hasResults) {
            convertGetProcedureColumnsToInternalDescriptors(paramTypesRs);
          } else {
            fakeParameterTypes(true);
          }
        }
        finally
        {
          SQLException sqlExRethrow;
          SQLException sqlExRethrow = null;
          if (paramTypesRs != null)
          {
            try
            {
              paramTypesRs.close();
            }
            catch (SQLException sqlEx)
            {
              sqlExRethrow = sqlEx;
            }
            paramTypesRs = null;
          }
          if (sqlExRethrow != null) {
            throw sqlExRethrow;
          }
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void convertGetProcedureColumnsToInternalDescriptors(ResultSet paramTypesRs)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        paramInfo = new CallableStatementParamInfo(paramTypesRs);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean execute()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        boolean returnVal = false;
        
        checkStreamability();
        
        setInOutParamsOnServer();
        setOutParams();
        
        returnVal = super.execute();
        if (callingStoredFunction)
        {
          functionReturnValueResults = results;
          functionReturnValueResults.next();
          results = null;
        }
        retrieveOutParams();
        if (!callingStoredFunction) {
          return returnVal;
        }
        return false;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet executeQuery()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        checkStreamability();
        
        ResultSet execResults = null;
        
        setInOutParamsOnServer();
        setOutParams();
        
        execResults = super.executeQuery();
        
        retrieveOutParams();
        
        return execResults;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int executeUpdate()
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(executeLargeUpdate());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private String extractProcedureName()
    throws SQLException
  {
    String sanitizedSql = StringUtils.stripComments(((PreparedQuery)query).getOriginalSql(), "`\"'", "`\"'", true, false, true, true);
    
    int endCallIndex = StringUtils.indexOfIgnoreCase(sanitizedSql, "CALL ");
    int offset = 5;
    if (endCallIndex == -1)
    {
      endCallIndex = StringUtils.indexOfIgnoreCase(sanitizedSql, "SELECT ");
      offset = 7;
    }
    if (endCallIndex != -1)
    {
      StringBuilder nameBuf = new StringBuilder();
      
      String trimmedStatement = sanitizedSql.substring(endCallIndex + offset).trim();
      
      int statementLength = trimmedStatement.length();
      for (int i = 0; i < statementLength; i++)
      {
        char c = trimmedStatement.charAt(i);
        if ((Character.isWhitespace(c)) || (c == '(') || (c == '?')) {
          break;
        }
        nameBuf.append(c);
      }
      return nameBuf.toString();
    }
    throw SQLError.createSQLException(Messages.getString("CallableStatement.1"), "S1000", getExceptionInterceptor());
  }
  
  protected String fixParameterName(String paramNameIn)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (paramNameIn == null) {
          paramNameIn = "nullpn";
        }
        if (noAccessToProcedureBodies) {
          throw SQLError.createSQLException(Messages.getString("CallableStatement.23"), "S1009", 
            getExceptionInterceptor());
        }
        return mangleParameterName(paramNameIn);
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Array getArray(int i)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(i);
        
        Array retValue = rs.getArray(mapOutputParameterIndexToRsIndex(i));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Array getArray(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Array retValue = rs.getArray(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public BigDecimal getBigDecimal(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  @Deprecated
  public BigDecimal getBigDecimal(int parameterIndex, int scale)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        BigDecimal retValue = rs.getBigDecimal(mapOutputParameterIndexToRsIndex(parameterIndex), scale);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public BigDecimal getBigDecimal(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        BigDecimal retValue = rs.getBigDecimal(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Blob getBlob(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Blob retValue = rs.getBlob(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Blob getBlob(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Blob retValue = rs.getBlob(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean getBoolean(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        boolean retValue = rs.getBoolean(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean getBoolean(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        boolean retValue = rs.getBoolean(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public byte getByte(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        byte retValue = rs.getByte(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public byte getByte(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        byte retValue = rs.getByte(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public byte[] getBytes(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        byte[] retValue = rs.getBytes(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public byte[] getBytes(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        byte[] retValue = rs.getBytes(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Clob getClob(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Clob retValue = rs.getClob(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Clob getClob(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Clob retValue = rs.getClob(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Date getDate(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Date getDate(int parameterIndex, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Date retValue = rs.getDate(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Date getDate(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Date retValue = rs.getDate(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Date getDate(String parameterName, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Date retValue = rs.getDate(fixParameterName(parameterName), cal);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public double getDouble(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        double retValue = rs.getDouble(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public double getDouble(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        double retValue = rs.getDouble(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public float getFloat(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        float retValue = rs.getFloat(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public float getFloat(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        float retValue = rs.getFloat(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getInt(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        int retValue = rs.getInt(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getInt(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        int retValue = rs.getInt(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long getLong(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        long retValue = rs.getLong(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long getLong(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        long retValue = rs.getLong(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected int getNamedParamIndex(String paramName, boolean forOut)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (noAccessToProcedureBodies) {
          throw SQLError.createSQLException("No access to parameters by name when connection has been configured not to access procedure bodies", "S1009", 
            getExceptionInterceptor());
        }
        if ((paramName == null) || (paramName.length() == 0)) {
          throw SQLError.createSQLException(Messages.getString("CallableStatement.2"), "S1009", 
            getExceptionInterceptor());
        }
        CallableStatementParam namedParamInfo;
        if ((paramInfo == null) || ((namedParamInfo = paramInfo.getParameter(paramName)) == null)) {
          throw SQLError.createSQLException(Messages.getString("CallableStatement.3", new Object[] { paramName }), "S1009", 
            getExceptionInterceptor());
        }
        CallableStatementParam namedParamInfo;
        if ((forOut) && (!isOut)) {
          throw SQLError.createSQLException(Messages.getString("CallableStatement.5", new Object[] { paramName }), "S1009", 
            getExceptionInterceptor());
        }
        if (placeholderToParameterIndexMap == null) {
          return index + 1;
        }
        for (int i = 0; i < placeholderToParameterIndexMap.length; i++) {
          if (placeholderToParameterIndexMap[i] == index) {
            return i + 1;
          }
        }
        throw SQLError.createSQLException(Messages.getString("CallableStatement.6", new Object[] { paramName }), "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObject(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
        
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Object retVal = rs.getObjectStoredProc(mapOutputParameterIndexToRsIndex(parameterIndex), desiredMysqlType.getJdbcType());
        
        outputParamWasNull = rs.wasNull();
        
        return retVal;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObject(int parameterIndex, Map<String, Class<?>> map)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Object retVal = rs.getObject(mapOutputParameterIndexToRsIndex(parameterIndex), map);
        
        outputParamWasNull = rs.wasNull();
        
        return retVal;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObject(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Object retValue = rs.getObject(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObject(String parameterName, Map<String, Class<?>> map)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Object retValue = rs.getObject(fixParameterName(parameterName), map);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T getObject(int parameterIndex, Class<T> type)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        T retVal = ((ResultSetImpl)rs).getObject(mapOutputParameterIndexToRsIndex(parameterIndex), type);
        
        outputParamWasNull = rs.wasNull();
        
        return retVal;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T getObject(String parameterName, Class<T> type)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        T retValue = ((ResultSetImpl)rs).getObject(fixParameterName(parameterName), type);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected ResultSetInternalMethods getOutputParameters(int paramIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        outputParamWasNull = false;
        if ((paramIndex == 1) && (callingStoredFunction) && (returnValueParam != null)) {
          return functionReturnValueResults;
        }
        if (outputParameterResults == null)
        {
          if (paramInfo.numberOfParameters() == 0) {
            throw SQLError.createSQLException(Messages.getString("CallableStatement.7"), "S1009", 
              getExceptionInterceptor());
          }
          throw SQLError.createSQLException(Messages.getString("CallableStatement.8"), "S1000", 
            getExceptionInterceptor());
        }
        return outputParameterResults;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ParameterMetaData getParameterMetaData()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (placeholderToParameterIndexMap == null) {
          return paramInfo;
        }
        return new CallableStatementParamInfo(paramInfo);
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Ref getRef(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Ref retValue = rs.getRef(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Ref getRef(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Ref retValue = rs.getRef(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public short getShort(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        short retValue = rs.getShort(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public short getShort(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        short retValue = rs.getShort(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getString(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        String retValue = rs.getString(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getString(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        String retValue = rs.getString(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Time getTime(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Time getTime(int parameterIndex, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Time retValue = rs.getTime(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Time getTime(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Time retValue = rs.getTime(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Time getTime(String parameterName, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Time retValue = rs.getTime(fixParameterName(parameterName), cal);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Timestamp getTimestamp(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Timestamp getTimestamp(int parameterIndex, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        Timestamp retValue = rs.getTimestamp(mapOutputParameterIndexToRsIndex(parameterIndex), cal);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Timestamp getTimestamp(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Timestamp getTimestamp(String parameterName, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        Timestamp retValue = rs.getTimestamp(fixParameterName(parameterName), cal);
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public URL getURL(int parameterIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
        
        URL retValue = rs.getURL(mapOutputParameterIndexToRsIndex(parameterIndex));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public URL getURL(String parameterName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ResultSetInternalMethods rs = getOutputParameters(0);
        
        URL retValue = rs.getURL(fixParameterName(parameterName));
        
        outputParamWasNull = rs.wasNull();
        
        return retValue;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected int mapOutputParameterIndexToRsIndex(int paramIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if ((returnValueParam != null) && (paramIndex == 1)) {
          return 1;
        }
        checkParameterIndexBounds(paramIndex);
        
        int localParamIndex = paramIndex - 1;
        if (placeholderToParameterIndexMap != null) {
          localParamIndex = placeholderToParameterIndexMap[localParamIndex];
        }
        int rsIndex = parameterIndexToRsIndex[localParamIndex];
        if (rsIndex == Integer.MIN_VALUE) {
          throw SQLError.createSQLException(Messages.getString("CallableStatement.21", new Object[] { Integer.valueOf(paramIndex) }), "S1009", 
            getExceptionInterceptor());
        }
        return rsIndex + 1;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void registerOutParameter(int parameterIndex, MysqlType mysqlType)
    throws SQLException
  {
    CallableStatementParam paramDescriptor = checkIsOutputParam(parameterIndex);
    desiredMysqlType = mysqlType;
  }
  
  public void registerOutParameter(int parameterIndex, int sqlType)
    throws SQLException
  {
    try
    {
      try
      {
        MysqlType mt = MysqlType.getByJdbcType(sqlType);
        registerOutParameter(parameterIndex, mt);
      }
      catch (FeatureNotAvailableException nae)
      {
        throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(sqlType), "S1C00", 
          getExceptionInterceptor());
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(int parameterIndex, SQLType sqlType)
    throws SQLException
  {
    try
    {
      if ((sqlType instanceof MysqlType)) {
        registerOutParameter(parameterIndex, (MysqlType)sqlType);
      } else {
        registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue());
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void registerOutParameter(int parameterIndex, MysqlType mysqlType, int scale)
    throws SQLException
  {
    registerOutParameter(parameterIndex, mysqlType);
  }
  
  public void registerOutParameter(int parameterIndex, int sqlType, int scale)
    throws SQLException
  {
    try
    {
      registerOutParameter(parameterIndex, sqlType);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(int parameterIndex, SQLType sqlType, int scale)
    throws SQLException
  {
    try
    {
      if ((sqlType instanceof MysqlType)) {
        registerOutParameter(parameterIndex, (MysqlType)sqlType, scale);
      } else {
        registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue(), scale);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void registerOutParameter(int parameterIndex, MysqlType mysqlType, String typeName)
    throws SQLException
  {
    registerOutParameter(parameterIndex, mysqlType);
  }
  
  public void registerOutParameter(int parameterIndex, int sqlType, String typeName)
    throws SQLException
  {
    try
    {
      try
      {
        MysqlType mt = MysqlType.getByJdbcType(sqlType);
        registerOutParameter(parameterIndex, mt, typeName);
      }
      catch (FeatureNotAvailableException nae)
      {
        throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(sqlType), "S1C00", 
          getExceptionInterceptor());
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(int parameterIndex, SQLType sqlType, String typeName)
    throws SQLException
  {
    try
    {
      if ((sqlType instanceof MysqlType)) {
        registerOutParameter(parameterIndex, (MysqlType)sqlType, typeName);
      } else {
        registerOutParameter(parameterIndex, sqlType.getVendorTypeNumber().intValue(), typeName);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(String parameterName, int sqlType)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        registerOutParameter(getNamedParamIndex(parameterName, true), sqlType);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(String parameterName, SQLType sqlType)
    throws SQLException
  {
    try
    {
      if ((sqlType instanceof MysqlType)) {
        registerOutParameter(getNamedParamIndex(parameterName, true), (MysqlType)sqlType);
      } else {
        registerOutParameter(getNamedParamIndex(parameterName, true), sqlType.getVendorTypeNumber().intValue());
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(String parameterName, int sqlType, int scale)
    throws SQLException
  {
    try
    {
      registerOutParameter(getNamedParamIndex(parameterName, true), sqlType, scale);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(String parameterName, SQLType sqlType, int scale)
    throws SQLException
  {
    try
    {
      if ((sqlType instanceof MysqlType)) {
        registerOutParameter(getNamedParamIndex(parameterName, true), (MysqlType)sqlType, scale);
      } else {
        registerOutParameter(getNamedParamIndex(parameterName, true), sqlType.getVendorTypeNumber().intValue(), scale);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(String parameterName, int sqlType, String typeName)
    throws SQLException
  {
    try
    {
      registerOutParameter(getNamedParamIndex(parameterName, true), sqlType, typeName);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void registerOutParameter(String parameterName, SQLType sqlType, String typeName)
    throws SQLException
  {
    try
    {
      if ((sqlType instanceof MysqlType)) {
        registerOutParameter(getNamedParamIndex(parameterName, true), (MysqlType)sqlType, typeName);
      } else {
        registerOutParameter(parameterName, sqlType.getVendorTypeNumber().intValue(), typeName);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void retrieveOutParams()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        int numParameters = paramInfo.numberOfParameters();
        
        parameterIndexToRsIndex = new int[numParameters];
        for (int i = 0; i < numParameters; i++) {
          parameterIndexToRsIndex[i] = Integer.MIN_VALUE;
        }
        int localParamIndex = 0;
        if (numParameters > 0)
        {
          StringBuilder outParameterQuery = new StringBuilder("SELECT ");
          
          boolean firstParam = true;
          boolean hadOutputParams = false;
          for (Iterator<CallableStatementParam> paramIter = paramInfo.iterator(); paramIter.hasNext();)
          {
            CallableStatementParam retrParamInfo = (CallableStatementParam)paramIter.next();
            if (isOut)
            {
              hadOutputParams = true;
              
              parameterIndexToRsIndex[index] = (localParamIndex++);
              if (paramName == null) {
                paramName = ("nullnp" + index);
              }
              String outParameterName = mangleParameterName(paramName);
              if (!firstParam) {
                outParameterQuery.append(",");
              } else {
                firstParam = false;
              }
              if (!outParameterName.startsWith("@")) {
                outParameterQuery.append('@');
              }
              outParameterQuery.append(outParameterName);
            }
          }
          if (hadOutputParams)
          {
            Statement outParameterStmt = null;
            ResultSet outParamRs = null;
            try
            {
              outParameterStmt = connection.createStatement();
              outParamRs = outParameterStmt.executeQuery(outParameterQuery.toString());
              outputParameterResults = resultSetFactory.createFromResultsetRows(outParamRs.getConcurrency(), outParamRs.getType(), ((ResultSetInternalMethods)outParamRs)
                .getRows());
              if (!outputParameterResults.next())
              {
                outputParameterResults.close();
                outputParameterResults = null;
              }
            }
            finally
            {
              if (outParameterStmt != null) {
                outParameterStmt.close();
              }
            }
          }
          else
          {
            outputParameterResults = null;
          }
        }
        else
        {
          outputParameterResults = null;
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setAsciiStream(String parameterName, InputStream x, int length)
    throws SQLException
  {
    try
    {
      setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBigDecimal(String parameterName, BigDecimal x)
    throws SQLException
  {
    try
    {
      setBigDecimal(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBinaryStream(String parameterName, InputStream x, int length)
    throws SQLException
  {
    try
    {
      setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBoolean(String parameterName, boolean x)
    throws SQLException
  {
    try
    {
      setBoolean(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setByte(String parameterName, byte x)
    throws SQLException
  {
    try
    {
      setByte(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBytes(String parameterName, byte[] x)
    throws SQLException
  {
    try
    {
      setBytes(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setCharacterStream(String parameterName, Reader reader, int length)
    throws SQLException
  {
    try
    {
      setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setDate(String parameterName, Date x)
    throws SQLException
  {
    try
    {
      setDate(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setDate(String parameterName, Date x, Calendar cal)
    throws SQLException
  {
    try
    {
      setDate(getNamedParamIndex(parameterName, false), x, cal);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setDouble(String parameterName, double x)
    throws SQLException
  {
    try
    {
      setDouble(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setFloat(String parameterName, float x)
    throws SQLException
  {
    try
    {
      setFloat(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void setInOutParamsOnServer()
    throws SQLException
  {
    try
    {
      Iterator<CallableStatementParam> paramIter;
      synchronized (checkClosed().getConnectionMutex())
      {
        if (paramInfo.numParameters > 0) {
          for (paramIter = paramInfo.iterator(); paramIter.hasNext();)
          {
            CallableStatementParam inParamInfo = (CallableStatementParam)paramIter.next();
            if ((isOut) && (isIn))
            {
              if (paramName == null) {
                paramName = ("nullnp" + index);
              }
              String inOutParameterName = mangleParameterName(paramName);
              StringBuilder queryBuf = new StringBuilder(4 + inOutParameterName.length() + 1 + 1);
              queryBuf.append("SET ");
              queryBuf.append(inOutParameterName);
              queryBuf.append("=?");
              
              ClientPreparedStatement setPstmt = null;
              try
              {
                setPstmt = (ClientPreparedStatement)connection.clientPrepareStatement(queryBuf.toString()).unwrap(ClientPreparedStatement.class);
                if (((PreparedQuery)query).getQueryBindings().getBindValues()[index].isNull())
                {
                  setPstmt.setBytesNoEscapeNoQuotes(1, "NULL".getBytes());
                }
                else
                {
                  byte[] parameterAsBytes = getBytesRepresentation(index + 1);
                  if (parameterAsBytes != null)
                  {
                    if ((parameterAsBytes.length > 8) && (parameterAsBytes[0] == 95) && (parameterAsBytes[1] == 98) && (parameterAsBytes[2] == 105) && (parameterAsBytes[3] == 110) && (parameterAsBytes[4] == 97) && (parameterAsBytes[5] == 114) && (parameterAsBytes[6] == 121) && (parameterAsBytes[7] == 39)) {
                      setPstmt.setBytesNoEscapeNoQuotes(1, parameterAsBytes);
                    } else {
                      switch (desiredMysqlType)
                      {
                      case BIT: 
                      case BINARY: 
                      case GEOMETRY: 
                      case TINYBLOB: 
                      case BLOB: 
                      case MEDIUMBLOB: 
                      case LONGBLOB: 
                      case VARBINARY: 
                        setPstmt.setBytes(1, parameterAsBytes);
                        break;
                      default: 
                        setPstmt.setBytesNoEscape(1, parameterAsBytes);break;
                      }
                    }
                  }
                  else {
                    setPstmt.setNull(1, MysqlType.NULL);
                  }
                }
                setPstmt.executeUpdate();
              }
              finally
              {
                if (setPstmt != null) {
                  setPstmt.close();
                }
              }
            }
          }
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setInt(String parameterName, int x)
    throws SQLException
  {
    try
    {
      setInt(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setLong(String parameterName, long x)
    throws SQLException
  {
    try
    {
      setLong(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNull(String parameterName, int sqlType)
    throws SQLException
  {
    try
    {
      setNull(getNamedParamIndex(parameterName, false), sqlType);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNull(String parameterName, int sqlType, String typeName)
    throws SQLException
  {
    try
    {
      setNull(getNamedParamIndex(parameterName, false), sqlType, typeName);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(String parameterName, Object x)
    throws SQLException
  {
    try
    {
      setObject(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(String parameterName, Object x, int targetSqlType)
    throws SQLException
  {
    try
    {
      setObject(getNamedParamIndex(parameterName, false), x, targetSqlType);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(String parameterName, Object x, SQLType targetSqlType)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        setObject(getNamedParamIndex(parameterName, false), x, targetSqlType);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(String parameterName, Object x, int targetSqlType, int scale)
    throws SQLException
  {
    try
    {
      setObject(getNamedParamIndex(parameterName, false), x, targetSqlType, scale);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(String parameterName, Object x, SQLType targetSqlType, int scaleOrLength)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        setObject(getNamedParamIndex(parameterName, false), x, targetSqlType, scaleOrLength);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void setOutParams()
    throws SQLException
  {
    try
    {
      Iterator<CallableStatementParam> paramIter;
      synchronized (checkClosed().getConnectionMutex())
      {
        if (paramInfo.numParameters > 0) {
          for (paramIter = paramInfo.iterator(); paramIter.hasNext();)
          {
            CallableStatementParam outParamInfo = (CallableStatementParam)paramIter.next();
            if ((!callingStoredFunction) && (isOut))
            {
              if (paramName == null) {
                paramName = ("nullnp" + index);
              }
              String outParameterName = mangleParameterName(paramName);
              
              int outParamIndex = 0;
              if (placeholderToParameterIndexMap == null)
              {
                outParamIndex = index + 1;
              }
              else
              {
                boolean found = false;
                for (int i = 0; i < placeholderToParameterIndexMap.length; i++) {
                  if (placeholderToParameterIndexMap[i] == index)
                  {
                    outParamIndex = i + 1;
                    found = true;
                    break;
                  }
                }
                if (!found) {
                  throw SQLError.createSQLException(Messages.getString("CallableStatement.21", new Object[] { paramName }), "S1009", 
                    getExceptionInterceptor());
                }
              }
              setBytesNoEscapeNoQuotes(outParamIndex, StringUtils.getBytes(outParameterName, charEncoding));
            }
          }
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setShort(String parameterName, short x)
    throws SQLException
  {
    try
    {
      setShort(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setString(String parameterName, String x)
    throws SQLException
  {
    try
    {
      setString(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTime(String parameterName, Time x)
    throws SQLException
  {
    try
    {
      setTime(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTime(String parameterName, Time x, Calendar cal)
    throws SQLException
  {
    try
    {
      setTime(getNamedParamIndex(parameterName, false), x, cal);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTimestamp(String parameterName, Timestamp x)
    throws SQLException
  {
    try
    {
      setTimestamp(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTimestamp(String parameterName, Timestamp x, Calendar cal)
    throws SQLException
  {
    try
    {
      setTimestamp(getNamedParamIndex(parameterName, false), x, cal);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setURL(String parameterName, URL val)
    throws SQLException
  {
    try
    {
      setURL(getNamedParamIndex(parameterName, false), val);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public boolean wasNull()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 34	com/mysql/cj/jdbc/CallableStatement:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 35 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 17	com/mysql/cj/jdbc/CallableStatement:outputParamWasNull	Z
    //   16: aload_1
    //   17: monitorexit
    //   18: ireturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1438	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 1444	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #2157	-> byte code offset #0
    //   Java source line #2158	-> byte code offset #12
    //   Java source line #2159	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	CallableStatement
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  public int[] executeBatch()
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(executeLargeBatch());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected int getParameterIndexOffset()
  {
    if (callingStoredFunction) {
      return -1;
    }
    return super.getParameterIndexOffset();
  }
  
  public void setAsciiStream(String parameterName, InputStream x)
    throws SQLException
  {
    try
    {
      setAsciiStream(getNamedParamIndex(parameterName, false), x);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setAsciiStream(String parameterName, InputStream x, long length)
    throws SQLException
  {
    try
    {
      setAsciiStream(getNamedParamIndex(parameterName, false), x, length);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBinaryStream(String parameterName, InputStream x)
    throws SQLException
  {
    try
    {
      setBinaryStream(getNamedParamIndex(parameterName, false), x);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBinaryStream(String parameterName, InputStream x, long length)
    throws SQLException
  {
    try
    {
      setBinaryStream(getNamedParamIndex(parameterName, false), x, length);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBlob(String parameterName, Blob x)
    throws SQLException
  {
    try
    {
      setBlob(getNamedParamIndex(parameterName, false), x);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBlob(String parameterName, InputStream inputStream)
    throws SQLException
  {
    try
    {
      setBlob(getNamedParamIndex(parameterName, false), inputStream);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBlob(String parameterName, InputStream inputStream, long length)
    throws SQLException
  {
    try
    {
      setBlob(getNamedParamIndex(parameterName, false), inputStream, length);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setCharacterStream(String parameterName, Reader reader)
    throws SQLException
  {
    try
    {
      setCharacterStream(getNamedParamIndex(parameterName, false), reader);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setCharacterStream(String parameterName, Reader reader, long length)
    throws SQLException
  {
    try
    {
      setCharacterStream(getNamedParamIndex(parameterName, false), reader, length);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setClob(String parameterName, Clob x)
    throws SQLException
  {
    try
    {
      setClob(getNamedParamIndex(parameterName, false), x);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setClob(String parameterName, Reader reader)
    throws SQLException
  {
    try
    {
      setClob(getNamedParamIndex(parameterName, false), reader);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setClob(String parameterName, Reader reader, long length)
    throws SQLException
  {
    try
    {
      setClob(getNamedParamIndex(parameterName, false), reader, length);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNCharacterStream(String parameterName, Reader value)
    throws SQLException
  {
    try
    {
      setNCharacterStream(getNamedParamIndex(parameterName, false), value);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNCharacterStream(String parameterName, Reader value, long length)
    throws SQLException
  {
    try
    {
      setNCharacterStream(getNamedParamIndex(parameterName, false), value, length);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private boolean checkReadOnlyProcedure()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (noAccessToProcedureBodies) {
          return false;
        }
        if (paramInfo.isReadOnlySafeChecked) {
          return paramInfo.isReadOnlySafeProcedure;
        }
        ResultSet rs = null;
        PreparedStatement ps = null;
        try
        {
          String procName = extractProcedureName();
          
          String db = getCurrentDatabase();
          if (procName.indexOf(".") != -1)
          {
            db = procName.substring(0, procName.indexOf("."));
            if ((StringUtils.startsWithIgnoreCaseAndWs(db, "`")) && (db.trim().endsWith("`"))) {
              db = db.substring(1, db.length() - 1);
            }
            procName = procName.substring(procName.indexOf(".") + 1);
            procName = StringUtils.toString(StringUtils.stripEnclosure(StringUtils.getBytes(procName), "`", "`"));
          }
          ps = connection.prepareStatement("SELECT SQL_DATA_ACCESS FROM information_schema.routines WHERE routine_schema = ? AND routine_name = ?");
          ps.setMaxRows(0);
          ps.setFetchSize(0);
          
          ps.setString(1, db);
          ps.setString(2, procName);
          rs = ps.executeQuery();
          if (rs.next())
          {
            String sqlDataAccess = rs.getString(1);
            if (("READS SQL DATA".equalsIgnoreCase(sqlDataAccess)) || ("NO SQL".equalsIgnoreCase(sqlDataAccess)))
            {
              synchronized (paramInfo)
              {
                paramInfo.isReadOnlySafeChecked = true;
                paramInfo.isReadOnlySafeProcedure = true;
              }
              ??? = 1;
              if (rs != null) {
                rs.close();
              }
              if (ps != null) {
                ps.close();
              }
              return ???;
            }
          }
        }
        catch (SQLException localSQLException) {}finally
        {
          if (rs != null) {
            rs.close();
          }
          if (ps != null) {
            ps.close();
          }
        }
        paramInfo.isReadOnlySafeChecked = false;
        paramInfo.isReadOnlySafeProcedure = false;
      }
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected boolean checkReadOnlySafeStatement()
    throws SQLException
  {
    return (super.checkReadOnlySafeStatement()) || (checkReadOnlyProcedure());
  }
  
  public RowId getRowId(int parameterIndex)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
      
      RowId retValue = rs.getRowId(mapOutputParameterIndexToRsIndex(parameterIndex));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public RowId getRowId(String parameterName)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(0);
      
      RowId retValue = rs.getRowId(fixParameterName(parameterName));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setRowId(String parameterName, RowId x)
    throws SQLException
  {
    try
    {
      setRowId(getNamedParamIndex(parameterName, false), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNString(String parameterName, String value)
    throws SQLException
  {
    try
    {
      setNString(getNamedParamIndex(parameterName, false), value);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNClob(String parameterName, NClob value)
    throws SQLException
  {
    try
    {
      setNClob(getNamedParamIndex(parameterName, false), value);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNClob(String parameterName, Reader reader)
    throws SQLException
  {
    try
    {
      setNClob(getNamedParamIndex(parameterName, false), reader);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNClob(String parameterName, Reader reader, long length)
    throws SQLException
  {
    try
    {
      setNClob(getNamedParamIndex(parameterName, false), reader, length);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setSQLXML(String parameterName, SQLXML xmlObject)
    throws SQLException
  {
    try
    {
      setSQLXML(getNamedParamIndex(parameterName, false), xmlObject);
      
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public SQLXML getSQLXML(int parameterIndex)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
      
      SQLXML retValue = rs.getSQLXML(mapOutputParameterIndexToRsIndex(parameterIndex));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public SQLXML getSQLXML(String parameterName)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(0);
      
      SQLXML retValue = rs.getSQLXML(fixParameterName(parameterName));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getNString(int parameterIndex)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
      
      String retValue = rs.getNString(mapOutputParameterIndexToRsIndex(parameterIndex));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getNString(String parameterName)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(0);
      String retValue = rs.getNString(fixParameterName(parameterName));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getNCharacterStream(int parameterIndex)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
      
      Reader retValue = rs.getNCharacterStream(mapOutputParameterIndexToRsIndex(parameterIndex));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getNCharacterStream(String parameterName)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(0);
      Reader retValue = rs.getNCharacterStream(fixParameterName(parameterName));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getCharacterStream(int parameterIndex)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
      
      Reader retValue = rs.getCharacterStream(mapOutputParameterIndexToRsIndex(parameterIndex));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getCharacterStream(String parameterName)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(0);
      
      Reader retValue = rs.getCharacterStream(fixParameterName(parameterName));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public NClob getNClob(int parameterIndex)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(parameterIndex);
      
      NClob retValue = rs.getNClob(mapOutputParameterIndexToRsIndex(parameterIndex));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public NClob getNClob(String parameterName)
    throws SQLException
  {
    try
    {
      ResultSetInternalMethods rs = getOutputParameters(0);
      
      NClob retValue = rs.getNClob(fixParameterName(parameterName));
      
      outputParamWasNull = rs.wasNull();
      
      return retValue;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected byte[] s2b(String s)
  {
    return s == null ? null : StringUtils.getBytes(s, charEncoding);
  }
  
  public long executeLargeUpdate()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        long returnVal = -1L;
        
        checkStreamability();
        if (callingStoredFunction)
        {
          execute();
          
          return -1L;
        }
        setInOutParamsOnServer();
        setOutParams();
        
        returnVal = super.executeLargeUpdate();
        
        retrieveOutParams();
        
        return returnVal;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long[] executeLargeBatch()
    throws SQLException
  {
    try
    {
      if (hasOutputParams) {
        throw SQLError.createSQLException("Can't call executeBatch() on CallableStatement with OUTPUT parameters", "S1009", 
          getExceptionInterceptor());
      }
      return super.executeLargeBatch();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.CallableStatement
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */