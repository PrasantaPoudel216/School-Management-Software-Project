package com.mysql.cj.jdbc;

import java.sql.Connection;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.util.Properties;

public abstract interface ClientInfoProvider
{
  public abstract void initialize(Connection paramConnection, Properties paramProperties)
    throws SQLException;
  
  public abstract void destroy()
    throws SQLException;
  
  public abstract Properties getClientInfo(Connection paramConnection)
    throws SQLException;
  
  public abstract String getClientInfo(Connection paramConnection, String paramString)
    throws SQLException;
  
  public abstract void setClientInfo(Connection paramConnection, Properties paramProperties)
    throws SQLClientInfoException;
  
  public abstract void setClientInfo(Connection paramConnection, String paramString1, String paramString2)
    throws SQLClientInfoException;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ClientInfoProvider
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */