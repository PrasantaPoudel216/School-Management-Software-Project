package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.util.StringUtils;
import java.sql.SQLException;
import java.util.StringTokenizer;

class DatabaseMetaData$TypeDescriptor
{
  int bufferLength;
  int charOctetLength;
  Integer datetimePrecision = null;
  Integer columnSize = null;
  Integer decimalDigits = null;
  String isNullable;
  int nullability;
  int numPrecRadix = 10;
  String mysqlTypeName;
  MysqlType mysqlType;
  
  DatabaseMetaData$TypeDescriptor(DatabaseMetaData this$0, String typeInfo, String nullabilityInfo)
    throws SQLException
  {
    if (typeInfo == null) {
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.0"), "S1009", this$0
        .getExceptionInterceptor());
    }
    mysqlType = MysqlType.getByName(typeInfo);
    
    int maxLength = 0;
    int endParenIndex;
    switch (DatabaseMetaData.11.$SwitchMap$com$mysql$cj$MysqlType[mysqlType.ordinal()])
    {
    case 7: 
      String temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
      StringTokenizer tokenizer = new StringTokenizer(temp, ",");
      while (tokenizer.hasMoreTokens())
      {
        String nextToken = tokenizer.nextToken();
        maxLength = Math.max(maxLength, nextToken.length() - 2);
      }
      columnSize = Integer.valueOf(maxLength);
      break;
    case 8: 
      String temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
      StringTokenizer tokenizer = new StringTokenizer(temp, ",");
      
      int numElements = tokenizer.countTokens();
      if (numElements > 0) {
        maxLength += numElements - 1;
      }
      while (tokenizer.hasMoreTokens())
      {
        String setMember = tokenizer.nextToken().trim();
        if ((setMember.startsWith("'")) && (setMember.endsWith("'"))) {
          maxLength += setMember.length() - 2;
        } else {
          maxLength += setMember.length();
        }
      }
      columnSize = Integer.valueOf(maxLength);
      break;
    case 1: 
    case 2: 
    case 3: 
    case 4: 
    case 5: 
    case 6: 
      if (typeInfo.indexOf(",") != -1)
      {
        columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(",")).trim());
        decimalDigits = Integer.valueOf(typeInfo.substring(typeInfo.indexOf(",") + 1, typeInfo.indexOf(")")).trim());
      }
      else
      {
        switch (DatabaseMetaData.11.$SwitchMap$com$mysql$cj$MysqlType[mysqlType.ordinal()])
        {
        case 1: 
        case 2: 
          columnSize = Integer.valueOf(65);
          break;
        case 3: 
        case 4: 
          columnSize = Integer.valueOf(12);
          break;
        case 5: 
        case 6: 
          columnSize = Integer.valueOf(22);
          break;
        }
        decimalDigits = Integer.valueOf(0);
      }
      break;
    case 9: 
    case 10: 
    case 11: 
    case 12: 
    case 13: 
    case 14: 
    case 15: 
    case 16: 
    case 17: 
    case 18: 
    case 19: 
    case 20: 
    case 21: 
    case 22: 
      if (mysqlType == MysqlType.CHAR) {
        columnSize = Integer.valueOf(1);
      }
      if (typeInfo.indexOf("(") != -1)
      {
        endParenIndex = typeInfo.indexOf(")");
        if (endParenIndex == -1) {
          endParenIndex = typeInfo.length();
        }
        columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, endParenIndex).trim());
        if ((tinyInt1isBit) && (columnSize.intValue() == 1) && 
          (StringUtils.startsWithIgnoreCase(typeInfo, 0, "tinyint"))) {
          if (transformedBitIsBoolean) {
            mysqlType = MysqlType.BOOLEAN;
          } else {
            mysqlType = MysqlType.BIT;
          }
        }
      }
      break;
    case 23: 
    case 24: 
      if ((tinyInt1isBit) && (typeInfo.indexOf("(1)") != -1))
      {
        if (transformedBitIsBoolean) {
          mysqlType = MysqlType.BOOLEAN;
        } else {
          mysqlType = MysqlType.BIT;
        }
      }
      else {
        columnSize = Integer.valueOf(3);
      }
      break;
    case 25: 
      datetimePrecision = Integer.valueOf(0);
      columnSize = Integer.valueOf(10);
      break;
    case 26: 
      datetimePrecision = Integer.valueOf(0);
      columnSize = Integer.valueOf(8);
      int fract;
      if ((typeInfo.indexOf("(") != -1) && 
        ((fract = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(")")).trim()).intValue()) > 0))
      {
        datetimePrecision = Integer.valueOf(fract);
        endParenIndex = this;(columnSize = Integer.valueOf(columnSize.intValue() + (fract + 1)));
      }
      break;
    case 27: 
    case 28: 
      datetimePrecision = Integer.valueOf(0);
      columnSize = Integer.valueOf(19);
      int fract;
      if ((typeInfo.indexOf("(") != -1) && 
        ((fract = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(")")).trim()).intValue()) > 0))
      {
        datetimePrecision = Integer.valueOf(fract);
        endParenIndex = this;(columnSize = Integer.valueOf(columnSize.intValue() + (fract + 1)));
      }
      break;
    }
    if (columnSize == null) {
      columnSize = Integer.valueOf(mysqlType.getPrecision().longValue() > 2147483647L ? Integer.MAX_VALUE : mysqlType.getPrecision().intValue());
    }
    bufferLength = DatabaseMetaData.maxBufferSize;
    
    numPrecRadix = 10;
    if (nullabilityInfo != null)
    {
      if (nullabilityInfo.equals("YES"))
      {
        nullability = 1;
        isNullable = "YES";
      }
      else if (nullabilityInfo.equals("UNKNOWN"))
      {
        nullability = 2;
        isNullable = "";
      }
      else
      {
        nullability = 0;
        isNullable = "NO";
      }
    }
    else
    {
      nullability = 0;
      isNullable = "NO";
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.TypeDescriptor
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */