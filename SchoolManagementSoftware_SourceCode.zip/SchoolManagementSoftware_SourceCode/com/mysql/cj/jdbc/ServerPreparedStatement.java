package com.mysql.cj.jdbc;

import com.mysql.cj.CancelQueryTask;
import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.NativeSession;
import com.mysql.cj.ParseInfo;
import com.mysql.cj.PreparedQuery;
import com.mysql.cj.Query;
import com.mysql.cj.QueryBindings;
import com.mysql.cj.ServerPreparedQuery;
import com.mysql.cj.ServerPreparedQueryBindValue;
import com.mysql.cj.ServerPreparedQueryBindings;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.jdbc.exceptions.MySQLStatementCancelledException;
import com.mysql.cj.jdbc.exceptions.MySQLTimeoutException;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.Resultset.Type;
import com.mysql.cj.protocol.a.NativeMessageBuilder;
import com.mysql.cj.protocol.a.NativeProtocol;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.sql.Date;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Wrapper;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class ServerPreparedStatement
  extends ClientPreparedStatement
{
  private boolean hasOnDuplicateKeyUpdate = false;
  private boolean invalid = false;
  private CJException invalidationException;
  protected boolean isCacheable = false;
  protected boolean isCached = false;
  
  protected static ServerPreparedStatement getInstance(JdbcConnection conn, String sql, String db, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    return new ServerPreparedStatement(conn, sql, db, resultSetType, resultSetConcurrency);
  }
  
  protected ServerPreparedStatement(JdbcConnection conn, String sql, String db, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    super(conn, db);
    
    checkNullOrEmptyQuery(sql);
    String statementComment = session.getProtocol().getQueryComment();
    ((PreparedQuery)query).setOriginalSql("/* " + statementComment + " */ " + sql);
    ((PreparedQuery)query).setParseInfo(new ParseInfo(((PreparedQuery)query).getOriginalSql(), session, charEncoding));
    
    hasOnDuplicateKeyUpdate = ((((PreparedQuery)query).getParseInfo().getFirstStmtChar() == 'I') && (containsOnDuplicateKeyInString(sql)));
    try
    {
      serverPrepare(sql);
    }
    catch (CJException|SQLException sqlEx)
    {
      realClose(false, true);
      
      throw SQLExceptionsMapping.translateException(sqlEx, exceptionInterceptor);
    }
    setResultSetType(resultSetType);
    setResultSetConcurrency(resultSetConcurrency);
  }
  
  protected void initQuery()
  {
    query = ServerPreparedQuery.getInstance(session);
  }
  
  public String toString()
  {
    StringBuilder toStringBuf = new StringBuilder();
    
    toStringBuf.append(getClass().getName() + "[");
    toStringBuf.append(((ServerPreparedQuery)query).getServerStatementId());
    toStringBuf.append("]: ");
    try
    {
      toStringBuf.append(asSql());
    }
    catch (SQLException sqlEx)
    {
      toStringBuf.append(Messages.getString("ServerPreparedStatement.6"));
      toStringBuf.append(sqlEx);
    }
    return toStringBuf.toString();
  }
  
  public void addBatch()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        query.addBatch(((PreparedQuery)query).getQueryBindings().clone());
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String asSql(boolean quoteStreamsAndUnknowns)
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      ClientPreparedStatement pStmtForSub = null;
      try
      {
        pStmtForSub = ClientPreparedStatement.getInstance(connection, ((PreparedQuery)query).getOriginalSql(), getCurrentDatabase());
        
        int numParameters = ((PreparedQuery)query).getParameterCount();
        int ourNumParameters = ((PreparedQuery)query).getParameterCount();
        
        ServerPreparedQueryBindValue[] parameterBindings = (ServerPreparedQueryBindValue[])((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).getBindValues();
        for (int i = 0; (i < numParameters) && (i < ourNumParameters); i++) {
          if (parameterBindings[i] != null) {
            if (parameterBindings[i].isNull())
            {
              pStmtForSub.setNull(i + 1, MysqlType.NULL);
            }
            else
            {
              ServerPreparedQueryBindValue bindValue = parameterBindings[i];
              switch (bufferType)
              {
              case 1: 
                pStmtForSub.setByte(i + 1, ((Long)value).byteValue());
                break;
              case 2: 
                pStmtForSub.setShort(i + 1, ((Long)value).shortValue());
                break;
              case 3: 
                pStmtForSub.setInt(i + 1, ((Long)value).intValue());
                break;
              case 8: 
                pStmtForSub.setLong(i + 1, ((Long)value).longValue());
                break;
              case 4: 
                pStmtForSub.setFloat(i + 1, ((Float)value).floatValue());
                break;
              case 5: 
                pStmtForSub.setDouble(i + 1, ((Double)value).doubleValue());
                break;
              case 6: 
              case 7: 
              default: 
                pStmtForSub.setObject(i + 1, value);
              }
            }
          }
        }
        i = pStmtForSub.asSql(quoteStreamsAndUnknowns);
        if (pStmtForSub != null) {
          try
          {
            pStmtForSub.close();
          }
          catch (SQLException localSQLException) {}
        }
        return i;
      }
      finally
      {
        if (pStmtForSub != null) {
          try
          {
            pStmtForSub.close();
          }
          catch (SQLException localSQLException1) {}
        }
      }
    }
  }
  
  protected JdbcConnection checkClosed()
  {
    if (invalid) {
      throw invalidationException;
    }
    return super.checkClosed();
  }
  
  public void clearParameters()
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((ServerPreparedQuery)query).clearParameters(true);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void setClosed(boolean flag)
  {
    isClosed = flag;
  }
  
  public void close()
    throws SQLException
  {
    try
    {
      JdbcConnection locallyScopedConn = connection;
      if (locallyScopedConn == null) {
        return;
      }
      synchronized (locallyScopedConn.getConnectionMutex())
      {
        if (isClosed) {
          return;
        }
        if ((isCacheable) && (isPoolable()))
        {
          clearParameters();
          
          isClosed = true;
          
          connection.recachePreparedStatement(this);
          isCached = true;
          return;
        }
        isClosed = false;
        realClose(true, true);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected long[] executeBatchSerially(int batchTimeout)
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      JdbcConnection locallyScopedConn = connection;
      if (locallyScopedConn.isReadOnly()) {
        throw SQLError.createSQLException(Messages.getString("ServerPreparedStatement.2") + Messages.getString("ServerPreparedStatement.3"), "S1009", exceptionInterceptor);
      }
      clearWarnings();
      
      ServerPreparedQueryBindValue[] oldBindValues = (ServerPreparedQueryBindValue[])((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).getBindValues();
      try
      {
        long[] updateCounts = null;
        if (query.getBatchedArgs() != null)
        {
          nbrCommands = query.getBatchedArgs().size();
          updateCounts = new long[nbrCommands];
          if (retrieveGeneratedKeys) {
            batchedGeneratedKeys = new ArrayList(nbrCommands);
          }
          for (int i = 0; i < nbrCommands; i++) {
            updateCounts[i] = -3L;
          }
          SQLException sqlEx = null;
          
          int commandIndex = 0;
          
          ServerPreparedQueryBindValue[] previousBindValuesForBatch = null;
          
          CancelQueryTask timeoutTask = null;
          try
          {
            timeoutTask = startQueryTimer(this, batchTimeout);
            for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++)
            {
              Object arg = query.getBatchedArgs().get(commandIndex);
              try
              {
                if ((arg instanceof String))
                {
                  updateCounts[commandIndex] = executeUpdateInternal((String)arg, true, retrieveGeneratedKeys);
                  
                  getBatchedGeneratedKeys((results.getFirstCharOfQuery() == 'I') && (containsOnDuplicateKeyInString((String)arg)) ? 1 : 0);
                }
                else
                {
                  ((ServerPreparedQuery)query).setQueryBindings((ServerPreparedQueryBindings)arg);
                  ServerPreparedQueryBindValue[] parameterBindings = (ServerPreparedQueryBindValue[])((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).getBindValues();
                  if (previousBindValuesForBatch != null) {
                    for (int j = 0; j < parameterBindings.length; j++) {
                      if (bufferType != bufferType)
                      {
                        ((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).getSendTypesToServer().set(true);
                        
                        break;
                      }
                    }
                  }
                  try
                  {
                    updateCounts[commandIndex] = executeUpdateInternal(false, true);
                  }
                  finally
                  {
                    previousBindValuesForBatch = parameterBindings;
                  }
                  getBatchedGeneratedKeys(containsOnDuplicateKeyUpdateInSQL() ? 1 : 0);
                }
              }
              catch (SQLException ex)
              {
                updateCounts[commandIndex] = -3L;
                if ((continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && 
                  (!hasDeadlockOrTimeoutRolledBackTx(ex)))
                {
                  sqlEx = ex;
                }
                else
                {
                  long[] newUpdateCounts = new long[commandIndex];
                  System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
                  
                  throw SQLError.createBatchUpdateException(ex, newUpdateCounts, exceptionInterceptor);
                }
              }
            }
          }
          finally
          {
            stopQueryTimer(timeoutTask, false, false);
            resetCancelledState();
          }
          if (sqlEx != null) {
            throw SQLError.createBatchUpdateException(sqlEx, updateCounts, exceptionInterceptor);
          }
        }
        int nbrCommands = updateCounts != null ? updateCounts : new long[0];
        
        ((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).setBindValues(oldBindValues);
        ((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).getSendTypesToServer().set(true);
        
        clearBatch();return nbrCommands;
      }
      finally
      {
        ((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).setBindValues(oldBindValues);
        ((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).getSendTypesToServer().set(true);
        
        clearBatch();
      }
    }
  }
  
  private static SQLException appendMessageToException(SQLException sqlEx, String messageToAppend, ExceptionInterceptor interceptor)
  {
    String sqlState = sqlEx.getSQLState();
    int vendorErrorCode = sqlEx.getErrorCode();
    
    SQLException sqlExceptionWithNewMessage = SQLError.createSQLException(sqlEx.getMessage() + messageToAppend, sqlState, vendorErrorCode, interceptor);
    sqlExceptionWithNewMessage.setStackTrace(sqlEx.getStackTrace());
    
    return sqlExceptionWithNewMessage;
  }
  
  protected <M extends Message> ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, M sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, ColumnDefinition metadata, boolean isBatch)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNumberOfExecutions(((PreparedQuery)query).getQueryBindings().getNumberOfExecutions() + 1);
        try
        {
          return serverExecute(maxRowsToRetrieve, createStreamingResultSet, metadata);
        }
        catch (SQLException sqlEx)
        {
          if (((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.enablePacketDebug).getValue()).booleanValue()) {
            session.dumpPacketRingBuffer();
          }
          if (((Boolean)dumpQueriesOnException.getValue()).booleanValue())
          {
            String extractedSql = toString();
            StringBuilder messageBuf = new StringBuilder(extractedSql.length() + 32);
            messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
            messageBuf.append(extractedSql);
            messageBuf.append("\n\n");
            
            sqlEx = appendMessageToException(sqlEx, messageBuf.toString(), exceptionInterceptor);
          }
          throw sqlEx;
        }
        catch (Exception ex)
        {
          if (((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.enablePacketDebug).getValue()).booleanValue()) {
            session.dumpPacketRingBuffer();
          }
          SQLException sqlEx = SQLError.createSQLException(ex.toString(), "S1000", ex, exceptionInterceptor);
          if (((Boolean)dumpQueriesOnException.getValue()).booleanValue())
          {
            String extractedSql = toString();
            StringBuilder messageBuf = new StringBuilder(extractedSql.length() + 32);
            messageBuf.append("\n\nQuery being executed when exception was thrown:\n");
            messageBuf.append(extractedSql);
            messageBuf.append("\n\n");
            
            sqlEx = appendMessageToException(sqlEx, messageBuf.toString(), exceptionInterceptor);
          }
          throw sqlEx;
        }
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected ServerPreparedQueryBindValue getBinding(int parameterIndex, boolean forLongData)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        int i = getCoreParameterIndex(parameterIndex);
        return ((ServerPreparedQueryBindings)((ServerPreparedQuery)query).getQueryBindings()).getBinding(i, forLongData);
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.ResultSetMetaData getMetaData()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ColumnDefinition resultFields = ((ServerPreparedQuery)query).getResultFields();
        
        return (resultFields == null) || (resultFields.getFields() == null) ? null : new com.mysql.cj.jdbc.result.ResultSetMetaData(session, resultFields
          .getFields(), 
          ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.useOldAliasMetadataBehavior).getValue()).booleanValue(), 
          ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue(), exceptionInterceptor);
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ParameterMetaData getParameterMetaData()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (parameterMetaData == null) {
          parameterMetaData = new MysqlParameterMetadata(session, ((ServerPreparedQuery)query).getParameterFields(), ((PreparedQuery)query).getParameterCount(), exceptionInterceptor);
        }
        return parameterMetaData;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isNull(int paramIndex)
  {
    throw new IllegalArgumentException(Messages.getString("ServerPreparedStatement.7"));
  }
  
  public void realClose(boolean calledExplicitly, boolean closeOpenResults)
    throws SQLException
  {
    try
    {
      JdbcConnection locallyScopedConn = connection;
      if (locallyScopedConn == null) {
        return;
      }
      synchronized (locallyScopedConn.getConnectionMutex())
      {
        if (connection != null)
        {
          CJException exceptionDuringClose = null;
          if ((calledExplicitly) && (!connection.isClosed())) {
            synchronized (connection.getConnectionMutex())
            {
              try
              {
                session.sendCommand(commandBuilder.buildComStmtClose(null, ((ServerPreparedQuery)query).getServerStatementId()), true, 0);
              }
              catch (CJException sqlEx)
              {
                exceptionDuringClose = sqlEx;
              }
            }
          }
          if (isCached)
          {
            connection.decachePreparedStatement(this);
            isCached = false;
          }
          super.realClose(calledExplicitly, closeOpenResults);
          
          ((ServerPreparedQuery)query).clearParameters(false);
          if (exceptionDuringClose != null) {
            throw exceptionDuringClose;
          }
        }
      }
      return;
    }
    catch (CJException localCJException1)
    {
      throw SQLExceptionsMapping.translateException(localCJException1, getExceptionInterceptor());
    }
  }
  
  protected void rePrepare()
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      invalidationException = null;
      try
      {
        serverPrepare(((PreparedQuery)query).getOriginalSql());
      }
      catch (Exception ex)
      {
        invalidationException = ExceptionFactory.createException(ex.getMessage(), ex);
      }
      if (invalidationException != null)
      {
        invalid = true;
        
        query.closeQuery();
        if (results != null) {
          try
          {
            results.close();
          }
          catch (Exception localException1) {}
        }
        if (generatedKeysResults != null) {
          try
          {
            generatedKeysResults.close();
          }
          catch (Exception localException2) {}
        }
        try
        {
          closeAllOpenResults();
        }
        catch (Exception localException3) {}
        if ((connection != null) && (!((Boolean)dontTrackOpenResources.getValue()).booleanValue())) {
          connection.unregisterStatement(this);
        }
      }
    }
  }
  
  protected ResultSetInternalMethods serverExecute(int maxRowsToRetrieve, boolean createStreamingResultSet, ColumnDefinition metadata)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        results = ((ResultSetInternalMethods)((ServerPreparedQuery)query).serverExecute(maxRowsToRetrieve, createStreamingResultSet, metadata, resultSetFactory));
        return results;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void serverPrepare(String sql)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        SQLException t = null;
        try
        {
          ServerPreparedQuery q = (ServerPreparedQuery)query;
          q.serverPrepare(sql);
        }
        catch (IOException ioEx)
        {
          t = SQLError.createCommunicationsException(connection, session.getProtocol().getPacketSentTimeHolder(), session
            .getProtocol().getPacketReceivedTimeHolder(), ioEx, exceptionInterceptor);
        }
        catch (CJException sqlEx)
        {
          SQLException ex = SQLExceptionsMapping.translateException(sqlEx);
          if (((Boolean)dumpQueriesOnException.getValue()).booleanValue())
          {
            StringBuilder messageBuf = new StringBuilder(((PreparedQuery)query).getOriginalSql().length() + 32);
            messageBuf.append("\n\nQuery being prepared when exception was thrown:\n\n");
            messageBuf.append(((PreparedQuery)query).getOriginalSql());
            
            ex = appendMessageToException(ex, messageBuf.toString(), exceptionInterceptor);
          }
          t = ex;
        }
        finally
        {
          try
          {
            session.clearInputStream();
          }
          catch (Exception e)
          {
            if (t == null) {
              t = SQLError.createCommunicationsException(connection, session.getProtocol().getPacketSentTimeHolder(), session
                .getProtocol().getPacketReceivedTimeHolder(), e, exceptionInterceptor);
            }
          }
          if (t != null) {
            throw t;
          }
        }
      }
      return;
    }
    catch (CJException localCJException1)
    {
      throw SQLExceptionsMapping.translateException(localCJException1, getExceptionInterceptor());
    }
  }
  
  protected void checkBounds(int parameterIndex, int parameterIndexOffset)
    throws SQLException
  {
    int paramCount = ((PreparedQuery)query).getParameterCount();
    if (paramCount == 0) {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("ServerPreparedStatement.8"), session
        .getExceptionInterceptor()));
    }
    if ((parameterIndex < 0) || (parameterIndex > paramCount)) {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
        Messages.getString("ServerPreparedStatement.9") + (parameterIndex + 1) + Messages.getString("ServerPreparedStatement.10") + paramCount, session
        .getExceptionInterceptor()));
    }
  }
  
  @Deprecated
  public void setUnicodeStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      checkClosed();
      
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setURL(int parameterIndex, URL x)
    throws SQLException
  {
    try
    {
      checkClosed();
      
      setString(parameterIndex, x.toString());
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long getServerStatementId()
  {
    return ((ServerPreparedQuery)query).getServerStatementId();
  }
  
  protected int setOneBatchedParameterSet(PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet)
    throws SQLException
  {
    ServerPreparedQueryBindValue[] paramArg = (ServerPreparedQueryBindValue[])((ServerPreparedQueryBindings)paramSet).getBindValues();
    for (int j = 0; j < paramArg.length; j++) {
      if (paramArg[j].isNull())
      {
        batchedStatement.setNull(batchedParamIndex++, MysqlType.NULL.getJdbcType());
      }
      else if (paramArg[j].isStream())
      {
        Object value = value;
        if ((value instanceof InputStream)) {
          batchedStatement.setBinaryStream(batchedParamIndex++, (InputStream)value, paramArg[j].getStreamLength());
        } else {
          batchedStatement.setCharacterStream(batchedParamIndex++, (Reader)value, paramArg[j].getStreamLength());
        }
      }
      else
      {
        switch (bufferType)
        {
        case 1: 
          batchedStatement.setByte(batchedParamIndex++, ((Long)value).byteValue());
          break;
        case 2: 
          batchedStatement.setShort(batchedParamIndex++, ((Long)value).shortValue());
          break;
        case 3: 
          batchedStatement.setInt(batchedParamIndex++, ((Long)value).intValue());
          break;
        case 8: 
          batchedStatement.setLong(batchedParamIndex++, ((Long)value).longValue());
          break;
        case 4: 
          batchedStatement.setFloat(batchedParamIndex++, ((Float)value).floatValue());
          break;
        case 5: 
          batchedStatement.setDouble(batchedParamIndex++, ((Double)value).doubleValue());
          break;
        case 11: 
          batchedStatement.setTime(batchedParamIndex++, (Time)value);
          break;
        case 10: 
          batchedStatement.setDate(batchedParamIndex++, (Date)value);
          break;
        case 7: 
        case 12: 
          batchedStatement.setTimestamp(batchedParamIndex++, (Timestamp)value);
          break;
        case 0: 
        case 15: 
        case 246: 
        case 253: 
        case 254: 
          Object value = value;
          if ((value instanceof byte[])) {
            batchedStatement.setBytes(batchedParamIndex, (byte[])value);
          } else {
            batchedStatement.setString(batchedParamIndex, (String)value);
          }
          if ((batchedStatement instanceof ServerPreparedStatement))
          {
            ServerPreparedQueryBindValue asBound = ((ServerPreparedStatement)batchedStatement).getBinding(batchedParamIndex, false);
            bufferType = bufferType;
          }
          batchedParamIndex++;
          
          break;
        default: 
          throw new IllegalArgumentException(Messages.getString("ServerPreparedStatement.26", new Object[] { Integer.valueOf(batchedParamIndex) }));
        }
      }
    }
    return batchedParamIndex;
  }
  
  protected boolean containsOnDuplicateKeyUpdateInSQL()
  {
    return hasOnDuplicateKeyUpdate;
  }
  
  protected ClientPreparedStatement prepareBatchedInsertSQL(JdbcConnection localConn, int numBatches)
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      try
      {
        ClientPreparedStatement pstmt = (ClientPreparedStatement)localConn.prepareStatement(((PreparedQuery)query).getParseInfo().getSqlForBatch(numBatches), resultSetConcurrency, query.getResultType().getIntValue()).unwrap(ClientPreparedStatement.class);
        pstmt.setRetrieveGeneratedKeys(retrieveGeneratedKeys);
        
        return pstmt;
      }
      catch (UnsupportedEncodingException e)
      {
        SQLException sqlEx = SQLError.createSQLException(Messages.getString("ServerPreparedStatement.27"), "S1000", exceptionInterceptor);
        
        sqlEx.initCause(e);
        
        throw sqlEx;
      }
    }
  }
  
  public void setPoolable(boolean poolable)
    throws SQLException
  {
    try
    {
      super.setPoolable(poolable);
      if ((!poolable) && (isCached))
      {
        connection.decachePreparedStatement(this);
        isCached = false;
        if (isClosed)
        {
          isClosed = false;
          realClose(true, true);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ServerPreparedStatement
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */