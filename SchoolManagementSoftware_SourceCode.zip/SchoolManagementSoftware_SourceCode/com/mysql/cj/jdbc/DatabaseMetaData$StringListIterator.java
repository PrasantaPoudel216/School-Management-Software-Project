package com.mysql.cj.jdbc;

import java.sql.SQLException;
import java.util.List;

public class DatabaseMetaData$StringListIterator
  extends DatabaseMetaData.IteratorWithCleanup<String>
{
  int idx = -1;
  List<String> list;
  
  DatabaseMetaData$StringListIterator(List<String> this$0)
  {
    super(this$0);
    this.list = list;
  }
  
  void close()
    throws SQLException
  {
    list = null;
  }
  
  boolean hasNext()
    throws SQLException
  {
    return idx < list.size() - 1;
  }
  
  String next()
    throws SQLException
  {
    idx += 1;
    return (String)list.get(idx);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.StringListIterator
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */