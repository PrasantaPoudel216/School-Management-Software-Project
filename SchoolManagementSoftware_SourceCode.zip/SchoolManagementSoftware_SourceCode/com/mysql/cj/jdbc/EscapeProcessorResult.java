package com.mysql.cj.jdbc;

class EscapeProcessorResult
{
  boolean callingStoredFunction = false;
  String escapedSql;
  byte usesVariables = 0;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.EscapeProcessorResult
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */