package com.mysql.cj.jdbc;

import com.mysql.cj.MysqlType;

public class CallableStatement$CallableStatementParam
{
  int index;
  int inOutModifier;
  boolean isIn;
  boolean isOut;
  int jdbcType;
  short nullability;
  String paramName;
  int precision;
  int scale;
  String typeName;
  MysqlType desiredMysqlType = MysqlType.UNKNOWN;
  
  CallableStatement$CallableStatementParam(String name, int idx, boolean in, boolean out, int jdbcType, String typeName, int precision, int scale, short nullability, int inOutModifier)
  {
    paramName = name;
    isIn = in;
    isOut = out;
    index = idx;
    
    this.jdbcType = jdbcType;
    this.typeName = typeName;
    this.precision = precision;
    this.scale = scale;
    this.nullability = nullability;
    this.inOutModifier = inOutModifier;
  }
  
  protected Object clone()
    throws CloneNotSupportedException
  {
    return super.clone();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.CallableStatement.CallableStatementParam
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */