package com.mysql.cj.jdbc;

import com.mysql.cj.BindValue;
import com.mysql.cj.CancelQueryTask;
import com.mysql.cj.ClientPreparedQuery;
import com.mysql.cj.ClientPreparedQueryBindings;
import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.NativeSession;
import com.mysql.cj.ParseInfo;
import com.mysql.cj.PreparedQuery;
import com.mysql.cj.Query;
import com.mysql.cj.QueryBindings;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.FeatureNotAvailableException;
import com.mysql.cj.exceptions.StatementIsClosedException;
import com.mysql.cj.jdbc.exceptions.MySQLStatementCancelledException;
import com.mysql.cj.jdbc.exceptions.MySQLTimeoutException;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.jdbc.result.CachedResultSetMetaData;
import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
import com.mysql.cj.log.ProfilerEventHandler;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.result.Field;
import com.mysql.cj.util.Util;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.JDBCType;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Wrapper;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class ClientPreparedStatement
  extends StatementImpl
  implements JdbcPreparedStatement
{
  protected boolean batchHasPlainStatements = false;
  protected MysqlParameterMetadata parameterMetaData;
  private java.sql.ResultSetMetaData pstmtResultMetaData;
  protected String batchedValuesClause;
  private boolean doPingInstead;
  private boolean compensateForOnDuplicateKeyUpdate = false;
  protected int rewrittenBatchSize = 0;
  
  protected static ClientPreparedStatement getInstance(JdbcConnection conn, String sql, String db)
    throws SQLException
  {
    return new ClientPreparedStatement(conn, sql, db);
  }
  
  protected static ClientPreparedStatement getInstance(JdbcConnection conn, String sql, String db, ParseInfo cachedParseInfo)
    throws SQLException
  {
    return new ClientPreparedStatement(conn, sql, db, cachedParseInfo);
  }
  
  protected void initQuery()
  {
    query = new ClientPreparedQuery(session);
  }
  
  protected ClientPreparedStatement(JdbcConnection conn, String db)
    throws SQLException
  {
    super(conn, db);
    
    setPoolable(true);
    compensateForOnDuplicateKeyUpdate = ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.compensateOnDuplicateKeyUpdateCounts).getValue()).booleanValue();
  }
  
  public ClientPreparedStatement(JdbcConnection conn, String sql, String db)
    throws SQLException
  {
    this(conn, sql, db, null);
  }
  
  public ClientPreparedStatement(JdbcConnection conn, String sql, String db, ParseInfo cachedParseInfo)
    throws SQLException
  {
    this(conn, db);
    try
    {
      ((PreparedQuery)query).checkNullOrEmptyQuery(sql);
      ((PreparedQuery)query).setOriginalSql(sql);
      ((PreparedQuery)query).setParseInfo(cachedParseInfo != null ? cachedParseInfo : new ParseInfo(sql, session, charEncoding));
    }
    catch (CJException e)
    {
      throw SQLExceptionsMapping.translateException(e, exceptionInterceptor);
    }
    doPingInstead = sql.startsWith("/* ping */");
    
    initializeFromParseInfo();
  }
  
  public QueryBindings<?> getQueryBindings()
  {
    return ((PreparedQuery)query).getQueryBindings();
  }
  
  public String toString()
  {
    StringBuilder buf = new StringBuilder();
    buf.append(getClass().getName());
    buf.append(": ");
    try
    {
      buf.append(asSql());
    }
    catch (SQLException sqlEx)
    {
      buf.append("EXCEPTION: " + sqlEx.toString());
    }
    return buf.toString();
  }
  
  public void addBatch()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        QueryBindings<?> queryBindings = ((PreparedQuery)query).getQueryBindings();
        queryBindings.checkAllParametersSet();
        query.addBatch(queryBindings.clone());
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void addBatch(String sql)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        batchHasPlainStatements = true;
        
        super.addBatch(sql);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String asSql()
    throws SQLException
  {
    return ((PreparedQuery)query).asSql(false);
  }
  
  /* Error */
  public String asSql(boolean quoteStreamsAndUnknowns)
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 47	com/mysql/cj/jdbc/ClientPreparedStatement:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 48 1 0
    //   9: dup
    //   10: astore_2
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 7	com/mysql/cj/jdbc/ClientPreparedStatement:query	Lcom/mysql/cj/Query;
    //   16: checkcast 20	com/mysql/cj/PreparedQuery
    //   19: iload_1
    //   20: invokeinterface 53 2 0
    //   25: aload_2
    //   26: monitorexit
    //   27: areturn
    //   28: astore_3
    //   29: aload_2
    //   30: monitorexit
    //   31: aload_3
    //   32: athrow
    //   33: astore 4
    //   35: aload 4
    //   37: aload_0
    //   38: invokevirtual 1264	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   41: invokestatic 29	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   44: athrow
    // Line number table:
    //   Java source line #275	-> byte code offset #0
    //   Java source line #276	-> byte code offset #12
    //   Java source line #277	-> byte code offset #28
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	38	0	this	ClientPreparedStatement
    //   0	33	1	quoteStreamsAndUnknowns	boolean
    //   10	20	2	Ljava/lang/Object;	Object
    //   28	4	3	localObject1	Object
    //   33	3	4	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	27	28	finally
    //   28	31	28	finally
    //   0	33	33	com/mysql/cj/exceptions/CJException
  }
  
  public void clearBatch()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        batchHasPlainStatements = false;
        
        super.clearBatch();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void clearParameters()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        for (BindValue bv : ((PreparedQuery)query).getQueryBindings().getBindValues()) {
          bv.reset();
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected boolean checkReadOnlySafeStatement()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        return (((PreparedQuery)query).getParseInfo().getFirstStmtChar() == 'S') || (!connection.isReadOnly());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean execute()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        JdbcConnection locallyScopedConn = connection;
        if ((!doPingInstead) && (!checkReadOnlySafeStatement())) {
          throw SQLError.createSQLException(Messages.getString("PreparedStatement.20") + Messages.getString("PreparedStatement.21"), "S1009", exceptionInterceptor);
        }
        ResultSetInternalMethods rs = null;
        
        lastQueryIsOnDupKeyUpdate = false;
        if (retrieveGeneratedKeys) {
          lastQueryIsOnDupKeyUpdate = containsOnDuplicateKeyUpdateInSQL();
        }
        batchedGeneratedKeys = null;
        
        resetCancelledState();
        
        implicitlyCloseAllOpenResults();
        
        clearWarnings();
        if (doPingInstead)
        {
          doPingInstead();
          
          return true;
        }
        setupStreamingTimeout(locallyScopedConn);
        
        Message sendPacket = ((PreparedQuery)query).fillSendPacket();
        
        String oldDb = null;
        if (!locallyScopedConn.getDatabase().equals(getCurrentDatabase()))
        {
          oldDb = locallyScopedConn.getDatabase();
          locallyScopedConn.setDatabase(getCurrentDatabase());
        }
        CachedResultSetMetaData cachedMetadata = null;
        
        boolean cacheResultSetMetadata = ((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue();
        if (cacheResultSetMetadata) {
          cachedMetadata = locallyScopedConn.getCachedMetaData(((PreparedQuery)query).getOriginalSql());
        }
        locallyScopedConn.setSessionMaxRows(((PreparedQuery)query).getParseInfo().getFirstStmtChar() == 'S' ? maxRows : -1);
        
        rs = executeInternal(maxRows, sendPacket, createStreamingResultSet(), ((PreparedQuery)query)
          .getParseInfo().getFirstStmtChar() == 'S', cachedMetadata, false);
        if (cachedMetadata != null) {
          locallyScopedConn.initializeResultsMetadataFromCache(((PreparedQuery)query).getOriginalSql(), cachedMetadata, rs);
        } else if ((rs.hasRows()) && (cacheResultSetMetadata)) {
          locallyScopedConn.initializeResultsMetadataFromCache(((PreparedQuery)query).getOriginalSql(), null, rs);
        }
        if (retrieveGeneratedKeys) {
          rs.setFirstCharOfQuery(((PreparedQuery)query).getParseInfo().getFirstStmtChar());
        }
        if (oldDb != null) {
          locallyScopedConn.setDatabase(oldDb);
        }
        if (rs != null)
        {
          lastInsertId = rs.getUpdateID();
          
          results = rs;
        }
        return (rs != null) && (rs.hasRows());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected long[] executeBatchInternal()
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      if (connection.isReadOnly()) {
        throw new SQLException(Messages.getString("PreparedStatement.25") + Messages.getString("PreparedStatement.26"), "S1009");
      }
      if ((query.getBatchedArgs() == null) || (query.getBatchedArgs().size() == 0)) {
        return new long[0];
      }
      int batchTimeout = getTimeoutInMillis();
      setTimeoutInMillis(0);
      
      resetCancelledState();
      try
      {
        statementBegins();
        
        clearWarnings();
        if ((!batchHasPlainStatements) && (((Boolean)rewriteBatchedStatements.getValue()).booleanValue()))
        {
          if (((PreparedQuery)query).getParseInfo().canRewriteAsMultiValueInsertAtSqlLevel())
          {
            arrayOfLong = executeBatchedInserts(batchTimeout);
            
            query.getStatementExecuting().set(false);
            
            clearBatch();return arrayOfLong;
          }
          if ((!batchHasPlainStatements) && (query.getBatchedArgs() != null) && 
            (query.getBatchedArgs().size() > 3))
          {
            arrayOfLong = executePreparedBatchAsMultiStatement(batchTimeout);
            
            query.getStatementExecuting().set(false);
            
            clearBatch();return arrayOfLong;
          }
        }
        long[] arrayOfLong = executeBatchSerially(batchTimeout);
        
        query.getStatementExecuting().set(false);
        
        clearBatch();return arrayOfLong;
      }
      finally
      {
        query.getStatementExecuting().set(false);
        
        clearBatch();
      }
    }
  }
  
  protected long[] executePreparedBatchAsMultiStatement(int batchTimeout)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (batchedValuesClause == null) {
          batchedValuesClause = (((PreparedQuery)query).getOriginalSql() + ";");
        }
        JdbcConnection locallyScopedConn = connection;
        
        boolean multiQueriesEnabled = ((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.allowMultiQueries).getValue()).booleanValue();
        CancelQueryTask timeoutTask = null;
        try
        {
          clearWarnings();
          
          int numBatchedArgs = query.getBatchedArgs().size();
          if (retrieveGeneratedKeys) {
            batchedGeneratedKeys = new ArrayList(numBatchedArgs);
          }
          int numValuesPerBatch = ((PreparedQuery)query).computeBatchSize(numBatchedArgs);
          if (numBatchedArgs < numValuesPerBatch) {
            numValuesPerBatch = numBatchedArgs;
          }
          PreparedStatement batchedStatement = null;
          
          int batchedParamIndex = 1;
          int numberToExecuteAsMultiValue = 0;
          int batchCounter = 0;
          int updateCountCounter = 0;
          long[] updateCounts = new long[numBatchedArgs * query).getParseInfo().numberOfQueries];
          SQLException sqlEx = null;
          try
          {
            if (!multiQueriesEnabled) {
              ((NativeSession)locallyScopedConn.getSession()).enableMultiQueries();
            }
            batchedStatement = retrieveGeneratedKeys ? (PreparedStatement)locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch), 1).unwrap(PreparedStatement.class) : (PreparedStatement)locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch)).unwrap(PreparedStatement.class);
            
            timeoutTask = startQueryTimer((StatementImpl)batchedStatement, batchTimeout);
            
            numberToExecuteAsMultiValue = numBatchedArgs < numValuesPerBatch ? numBatchedArgs : numBatchedArgs / numValuesPerBatch;
            
            int numberArgsToExecute = numberToExecuteAsMultiValue * numValuesPerBatch;
            for (int i = 0; i < numberArgsToExecute; i++)
            {
              if ((i != 0) && (i % numValuesPerBatch == 0))
              {
                try
                {
                  batchedStatement.execute();
                }
                catch (SQLException ex)
                {
                  sqlEx = handleExceptionForBatch(batchCounter, numValuesPerBatch, updateCounts, ex);
                }
                updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts);
                
                batchedStatement.clearParameters();
                batchedParamIndex = 1;
              }
              batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, query.getBatchedArgs().get(batchCounter++));
            }
            try
            {
              batchedStatement.execute();
            }
            catch (SQLException ex)
            {
              sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
            }
            updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts);
            
            batchedStatement.clearParameters();
            
            numValuesPerBatch = numBatchedArgs - batchCounter;
            if (timeoutTask != null) {
              ((JdbcPreparedStatement)batchedStatement).checkCancelTimeout();
            }
          }
          finally
          {
            if (batchedStatement != null)
            {
              batchedStatement.close();
              batchedStatement = null;
            }
          }
          try
          {
            if (numValuesPerBatch > 0)
            {
              batchedStatement = retrieveGeneratedKeys ? locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch), 1) : locallyScopedConn.prepareStatement(generateMultiStatementForBatch(numValuesPerBatch));
              if (timeoutTask != null) {
                timeoutTask.setQueryToCancel((Query)batchedStatement);
              }
              batchedParamIndex = 1;
              while (batchCounter < numBatchedArgs) {
                batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, query.getBatchedArgs().get(batchCounter++));
              }
              try
              {
                batchedStatement.execute();
              }
              catch (SQLException ex)
              {
                sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
              }
              updateCountCounter = processMultiCountsAndKeys((StatementImpl)batchedStatement, updateCountCounter, updateCounts);
              
              batchedStatement.clearParameters();
            }
            if (timeoutTask != null)
            {
              stopQueryTimer(timeoutTask, true, true);
              timeoutTask = null;
            }
            if (sqlEx != null) {
              throw SQLError.createBatchUpdateException(sqlEx, updateCounts, exceptionInterceptor);
            }
            ex = updateCounts;
            if (batchedStatement != null) {
              batchedStatement.close();
            }
            stopQueryTimer(timeoutTask, false, false);
            resetCancelledState();
            if (!multiQueriesEnabled) {
              ((NativeSession)locallyScopedConn.getSession()).disableMultiQueries();
            }
            clearBatch();return ex;
          }
          finally
          {
            if (batchedStatement != null) {
              batchedStatement.close();
            }
          }
          localObject4 = finally;
        }
        finally
        {
          stopQueryTimer(timeoutTask, false, false);
          resetCancelledState();
          if (!multiQueriesEnabled) {
            ((NativeSession)locallyScopedConn.getSession()).disableMultiQueries();
          }
          clearBatch();
        }
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected int setOneBatchedParameterSet(PreparedStatement batchedStatement, int batchedParamIndex, Object paramSet)
    throws SQLException
  {
    QueryBindings<?> paramArg = (QueryBindings)paramSet;
    
    BindValue[] bindValues = paramArg.getBindValues();
    for (int j = 0; j < bindValues.length; j++) {
      if (bindValues[j].isNull()) {
        batchedStatement.setNull(batchedParamIndex++, MysqlType.NULL.getJdbcType());
      } else if (bindValues[j].isStream()) {
        batchedStatement.setBinaryStream(batchedParamIndex++, bindValues[j].getStreamValue(), bindValues[j].getStreamLength());
      } else {
        ((JdbcPreparedStatement)batchedStatement).setBytesNoEscapeNoQuotes(batchedParamIndex++, bindValues[j].getByteValue());
      }
    }
    return batchedParamIndex;
  }
  
  private String generateMultiStatementForBatch(int numBatches)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        String origSql = ((PreparedQuery)query).getOriginalSql();
        StringBuilder newStatementSql = new StringBuilder((origSql.length() + 1) * numBatches);
        
        newStatementSql.append(origSql);
        for (int i = 0; i < numBatches - 1; i++)
        {
          newStatementSql.append(';');
          newStatementSql.append(origSql);
        }
        return newStatementSql.toString();
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected long[] executeBatchedInserts(int batchTimeout)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        String valuesClause = ((PreparedQuery)query).getParseInfo().getValuesClause();
        
        JdbcConnection locallyScopedConn = connection;
        if (valuesClause == null) {
          return executeBatchSerially(batchTimeout);
        }
        int numBatchedArgs = query.getBatchedArgs().size();
        if (retrieveGeneratedKeys) {
          batchedGeneratedKeys = new ArrayList(numBatchedArgs);
        }
        int numValuesPerBatch = ((PreparedQuery)query).computeBatchSize(numBatchedArgs);
        if (numBatchedArgs < numValuesPerBatch) {
          numValuesPerBatch = numBatchedArgs;
        }
        JdbcPreparedStatement batchedStatement = null;
        
        int batchedParamIndex = 1;
        long updateCountRunningTotal = 0L;
        int numberToExecuteAsMultiValue = 0;
        int batchCounter = 0;
        CancelQueryTask timeoutTask = null;
        SQLException sqlEx = null;
        
        long[] updateCounts = new long[numBatchedArgs];
        try
        {
          try
          {
            batchedStatement = prepareBatchedInsertSQL(locallyScopedConn, numValuesPerBatch);
            
            timeoutTask = startQueryTimer(batchedStatement, batchTimeout);
            
            numberToExecuteAsMultiValue = numBatchedArgs < numValuesPerBatch ? numBatchedArgs : numBatchedArgs / numValuesPerBatch;
            
            int numberArgsToExecute = numberToExecuteAsMultiValue * numValuesPerBatch;
            for (int i = 0; i < numberArgsToExecute; i++)
            {
              if ((i != 0) && (i % numValuesPerBatch == 0))
              {
                try
                {
                  updateCountRunningTotal += batchedStatement.executeLargeUpdate();
                }
                catch (SQLException ex)
                {
                  sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
                }
                getBatchedGeneratedKeys(batchedStatement);
                batchedStatement.clearParameters();
                batchedParamIndex = 1;
              }
              batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, query.getBatchedArgs().get(batchCounter++));
            }
            try
            {
              updateCountRunningTotal += batchedStatement.executeLargeUpdate();
            }
            catch (SQLException ex)
            {
              sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
            }
            getBatchedGeneratedKeys(batchedStatement);
            
            numValuesPerBatch = numBatchedArgs - batchCounter;
          }
          finally
          {
            if (batchedStatement != null)
            {
              batchedStatement.close();
              batchedStatement = null;
            }
          }
          try
          {
            if (numValuesPerBatch > 0)
            {
              batchedStatement = prepareBatchedInsertSQL(locallyScopedConn, numValuesPerBatch);
              if (timeoutTask != null) {
                timeoutTask.setQueryToCancel(batchedStatement);
              }
              batchedParamIndex = 1;
              while (batchCounter < numBatchedArgs) {
                batchedParamIndex = setOneBatchedParameterSet(batchedStatement, batchedParamIndex, query.getBatchedArgs().get(batchCounter++));
              }
              try
              {
                updateCountRunningTotal += batchedStatement.executeLargeUpdate();
              }
              catch (SQLException ex)
              {
                sqlEx = handleExceptionForBatch(batchCounter - 1, numValuesPerBatch, updateCounts, ex);
              }
              getBatchedGeneratedKeys(batchedStatement);
            }
            if (sqlEx != null) {
              throw SQLError.createBatchUpdateException(sqlEx, updateCounts, exceptionInterceptor);
            }
            if (numBatchedArgs > 1)
            {
              updCount = updateCountRunningTotal > 0L ? -2L : 0L;
              for (int j = 0; j < numBatchedArgs; j++) {
                updateCounts[j] = updCount;
              }
            }
            else
            {
              updateCounts[0] = updateCountRunningTotal;
            }
            long updCount = updateCounts;
            if (batchedStatement != null) {
              batchedStatement.close();
            }
            stopQueryTimer(timeoutTask, false, false);
            resetCancelledState();return updCount;
          }
          finally
          {
            if (batchedStatement != null) {
              batchedStatement.close();
            }
          }
          localObject4 = finally;
        }
        finally
        {
          stopQueryTimer(timeoutTask, false, false);
          resetCancelledState();
        }
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected long[] executeBatchSerially(int batchTimeout)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (connection == null) {
          checkClosed();
        }
        long[] updateCounts = null;
        if (query.getBatchedArgs() != null)
        {
          int nbrCommands = query.getBatchedArgs().size();
          updateCounts = new long[nbrCommands];
          for (int i = 0; i < nbrCommands; i++) {
            updateCounts[i] = -3L;
          }
          SQLException sqlEx = null;
          
          CancelQueryTask timeoutTask = null;
          try
          {
            timeoutTask = startQueryTimer(this, batchTimeout);
            if (retrieveGeneratedKeys) {
              batchedGeneratedKeys = new ArrayList(nbrCommands);
            }
            int batchCommandIndex = ((PreparedQuery)query).getBatchCommandIndex();
            for (batchCommandIndex = 0; batchCommandIndex < nbrCommands; batchCommandIndex++)
            {
              ((PreparedQuery)query).setBatchCommandIndex(batchCommandIndex);
              
              Object arg = query.getBatchedArgs().get(batchCommandIndex);
              try
              {
                if ((arg instanceof String))
                {
                  updateCounts[batchCommandIndex] = executeUpdateInternal((String)arg, true, retrieveGeneratedKeys);
                  
                  getBatchedGeneratedKeys((results.getFirstCharOfQuery() == 'I') && (containsOnDuplicateKeyInString((String)arg)) ? 1 : 0);
                }
                else
                {
                  QueryBindings<?> queryBindings = (QueryBindings)arg;
                  updateCounts[batchCommandIndex] = executeUpdateInternal(queryBindings, true);
                  
                  getBatchedGeneratedKeys(containsOnDuplicateKeyUpdateInSQL() ? 1 : 0);
                }
              }
              catch (SQLException ex)
              {
                updateCounts[batchCommandIndex] = -3L;
                if ((continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && 
                  (!hasDeadlockOrTimeoutRolledBackTx(ex)))
                {
                  sqlEx = ex;
                }
                else
                {
                  long[] newUpdateCounts = new long[batchCommandIndex];
                  System.arraycopy(updateCounts, 0, newUpdateCounts, 0, batchCommandIndex);
                  
                  throw SQLError.createBatchUpdateException(ex, newUpdateCounts, exceptionInterceptor);
                }
              }
            }
            if (sqlEx != null) {
              throw SQLError.createBatchUpdateException(sqlEx, updateCounts, exceptionInterceptor);
            }
          }
          catch (NullPointerException npe)
          {
            try
            {
              checkClosed();
            }
            catch (StatementIsClosedException connectionClosedEx)
            {
              int batchCommandIndex = ((PreparedQuery)query).getBatchCommandIndex();
              updateCounts[batchCommandIndex] = -3L;
              
              long[] newUpdateCounts = new long[batchCommandIndex];
              
              System.arraycopy(updateCounts, 0, newUpdateCounts, 0, batchCommandIndex);
              
              throw SQLError.createBatchUpdateException(SQLExceptionsMapping.translateException(connectionClosedEx), newUpdateCounts, exceptionInterceptor);
            }
            throw npe;
          }
          finally
          {
            ((PreparedQuery)query).setBatchCommandIndex(-1);
            
            stopQueryTimer(timeoutTask, false, false);
            resetCancelledState();
          }
        }
        return updateCounts != null ? updateCounts : new long[0];
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected <M extends Message> ResultSetInternalMethods executeInternal(int maxRowsToRetrieve, M sendPacket, boolean createStreamingResultSet, boolean queryIsSelectOnly, ColumnDefinition metadata, boolean isBatch)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        try
        {
          JdbcConnection locallyScopedConnection = connection;
          
          ((PreparedQuery)query).getQueryBindings()
            .setNumberOfExecutions(((PreparedQuery)query).getQueryBindings().getNumberOfExecutions() + 1);
          
          CancelQueryTask timeoutTask = null;
          try
          {
            timeoutTask = startQueryTimer(this, getTimeoutInMillis());
            if (!isBatch) {
              statementBegins();
            }
            ResultSetInternalMethods rs = (ResultSetInternalMethods)((NativeSession)locallyScopedConnection.getSession()).execSQL(this, null, maxRowsToRetrieve, (NativePacketPayload)sendPacket, createStreamingResultSet, 
              getResultSetFactory(), metadata, isBatch);
            if (timeoutTask != null)
            {
              stopQueryTimer(timeoutTask, true, true);
              timeoutTask = null;
            }
          }
          finally
          {
            if (!isBatch) {
              query.getStatementExecuting().set(false);
            }
            stopQueryTimer(timeoutTask, false, false);
          }
          ResultSetInternalMethods rs;
          return rs;
        }
        catch (NullPointerException npe)
        {
          checkClosed();
          
          throw npe;
        }
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet executeQuery()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        JdbcConnection locallyScopedConn = connection;
        
        checkForDml(((PreparedQuery)query).getOriginalSql(), ((PreparedQuery)query).getParseInfo().getFirstStmtChar());
        
        batchedGeneratedKeys = null;
        
        resetCancelledState();
        
        implicitlyCloseAllOpenResults();
        
        clearWarnings();
        if (doPingInstead)
        {
          doPingInstead();
          
          return results;
        }
        setupStreamingTimeout(locallyScopedConn);
        
        Message sendPacket = ((PreparedQuery)query).fillSendPacket();
        
        String oldDb = null;
        if (!locallyScopedConn.getDatabase().equals(getCurrentDatabase()))
        {
          oldDb = locallyScopedConn.getDatabase();
          locallyScopedConn.setDatabase(getCurrentDatabase());
        }
        CachedResultSetMetaData cachedMetadata = null;
        boolean cacheResultSetMetadata = ((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue();
        
        String origSql = ((PreparedQuery)query).getOriginalSql();
        if (cacheResultSetMetadata) {
          cachedMetadata = locallyScopedConn.getCachedMetaData(origSql);
        }
        locallyScopedConn.setSessionMaxRows(maxRows);
        
        results = executeInternal(maxRows, sendPacket, createStreamingResultSet(), true, cachedMetadata, false);
        if (oldDb != null) {
          locallyScopedConn.setDatabase(oldDb);
        }
        if (cachedMetadata != null) {
          locallyScopedConn.initializeResultsMetadataFromCache(origSql, cachedMetadata, results);
        } else if (cacheResultSetMetadata) {
          locallyScopedConn.initializeResultsMetadataFromCache(origSql, null, results);
        }
        lastInsertId = results.getUpdateID();
        
        return results;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int executeUpdate()
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(executeLargeUpdate());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected long executeUpdateInternal(boolean clearBatchedGeneratedKeysAndWarnings, boolean isBatch)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (clearBatchedGeneratedKeysAndWarnings)
        {
          clearWarnings();
          batchedGeneratedKeys = null;
        }
        return executeUpdateInternal(((PreparedQuery)query).getQueryBindings(), isBatch);
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected long executeUpdateInternal(QueryBindings<?> bindings, boolean isReallyBatch)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        JdbcConnection locallyScopedConn = connection;
        if (locallyScopedConn.isReadOnly(false)) {
          throw SQLError.createSQLException(Messages.getString("PreparedStatement.34") + Messages.getString("PreparedStatement.35"), "S1009", exceptionInterceptor);
        }
        if ((((PreparedQuery)query).getParseInfo().getFirstStmtChar() == 'S') && (isSelectQuery())) {
          throw SQLError.createSQLException(Messages.getString("PreparedStatement.37"), "01S03", exceptionInterceptor);
        }
        resetCancelledState();
        
        implicitlyCloseAllOpenResults();
        
        ResultSetInternalMethods rs = null;
        
        Message sendPacket = ((PreparedQuery)query).fillSendPacket(bindings);
        
        String oldDb = null;
        if (!locallyScopedConn.getDatabase().equals(getCurrentDatabase()))
        {
          oldDb = locallyScopedConn.getDatabase();
          locallyScopedConn.setDatabase(getCurrentDatabase());
        }
        locallyScopedConn.setSessionMaxRows(-1);
        
        rs = executeInternal(-1, sendPacket, false, false, null, isReallyBatch);
        if (retrieveGeneratedKeys) {
          rs.setFirstCharOfQuery(((PreparedQuery)query).getParseInfo().getFirstStmtChar());
        }
        if (oldDb != null) {
          locallyScopedConn.setDatabase(oldDb);
        }
        results = rs;
        
        updateCount = rs.getUpdateCount();
        if ((containsOnDuplicateKeyUpdateInSQL()) && (compensateForOnDuplicateKeyUpdate) && (
          (updateCount == 2L) || (updateCount == 0L))) {
          updateCount = 1L;
        }
        lastInsertId = rs.getUpdateID();
        
        return updateCount;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected boolean containsOnDuplicateKeyUpdateInSQL()
  {
    return ((PreparedQuery)query).getParseInfo().containsOnDuplicateKeyUpdateInSQL();
  }
  
  protected ClientPreparedStatement prepareBatchedInsertSQL(JdbcConnection localConn, int numBatches)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ClientPreparedStatement pstmt = new ClientPreparedStatement(localConn, "Rewritten batch of: " + ((PreparedQuery)query).getOriginalSql(), getCurrentDatabase(), ((PreparedQuery)query).getParseInfo().getParseInfoForBatch(numBatches));
        pstmt.setRetrieveGeneratedKeys(retrieveGeneratedKeys);
        rewrittenBatchSize = numBatches;
        
        return pstmt;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void setRetrieveGeneratedKeys(boolean flag)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        retrieveGeneratedKeys = flag;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public byte[] getBytesRepresentation(int parameterIndex)
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 47	com/mysql/cj/jdbc/ClientPreparedStatement:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 48 1 0
    //   9: dup
    //   10: astore_2
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 7	com/mysql/cj/jdbc/ClientPreparedStatement:query	Lcom/mysql/cj/Query;
    //   16: checkcast 20	com/mysql/cj/PreparedQuery
    //   19: invokeinterface 35 1 0
    //   24: aload_0
    //   25: iload_1
    //   26: invokevirtual 208	com/mysql/cj/jdbc/ClientPreparedStatement:getCoreParameterIndex	(I)I
    //   29: invokeinterface 209 2 0
    //   34: aload_2
    //   35: monitorexit
    //   36: areturn
    //   37: astore_3
    //   38: aload_2
    //   39: monitorexit
    //   40: aload_3
    //   41: athrow
    //   42: astore 4
    //   44: aload 4
    //   46: aload_0
    //   47: invokevirtual 1264	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   50: invokestatic 29	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   53: athrow
    // Line number table:
    //   Java source line #1152	-> byte code offset #0
    //   Java source line #1153	-> byte code offset #12
    //   Java source line #1154	-> byte code offset #37
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	47	0	this	ClientPreparedStatement
    //   0	42	1	parameterIndex	int
    //   10	29	2	Ljava/lang/Object;	Object
    //   37	4	3	localObject1	Object
    //   42	3	4	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	36	37	finally
    //   37	40	37	finally
    //   0	42	42	com/mysql/cj/exceptions/CJException
  }
  
  public java.sql.ResultSetMetaData getMetaData()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!isSelectQuery()) {
          return null;
        }
        JdbcPreparedStatement mdStmt = null;
        ResultSet mdRs = null;
        if (pstmtResultMetaData == null) {
          try
          {
            mdStmt = new ClientPreparedStatement(connection, ((PreparedQuery)query).getOriginalSql(), getCurrentDatabase(), ((PreparedQuery)query).getParseInfo());
            
            mdStmt.setMaxRows(1);
            
            int paramCount = ((PreparedQuery)query).getParameterCount();
            for (int i = 1; i <= paramCount; i++) {
              mdStmt.setString(i, "");
            }
            boolean hadResults = mdStmt.execute();
            if (hadResults)
            {
              mdRs = mdStmt.getResultSet();
              
              pstmtResultMetaData = mdRs.getMetaData();
            }
            else
            {
              pstmtResultMetaData = new com.mysql.cj.jdbc.result.ResultSetMetaData(session, new Field[0], ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.useOldAliasMetadataBehavior).getValue()).booleanValue(), ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue(), exceptionInterceptor);
            }
          }
          finally
          {
            SQLException sqlExRethrow;
            SQLException sqlExRethrow = null;
            if (mdRs != null)
            {
              try
              {
                mdRs.close();
              }
              catch (SQLException sqlEx)
              {
                sqlExRethrow = sqlEx;
              }
              mdRs = null;
            }
            if (mdStmt != null)
            {
              try
              {
                mdStmt.close();
              }
              catch (SQLException sqlEx)
              {
                sqlExRethrow = sqlEx;
              }
              mdStmt = null;
            }
            if (sqlExRethrow != null) {
              throw sqlExRethrow;
            }
          }
        }
        return pstmtResultMetaData;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  protected boolean isSelectQuery()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 47	com/mysql/cj/jdbc/ClientPreparedStatement:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 48 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 7	com/mysql/cj/jdbc/ClientPreparedStatement:query	Lcom/mysql/cj/Query;
    //   16: checkcast 20	com/mysql/cj/PreparedQuery
    //   19: invokeinterface 85 1 0
    //   24: ldc -32
    //   26: ldc -32
    //   28: iconst_1
    //   29: iconst_0
    //   30: iconst_1
    //   31: iconst_1
    //   32: invokestatic 225	com/mysql/cj/util/StringUtils:stripComments	(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ZZZZ)Ljava/lang/String;
    //   35: ldc -30
    //   37: invokestatic 227	com/mysql/cj/util/StringUtils:startsWithIgnoreCaseAndWs	(Ljava/lang/String;Ljava/lang/String;)Z
    //   40: aload_1
    //   41: monitorexit
    //   42: ireturn
    //   43: astore_2
    //   44: aload_1
    //   45: monitorexit
    //   46: aload_2
    //   47: athrow
    //   48: astore_3
    //   49: aload_3
    //   50: aload_0
    //   51: invokevirtual 1264	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   54: invokestatic 29	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   57: athrow
    // Line number table:
    //   Java source line #1233	-> byte code offset #0
    //   Java source line #1234	-> byte code offset #12
    //   Java source line #1235	-> byte code offset #19
    //   Java source line #1234	-> byte code offset #37
    //   Java source line #1236	-> byte code offset #43
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	51	0	this	ClientPreparedStatement
    //   10	35	1	Ljava/lang/Object;	Object
    //   43	4	2	localObject1	Object
    //   48	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	42	43	finally
    //   43	46	43	finally
    //   0	48	48	com/mysql/cj/exceptions/CJException
  }
  
  public ParameterMetaData getParameterMetaData()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (parameterMetaData == null) {
          if (((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.generateSimpleParameterMetadata).getValue()).booleanValue()) {
            parameterMetaData = new MysqlParameterMetadata(((PreparedQuery)query).getParameterCount());
          } else {
            parameterMetaData = new MysqlParameterMetadata(session, null, ((PreparedQuery)query).getParameterCount(), exceptionInterceptor);
          }
        }
        return parameterMetaData;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ParseInfo getParseInfo()
  {
    return ((PreparedQuery)query).getParseInfo();
  }
  
  private void initializeFromParseInfo()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        int parameterCount = ((PreparedQuery)query).getParseInfo().getStaticSql().length - 1;
        ((PreparedQuery)query).setParameterCount(parameterCount);
        ((PreparedQuery)query).setQueryBindings(new ClientPreparedQueryBindings(parameterCount, session));
        ((ClientPreparedQueryBindings)((ClientPreparedQuery)query).getQueryBindings()).setLoadDataQuery(((PreparedQuery)query).getParseInfo().isFoundLoadData());
        
        clearParameters();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public boolean isNull(int paramIndex)
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 47	com/mysql/cj/jdbc/ClientPreparedStatement:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 48 1 0
    //   9: dup
    //   10: astore_2
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 7	com/mysql/cj/jdbc/ClientPreparedStatement:query	Lcom/mysql/cj/Query;
    //   16: checkcast 20	com/mysql/cj/PreparedQuery
    //   19: invokeinterface 35 1 0
    //   24: invokeinterface 55 1 0
    //   29: aload_0
    //   30: iload_1
    //   31: invokevirtual 208	com/mysql/cj/jdbc/ClientPreparedStatement:getCoreParameterIndex	(I)I
    //   34: aaload
    //   35: invokeinterface 145 1 0
    //   40: aload_2
    //   41: monitorexit
    //   42: ireturn
    //   43: astore_3
    //   44: aload_2
    //   45: monitorexit
    //   46: aload_3
    //   47: athrow
    //   48: astore 4
    //   50: aload 4
    //   52: aload_0
    //   53: invokevirtual 1264	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   56: invokestatic 29	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   59: athrow
    // Line number table:
    //   Java source line #1275	-> byte code offset #0
    //   Java source line #1276	-> byte code offset #12
    //   Java source line #1277	-> byte code offset #43
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	53	0	this	ClientPreparedStatement
    //   0	48	1	paramIndex	int
    //   10	35	2	Ljava/lang/Object;	Object
    //   43	4	3	localObject1	Object
    //   48	3	4	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	42	43	finally
    //   43	46	43	finally
    //   0	48	48	com/mysql/cj/exceptions/CJException
  }
  
  public void realClose(boolean calledExplicitly, boolean closeOpenResults)
    throws SQLException
  {
    JdbcConnection locallyScopedConn = connection;
    if (locallyScopedConn == null) {
      return;
    }
    synchronized (locallyScopedConn.getConnectionMutex())
    {
      if (isClosed) {
        return;
      }
      if ((useUsageAdvisor) && 
        (((PreparedQuery)query).getQueryBindings().getNumberOfExecutions() <= 1)) {
        session.getProfilerEventHandler().processEvent((byte)0, session, this, null, 0L, new Throwable(), 
          Messages.getString("PreparedStatement.43"));
      }
      super.realClose(calledExplicitly, closeOpenResults);
      
      ((PreparedQuery)query).setOriginalSql(null);
      ((PreparedQuery)query).setQueryBindings(null);
    }
  }
  
  public String getPreparedSql()
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      if (rewrittenBatchSize == 0) {
        return ((PreparedQuery)query).getOriginalSql();
      }
      try
      {
        return ((PreparedQuery)query).getParseInfo().getSqlForBatch();
      }
      catch (UnsupportedEncodingException e)
      {
        throw new RuntimeException(e);
      }
    }
  }
  
  public int getUpdateCount()
    throws SQLException
  {
    try
    {
      int count = super.getUpdateCount();
      if ((containsOnDuplicateKeyUpdateInSQL()) && (compensateForOnDuplicateKeyUpdate) && (
        (count == 2) || (count == 0))) {}
      return 1;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long executeLargeUpdate()
    throws SQLException
  {
    try
    {
      return executeUpdateInternal(true, false);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public ParameterBindings getParameterBindings()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 47	com/mysql/cj/jdbc/ClientPreparedStatement:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 48 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: new 257	com/mysql/cj/jdbc/ParameterBindingsImpl
    //   15: dup
    //   16: aload_0
    //   17: getfield 7	com/mysql/cj/jdbc/ClientPreparedStatement:query	Lcom/mysql/cj/Query;
    //   20: checkcast 20	com/mysql/cj/PreparedQuery
    //   23: aload_0
    //   24: getfield 5	com/mysql/cj/jdbc/ClientPreparedStatement:session	Lcom/mysql/cj/NativeSession;
    //   27: aload_0
    //   28: getfield 258	com/mysql/cj/jdbc/ClientPreparedStatement:resultSetFactory	Lcom/mysql/cj/jdbc/result/ResultSetFactory;
    //   31: invokespecial 259	com/mysql/cj/jdbc/ParameterBindingsImpl:<init>	(Lcom/mysql/cj/PreparedQuery;Lcom/mysql/cj/Session;Lcom/mysql/cj/jdbc/result/ResultSetFactory;)V
    //   34: aload_1
    //   35: monitorexit
    //   36: areturn
    //   37: astore_2
    //   38: aload_1
    //   39: monitorexit
    //   40: aload_2
    //   41: athrow
    //   42: astore_3
    //   43: aload_3
    //   44: aload_0
    //   45: invokevirtual 1264	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   48: invokestatic 29	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   51: athrow
    // Line number table:
    //   Java source line #1344	-> byte code offset #0
    //   Java source line #1345	-> byte code offset #12
    //   Java source line #1346	-> byte code offset #37
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	45	0	this	ClientPreparedStatement
    //   10	29	1	Ljava/lang/Object;	Object
    //   37	4	2	localObject1	Object
    //   42	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	36	37	finally
    //   37	40	37	finally
    //   0	42	42	com/mysql/cj/exceptions/CJException
  }
  
  protected int getParameterIndexOffset()
  {
    return 0;
  }
  
  protected void checkBounds(int paramIndex, int parameterIndexOffset)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (paramIndex < 1) {
          throw SQLError.createSQLException(Messages.getString("PreparedStatement.49") + paramIndex + Messages.getString("PreparedStatement.50"), "S1009", exceptionInterceptor);
        }
        if (paramIndex > ((PreparedQuery)query).getParameterCount()) {
          throw SQLError.createSQLException(
            Messages.getString("PreparedStatement.51") + paramIndex + Messages.getString("PreparedStatement.52") + ((PreparedQuery)query)
            .getParameterCount() + Messages.getString("PreparedStatement.53"), "S1009", exceptionInterceptor);
        }
        if ((parameterIndexOffset == -1) && (paramIndex == 1)) {
          throw SQLError.createSQLException(Messages.getString("PreparedStatement.63"), "S1009", exceptionInterceptor);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected final int getCoreParameterIndex(int paramIndex)
    throws SQLException
  {
    int parameterIndexOffset = getParameterIndexOffset();
    checkBounds(paramIndex, parameterIndexOffset);
    return paramIndex - 1 + parameterIndexOffset;
  }
  
  public void setArray(int i, Array x)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setAsciiStream(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setAsciiStream(getCoreParameterIndex(parameterIndex), x, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x, long length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setAsciiStream(getCoreParameterIndex(parameterIndex), x, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBigDecimal(int parameterIndex, BigDecimal x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBigDecimal(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBinaryStream(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBinaryStream(getCoreParameterIndex(parameterIndex), x, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x, long length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBinaryStream(getCoreParameterIndex(parameterIndex), x, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBlob(int i, Blob x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBlob(getCoreParameterIndex(i), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBlob(int parameterIndex, InputStream inputStream)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBlob(getCoreParameterIndex(parameterIndex), inputStream);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBlob(int parameterIndex, InputStream inputStream, long length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBlob(getCoreParameterIndex(parameterIndex), inputStream, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBoolean(int parameterIndex, boolean x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBoolean(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setByte(int parameterIndex, byte x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setByte(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBytes(int parameterIndex, byte[] x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBytes(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBytes(int parameterIndex, byte[] x, boolean checkForIntroducer, boolean escapeForMBChars)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setBytes(getCoreParameterIndex(parameterIndex), x, checkForIntroducer, escapeForMBChars);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBytesNoEscape(int parameterIndex, byte[] parameterAsBytes)
    throws SQLException
  {
    ((PreparedQuery)query).getQueryBindings().setBytesNoEscape(getCoreParameterIndex(parameterIndex), parameterAsBytes);
  }
  
  public void setBytesNoEscapeNoQuotes(int parameterIndex, byte[] parameterAsBytes)
    throws SQLException
  {
    ((PreparedQuery)query).getQueryBindings().setBytesNoEscapeNoQuotes(getCoreParameterIndex(parameterIndex), parameterAsBytes);
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader, int length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setClob(int parameterIndex, Reader reader)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setClob(int parameterIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setCharacterStream(getCoreParameterIndex(parameterIndex), reader, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setClob(int i, Clob x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setClob(getCoreParameterIndex(i), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setDate(int parameterIndex, Date x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setDate(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setDate(int parameterIndex, Date x, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setDate(getCoreParameterIndex(parameterIndex), x, cal);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setDouble(int parameterIndex, double x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setDouble(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setFloat(int parameterIndex, float x)
    throws SQLException
  {
    try
    {
      ((PreparedQuery)query).getQueryBindings().setFloat(getCoreParameterIndex(parameterIndex), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setInt(int parameterIndex, int x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setInt(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setLong(int parameterIndex, long x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setLong(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setBigInteger(int parameterIndex, BigInteger x)
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      ((PreparedQuery)query).getQueryBindings().setBigInteger(getCoreParameterIndex(parameterIndex), x);
    }
  }
  
  public void setNCharacterStream(int parameterIndex, Reader value)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNCharacterStream(getCoreParameterIndex(parameterIndex), value);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNCharacterStream(int parameterIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNCharacterStream(getCoreParameterIndex(parameterIndex), reader, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNClob(int parameterIndex, Reader reader)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNClob(getCoreParameterIndex(parameterIndex), reader);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNClob(int parameterIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNClob(getCoreParameterIndex(parameterIndex), reader, length);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNClob(int parameterIndex, NClob value)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNClob(getCoreParameterIndex(parameterIndex), value);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNString(int parameterIndex, String x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNString(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNull(int parameterIndex, int sqlType)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNull(getCoreParameterIndex(parameterIndex));
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNull(int parameterIndex, int sqlType, String typeName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setNull(getCoreParameterIndex(parameterIndex));
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setNull(int parameterIndex, MysqlType mysqlType)
    throws SQLException
  {
    setNull(parameterIndex, mysqlType.getJdbcType());
  }
  
  public void setObject(int parameterIndex, Object parameterObj)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), parameterObj);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(int parameterIndex, Object parameterObj, int targetSqlType)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        try
        {
          ((PreparedQuery)query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), parameterObj, 
            MysqlType.getByJdbcType(targetSqlType));
        }
        catch (FeatureNotAvailableException nae)
        {
          throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(targetSqlType), "S1C00", exceptionInterceptor);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(int parameterIndex, Object parameterObj, SQLType targetSqlType)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if ((targetSqlType instanceof MysqlType)) {
          ((PreparedQuery)query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), parameterObj, (MysqlType)targetSqlType);
        } else {
          setObject(parameterIndex, parameterObj, targetSqlType.getVendorTypeNumber().intValue());
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(int parameterIndex, Object parameterObj, int targetSqlType, int scale)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        try
        {
          ((PreparedQuery)query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), parameterObj, 
            MysqlType.getByJdbcType(targetSqlType), scale);
        }
        catch (FeatureNotAvailableException nae)
        {
          throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(targetSqlType), "S1C00", exceptionInterceptor);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setObject(int parameterIndex, Object x, SQLType targetSqlType, int scaleOrLength)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if ((targetSqlType instanceof MysqlType)) {
          ((PreparedQuery)query).getQueryBindings().setObject(getCoreParameterIndex(parameterIndex), x, (MysqlType)targetSqlType, scaleOrLength);
        } else {
          setObject(parameterIndex, x, targetSqlType.getVendorTypeNumber().intValue(), scaleOrLength);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setRef(int i, Ref x)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setRowId(int parameterIndex, RowId x)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setShort(int parameterIndex, short x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setShort(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setSQLXML(int parameterIndex, SQLXML xmlObject)
    throws SQLException
  {
    try
    {
      if (xmlObject == null) {
        setNull(parameterIndex, MysqlType.VARCHAR);
      } else {
        setCharacterStream(parameterIndex, ((MysqlSQLXML)xmlObject).serializeAsCharacterStream());
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setString(int parameterIndex, String x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setString(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTime(int parameterIndex, Time x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setTime(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTime(int parameterIndex, Time x, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setTime(getCoreParameterIndex(parameterIndex), x, cal);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTimestamp(int parameterIndex, Timestamp x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setTimestamp(getCoreParameterIndex(parameterIndex), x);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        ((PreparedQuery)query).getQueryBindings().setTimestamp(getCoreParameterIndex(parameterIndex), x, cal);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setTimestamp(int parameterIndex, Timestamp x, Calendar targetCalendar, int fractionalLength)
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      ((PreparedQuery)query).getQueryBindings().setTimestamp(getCoreParameterIndex(parameterIndex), x, targetCalendar, fractionalLength);
    }
  }
  
  @Deprecated
  public void setUnicodeStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      setBinaryStream(parameterIndex, x, length);
      ((PreparedQuery)query).getQueryBindings().getBindValues()[getCoreParameterIndex(parameterIndex)].setMysqlType(MysqlType.TEXT);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setURL(int parameterIndex, URL arg)
    throws SQLException
  {
    try
    {
      if (arg == null)
      {
        setNull(parameterIndex, MysqlType.VARCHAR);
      }
      else
      {
        setString(parameterIndex, arg.toString());
        ((PreparedQuery)query).getQueryBindings().getBindValues()[getCoreParameterIndex(parameterIndex)].setMysqlType(MysqlType.VARCHAR);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ClientPreparedStatement
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */