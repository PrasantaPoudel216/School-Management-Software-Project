package com.mysql.cj.jdbc;

import com.mysql.cj.MysqlConnection;
import com.mysql.cj.protocol.NetworkResources;
import java.lang.ref.PhantomReference;
import java.lang.ref.ReferenceQueue;

class AbandonedConnectionCleanupThread$ConnectionFinalizerPhantomReference
  extends PhantomReference<MysqlConnection>
{
  private NetworkResources networkResources;
  
  AbandonedConnectionCleanupThread$ConnectionFinalizerPhantomReference(MysqlConnection conn, NetworkResources networkResources, ReferenceQueue<? super MysqlConnection> refQueue)
  {
    super(conn, refQueue);
    this.networkResources = networkResources;
  }
  
  /* Error */
  void finalizeResources()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 2	com/mysql/cj/jdbc/AbandonedConnectionCleanupThread$ConnectionFinalizerPhantomReference:networkResources	Lcom/mysql/cj/protocol/NetworkResources;
    //   4: ifnull +26 -> 30
    //   7: aload_0
    //   8: getfield 2	com/mysql/cj/jdbc/AbandonedConnectionCleanupThread$ConnectionFinalizerPhantomReference:networkResources	Lcom/mysql/cj/protocol/NetworkResources;
    //   11: invokevirtual 3	com/mysql/cj/protocol/NetworkResources:forceClose	()V
    //   14: aload_0
    //   15: aconst_null
    //   16: putfield 2	com/mysql/cj/jdbc/AbandonedConnectionCleanupThread$ConnectionFinalizerPhantomReference:networkResources	Lcom/mysql/cj/protocol/NetworkResources;
    //   19: goto +11 -> 30
    //   22: astore_1
    //   23: aload_0
    //   24: aconst_null
    //   25: putfield 2	com/mysql/cj/jdbc/AbandonedConnectionCleanupThread$ConnectionFinalizerPhantomReference:networkResources	Lcom/mysql/cj/protocol/NetworkResources;
    //   28: aload_1
    //   29: athrow
    //   30: return
    // Line number table:
    //   Java source line #235	-> byte code offset #0
    //   Java source line #237	-> byte code offset #7
    //   Java source line #239	-> byte code offset #14
    //   Java source line #240	-> byte code offset #19
    //   Java source line #239	-> byte code offset #22
    //   Java source line #240	-> byte code offset #28
    //   Java source line #242	-> byte code offset #30
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	31	0	this	ConnectionFinalizerPhantomReference
    //   22	7	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   7	14	22	finally
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.AbandonedConnectionCleanupThread.ConnectionFinalizerPhantomReference
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */