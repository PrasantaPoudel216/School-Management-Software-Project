package com.mysql.cj.jdbc;

import com.mysql.cj.jdbc.interceptors.ConnectionLifecycleInterceptor;
import java.sql.SQLException;
import java.util.Iterator;

class ConnectionImpl$5
  extends IterateBlock<ConnectionLifecycleInterceptor>
{
  ConnectionImpl$5(ConnectionImpl this$0, Iterator i, boolean paramBoolean)
  {
    super(i);
  }
  
  void forEach(ConnectionLifecycleInterceptor each)
    throws SQLException
  {
    if (!each.setAutoCommit(val$autoCommitFlag)) {
      stopIterating = true;
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionImpl.5
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */