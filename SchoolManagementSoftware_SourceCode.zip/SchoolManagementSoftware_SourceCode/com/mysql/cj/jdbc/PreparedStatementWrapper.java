package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
import java.io.InputStream;
import java.io.Reader;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.net.URL;
import java.sql.Array;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.ParameterMetaData;
import java.sql.PreparedStatement;
import java.sql.Ref;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

public class PreparedStatementWrapper
  extends StatementWrapper
  implements PreparedStatement
{
  protected static PreparedStatementWrapper getInstance(ConnectionWrapper c, MysqlPooledConnection conn, PreparedStatement toWrap)
    throws SQLException
  {
    return new PreparedStatementWrapper(c, conn, toWrap);
  }
  
  PreparedStatementWrapper(ConnectionWrapper c, MysqlPooledConnection conn, PreparedStatement toWrap)
  {
    super(c, conn, toWrap);
  }
  
  public void setArray(int parameterIndex, Array x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setArray(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setAsciiStream(parameterIndex, x, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBigDecimal(int parameterIndex, BigDecimal x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBigDecimal(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBinaryStream(parameterIndex, x, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBlob(int parameterIndex, Blob x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBlob(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBoolean(int parameterIndex, boolean x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBoolean(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setByte(int parameterIndex, byte x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setByte(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBytes(int parameterIndex, byte[] x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBytes(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader, int length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setCharacterStream(parameterIndex, reader, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setClob(int parameterIndex, Clob x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setClob(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setDate(int parameterIndex, Date x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setDate(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setDate(int parameterIndex, Date x, Calendar cal)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setDate(parameterIndex, x, cal);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setDouble(int parameterIndex, double x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setDouble(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setFloat(int parameterIndex, float x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setFloat(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setInt(int parameterIndex, int x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setInt(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setLong(int parameterIndex, long x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setLong(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public ResultSetMetaData getMetaData()
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        return ((PreparedStatement)wrappedStmt).getMetaData();
      }
      throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
    return null;
  }
  
  public void setNull(int parameterIndex, int sqlType)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setNull(parameterIndex, sqlType);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setNull(int parameterIndex, int sqlType, String typeName)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setNull(parameterIndex, sqlType, typeName);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setObject(int parameterIndex, Object x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setObject(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setObject(int parameterIndex, Object x, int targetSqlType)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setObject(parameterIndex, x, targetSqlType);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setObject(int parameterIndex, Object x, int targetSqlType, int scale)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setObject(parameterIndex, x, targetSqlType, scale);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public ParameterMetaData getParameterMetaData()
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        return ((PreparedStatement)wrappedStmt).getParameterMetaData();
      }
      throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
    return null;
  }
  
  public void setRef(int parameterIndex, Ref x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setRef(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setShort(int parameterIndex, short x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setShort(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setString(int parameterIndex, String x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setString(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setTime(int parameterIndex, Time x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setTime(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setTime(int parameterIndex, Time x, Calendar cal)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setTime(parameterIndex, x, cal);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setTimestamp(int parameterIndex, Timestamp x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setTimestamp(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setTimestamp(parameterIndex, x, cal);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setURL(int parameterIndex, URL x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setURL(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  @Deprecated
  public void setUnicodeStream(int parameterIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setUnicodeStream(parameterIndex, x, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void addBatch()
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).addBatch();
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void clearParameters()
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).clearParameters();
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public boolean execute()
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        return ((PreparedStatement)wrappedStmt).execute();
      }
      throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
    return false;
  }
  
  public ResultSet executeQuery()
    throws SQLException
  {
    ResultSet rs = null;
    try
    {
      if (wrappedStmt == null) {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
      rs = ((PreparedStatement)wrappedStmt).executeQuery();
      ((ResultSetInternalMethods)rs).setWrapperStatement(this);
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
    return rs;
  }
  
  public int executeUpdate()
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        return ((PreparedStatement)wrappedStmt).executeUpdate();
      }
      throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
    return -1;
  }
  
  public String toString()
  {
    StringBuilder buf = new StringBuilder(super.toString());
    if (wrappedStmt != null)
    {
      buf.append(": ");
      try
      {
        buf.append(((ClientPreparedStatement)wrappedStmt).asSql());
      }
      catch (SQLException sqlEx)
      {
        buf.append("EXCEPTION: " + sqlEx.toString());
      }
    }
    return buf.toString();
  }
  
  public void setRowId(int parameterIndex, RowId x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setRowId(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setNString(int parameterIndex, String value)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setNString(parameterIndex, value);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setNCharacterStream(int parameterIndex, Reader value, long length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setNCharacterStream(parameterIndex, value, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setNClob(int parameterIndex, NClob value)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setNClob(parameterIndex, value);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setClob(int parameterIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setClob(parameterIndex, reader, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBlob(int parameterIndex, InputStream inputStream, long length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBlob(parameterIndex, inputStream, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setNClob(int parameterIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setNClob(parameterIndex, reader, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setSQLXML(int parameterIndex, SQLXML xmlObject)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setSQLXML(parameterIndex, xmlObject);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x, long length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setAsciiStream(parameterIndex, x, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x, long length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBinaryStream(parameterIndex, x, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setCharacterStream(parameterIndex, reader, length);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setAsciiStream(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBinaryStream(parameterIndex, x);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setCharacterStream(parameterIndex, reader);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setNCharacterStream(int parameterIndex, Reader value)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setNCharacterStream(parameterIndex, value);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setClob(int parameterIndex, Reader reader)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setClob(parameterIndex, reader);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setBlob(int parameterIndex, InputStream inputStream)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setBlob(parameterIndex, inputStream);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setNClob(int parameterIndex, Reader reader)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setNClob(parameterIndex, reader);
      } else {
        throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    boolean isInstance = iface.isInstance(this);
    if (isInstance) {
      return true;
    }
    String interfaceClassName = iface.getName();
    
    return (interfaceClassName.equals("com.mysql.cj.jdbc.Statement")) || (interfaceClassName.equals("java.sql.Statement")) || 
      (interfaceClassName.equals("java.sql.Wrapper")) || (interfaceClassName.equals("java.sql.PreparedStatement"));
  }
  
  public synchronized <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      if (("java.sql.Statement".equals(iface.getName())) || ("java.sql.PreparedStatement".equals(iface.getName())) || 
        ("java.sql.Wrapper.class".equals(iface.getName()))) {
        return (T)iface.cast(this);
      }
      if (unwrappedInterfaces == null) {
        unwrappedInterfaces = new HashMap();
      }
      Object cachedUnwrapped = unwrappedInterfaces.get(iface);
      if (cachedUnwrapped == null)
      {
        cachedUnwrapped = Proxy.newProxyInstance(wrappedStmt.getClass().getClassLoader(), new Class[] { iface }, new WrapperBase.ConnectionErrorFiringInvocationHandler(this, wrappedStmt));
        
        unwrappedInterfaces.put(iface, cachedUnwrapped);
      }
      return (T)iface.cast(cachedUnwrapped);
    }
    catch (ClassCastException cce)
    {
      throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", exceptionInterceptor);
    }
  }
  
  /* Error */
  public synchronized void close()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 108	com/mysql/cj/jdbc/PreparedStatementWrapper:pooledConnection	Lcom/mysql/cj/jdbc/MysqlPooledConnection;
    //   4: ifnonnull +4 -> 8
    //   7: return
    //   8: aload_0
    //   9: getfield 108	com/mysql/cj/jdbc/PreparedStatementWrapper:pooledConnection	Lcom/mysql/cj/jdbc/MysqlPooledConnection;
    //   12: astore_1
    //   13: aload_0
    //   14: invokespecial 109	com/mysql/cj/jdbc/StatementWrapper:close	()V
    //   17: new 110	javax/sql/StatementEvent
    //   20: dup
    //   21: aload_1
    //   22: aload_0
    //   23: invokespecial 111	javax/sql/StatementEvent:<init>	(Ljavax/sql/PooledConnection;Ljava/sql/PreparedStatement;)V
    //   26: astore_2
    //   27: aload_1
    //   28: aload_2
    //   29: invokevirtual 112	com/mysql/cj/jdbc/MysqlPooledConnection:fireStatementEvent	(Ljavax/sql/StatementEvent;)V
    //   32: aload_0
    //   33: aconst_null
    //   34: putfield 91	com/mysql/cj/jdbc/PreparedStatementWrapper:unwrappedInterfaces	Ljava/util/Map;
    //   37: goto +11 -> 48
    //   40: astore_3
    //   41: aload_0
    //   42: aconst_null
    //   43: putfield 91	com/mysql/cj/jdbc/PreparedStatementWrapper:unwrappedInterfaces	Ljava/util/Map;
    //   46: aload_3
    //   47: athrow
    //   48: goto +43 -> 91
    //   51: astore 4
    //   53: new 110	javax/sql/StatementEvent
    //   56: dup
    //   57: aload_1
    //   58: aload_0
    //   59: invokespecial 111	javax/sql/StatementEvent:<init>	(Ljavax/sql/PooledConnection;Ljava/sql/PreparedStatement;)V
    //   62: astore 5
    //   64: aload_1
    //   65: aload 5
    //   67: invokevirtual 112	com/mysql/cj/jdbc/MysqlPooledConnection:fireStatementEvent	(Ljavax/sql/StatementEvent;)V
    //   70: aload_0
    //   71: aconst_null
    //   72: putfield 91	com/mysql/cj/jdbc/PreparedStatementWrapper:unwrappedInterfaces	Ljava/util/Map;
    //   75: goto +13 -> 88
    //   78: astore 6
    //   80: aload_0
    //   81: aconst_null
    //   82: putfield 91	com/mysql/cj/jdbc/PreparedStatementWrapper:unwrappedInterfaces	Ljava/util/Map;
    //   85: aload 6
    //   87: athrow
    //   88: aload 4
    //   90: athrow
    //   91: return
    // Line number table:
    //   Java source line #922	-> byte code offset #0
    //   Java source line #924	-> byte code offset #7
    //   Java source line #927	-> byte code offset #8
    //   Java source line #930	-> byte code offset #13
    //   Java source line #933	-> byte code offset #17
    //   Java source line #934	-> byte code offset #27
    //   Java source line #936	-> byte code offset #32
    //   Java source line #937	-> byte code offset #37
    //   Java source line #936	-> byte code offset #40
    //   Java source line #937	-> byte code offset #46
    //   Java source line #938	-> byte code offset #48
    //   Java source line #932	-> byte code offset #51
    //   Java source line #933	-> byte code offset #53
    //   Java source line #934	-> byte code offset #64
    //   Java source line #936	-> byte code offset #70
    //   Java source line #937	-> byte code offset #75
    //   Java source line #936	-> byte code offset #78
    //   Java source line #937	-> byte code offset #85
    //   Java source line #938	-> byte code offset #88
    //   Java source line #939	-> byte code offset #91
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	92	0	this	PreparedStatementWrapper
    //   12	53	1	con	MysqlPooledConnection
    //   26	3	2	e	javax.sql.StatementEvent
    //   40	7	3	localObject1	Object
    //   51	38	4	localObject2	Object
    //   62	4	5	e	javax.sql.StatementEvent
    //   78	8	6	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   17	32	40	finally
    //   13	17	51	finally
    //   51	53	51	finally
    //   53	70	78	finally
    //   78	80	78	finally
  }
  
  public long executeLargeUpdate()
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        return ((ClientPreparedStatement)wrappedStmt).executeLargeUpdate();
      }
      throw SQLError.createSQLException(Messages.getString("Statement.AlreadyClosed"), "S1009", exceptionInterceptor);
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
    return -1L;
  }
  
  public void setObject(int parameterIndex, Object x, SQLType targetSqlType)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setObject(parameterIndex, x, targetSqlType);
      } else {
        throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
  
  public void setObject(int parameterIndex, Object x, SQLType targetSqlType, int scaleOrLength)
    throws SQLException
  {
    try
    {
      if (wrappedStmt != null) {
        ((PreparedStatement)wrappedStmt).setObject(parameterIndex, x, targetSqlType, scaleOrLength);
      } else {
        throw SQLError.createSQLException("No operations allowed after statement closed", "S1000", exceptionInterceptor);
      }
    }
    catch (SQLException sqlEx)
    {
      checkAndFireConnectionError(sqlEx);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.PreparedStatementWrapper
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */