package com.mysql.cj.jdbc;

import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.util.StringUtils;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.SortedMap;

class DatabaseMetaData$6
  extends IterateBlock<String>
{
  DatabaseMetaData$6(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, String paramString, Statement paramStatement, boolean paramBoolean1, boolean paramBoolean2, SortedMap paramSortedMap)
  {
    super(i);
  }
  
  void forEach(String dbStr)
    throws SQLException
  {
    ResultSet results = null;
    try
    {
      StringBuilder queryBuf = new StringBuilder("SHOW INDEX FROM ");
      queryBuf.append(StringUtils.quoteIdentifier(val$table, this$0.quotedId, this$0.pedantic));
      queryBuf.append(" FROM ");
      queryBuf.append(StringUtils.quoteIdentifier(dbStr, this$0.quotedId, this$0.pedantic));
      try
      {
        results = val$stmt.executeQuery(queryBuf.toString());
      }
      catch (SQLException sqlEx)
      {
        String sqlState = sqlEx.getSQLState();
        int errorCode = sqlEx.getErrorCode();
        if ((!"42S02".equals(sqlState)) && (errorCode != 1146) && (errorCode != 1049)) {
          throw sqlEx;
        }
      }
      while ((results != null) && (results.next()))
      {
        byte[][] row = new byte[14][];
        row[0] = (val$dbMapsToSchema ? this$0.s2b("def") : this$0.s2b(dbStr));
        row[1] = (val$dbMapsToSchema ? this$0.s2b(dbStr) : null);
        row[2] = results.getBytes("Table");
        
        boolean indexIsUnique = results.getInt("Non_unique") == 0;
        
        row[3] = (!indexIsUnique ? this$0.s2b("true") : this$0.s2b("false"));
        row[4] = null;
        row[5] = results.getBytes("Key_name");
        short indexType = 3;
        row[6] = Integer.toString(indexType).getBytes();
        row[7] = results.getBytes("Seq_in_index");
        row[8] = results.getBytes("Column_name");
        row[9] = results.getBytes("Collation");
        
        long cardinality = results.getLong("Cardinality");
        
        row[10] = this$0.s2b(String.valueOf(cardinality));
        row[11] = this$0.s2b("0");
        row[12] = null;
        
        DatabaseMetaData.IndexMetaDataKey indexInfoKey = new DatabaseMetaData.IndexMetaDataKey(this$0, !indexIsUnique, indexType, results.getString("Key_name").toLowerCase(), results.getShort("Seq_in_index"));
        if (val$unique)
        {
          if (indexIsUnique) {
            val$sortedRows.put(indexInfoKey, new ByteArrayRow(row, this$0.getExceptionInterceptor()));
          }
        }
        else {
          val$sortedRows.put(indexInfoKey, new ByteArrayRow(row, this$0.getExceptionInterceptor()));
        }
      }
    }
    finally
    {
      if (results != null)
      {
        try
        {
          results.close();
        }
        catch (Exception localException1) {}
        results = null;
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.6
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */