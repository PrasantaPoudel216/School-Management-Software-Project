package com.mysql.cj.jdbc;

import com.mysql.cj.conf.PropertySet;
import java.sql.DriverPropertyInfo;
import java.sql.SQLException;
import java.util.Properties;

public abstract interface JdbcPropertySet
  extends PropertySet
{
  public abstract DriverPropertyInfo[] exposeAsDriverPropertyInfo(Properties paramProperties, int paramInt)
    throws SQLException;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.JdbcPropertySet
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */