package com.mysql.cj.jdbc;

class CallableStatement$1 {}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.CallableStatement.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */