package com.mysql.cj.jdbc;

import java.sql.SQLException;

class ConnectionImpl$7
  implements Runnable
{
  ConnectionImpl$7(ConnectionImpl this$0) {}
  
  public void run()
  {
    try
    {
      this$0.abortInternal();
    }
    catch (SQLException e)
    {
      throw new RuntimeException(e);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionImpl.7
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */