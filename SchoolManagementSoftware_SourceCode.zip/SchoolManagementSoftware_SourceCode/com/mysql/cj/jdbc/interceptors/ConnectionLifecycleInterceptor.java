package com.mysql.cj.jdbc.interceptors;

import com.mysql.cj.MysqlConnection;
import com.mysql.cj.log.Log;
import java.sql.SQLException;
import java.sql.Savepoint;
import java.util.Properties;

public abstract interface ConnectionLifecycleInterceptor
{
  public abstract ConnectionLifecycleInterceptor init(MysqlConnection paramMysqlConnection, Properties paramProperties, Log paramLog);
  
  public abstract void destroy();
  
  public abstract void close()
    throws SQLException;
  
  public abstract boolean commit()
    throws SQLException;
  
  public abstract boolean rollback()
    throws SQLException;
  
  public abstract boolean rollback(Savepoint paramSavepoint)
    throws SQLException;
  
  public abstract boolean setAutoCommit(boolean paramBoolean)
    throws SQLException;
  
  public abstract boolean setDatabase(String paramString)
    throws SQLException;
  
  public abstract boolean transactionBegun();
  
  public abstract boolean transactionCompleted();
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.interceptors.ConnectionLifecycleInterceptor
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */