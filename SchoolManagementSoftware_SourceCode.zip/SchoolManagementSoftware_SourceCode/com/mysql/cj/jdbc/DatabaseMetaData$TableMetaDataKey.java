package com.mysql.cj.jdbc;

public class DatabaseMetaData$TableMetaDataKey
  implements Comparable<TableMetaDataKey>
{
  String tableType;
  String tableCat;
  String tableSchem;
  String tableName;
  
  DatabaseMetaData$TableMetaDataKey(DatabaseMetaData this$0, String tableType, String tableCat, String tableSchem, String tableName)
  {
    this.tableType = (tableType == null ? "" : tableType);
    this.tableCat = (tableCat == null ? "" : tableCat);
    this.tableSchem = (tableSchem == null ? "" : tableSchem);
    this.tableName = (tableName == null ? "" : tableName);
  }
  
  public int compareTo(TableMetaDataKey tablesKey)
  {
    int compareResult;
    if ((compareResult = tableType.compareTo(tableType)) != 0) {
      return compareResult;
    }
    if ((compareResult = tableCat.compareTo(tableCat)) != 0) {
      return compareResult;
    }
    if ((compareResult = tableSchem.compareTo(tableSchem)) != 0) {
      return compareResult;
    }
    return tableName.compareTo(tableName);
  }
  
  public boolean equals(Object obj)
  {
    if (obj == null) {
      return false;
    }
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof TableMetaDataKey)) {
      return false;
    }
    return compareTo((TableMetaDataKey)obj) == 0;
  }
  
  public int hashCode()
  {
    if (!$assertionsDisabled) {
      throw new AssertionError("hashCode not designed");
    }
    return 0;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.TableMetaDataKey
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */