package com.mysql.cj.jdbc;

import com.mysql.cj.util.LRUCache;
import java.sql.SQLException;
import java.util.Map.Entry;

class ConnectionImpl$2
  extends LRUCache<ConnectionImpl.CompoundCacheKey, ServerPreparedStatement>
{
  private static final long serialVersionUID = 7692318650375988114L;
  
  ConnectionImpl$2(ConnectionImpl this$0, int maxSize)
  {
    super(maxSize);
  }
  
  protected boolean removeEldestEntry(Map.Entry<ConnectionImpl.CompoundCacheKey, ServerPreparedStatement> eldest)
  {
    if (maxElements <= 1) {
      return false;
    }
    boolean removeIt = super.removeEldestEntry(eldest);
    if (removeIt)
    {
      ServerPreparedStatement ps = (ServerPreparedStatement)eldest.getValue();
      isCached = false;
      ps.setClosed(false);
      try
      {
        ps.realClose(true, true);
      }
      catch (SQLException localSQLException) {}
    }
    return removeIt;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionImpl.2
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */