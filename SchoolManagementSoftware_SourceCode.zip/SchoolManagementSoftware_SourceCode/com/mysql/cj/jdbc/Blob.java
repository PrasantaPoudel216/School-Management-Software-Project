package com.mysql.cj.jdbc;

import com.mysql.cj.Constants;
import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
import com.mysql.cj.protocol.OutputStreamWatcher;
import com.mysql.cj.protocol.WatchableOutputStream;
import com.mysql.cj.protocol.WatchableStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;

public class Blob
  implements java.sql.Blob, OutputStreamWatcher
{
  private byte[] binaryData = null;
  private boolean isClosed = false;
  private ExceptionInterceptor exceptionInterceptor;
  
  Blob(ExceptionInterceptor exceptionInterceptor)
  {
    setBinaryData(Constants.EMPTY_BYTE_ARRAY);
    this.exceptionInterceptor = exceptionInterceptor;
  }
  
  public Blob(byte[] data, ExceptionInterceptor exceptionInterceptor)
  {
    setBinaryData(data);
    this.exceptionInterceptor = exceptionInterceptor;
  }
  
  Blob(byte[] data, ResultSetInternalMethods creatorResultSetToSet, int columnIndexToSet)
  {
    setBinaryData(data);
  }
  
  private synchronized byte[] getBinaryData()
  {
    return binaryData;
  }
  
  public synchronized InputStream getBinaryStream()
    throws SQLException
  {
    try
    {
      checkClosed();
      
      return new ByteArrayInputStream(getBinaryData());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized byte[] getBytes(long pos, int length)
    throws SQLException
  {
    try
    {
      checkClosed();
      if (pos < 1L) {
        throw SQLError.createSQLException(Messages.getString("Blob.2"), "S1009", exceptionInterceptor);
      }
      pos -= 1L;
      if (pos > binaryData.length) {
        throw SQLError.createSQLException(Messages.getString("Blob.3"), "S1009", exceptionInterceptor);
      }
      if (pos + length > binaryData.length) {
        throw SQLError.createSQLException(Messages.getString("Blob.4"), "S1009", exceptionInterceptor);
      }
      byte[] newData = new byte[length];
      System.arraycopy(getBinaryData(), (int)pos, newData, 0, length);
      
      return newData;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized long length()
    throws SQLException
  {
    try
    {
      checkClosed();
      
      return getBinaryData().length;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized long position(byte[] pattern, long start)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized long position(java.sql.Blob pattern, long start)
    throws SQLException
  {
    try
    {
      checkClosed();
      
      return position(pattern.getBytes(0L, (int)pattern.length()), start);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  private synchronized void setBinaryData(byte[] newBinaryData)
  {
    binaryData = newBinaryData;
  }
  
  public synchronized OutputStream setBinaryStream(long indexToWriteAt)
    throws SQLException
  {
    try
    {
      checkClosed();
      if (indexToWriteAt < 1L) {
        throw SQLError.createSQLException(Messages.getString("Blob.0"), "S1009", exceptionInterceptor);
      }
      WatchableOutputStream bytesOut = new WatchableOutputStream();
      bytesOut.setWatcher(this);
      if (indexToWriteAt > 0L) {
        bytesOut.write(binaryData, 0, (int)(indexToWriteAt - 1L));
      }
      return bytesOut;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized int setBytes(long writeAt, byte[] bytes)
    throws SQLException
  {
    try
    {
      checkClosed();
      
      return setBytes(writeAt, bytes, 0, bytes.length);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized int setBytes(long writeAt, byte[] bytes, int offset, int length)
    throws SQLException
  {
    try
    {
      checkClosed();
      
      OutputStream bytesOut = setBinaryStream(writeAt);
      try
      {
        bytesOut.write(bytes, offset, length);
        SQLException sqlEx;
        return length;
      }
      catch (IOException ioEx)
      {
        sqlEx = SQLError.createSQLException(Messages.getString("Blob.1"), "S1000", exceptionInterceptor);
        
        sqlEx.initCause(ioEx);
        
        throw sqlEx;
      }
      finally
      {
        try
        {
          bytesOut.close();
        }
        catch (IOException localIOException2) {}
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized void streamClosed(byte[] byteData)
  {
    binaryData = byteData;
  }
  
  public synchronized void streamClosed(WatchableStream out)
  {
    int streamSize = out.size();
    if (streamSize < binaryData.length) {
      out.write(binaryData, streamSize, binaryData.length - streamSize);
    }
    binaryData = out.toByteArray();
  }
  
  public synchronized void truncate(long len)
    throws SQLException
  {
    try
    {
      checkClosed();
      if (len < 0L) {
        throw SQLError.createSQLException(Messages.getString("Blob.5"), "S1009", exceptionInterceptor);
      }
      if (len > binaryData.length) {
        throw SQLError.createSQLException(Messages.getString("Blob.6"), "S1009", exceptionInterceptor);
      }
      byte[] newData = new byte[(int)len];
      System.arraycopy(getBinaryData(), 0, newData, 0, (int)len);
      binaryData = newData;
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized void free()
    throws SQLException
  {
    try
    {
      binaryData = null;
      isClosed = true;
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized InputStream getBinaryStream(long pos, long length)
    throws SQLException
  {
    try
    {
      checkClosed();
      if (pos < 1L) {
        throw SQLError.createSQLException(Messages.getString("Blob.2"), "S1009", exceptionInterceptor);
      }
      pos -= 1L;
      if (pos > binaryData.length) {
        throw SQLError.createSQLException(Messages.getString("Blob.6"), "S1009", exceptionInterceptor);
      }
      if (pos + length > binaryData.length) {
        throw SQLError.createSQLException(Messages.getString("Blob.4"), "S1009", exceptionInterceptor);
      }
      return new ByteArrayInputStream(getBinaryData(), (int)pos, (int)length);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  private synchronized void checkClosed()
    throws SQLException
  {
    if (isClosed) {
      throw SQLError.createSQLException(Messages.getString("Blob.7"), "S1009", exceptionInterceptor);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.Blob
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */