package com.mysql.cj.jdbc;

import com.mysql.cj.jdbc.interceptors.ConnectionLifecycleInterceptor;
import java.sql.SQLException;
import java.util.Iterator;

class ConnectionImpl$1
  extends IterateBlock<ConnectionLifecycleInterceptor>
{
  ConnectionImpl$1(ConnectionImpl this$0, Iterator i)
  {
    super(i);
  }
  
  void forEach(ConnectionLifecycleInterceptor each)
    throws SQLException
  {
    if (!each.commit()) {
      stopIterating = true;
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionImpl.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */