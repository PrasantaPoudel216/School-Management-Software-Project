package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.Session;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.log.Log;
import com.mysql.cj.util.StringUtils;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.sql.XAConnection;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;

public class MysqlXAConnection
  extends MysqlPooledConnection
  implements XAConnection, XAResource
{
  private static final int MAX_COMMAND_LENGTH = 300;
  private JdbcConnection underlyingConnection;
  private static final Map<Integer, Integer> MYSQL_ERROR_CODES_TO_XA_ERROR_CODES;
  private Log log;
  protected boolean logXaCommands;
  
  static
  {
    HashMap<Integer, Integer> temp = new HashMap();
    
    temp.put(Integer.valueOf(1397), Integer.valueOf(-4));
    temp.put(Integer.valueOf(1398), Integer.valueOf(-5));
    temp.put(Integer.valueOf(1399), Integer.valueOf(-7));
    temp.put(Integer.valueOf(1400), Integer.valueOf(-9));
    temp.put(Integer.valueOf(1401), Integer.valueOf(-3));
    temp.put(Integer.valueOf(1402), Integer.valueOf(100));
    temp.put(Integer.valueOf(1440), Integer.valueOf(-8));
    temp.put(Integer.valueOf(1613), Integer.valueOf(106));
    temp.put(Integer.valueOf(1614), Integer.valueOf(102));
    
    MYSQL_ERROR_CODES_TO_XA_ERROR_CODES = Collections.unmodifiableMap(temp);
  }
  
  protected static MysqlXAConnection getInstance(JdbcConnection mysqlConnection, boolean logXaCommands)
    throws SQLException
  {
    return new MysqlXAConnection(mysqlConnection, logXaCommands);
  }
  
  public MysqlXAConnection(JdbcConnection connection, boolean logXaCommands)
  {
    super(connection);
    underlyingConnection = connection;
    log = connection.getSession().getLog();
    this.logXaCommands = logXaCommands;
  }
  
  public XAResource getXAResource()
    throws SQLException
  {
    try
    {
      return this;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public int getTransactionTimeout()
    throws XAException
  {
    return 0;
  }
  
  public boolean setTransactionTimeout(int arg0)
    throws XAException
  {
    return false;
  }
  
  public boolean isSameRM(XAResource xares)
    throws XAException
  {
    if ((xares instanceof MysqlXAConnection)) {
      return underlyingConnection.isSameResource(underlyingConnection);
    }
    return false;
  }
  
  public Xid[] recover(int flag)
    throws XAException
  {
    return recover(underlyingConnection, flag);
  }
  
  protected static Xid[] recover(Connection c, int flag)
    throws XAException
  {
    boolean startRscan = (flag & 0x1000000) > 0;
    boolean endRscan = (flag & 0x800000) > 0;
    if ((!startRscan) && (!endRscan) && (flag != 0)) {
      throw new MysqlXAException(-5, Messages.getString("MysqlXAConnection.001"), null);
    }
    if (!startRscan) {
      return new Xid[0];
    }
    ResultSet rs = null;
    Statement stmt = null;
    
    List<MysqlXid> recoveredXidList = new ArrayList();
    try
    {
      stmt = c.createStatement();
      
      rs = stmt.executeQuery("XA RECOVER");
      while (rs.next())
      {
        int formatId = rs.getInt(1);
        int gtridLength = rs.getInt(2);
        int bqualLength = rs.getInt(3);
        byte[] gtridAndBqual = rs.getBytes(4);
        
        byte[] gtrid = new byte[gtridLength];
        byte[] bqual = new byte[bqualLength];
        if (gtridAndBqual.length != gtridLength + bqualLength) {
          throw new MysqlXAException(105, Messages.getString("MysqlXAConnection.002"), null);
        }
        System.arraycopy(gtridAndBqual, 0, gtrid, 0, gtridLength);
        System.arraycopy(gtridAndBqual, gtridLength, bqual, 0, bqualLength);
        
        recoveredXidList.add(new MysqlXid(gtrid, bqual, formatId));
      }
      if (rs != null) {
        try
        {
          rs.close();
        }
        catch (SQLException sqlEx)
        {
          throw mapXAExceptionFromSQLException(sqlEx);
        }
      }
      if (stmt != null) {
        try
        {
          stmt.close();
        }
        catch (SQLException sqlEx)
        {
          throw mapXAExceptionFromSQLException(sqlEx);
        }
      }
      numXids = recoveredXidList.size();
    }
    catch (SQLException sqlEx)
    {
      throw mapXAExceptionFromSQLException(sqlEx);
    }
    finally
    {
      if (rs != null) {
        try
        {
          rs.close();
        }
        catch (SQLException sqlEx)
        {
          throw mapXAExceptionFromSQLException(sqlEx);
        }
      }
      if (stmt != null) {
        try
        {
          stmt.close();
        }
        catch (SQLException sqlEx)
        {
          throw mapXAExceptionFromSQLException(sqlEx);
        }
      }
    }
    int numXids;
    Xid[] asXids = new Xid[numXids];
    Object[] asObjects = recoveredXidList.toArray();
    for (int i = 0; i < numXids; i++) {
      asXids[i] = ((Xid)asObjects[i]);
    }
    return asXids;
  }
  
  public int prepare(Xid xid)
    throws XAException
  {
    StringBuilder commandBuf = new StringBuilder(300);
    commandBuf.append("XA PREPARE ");
    appendXid(commandBuf, xid);
    
    dispatchCommand(commandBuf.toString());
    
    return 0;
  }
  
  public void end(Xid xid, int flags)
    throws XAException
  {
    StringBuilder commandBuf = new StringBuilder(300);
    commandBuf.append("XA END ");
    appendXid(commandBuf, xid);
    switch (flags)
    {
    case 67108864: 
      break;
    case 33554432: 
      commandBuf.append(" SUSPEND");
      break;
    case 536870912: 
      break;
    default: 
      throw new XAException(-5);
    }
    dispatchCommand(commandBuf.toString());
  }
  
  public void start(Xid xid, int flags)
    throws XAException
  {
    StringBuilder commandBuf = new StringBuilder(300);
    commandBuf.append("XA START ");
    appendXid(commandBuf, xid);
    switch (flags)
    {
    case 2097152: 
      commandBuf.append(" JOIN");
      break;
    case 134217728: 
      commandBuf.append(" RESUME");
      break;
    case 0: 
      break;
    default: 
      throw new XAException(-5);
    }
    dispatchCommand(commandBuf.toString());
    
    underlyingConnection.setInGlobalTx(true);
  }
  
  public void commit(Xid xid, boolean onePhase)
    throws XAException
  {
    StringBuilder commandBuf = new StringBuilder(300);
    commandBuf.append("XA COMMIT ");
    appendXid(commandBuf, xid);
    if (onePhase) {
      commandBuf.append(" ONE PHASE");
    }
    try
    {
      dispatchCommand(commandBuf.toString());
    }
    finally
    {
      underlyingConnection.setInGlobalTx(false);
    }
  }
  
  private ResultSet dispatchCommand(String command)
    throws XAException
  {
    Statement stmt = null;
    try
    {
      if (logXaCommands) {
        log.logDebug("Executing XA statement: " + command);
      }
      stmt = underlyingConnection.createStatement();
      
      stmt.execute(command);
      
      ResultSet rs = stmt.getResultSet();
      
      return rs;
    }
    catch (SQLException sqlEx)
    {
      throw mapXAExceptionFromSQLException(sqlEx);
    }
    finally
    {
      if (stmt != null) {
        try
        {
          stmt.close();
        }
        catch (SQLException localSQLException2) {}
      }
    }
  }
  
  protected static XAException mapXAExceptionFromSQLException(SQLException sqlEx)
  {
    Integer xaCode = (Integer)MYSQL_ERROR_CODES_TO_XA_ERROR_CODES.get(Integer.valueOf(sqlEx.getErrorCode()));
    if (xaCode != null) {
      return (XAException)new MysqlXAException(xaCode.intValue(), sqlEx.getMessage(), null).initCause(sqlEx);
    }
    return (XAException)new MysqlXAException(-7, Messages.getString("MysqlXAConnection.003"), null).initCause(sqlEx);
  }
  
  private static void appendXid(StringBuilder builder, Xid xid)
  {
    byte[] gtrid = xid.getGlobalTransactionId();
    byte[] btrid = xid.getBranchQualifier();
    if (gtrid != null) {
      StringUtils.appendAsHex(builder, gtrid);
    }
    builder.append(',');
    if (btrid != null) {
      StringUtils.appendAsHex(builder, btrid);
    }
    builder.append(',');
    StringUtils.appendAsHex(builder, xid.getFormatId());
  }
  
  public synchronized Connection getConnection()
    throws SQLException
  {
    try
    {
      return getConnection(false, true);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public void forget(Xid xid)
    throws XAException
  {}
  
  /* Error */
  public void rollback(Xid xid)
    throws XAException
  {
    // Byte code:
    //   0: new 39	java/lang/StringBuilder
    //   3: dup
    //   4: sipush 300
    //   7: invokespecial 40	java/lang/StringBuilder:<init>	(I)V
    //   10: astore_2
    //   11: aload_2
    //   12: ldc 46
    //   14: invokevirtual 42	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   17: pop
    //   18: aload_2
    //   19: aload_1
    //   20: invokestatic 43	com/mysql/cj/jdbc/MysqlXAConnection:appendXid	(Ljava/lang/StringBuilder;Ljavax/transaction/xa/Xid;)V
    //   23: aload_0
    //   24: aload_2
    //   25: invokevirtual 44	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   28: invokespecial 45	com/mysql/cj/jdbc/MysqlXAConnection:dispatchCommand	(Ljava/lang/String;)Ljava/sql/ResultSet;
    //   31: pop
    //   32: aload_0
    //   33: getfield 4	com/mysql/cj/jdbc/MysqlXAConnection:underlyingConnection	Lcom/mysql/cj/jdbc/JdbcConnection;
    //   36: iconst_0
    //   37: invokeinterface 47 2 0
    //   42: goto +16 -> 58
    //   45: astore_3
    //   46: aload_0
    //   47: getfield 4	com/mysql/cj/jdbc/MysqlXAConnection:underlyingConnection	Lcom/mysql/cj/jdbc/JdbcConnection;
    //   50: iconst_0
    //   51: invokeinterface 47 2 0
    //   56: aload_3
    //   57: athrow
    //   58: return
    // Line number table:
    //   Java source line #238	-> byte code offset #0
    //   Java source line #239	-> byte code offset #11
    //   Java source line #240	-> byte code offset #18
    //   Java source line #243	-> byte code offset #23
    //   Java source line #245	-> byte code offset #32
    //   Java source line #246	-> byte code offset #42
    //   Java source line #245	-> byte code offset #45
    //   Java source line #246	-> byte code offset #56
    //   Java source line #247	-> byte code offset #58
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	59	0	this	MysqlXAConnection
    //   0	59	1	xid	Xid
    //   10	15	2	commandBuf	StringBuilder
    //   45	12	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   23	32	45	finally
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.MysqlXAConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */