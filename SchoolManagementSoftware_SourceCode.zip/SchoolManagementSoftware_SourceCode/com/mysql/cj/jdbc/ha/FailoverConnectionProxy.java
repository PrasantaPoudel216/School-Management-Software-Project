package com.mysql.cj.jdbc.ha;

import com.mysql.cj.Session;
import com.mysql.cj.conf.ConnectionUrl;
import com.mysql.cj.conf.HostInfo;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.jdbc.ConnectionImpl;
import com.mysql.cj.jdbc.JdbcConnection;
import com.mysql.cj.jdbc.JdbcPropertySetImpl;
import com.mysql.cj.jdbc.exceptions.CommunicationsException;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.log.Log;
import com.mysql.cj.util.Util;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.Executor;

public class FailoverConnectionProxy
  extends MultiHostConnectionProxy
{
  private static final String METHOD_SET_READ_ONLY = "setReadOnly";
  private static final String METHOD_SET_AUTO_COMMIT = "setAutoCommit";
  private static final String METHOD_COMMIT = "commit";
  private static final String METHOD_ROLLBACK = "rollback";
  private static final int NO_CONNECTION_INDEX = -1;
  private static final int DEFAULT_PRIMARY_HOST_INDEX = 0;
  private int secondsBeforeRetryPrimaryHost;
  private long queriesBeforeRetryPrimaryHost;
  private boolean failoverReadOnly;
  private int retriesAllDown;
  private int currentHostIndex = -1;
  private int primaryHostIndex = 0;
  private Boolean explicitlyReadOnly = null;
  private boolean explicitlyAutoCommit = true;
  private boolean enableFallBackToPrimaryHost = true;
  private long primaryHostFailTimeMillis = 0L;
  private long queriesIssuedSinceFailover = 0L;
  
  class FailoverJdbcInterfaceProxy
    extends MultiHostConnectionProxy.JdbcInterfaceProxy
  {
    FailoverJdbcInterfaceProxy(Object toInvokeOn)
    {
      super(toInvokeOn);
    }
    
    public Object invoke(Object proxy, Method method, Object[] args)
      throws Throwable
    {
      String methodName = method.getName();
      
      boolean isExecute = methodName.startsWith("execute");
      if ((connectedToSecondaryHost()) && (isExecute)) {
        incrementQueriesIssuedSinceFailover();
      }
      Object result = super.invoke(proxy, method, args);
      if ((explicitlyAutoCommit) && (isExecute) && (readyToFallBackToPrimaryHost())) {
        fallBackToPrimaryIfAvailable();
      }
      return result;
    }
  }
  
  public static JdbcConnection createProxyInstance(ConnectionUrl connectionUrl)
    throws SQLException
  {
    FailoverConnectionProxy connProxy = new FailoverConnectionProxy(connectionUrl);
    
    return (JdbcConnection)Proxy.newProxyInstance(JdbcConnection.class.getClassLoader(), new Class[] { JdbcConnection.class }, connProxy);
  }
  
  private FailoverConnectionProxy(ConnectionUrl connectionUrl)
    throws SQLException
  {
    super(connectionUrl);
    
    JdbcPropertySetImpl connProps = new JdbcPropertySetImpl();
    connProps.initializeProperties(connectionUrl.getConnectionArgumentsAsProperties());
    
    secondsBeforeRetryPrimaryHost = ((Integer)connProps.getIntegerProperty(PropertyKey.secondsBeforeRetryMaster).getValue()).intValue();
    queriesBeforeRetryPrimaryHost = ((Integer)connProps.getIntegerProperty(PropertyKey.queriesBeforeRetryMaster).getValue()).intValue();
    failoverReadOnly = ((Boolean)connProps.getBooleanProperty(PropertyKey.failOverReadOnly).getValue()).booleanValue();
    retriesAllDown = ((Integer)connProps.getIntegerProperty(PropertyKey.retriesAllDown).getValue()).intValue();
    
    enableFallBackToPrimaryHost = ((secondsBeforeRetryPrimaryHost > 0) || (queriesBeforeRetryPrimaryHost > 0L));
    
    pickNewConnection();
    
    explicitlyAutoCommit = currentConnection.getAutoCommit();
  }
  
  MultiHostConnectionProxy.JdbcInterfaceProxy getNewJdbcInterfaceProxy(Object toProxy)
  {
    return new FailoverJdbcInterfaceProxy(toProxy);
  }
  
  boolean shouldExceptionTriggerConnectionSwitch(Throwable t)
  {
    String sqlState = null;
    if (((t instanceof CommunicationsException)) || ((t instanceof CJCommunicationsException))) {
      return true;
    }
    if ((t instanceof SQLException)) {
      sqlState = ((SQLException)t).getSQLState();
    } else if ((t instanceof CJException)) {
      sqlState = ((CJException)t).getSQLState();
    }
    if ((sqlState != null) && 
      (sqlState.startsWith("08"))) {
      return true;
    }
    return false;
  }
  
  boolean isMasterConnection()
  {
    return connectedToPrimaryHost();
  }
  
  synchronized void pickNewConnection()
    throws SQLException
  {
    if ((isClosed) && (closedExplicitly)) {
      return;
    }
    if ((!isConnected()) || (readyToFallBackToPrimaryHost())) {
      try
      {
        connectTo(primaryHostIndex);
      }
      catch (SQLException e)
      {
        resetAutoFallBackCounters();
        failOver(primaryHostIndex);
      }
    } else {
      failOver();
    }
  }
  
  synchronized ConnectionImpl createConnectionForHostIndex(int hostIndex)
    throws SQLException
  {
    return createConnectionForHost((HostInfo)hostsList.get(hostIndex));
  }
  
  private synchronized void connectTo(int hostIndex)
    throws SQLException
  {
    try
    {
      switchCurrentConnectionTo(hostIndex, createConnectionForHostIndex(hostIndex));
    }
    catch (SQLException e)
    {
      if (currentConnection != null)
      {
        StringBuilder msg = new StringBuilder("Connection to ").append(isPrimaryHostIndex(hostIndex) ? "primary" : "secondary").append(" host '").append(hostsList.get(hostIndex)).append("' failed");
        try
        {
          currentConnection.getSession().getLog().logWarn(msg.toString(), e);
        }
        catch (CJException ex)
        {
          throw SQLExceptionsMapping.translateException(e, currentConnection.getExceptionInterceptor());
        }
      }
      throw e;
    }
  }
  
  private synchronized void switchCurrentConnectionTo(int hostIndex, JdbcConnection connection)
    throws SQLException
  {
    invalidateCurrentConnection();
    boolean readOnly;
    boolean readOnly;
    if (isPrimaryHostIndex(hostIndex))
    {
      readOnly = explicitlyReadOnly == null ? false : explicitlyReadOnly.booleanValue();
    }
    else
    {
      boolean readOnly;
      if (failoverReadOnly)
      {
        readOnly = true;
      }
      else
      {
        boolean readOnly;
        if (explicitlyReadOnly != null)
        {
          readOnly = explicitlyReadOnly.booleanValue();
        }
        else
        {
          boolean readOnly;
          if (currentConnection != null) {
            readOnly = currentConnection.isReadOnly();
          } else {
            readOnly = false;
          }
        }
      }
    }
    syncSessionState(currentConnection, connection, readOnly);
    currentConnection = connection;
    currentHostIndex = hostIndex;
  }
  
  private synchronized void failOver()
    throws SQLException
  {
    failOver(currentHostIndex);
  }
  
  private synchronized void failOver(int failedHostIdx)
    throws SQLException
  {
    int prevHostIndex = currentHostIndex;
    int nextHostIndex = nextHost(failedHostIdx, false);
    int firstHostIndexTried = nextHostIndex;
    
    SQLException lastExceptionCaught = null;
    int attempts = 0;
    boolean gotConnection = false;
    boolean firstConnOrPassedByPrimaryHost = (prevHostIndex == -1) || (isPrimaryHostIndex(prevHostIndex));
    do
    {
      try
      {
        firstConnOrPassedByPrimaryHost = (firstConnOrPassedByPrimaryHost) || (isPrimaryHostIndex(nextHostIndex));
        
        connectTo(nextHostIndex);
        if ((firstConnOrPassedByPrimaryHost) && (connectedToSecondaryHost())) {
          resetAutoFallBackCounters();
        }
        gotConnection = true;
      }
      catch (SQLException e)
      {
        lastExceptionCaught = e;
        if (shouldExceptionTriggerConnectionSwitch(e))
        {
          int newNextHostIndex = nextHost(nextHostIndex, attempts > 0);
          if ((newNextHostIndex == firstHostIndexTried) && (newNextHostIndex == (newNextHostIndex = nextHost(nextHostIndex, true))))
          {
            attempts++;
            try
            {
              Thread.sleep(250L);
            }
            catch (InterruptedException localInterruptedException) {}
          }
          nextHostIndex = newNextHostIndex;
        }
        else
        {
          throw e;
        }
      }
    } while ((attempts < retriesAllDown) && (!gotConnection));
    if (!gotConnection) {
      throw lastExceptionCaught;
    }
  }
  
  synchronized void fallBackToPrimaryIfAvailable()
  {
    JdbcConnection connection = null;
    try
    {
      connection = createConnectionForHostIndex(primaryHostIndex);
      switchCurrentConnectionTo(primaryHostIndex, connection);
    }
    catch (SQLException e1)
    {
      if (connection != null) {
        try
        {
          connection.close();
        }
        catch (SQLException localSQLException1) {}
      }
      resetAutoFallBackCounters();
    }
  }
  
  private int nextHost(int currHostIdx, boolean vouchForPrimaryHost)
  {
    int nextHostIdx = (currHostIdx + 1) % hostsList.size();
    if ((isPrimaryHostIndex(nextHostIdx)) && (isConnected()) && (!vouchForPrimaryHost) && (enableFallBackToPrimaryHost) && (!readyToFallBackToPrimaryHost())) {
      nextHostIdx = nextHost(nextHostIdx, vouchForPrimaryHost);
    }
    return nextHostIdx;
  }
  
  synchronized void incrementQueriesIssuedSinceFailover()
  {
    queriesIssuedSinceFailover += 1L;
  }
  
  synchronized boolean readyToFallBackToPrimaryHost()
  {
    return (enableFallBackToPrimaryHost) && (connectedToSecondaryHost()) && ((secondsBeforeRetryPrimaryHostIsMet()) || (queriesBeforeRetryPrimaryHostIsMet()));
  }
  
  synchronized boolean isConnected()
  {
    return currentHostIndex != -1;
  }
  
  synchronized boolean isPrimaryHostIndex(int hostIndex)
  {
    return hostIndex == primaryHostIndex;
  }
  
  synchronized boolean connectedToPrimaryHost()
  {
    return isPrimaryHostIndex(currentHostIndex);
  }
  
  synchronized boolean connectedToSecondaryHost()
  {
    return (currentHostIndex >= 0) && (!isPrimaryHostIndex(currentHostIndex));
  }
  
  private synchronized boolean secondsBeforeRetryPrimaryHostIsMet()
  {
    return (secondsBeforeRetryPrimaryHost > 0) && (Util.secondsSinceMillis(primaryHostFailTimeMillis) >= secondsBeforeRetryPrimaryHost);
  }
  
  private synchronized boolean queriesBeforeRetryPrimaryHostIsMet()
  {
    return (queriesBeforeRetryPrimaryHost > 0L) && (queriesIssuedSinceFailover >= queriesBeforeRetryPrimaryHost);
  }
  
  private synchronized void resetAutoFallBackCounters()
  {
    primaryHostFailTimeMillis = System.currentTimeMillis();
    queriesIssuedSinceFailover = 0L;
  }
  
  synchronized void doClose()
    throws SQLException
  {
    currentConnection.close();
  }
  
  synchronized void doAbortInternal()
    throws SQLException
  {
    currentConnection.abortInternal();
  }
  
  synchronized void doAbort(Executor executor)
    throws SQLException
  {
    currentConnection.abort(executor);
  }
  
  public synchronized Object invokeMore(Object proxy, Method method, Object[] args)
    throws Throwable
  {
    String methodName = method.getName();
    if ("setReadOnly".equals(methodName))
    {
      explicitlyReadOnly = ((Boolean)args[0]);
      if ((failoverReadOnly) && (connectedToSecondaryHost())) {
        return null;
      }
    }
    if ((isClosed) && (!allowedOnClosedConnection(method))) {
      if ((autoReconnect) && (!closedExplicitly))
      {
        currentHostIndex = -1;
        pickNewConnection();
        isClosed = false;
        closedReason = null;
      }
      else
      {
        String reason = "No operations allowed after connection closed.";
        if (closedReason != null) {
          reason = reason + "  " + closedReason;
        }
        throw SQLError.createSQLException(reason, "08003", null);
      }
    }
    Object result = null;
    try
    {
      result = method.invoke(thisAsConnection, args);
      result = proxyIfReturnTypeIsJdbcInterface(method.getReturnType(), result);
    }
    catch (InvocationTargetException e)
    {
      dealWithInvocationException(e);
    }
    if ("setAutoCommit".equals(methodName)) {
      explicitlyAutoCommit = ((Boolean)args[0]).booleanValue();
    }
    if (((explicitlyAutoCommit) || ("commit".equals(methodName)) || ("rollback".equals(methodName))) && (readyToFallBackToPrimaryHost())) {
      fallBackToPrimaryIfAvailable();
    }
    return result;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.FailoverConnectionProxy
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */