package com.mysql.cj.jdbc.ha;

import java.lang.reflect.Method;

class FailoverConnectionProxy$FailoverJdbcInterfaceProxy
  extends MultiHostConnectionProxy.JdbcInterfaceProxy
{
  FailoverConnectionProxy$FailoverJdbcInterfaceProxy(FailoverConnectionProxy this$0, Object toInvokeOn)
  {
    super(this$0, toInvokeOn);
  }
  
  public Object invoke(Object proxy, Method method, Object[] args)
    throws Throwable
  {
    String methodName = method.getName();
    
    boolean isExecute = methodName.startsWith("execute");
    if ((this$0.connectedToSecondaryHost()) && (isExecute)) {
      this$0.incrementQueriesIssuedSinceFailover();
    }
    Object result = super.invoke(proxy, method, args);
    if ((FailoverConnectionProxy.access$000(this$0)) && (isExecute) && (this$0.readyToFallBackToPrimaryHost())) {
      this$0.fallBackToPrimaryIfAvailable();
    }
    return result;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.FailoverConnectionProxy.FailoverJdbcInterfaceProxy
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */