package com.mysql.cj.jdbc.ha;

import com.mysql.cj.jdbc.JdbcConnection;
import java.sql.SQLException;

public abstract interface ReplicationConnection
  extends JdbcConnection
{
  public abstract long getConnectionGroupId();
  
  public abstract JdbcConnection getCurrentConnection();
  
  public abstract JdbcConnection getMasterConnection();
  
  public abstract void promoteSlaveToMaster(String paramString)
    throws SQLException;
  
  public abstract void removeMasterHost(String paramString)
    throws SQLException;
  
  public abstract void removeMasterHost(String paramString, boolean paramBoolean)
    throws SQLException;
  
  public abstract boolean isHostMaster(String paramString);
  
  public abstract JdbcConnection getSlavesConnection();
  
  public abstract void addSlaveHost(String paramString)
    throws SQLException;
  
  public abstract void removeSlave(String paramString)
    throws SQLException;
  
  public abstract void removeSlave(String paramString, boolean paramBoolean)
    throws SQLException;
  
  public abstract boolean isHostSlave(String paramString);
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.ReplicationConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */