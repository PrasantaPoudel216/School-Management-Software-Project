package com.mysql.cj.jdbc.ha;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

class MultiHostConnectionProxy$JdbcInterfaceProxy
  implements InvocationHandler
{
  Object invokeOn = null;
  
  MultiHostConnectionProxy$JdbcInterfaceProxy(MultiHostConnectionProxy this$0, Object toInvokeOn)
  {
    invokeOn = toInvokeOn;
  }
  
  public Object invoke(Object proxy, Method method, Object[] args)
    throws Throwable
  {
    if ("equals".equals(method.getName())) {
      return Boolean.valueOf(args[0].equals(this));
    }
    synchronized (this$0)
    {
      Object result = null;
      try
      {
        result = method.invoke(invokeOn, args);
        result = this$0.proxyIfReturnTypeIsJdbcInterface(method.getReturnType(), result);
      }
      catch (InvocationTargetException e)
      {
        this$0.dealWithInvocationException(e);
      }
      return result;
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.MultiHostConnectionProxy.JdbcInterfaceProxy
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */