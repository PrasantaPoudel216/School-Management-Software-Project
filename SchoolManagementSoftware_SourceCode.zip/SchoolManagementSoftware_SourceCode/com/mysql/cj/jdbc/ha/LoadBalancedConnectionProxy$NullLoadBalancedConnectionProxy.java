package com.mysql.cj.jdbc.ha;

import com.mysql.cj.Messages;
import com.mysql.cj.jdbc.exceptions.SQLError;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.sql.SQLException;

class LoadBalancedConnectionProxy$NullLoadBalancedConnectionProxy
  implements InvocationHandler
{
  public Object invoke(Object proxy, Method method, Object[] args)
    throws Throwable
  {
    SQLException exceptionToThrow = SQLError.createSQLException(Messages.getString("LoadBalancedConnectionProxy.unusableConnection"), "25000", 1000001, true, null);
    
    Class<?>[] declaredException = method.getExceptionTypes();
    for (Class<?> declEx : declaredException) {
      if (declEx.isAssignableFrom(exceptionToThrow.getClass())) {
        throw exceptionToThrow;
      }
    }
    throw new IllegalStateException(exceptionToThrow.getMessage(), exceptionToThrow);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.LoadBalancedConnectionProxy.NullLoadBalancedConnectionProxy
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */