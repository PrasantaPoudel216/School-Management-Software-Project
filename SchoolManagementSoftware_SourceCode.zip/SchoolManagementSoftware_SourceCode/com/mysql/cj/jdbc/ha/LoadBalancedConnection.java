package com.mysql.cj.jdbc.ha;

import com.mysql.cj.jdbc.JdbcConnection;
import java.sql.SQLException;

public abstract interface LoadBalancedConnection
  extends JdbcConnection
{
  public abstract boolean addHost(String paramString)
    throws SQLException;
  
  public abstract void removeHost(String paramString)
    throws SQLException;
  
  public abstract void removeHostWhenNotInUse(String paramString)
    throws SQLException;
  
  public abstract void ping(boolean paramBoolean)
    throws SQLException;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.LoadBalancedConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */