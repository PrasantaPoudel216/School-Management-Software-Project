package com.mysql.cj.jdbc.ha;

import java.util.Properties;

public abstract interface LoadBalanceExceptionChecker
{
  public abstract void init(Properties paramProperties);
  
  public abstract void destroy();
  
  public abstract boolean shouldExceptionTriggerFailover(Throwable paramThrowable);
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.LoadBalanceExceptionChecker
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */