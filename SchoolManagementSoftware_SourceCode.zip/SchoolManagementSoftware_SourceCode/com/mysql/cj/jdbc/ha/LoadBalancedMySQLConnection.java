package com.mysql.cj.jdbc.ha;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.jdbc.JdbcConnection;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import java.sql.SQLException;

public class LoadBalancedMySQLConnection
  extends MultiHostMySQLConnection
  implements LoadBalancedConnection
{
  public LoadBalancedMySQLConnection(LoadBalancedConnectionProxy proxy)
  {
    super(proxy);
  }
  
  public LoadBalancedConnectionProxy getThisAsProxy()
  {
    return (LoadBalancedConnectionProxy)super.getThisAsProxy();
  }
  
  public void close()
    throws SQLException
  {
    try
    {
      getThisAsProxy().doClose();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void ping()
    throws SQLException
  {
    try
    {
      ping(true);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void ping(boolean allConnections)
    throws SQLException
  {
    try
    {
      if (allConnections) {
        getThisAsProxy().doPing();
      } else {
        getActiveMySQLConnection().ping();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean addHost(String host)
    throws SQLException
  {
    try
    {
      return getThisAsProxy().addHost(host);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void removeHost(String host)
    throws SQLException
  {
    try
    {
      getThisAsProxy().removeHost(host);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void removeHostWhenNotInUse(String host)
    throws SQLException
  {
    try
    {
      getThisAsProxy().removeHostWhenNotInUse(host);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    try
    {
      return iface.isInstance(this);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      try
      {
        return (T)iface.cast(this);
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.LoadBalancedMySQLConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */