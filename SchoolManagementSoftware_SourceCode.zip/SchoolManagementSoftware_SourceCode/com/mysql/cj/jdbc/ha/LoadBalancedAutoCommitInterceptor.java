package com.mysql.cj.jdbc.ha;

import com.mysql.cj.MysqlConnection;
import com.mysql.cj.Query;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.interceptors.QueryInterceptor;
import com.mysql.cj.jdbc.JdbcConnection;
import com.mysql.cj.log.Log;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.util.StringUtils;
import java.sql.SQLException;
import java.util.Properties;
import java.util.function.Supplier;

public class LoadBalancedAutoCommitInterceptor
  implements QueryInterceptor
{
  private int matchingAfterStatementCount = 0;
  private int matchingAfterStatementThreshold = 0;
  private String matchingAfterStatementRegex;
  private JdbcConnection conn;
  private LoadBalancedConnectionProxy proxy = null;
  private boolean countStatements = false;
  
  public void destroy()
  {
    conn = null;
    proxy = null;
  }
  
  public boolean executeTopLevelOnly()
  {
    return false;
  }
  
  public QueryInterceptor init(MysqlConnection connection, Properties props, Log log)
  {
    conn = ((JdbcConnection)connection);
    
    String autoCommitSwapThresholdAsString = props.getProperty(PropertyKey.loadBalanceAutoCommitStatementThreshold.getKeyName(), "0");
    try
    {
      matchingAfterStatementThreshold = Integer.parseInt(autoCommitSwapThresholdAsString);
    }
    catch (NumberFormatException localNumberFormatException) {}
    String autoCommitSwapRegex = props.getProperty(PropertyKey.loadBalanceAutoCommitStatementRegex.getKeyName(), "");
    if (!"".equals(autoCommitSwapRegex)) {
      matchingAfterStatementRegex = autoCommitSwapRegex;
    }
    return this;
  }
  
  public <T extends Resultset> T postProcess(Supplier<String> sql, Query interceptedQuery, T originalResultSet, ServerSession serverSession)
  {
    try
    {
      if ((!countStatements) || (StringUtils.startsWithIgnoreCase((String)sql.get(), "SET")) || (StringUtils.startsWithIgnoreCase((String)sql.get(), "SHOW"))) {
        return originalResultSet;
      }
      if (!conn.getAutoCommit())
      {
        matchingAfterStatementCount = 0;
        return originalResultSet;
      }
      if ((proxy == null) && (conn.isProxySet()))
      {
        JdbcConnection lcl_proxy = conn.getMultiHostSafeProxy();
        while ((lcl_proxy != null) && (!(lcl_proxy instanceof LoadBalancedMySQLConnection))) {
          lcl_proxy = lcl_proxy.getMultiHostSafeProxy();
        }
        if (lcl_proxy != null) {
          proxy = ((LoadBalancedMySQLConnection)lcl_proxy).getThisAsProxy();
        }
      }
      if (proxy == null) {
        return originalResultSet;
      }
      if ((matchingAfterStatementRegex == null) || (((String)sql.get()).matches(matchingAfterStatementRegex))) {
        matchingAfterStatementCount += 1;
      }
      if (matchingAfterStatementCount >= matchingAfterStatementThreshold)
      {
        matchingAfterStatementCount = 0;
        try
        {
          proxy.pickNewConnection();
        }
        catch (SQLException localSQLException1) {}
      }
    }
    catch (SQLException ex)
    {
      throw ExceptionFactory.createException(ex.getMessage(), ex);
    }
    return originalResultSet;
  }
  
  public <T extends Resultset> T preProcess(Supplier<String> sql, Query interceptedQuery)
  {
    return null;
  }
  
  void pauseCounters()
  {
    countStatements = false;
  }
  
  void resumeCounters()
  {
    countStatements = true;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.LoadBalancedAutoCommitInterceptor
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */