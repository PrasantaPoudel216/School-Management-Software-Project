package com.mysql.cj.jdbc.ha;

import com.mysql.cj.jdbc.JdbcConnection;
import java.lang.reflect.InvocationHandler;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public abstract interface BalanceStrategy
{
  public abstract JdbcConnection pickConnection(InvocationHandler paramInvocationHandler, List<String> paramList, Map<String, JdbcConnection> paramMap, long[] paramArrayOfLong, int paramInt)
    throws SQLException;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.BalanceStrategy
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */