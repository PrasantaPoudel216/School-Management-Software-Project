package com.mysql.cj.jdbc.ha;

import com.mysql.cj.jdbc.ConnectionImpl;
import com.mysql.cj.jdbc.JdbcConnection;
import java.lang.reflect.InvocationHandler;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class BestResponseTimeBalanceStrategy
  implements BalanceStrategy
{
  public ConnectionImpl pickConnection(InvocationHandler proxy, List<String> configuredHosts, Map<String, JdbcConnection> liveConnections, long[] responseTimes, int numRetries)
    throws SQLException
  {
    Map<String, Long> blackList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlacklist();
    
    SQLException ex = null;
    
    int attempts = 0;
    ConnectionImpl conn;
    for (;;)
    {
      if (attempts >= numRetries) {
        break label258;
      }
      long minResponseTime = Long.MAX_VALUE;
      
      int bestHostIndex = 0;
      if (blackList.size() == configuredHosts.size()) {
        blackList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlacklist();
      }
      for (int i = 0; i < responseTimes.length; i++)
      {
        long candidateResponseTime = responseTimes[i];
        if ((candidateResponseTime < minResponseTime) && (!blackList.containsKey(configuredHosts.get(i))))
        {
          if (candidateResponseTime == 0L)
          {
            bestHostIndex = i;
            
            break;
          }
          bestHostIndex = i;
          minResponseTime = candidateResponseTime;
        }
      }
      String bestHost = (String)configuredHosts.get(bestHostIndex);
      
      conn = (ConnectionImpl)liveConnections.get(bestHost);
      if (conn == null) {
        try
        {
          conn = ((LoadBalancedConnectionProxy)proxy).createConnectionForHost(bestHost);
        }
        catch (SQLException sqlEx)
        {
          ex = sqlEx;
          if (((LoadBalancedConnectionProxy)proxy).shouldExceptionTriggerConnectionSwitch(sqlEx))
          {
            ((LoadBalancedConnectionProxy)proxy).addToGlobalBlacklist(bestHost);
            blackList.put(bestHost, null);
            if (blackList.size() == configuredHosts.size())
            {
              attempts++;
              try
              {
                Thread.sleep(250L);
              }
              catch (InterruptedException localInterruptedException) {}
              blackList = ((LoadBalancedConnectionProxy)proxy).getGlobalBlacklist();
            }
          }
          else
          {
            throw sqlEx;
          }
        }
      }
    }
    return conn;
    label258:
    if (ex != null) {
      throw ex;
    }
    return null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ha.BestResponseTimeBalanceStrategy
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */