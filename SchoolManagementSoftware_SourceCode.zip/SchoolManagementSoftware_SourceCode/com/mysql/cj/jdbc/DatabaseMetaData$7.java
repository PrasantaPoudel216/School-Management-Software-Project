package com.mysql.cj.jdbc;

import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.util.StringUtils;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.TreeMap;

class DatabaseMetaData$7
  extends IterateBlock<String>
{
  DatabaseMetaData$7(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, String paramString, Statement paramStatement, boolean paramBoolean, ArrayList paramArrayList)
  {
    super(i);
  }
  
  void forEach(String dbStr)
    throws SQLException
  {
    ResultSet rs = null;
    try
    {
      StringBuilder queryBuf = new StringBuilder("SHOW KEYS FROM ");
      queryBuf.append(StringUtils.quoteIdentifier(val$table, this$0.quotedId, this$0.pedantic));
      queryBuf.append(" FROM ");
      queryBuf.append(StringUtils.quoteIdentifier(dbStr, this$0.quotedId, this$0.pedantic));
      try
      {
        rs = val$stmt.executeQuery(queryBuf.toString());
      }
      catch (SQLException sqlEx)
      {
        String sqlState = sqlEx.getSQLState();
        int errorCode = sqlEx.getErrorCode();
        if ((!"42S02".equals(sqlState)) && (errorCode != 1146) && (errorCode != 1049)) {
          throw sqlEx;
        }
      }
      TreeMap<String, byte[][]> sortMap = new TreeMap();
      while ((rs != null) && (rs.next()))
      {
        String keyType = rs.getString("Key_name");
        if ((keyType != null) && (
          (keyType.equalsIgnoreCase("PRIMARY")) || (keyType.equalsIgnoreCase("PRI"))))
        {
          byte[][] tuple = new byte[6][];
          tuple[0] = (val$dbMapsToSchema ? this$0.s2b("def") : this$0.s2b(dbStr));
          tuple[1] = (val$dbMapsToSchema ? this$0.s2b(dbStr) : null);
          tuple[2] = this$0.s2b(val$table);
          
          String columnName = rs.getString("Column_name");
          tuple[3] = this$0.s2b(columnName);
          tuple[4] = this$0.s2b(rs.getString("Seq_in_index"));
          tuple[5] = this$0.s2b(keyType);
          sortMap.put(columnName, tuple);
        }
      }
      Iterator<byte[][]> sortedIterator = sortMap.values().iterator();
      while (sortedIterator.hasNext()) {
        val$rows.add(new ByteArrayRow((byte[][])sortedIterator.next(), this$0.getExceptionInterceptor()));
      }
    }
    finally
    {
      if (rs != null)
      {
        try
        {
          rs.close();
        }
        catch (Exception localException1) {}
        rs = null;
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.7
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */