package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.NativeSession;
import com.mysql.cj.PreparedQuery;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import java.sql.ParameterMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class CallableStatement$CallableStatementParamInfo
  implements ParameterMetaData
{
  String dbInUse;
  boolean isFunctionCall;
  String nativeSql;
  int numParameters;
  List<CallableStatement.CallableStatementParam> parameterList;
  Map<String, CallableStatement.CallableStatementParam> parameterMap;
  boolean isReadOnlySafeProcedure = false;
  boolean isReadOnlySafeChecked = false;
  
  CallableStatement$CallableStatementParamInfo(CallableStatement this$0, CallableStatementParamInfo fullParamInfo)
  {
    nativeSql = ((PreparedQuery)query).getOriginalSql();
    dbInUse = this$0.getCurrentDatabase();
    isFunctionCall = isFunctionCall;
    
    int[] localParameterMap = CallableStatement.access$000(this$0);
    int parameterMapLength = localParameterMap.length;
    
    isReadOnlySafeProcedure = isReadOnlySafeProcedure;
    isReadOnlySafeChecked = isReadOnlySafeChecked;
    parameterList = new ArrayList(numParameters);
    parameterMap = new HashMap(numParameters);
    if (isFunctionCall) {
      parameterList.add(parameterList.get(0));
    }
    int offset = isFunctionCall ? 1 : 0;
    for (int i = 0; i < parameterMapLength; i++) {
      if (localParameterMap[i] != 0)
      {
        CallableStatement.CallableStatementParam param = (CallableStatement.CallableStatementParam)parameterList.get(localParameterMap[i] + offset);
        
        parameterList.add(param);
        parameterMap.put(paramName, param);
      }
    }
    numParameters = parameterList.size();
  }
  
  CallableStatement$CallableStatementParamInfo(CallableStatement this$0, ResultSet paramTypesRs)
    throws SQLException
  {
    boolean hadRows = paramTypesRs.last();
    
    nativeSql = ((PreparedQuery)query).getOriginalSql();
    dbInUse = this$0.getCurrentDatabase();
    isFunctionCall = CallableStatement.access$100(this$0);
    if (hadRows)
    {
      numParameters = paramTypesRs.getRow();
      
      parameterList = new ArrayList(numParameters);
      parameterMap = new HashMap(numParameters);
      
      paramTypesRs.beforeFirst();
      
      addParametersFromDBMD(paramTypesRs);
    }
    else
    {
      numParameters = 0;
    }
    if (isFunctionCall) {
      numParameters += 1;
    }
  }
  
  private void addParametersFromDBMD(ResultSet paramTypesRs)
    throws SQLException
  {
    int i = 0;
    while (paramTypesRs.next())
    {
      String paramName = paramTypesRs.getString(4);
      int inOutModifier;
      int inOutModifier;
      int inOutModifier;
      int inOutModifier;
      switch (paramTypesRs.getInt(5))
      {
      case 1: 
        inOutModifier = 1;
        break;
      case 2: 
        inOutModifier = 2;
        break;
      case 4: 
      case 5: 
        inOutModifier = 4;
        break;
      case 3: 
      default: 
        inOutModifier = 0;
      }
      boolean isOutParameter = false;
      boolean isInParameter = false;
      if ((i == 0) && (isFunctionCall))
      {
        isOutParameter = true;
        isInParameter = false;
      }
      else if (inOutModifier == 2)
      {
        isOutParameter = true;
        isInParameter = true;
      }
      else if (inOutModifier == 1)
      {
        isOutParameter = false;
        isInParameter = true;
      }
      else if (inOutModifier == 4)
      {
        isOutParameter = true;
        isInParameter = false;
      }
      int jdbcType = paramTypesRs.getInt(6);
      String typeName = paramTypesRs.getString(7);
      int precision = paramTypesRs.getInt(8);
      int scale = paramTypesRs.getInt(10);
      short nullability = paramTypesRs.getShort(12);
      
      CallableStatement.CallableStatementParam paramInfoToAdd = new CallableStatement.CallableStatementParam(paramName, i++, isInParameter, isOutParameter, jdbcType, typeName, precision, scale, nullability, inOutModifier);
      
      parameterList.add(paramInfoToAdd);
      parameterMap.put(paramName, paramInfoToAdd);
    }
  }
  
  protected void checkBounds(int paramIndex)
    throws SQLException
  {
    int localParamIndex = paramIndex - 1;
    if ((paramIndex < 0) || (localParamIndex >= numParameters)) {
      throw SQLError.createSQLException(Messages.getString("CallableStatement.11", new Object[] { Integer.valueOf(paramIndex), Integer.valueOf(numParameters) }), "S1009", this$0
        .getExceptionInterceptor());
    }
  }
  
  protected Object clone()
    throws CloneNotSupportedException
  {
    return super.clone();
  }
  
  CallableStatement.CallableStatementParam getParameter(int index)
  {
    return (CallableStatement.CallableStatementParam)parameterList.get(index);
  }
  
  CallableStatement.CallableStatementParam getParameter(String name)
  {
    return (CallableStatement.CallableStatementParam)parameterMap.get(name);
  }
  
  public String getParameterClassName(int arg0)
    throws SQLException
  {
    try
    {
      String mysqlTypeName = getParameterTypeName(arg0);
      
      MysqlType mysqlType = MysqlType.getByName(mysqlTypeName);
      switch (CallableStatement.1.$SwitchMap$com$mysql$cj$MysqlType[mysqlType.ordinal()])
      {
      case 1: 
        if (!((Boolean)this$0.session.getPropertySet().getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue()) {
          return Short.class.getName();
        }
        return mysqlType.getClassName();
      }
      return mysqlType.getClassName();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public int getParameterCount()
    throws SQLException
  {
    try
    {
      if (parameterList == null) {
        return 0;
      }
      return parameterList.size();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public int getParameterMode(int arg0)
    throws SQLException
  {
    try
    {
      checkBounds(arg0);
      
      return getParameter1inOutModifier;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public int getParameterType(int arg0)
    throws SQLException
  {
    try
    {
      checkBounds(arg0);
      
      return getParameter1jdbcType;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public String getParameterTypeName(int arg0)
    throws SQLException
  {
    try
    {
      checkBounds(arg0);
      
      return getParameter1typeName;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public int getPrecision(int arg0)
    throws SQLException
  {
    try
    {
      checkBounds(arg0);
      
      return getParameter1precision;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public int getScale(int arg0)
    throws SQLException
  {
    try
    {
      checkBounds(arg0);
      
      return getParameter1scale;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public int isNullable(int arg0)
    throws SQLException
  {
    try
    {
      checkBounds(arg0);
      
      return getParameter1nullability;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public boolean isSigned(int arg0)
    throws SQLException
  {
    try
    {
      checkBounds(arg0);
      
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  Iterator<CallableStatement.CallableStatementParam> iterator()
  {
    return parameterList.iterator();
  }
  
  int numberOfParameters()
  {
    return numParameters;
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    try
    {
      this$0.checkClosed();
      
      return iface.isInstance(this);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      try
      {
        return (T)iface.cast(this);
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", this$0
          .getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.CallableStatement.CallableStatementParamInfo
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */