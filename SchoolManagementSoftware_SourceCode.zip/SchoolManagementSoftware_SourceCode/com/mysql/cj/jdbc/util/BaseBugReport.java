package com.mysql.cj.jdbc.util;

import com.mysql.cj.jdbc.Driver;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

public abstract class BaseBugReport
{
  private Connection conn;
  private Driver driver;
  
  public BaseBugReport()
  {
    try
    {
      driver = new Driver();
    }
    catch (SQLException ex)
    {
      throw new RuntimeException(ex.toString());
    }
  }
  
  public abstract void setUp()
    throws Exception;
  
  public abstract void tearDown()
    throws Exception;
  
  public abstract void runTest()
    throws Exception;
  
  /* Error */
  public final void run()
    throws Exception
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 9	com/mysql/cj/jdbc/util/BaseBugReport:setUp	()V
    //   4: aload_0
    //   5: invokevirtual 10	com/mysql/cj/jdbc/util/BaseBugReport:runTest	()V
    //   8: aload_0
    //   9: invokevirtual 11	com/mysql/cj/jdbc/util/BaseBugReport:tearDown	()V
    //   12: goto +10 -> 22
    //   15: astore_1
    //   16: aload_0
    //   17: invokevirtual 11	com/mysql/cj/jdbc/util/BaseBugReport:tearDown	()V
    //   20: aload_1
    //   21: athrow
    //   22: return
    // Line number table:
    //   Java source line #137	-> byte code offset #0
    //   Java source line #138	-> byte code offset #4
    //   Java source line #141	-> byte code offset #8
    //   Java source line #142	-> byte code offset #12
    //   Java source line #141	-> byte code offset #15
    //   Java source line #142	-> byte code offset #20
    //   Java source line #143	-> byte code offset #22
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	23	0	this	BaseBugReport
    //   15	6	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   0	8	15	finally
  }
  
  protected final void assertTrue(String message, boolean condition)
    throws Exception
  {
    if (!condition) {
      throw new Exception("Assertion failed: " + message);
    }
  }
  
  protected final void assertTrue(boolean condition)
    throws Exception
  {
    assertTrue("(no message given)", condition);
  }
  
  public String getUrl()
  {
    return "jdbc:mysql:///test";
  }
  
  public final synchronized Connection getConnection()
    throws SQLException
  {
    if ((conn == null) || (conn.isClosed())) {
      conn = getNewConnection();
    }
    return conn;
  }
  
  public final synchronized Connection getNewConnection()
    throws SQLException
  {
    return getConnection(getUrl());
  }
  
  public final synchronized Connection getConnection(String url)
    throws SQLException
  {
    return getConnection(url, null);
  }
  
  public final synchronized Connection getConnection(String url, Properties props)
    throws SQLException
  {
    return driver.connect(url, props);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.util.BaseBugReport
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */