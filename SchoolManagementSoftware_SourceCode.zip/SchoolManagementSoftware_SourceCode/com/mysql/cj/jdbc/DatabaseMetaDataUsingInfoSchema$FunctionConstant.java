package com.mysql.cj.jdbc;

public enum DatabaseMetaDataUsingInfoSchema$FunctionConstant
{
  FUNCTION_COLUMN_UNKNOWN,  FUNCTION_COLUMN_IN,  FUNCTION_COLUMN_INOUT,  FUNCTION_COLUMN_OUT,  FUNCTION_COLUMN_RETURN,  FUNCTION_COLUMN_RESULT,  FUNCTION_NO_NULLS,  FUNCTION_NULLABLE,  FUNCTION_NULLABLE_UNKNOWN;
  
  private DatabaseMetaDataUsingInfoSchema$FunctionConstant() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaDataUsingInfoSchema.FunctionConstant
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */