package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.jdbc.exceptions.SQLError;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.SQLException;

class BlobFromLocator$LocatorInputStream
  extends InputStream
{
  long currentPositionInBlob = 0L;
  long length = 0L;
  PreparedStatement pStmt = null;
  
  BlobFromLocator$LocatorInputStream(BlobFromLocator this$0)
    throws SQLException
  {
    length = this$0.length();
    pStmt = this$0.createGetBytesStatement();
  }
  
  BlobFromLocator$LocatorInputStream(BlobFromLocator this$0, long pos, long len)
    throws SQLException
  {
    length = (pos + len);
    currentPositionInBlob = pos;
    long blobLength = this$0.length();
    if (pos + len > blobLength) {
      throw SQLError.createSQLException(
        Messages.getString("Blob.invalidStreamLength", new Object[] {Long.valueOf(blobLength), Long.valueOf(pos), Long.valueOf(len) }), "S1009", 
        BlobFromLocator.access$000(this$0));
    }
    if (pos < 1L) {
      throw SQLError.createSQLException(Messages.getString("Blob.invalidStreamPos"), "S1009", 
        BlobFromLocator.access$000(this$0));
    }
    if (pos > blobLength) {
      throw SQLError.createSQLException(Messages.getString("Blob.invalidStreamPos"), "S1009", 
        BlobFromLocator.access$000(this$0));
    }
  }
  
  public int read()
    throws IOException
  {
    if (currentPositionInBlob + 1L > length) {
      return -1;
    }
    try
    {
      byte[] asBytes = this$0.getBytesInternal(pStmt, currentPositionInBlob++ + 1L, 1);
      if (asBytes == null) {
        return -1;
      }
      return asBytes[0];
    }
    catch (SQLException sqlEx)
    {
      throw new IOException(sqlEx.toString());
    }
  }
  
  public int read(byte[] b, int off, int len)
    throws IOException
  {
    if (currentPositionInBlob + 1L > length) {
      return -1;
    }
    try
    {
      byte[] asBytes = this$0.getBytesInternal(pStmt, currentPositionInBlob + 1L, len);
      if (asBytes == null) {
        return -1;
      }
      System.arraycopy(asBytes, 0, b, off, asBytes.length);
      
      currentPositionInBlob += asBytes.length;
      
      return asBytes.length;
    }
    catch (SQLException sqlEx)
    {
      throw new IOException(sqlEx.toString());
    }
  }
  
  public int read(byte[] b)
    throws IOException
  {
    if (currentPositionInBlob + 1L > length) {
      return -1;
    }
    try
    {
      byte[] asBytes = this$0.getBytesInternal(pStmt, currentPositionInBlob + 1L, b.length);
      if (asBytes == null) {
        return -1;
      }
      System.arraycopy(asBytes, 0, b, 0, asBytes.length);
      
      currentPositionInBlob += asBytes.length;
      
      return asBytes.length;
    }
    catch (SQLException sqlEx)
    {
      throw new IOException(sqlEx.toString());
    }
  }
  
  public void close()
    throws IOException
  {
    if (pStmt != null) {
      try
      {
        pStmt.close();
      }
      catch (SQLException sqlEx)
      {
        throw new IOException(sqlEx.toString());
      }
    }
    super.close();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.BlobFromLocator.LocatorInputStream
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */