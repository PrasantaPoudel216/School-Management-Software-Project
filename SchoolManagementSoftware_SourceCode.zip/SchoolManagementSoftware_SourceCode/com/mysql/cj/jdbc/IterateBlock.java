package com.mysql.cj.jdbc;

import java.sql.SQLException;
import java.util.Iterator;

public abstract class IterateBlock<T>
{
  DatabaseMetaData.IteratorWithCleanup<T> iteratorWithCleanup;
  Iterator<T> javaIterator;
  boolean stopIterating = false;
  
  IterateBlock(DatabaseMetaData.IteratorWithCleanup<T> i)
  {
    iteratorWithCleanup = i;
    javaIterator = null;
  }
  
  IterateBlock(Iterator<T> i)
  {
    javaIterator = i;
    iteratorWithCleanup = null;
  }
  
  /* Error */
  public void doForAll()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 3	com/mysql/cj/jdbc/IterateBlock:iteratorWithCleanup	Lcom/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup;
    //   4: ifnull +57 -> 61
    //   7: aload_0
    //   8: getfield 3	com/mysql/cj/jdbc/IterateBlock:iteratorWithCleanup	Lcom/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup;
    //   11: invokevirtual 5	com/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup:hasNext	()Z
    //   14: ifeq +24 -> 38
    //   17: aload_0
    //   18: aload_0
    //   19: getfield 3	com/mysql/cj/jdbc/IterateBlock:iteratorWithCleanup	Lcom/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup;
    //   22: invokevirtual 6	com/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup:next	()Ljava/lang/Object;
    //   25: invokevirtual 7	com/mysql/cj/jdbc/IterateBlock:forEach	(Ljava/lang/Object;)V
    //   28: aload_0
    //   29: getfield 2	com/mysql/cj/jdbc/IterateBlock:stopIterating	Z
    //   32: ifeq -25 -> 7
    //   35: goto +3 -> 38
    //   38: aload_0
    //   39: getfield 3	com/mysql/cj/jdbc/IterateBlock:iteratorWithCleanup	Lcom/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup;
    //   42: invokevirtual 8	com/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup:close	()V
    //   45: goto +13 -> 58
    //   48: astore_1
    //   49: aload_0
    //   50: getfield 3	com/mysql/cj/jdbc/IterateBlock:iteratorWithCleanup	Lcom/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup;
    //   53: invokevirtual 8	com/mysql/cj/jdbc/DatabaseMetaData$IteratorWithCleanup:close	()V
    //   56: aload_1
    //   57: athrow
    //   58: goto +38 -> 96
    //   61: aload_0
    //   62: getfield 4	com/mysql/cj/jdbc/IterateBlock:javaIterator	Ljava/util/Iterator;
    //   65: invokeinterface 9 1 0
    //   70: ifeq +26 -> 96
    //   73: aload_0
    //   74: aload_0
    //   75: getfield 4	com/mysql/cj/jdbc/IterateBlock:javaIterator	Ljava/util/Iterator;
    //   78: invokeinterface 10 1 0
    //   83: invokevirtual 7	com/mysql/cj/jdbc/IterateBlock:forEach	(Ljava/lang/Object;)V
    //   86: aload_0
    //   87: getfield 2	com/mysql/cj/jdbc/IterateBlock:stopIterating	Z
    //   90: ifeq -29 -> 61
    //   93: goto +3 -> 96
    //   96: return
    // Line number table:
    //   Java source line #53	-> byte code offset #0
    //   Java source line #55	-> byte code offset #7
    //   Java source line #56	-> byte code offset #17
    //   Java source line #58	-> byte code offset #28
    //   Java source line #59	-> byte code offset #35
    //   Java source line #63	-> byte code offset #38
    //   Java source line #64	-> byte code offset #45
    //   Java source line #63	-> byte code offset #48
    //   Java source line #64	-> byte code offset #56
    //   Java source line #66	-> byte code offset #61
    //   Java source line #67	-> byte code offset #73
    //   Java source line #69	-> byte code offset #86
    //   Java source line #70	-> byte code offset #93
    //   Java source line #74	-> byte code offset #96
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	97	0	this	IterateBlock<T>
    //   48	9	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   7	38	48	finally
  }
  
  abstract void forEach(T paramT)
    throws SQLException;
  
  public final boolean fullIteration()
  {
    return !stopIterating;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.IterateBlock
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */