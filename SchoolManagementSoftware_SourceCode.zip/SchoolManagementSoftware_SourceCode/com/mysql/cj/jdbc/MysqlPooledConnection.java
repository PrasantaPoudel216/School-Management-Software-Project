package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import javax.sql.ConnectionEvent;
import javax.sql.ConnectionEventListener;
import javax.sql.PooledConnection;
import javax.sql.StatementEvent;
import javax.sql.StatementEventListener;

public class MysqlPooledConnection
  implements PooledConnection
{
  public static final int CONNECTION_ERROR_EVENT = 1;
  public static final int CONNECTION_CLOSED_EVENT = 2;
  private Map<ConnectionEventListener, ConnectionEventListener> connectionEventListeners;
  private Connection logicalHandle;
  private JdbcConnection physicalConn;
  private ExceptionInterceptor exceptionInterceptor;
  
  protected static MysqlPooledConnection getInstance(JdbcConnection connection)
    throws SQLException
  {
    return new MysqlPooledConnection(connection);
  }
  
  private final Map<StatementEventListener, StatementEventListener> statementEventListeners = new HashMap();
  
  public MysqlPooledConnection(JdbcConnection connection)
  {
    logicalHandle = null;
    physicalConn = connection;
    connectionEventListeners = new HashMap();
    exceptionInterceptor = physicalConn.getExceptionInterceptor();
  }
  
  public synchronized void addConnectionEventListener(ConnectionEventListener connectioneventlistener)
  {
    if (connectionEventListeners != null) {
      connectionEventListeners.put(connectioneventlistener, connectioneventlistener);
    }
  }
  
  public synchronized void removeConnectionEventListener(ConnectionEventListener connectioneventlistener)
  {
    if (connectionEventListeners != null) {
      connectionEventListeners.remove(connectioneventlistener);
    }
  }
  
  public synchronized Connection getConnection()
    throws SQLException
  {
    try
    {
      return getConnection(true, false);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  protected synchronized Connection getConnection(boolean resetServerState, boolean forXa)
    throws SQLException
  {
    if (physicalConn == null)
    {
      SQLException sqlException = SQLError.createSQLException(Messages.getString("MysqlPooledConnection.0"), exceptionInterceptor);
      callConnectionEventListeners(1, sqlException);
      
      throw sqlException;
    }
    try
    {
      if (logicalHandle != null) {
        ((ConnectionWrapper)logicalHandle).close(false);
      }
      if (resetServerState) {
        physicalConn.resetServerState();
      }
      logicalHandle = ConnectionWrapper.getInstance(this, physicalConn, forXa);
    }
    catch (SQLException sqlException)
    {
      callConnectionEventListeners(1, sqlException);
      
      throw sqlException;
    }
    return logicalHandle;
  }
  
  public synchronized void close()
    throws SQLException
  {
    try
    {
      if (physicalConn != null)
      {
        physicalConn.close();
        
        physicalConn = null;
      }
      if (connectionEventListeners != null)
      {
        connectionEventListeners.clear();
        
        connectionEventListeners = null;
      }
      statementEventListeners.clear();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  protected synchronized void callConnectionEventListeners(int eventType, SQLException sqlException)
  {
    if (connectionEventListeners == null) {
      return;
    }
    Iterator<Map.Entry<ConnectionEventListener, ConnectionEventListener>> iterator = connectionEventListeners.entrySet().iterator();
    
    ConnectionEvent connectionevent = new ConnectionEvent(this, sqlException);
    while (iterator.hasNext())
    {
      ConnectionEventListener connectioneventlistener = (ConnectionEventListener)((Map.Entry)iterator.next()).getValue();
      if (eventType == 2) {
        connectioneventlistener.connectionClosed(connectionevent);
      } else if (eventType == 1) {
        connectioneventlistener.connectionErrorOccurred(connectionevent);
      }
    }
  }
  
  protected ExceptionInterceptor getExceptionInterceptor()
  {
    return exceptionInterceptor;
  }
  
  public void addStatementEventListener(StatementEventListener listener)
  {
    synchronized (statementEventListeners)
    {
      statementEventListeners.put(listener, listener);
    }
  }
  
  public void removeStatementEventListener(StatementEventListener listener)
  {
    synchronized (statementEventListeners)
    {
      statementEventListeners.remove(listener);
    }
  }
  
  void fireStatementEvent(StatementEvent event)
    throws SQLException
  {
    synchronized (statementEventListeners)
    {
      for (StatementEventListener listener : statementEventListeners.keySet()) {
        listener.statementClosed(event);
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.MysqlPooledConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */