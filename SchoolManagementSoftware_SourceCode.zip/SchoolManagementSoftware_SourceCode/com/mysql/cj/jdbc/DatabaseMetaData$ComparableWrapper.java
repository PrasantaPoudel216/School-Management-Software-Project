package com.mysql.cj.jdbc;

public class DatabaseMetaData$ComparableWrapper<K,  extends Comparable<? super K>, V>
  implements Comparable<ComparableWrapper<K, V>>
{
  K key;
  V value;
  
  public DatabaseMetaData$ComparableWrapper(K this$0, V key)
  {
    this.key = key;
    this.value = value;
  }
  
  public K getKey()
  {
    return (K)key;
  }
  
  public V getValue()
  {
    return (V)value;
  }
  
  public int compareTo(ComparableWrapper<K, V> other)
  {
    return ((Comparable)getKey()).compareTo(other.getKey());
  }
  
  public boolean equals(Object obj)
  {
    if (obj == null) {
      return false;
    }
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof ComparableWrapper)) {
      return false;
    }
    Object otherKey = ((ComparableWrapper)obj).getKey();
    return key.equals(otherKey);
  }
  
  public int hashCode()
  {
    if (!$assertionsDisabled) {
      throw new AssertionError("hashCode not designed");
    }
    return 0;
  }
  
  public String toString()
  {
    return "{KEY:" + key + "; VALUE:" + value + "}";
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.ComparableWrapper
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */