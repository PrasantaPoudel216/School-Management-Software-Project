package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.NativeSession;
import com.mysql.cj.ServerVersion;
import com.mysql.cj.conf.PropertyDefinitions.DatabaseTerm;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.AssertionFailedException;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.jdbc.result.ResultSetFactory;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
import com.mysql.cj.result.DefaultColumnDefinition;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.Row;
import com.mysql.cj.util.StringUtils;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.RowIdLifetime;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.StringTokenizer;
import java.util.TreeMap;
import java.util.TreeSet;

public class DatabaseMetaData
  implements java.sql.DatabaseMetaData
{
  protected static int maxBufferSize = 65535;
  protected static final int MAX_IDENTIFIER_LENGTH = 64;
  private static final String SUPPORTS_FK = "SUPPORTS_FK";
  
  protected abstract class IteratorWithCleanup<T>
  {
    protected IteratorWithCleanup() {}
    
    abstract void close()
      throws SQLException;
    
    abstract boolean hasNext()
      throws SQLException;
    
    abstract T next()
      throws SQLException;
  }
  
  class LocalAndReferencedColumns
  {
    String constraintName;
    List<String> localColumnsList;
    String referencedDatabase;
    List<String> referencedColumnsList;
    String referencedTable;
    
    LocalAndReferencedColumns(List<String> localColumns, String refColumns, String constName, String refDatabase)
    {
      localColumnsList = localColumns;
      referencedColumnsList = refColumns;
      constraintName = constName;
      referencedTable = refTable;
      referencedDatabase = refDatabase;
    }
  }
  
  protected class StringListIterator
    extends DatabaseMetaData.IteratorWithCleanup<String>
  {
    int idx = -1;
    List<String> list;
    
    StringListIterator()
    {
      super();
      this.list = list;
    }
    
    void close()
      throws SQLException
    {
      list = null;
    }
    
    boolean hasNext()
      throws SQLException
    {
      return idx < list.size() - 1;
    }
    
    String next()
      throws SQLException
    {
      idx += 1;
      return (String)list.get(idx);
    }
  }
  
  protected class SingleStringIterator
    extends DatabaseMetaData.IteratorWithCleanup<String>
  {
    boolean onFirst = true;
    String value;
    
    SingleStringIterator(String s)
    {
      super();
      value = s;
    }
    
    void close()
      throws SQLException
    {}
    
    boolean hasNext()
      throws SQLException
    {
      return onFirst;
    }
    
    String next()
      throws SQLException
    {
      onFirst = false;
      return value;
    }
  }
  
  class TypeDescriptor
  {
    int bufferLength;
    int charOctetLength;
    Integer datetimePrecision = null;
    Integer columnSize = null;
    Integer decimalDigits = null;
    String isNullable;
    int nullability;
    int numPrecRadix = 10;
    String mysqlTypeName;
    MysqlType mysqlType;
    
    TypeDescriptor(String typeInfo, String nullabilityInfo)
      throws SQLException
    {
      if (typeInfo == null) {
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.0"), "S1009", 
          getExceptionInterceptor());
      }
      mysqlType = MysqlType.getByName(typeInfo);
      
      int maxLength = 0;
      int endParenIndex;
      switch (DatabaseMetaData.11.$SwitchMap$com$mysql$cj$MysqlType[mysqlType.ordinal()])
      {
      case 7: 
        String temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
        StringTokenizer tokenizer = new StringTokenizer(temp, ",");
        while (tokenizer.hasMoreTokens())
        {
          String nextToken = tokenizer.nextToken();
          maxLength = Math.max(maxLength, nextToken.length() - 2);
        }
        columnSize = Integer.valueOf(maxLength);
        break;
      case 8: 
        String temp = typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.lastIndexOf(")"));
        StringTokenizer tokenizer = new StringTokenizer(temp, ",");
        
        int numElements = tokenizer.countTokens();
        if (numElements > 0) {
          maxLength += numElements - 1;
        }
        while (tokenizer.hasMoreTokens())
        {
          String setMember = tokenizer.nextToken().trim();
          if ((setMember.startsWith("'")) && (setMember.endsWith("'"))) {
            maxLength += setMember.length() - 2;
          } else {
            maxLength += setMember.length();
          }
        }
        columnSize = Integer.valueOf(maxLength);
        break;
      case 1: 
      case 2: 
      case 3: 
      case 4: 
      case 5: 
      case 6: 
        if (typeInfo.indexOf(",") != -1)
        {
          columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(",")).trim());
          decimalDigits = Integer.valueOf(typeInfo.substring(typeInfo.indexOf(",") + 1, typeInfo.indexOf(")")).trim());
        }
        else
        {
          switch (DatabaseMetaData.11.$SwitchMap$com$mysql$cj$MysqlType[mysqlType.ordinal()])
          {
          case 1: 
          case 2: 
            columnSize = Integer.valueOf(65);
            break;
          case 3: 
          case 4: 
            columnSize = Integer.valueOf(12);
            break;
          case 5: 
          case 6: 
            columnSize = Integer.valueOf(22);
            break;
          }
          decimalDigits = Integer.valueOf(0);
        }
        break;
      case 9: 
      case 10: 
      case 11: 
      case 12: 
      case 13: 
      case 14: 
      case 15: 
      case 16: 
      case 17: 
      case 18: 
      case 19: 
      case 20: 
      case 21: 
      case 22: 
        if (mysqlType == MysqlType.CHAR) {
          columnSize = Integer.valueOf(1);
        }
        if (typeInfo.indexOf("(") != -1)
        {
          endParenIndex = typeInfo.indexOf(")");
          if (endParenIndex == -1) {
            endParenIndex = typeInfo.length();
          }
          columnSize = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, endParenIndex).trim());
          if ((tinyInt1isBit) && (columnSize.intValue() == 1) && 
            (StringUtils.startsWithIgnoreCase(typeInfo, 0, "tinyint"))) {
            if (transformedBitIsBoolean) {
              mysqlType = MysqlType.BOOLEAN;
            } else {
              mysqlType = MysqlType.BIT;
            }
          }
        }
        break;
      case 23: 
      case 24: 
        if ((tinyInt1isBit) && (typeInfo.indexOf("(1)") != -1))
        {
          if (transformedBitIsBoolean) {
            mysqlType = MysqlType.BOOLEAN;
          } else {
            mysqlType = MysqlType.BIT;
          }
        }
        else {
          columnSize = Integer.valueOf(3);
        }
        break;
      case 25: 
        datetimePrecision = Integer.valueOf(0);
        columnSize = Integer.valueOf(10);
        break;
      case 26: 
        datetimePrecision = Integer.valueOf(0);
        columnSize = Integer.valueOf(8);
        int fract;
        if ((typeInfo.indexOf("(") != -1) && 
          ((fract = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(")")).trim()).intValue()) > 0))
        {
          datetimePrecision = Integer.valueOf(fract);
          endParenIndex = this;(columnSize = Integer.valueOf(columnSize.intValue() + (fract + 1)));
        }
        break;
      case 27: 
      case 28: 
        datetimePrecision = Integer.valueOf(0);
        columnSize = Integer.valueOf(19);
        int fract;
        if ((typeInfo.indexOf("(") != -1) && 
          ((fract = Integer.valueOf(typeInfo.substring(typeInfo.indexOf("(") + 1, typeInfo.indexOf(")")).trim()).intValue()) > 0))
        {
          datetimePrecision = Integer.valueOf(fract);
          endParenIndex = this;(columnSize = Integer.valueOf(columnSize.intValue() + (fract + 1)));
        }
        break;
      }
      if (columnSize == null) {
        columnSize = Integer.valueOf(mysqlType.getPrecision().longValue() > 2147483647L ? Integer.MAX_VALUE : mysqlType.getPrecision().intValue());
      }
      bufferLength = DatabaseMetaData.maxBufferSize;
      
      numPrecRadix = 10;
      if (nullabilityInfo != null)
      {
        if (nullabilityInfo.equals("YES"))
        {
          nullability = 1;
          isNullable = "YES";
        }
        else if (nullabilityInfo.equals("UNKNOWN"))
        {
          nullability = 2;
          isNullable = "";
        }
        else
        {
          nullability = 0;
          isNullable = "NO";
        }
      }
      else
      {
        nullability = 0;
        isNullable = "NO";
      }
    }
  }
  
  protected class IndexMetaDataKey
    implements Comparable<IndexMetaDataKey>
  {
    Boolean columnNonUnique;
    Short columnType;
    String columnIndexName;
    Short columnOrdinalPosition;
    
    IndexMetaDataKey(boolean columnNonUnique, short columnType, String columnIndexName, short columnOrdinalPosition)
    {
      this.columnNonUnique = Boolean.valueOf(columnNonUnique);
      this.columnType = Short.valueOf(columnType);
      this.columnIndexName = columnIndexName;
      this.columnOrdinalPosition = Short.valueOf(columnOrdinalPosition);
    }
    
    public int compareTo(IndexMetaDataKey indexInfoKey)
    {
      int compareResult;
      if ((compareResult = columnNonUnique.compareTo(columnNonUnique)) != 0) {
        return compareResult;
      }
      if ((compareResult = columnType.compareTo(columnType)) != 0) {
        return compareResult;
      }
      if ((compareResult = columnIndexName.compareTo(columnIndexName)) != 0) {
        return compareResult;
      }
      return columnOrdinalPosition.compareTo(columnOrdinalPosition);
    }
    
    public boolean equals(Object obj)
    {
      if (obj == null) {
        return false;
      }
      if (obj == this) {
        return true;
      }
      if (!(obj instanceof IndexMetaDataKey)) {
        return false;
      }
      return compareTo((IndexMetaDataKey)obj) == 0;
    }
    
    public int hashCode()
    {
      if (!$assertionsDisabled) {
        throw new AssertionError("hashCode not designed");
      }
      return 0;
    }
  }
  
  protected class TableMetaDataKey
    implements Comparable<TableMetaDataKey>
  {
    String tableType;
    String tableCat;
    String tableSchem;
    String tableName;
    
    TableMetaDataKey(String tableType, String tableCat, String tableSchem, String tableName)
    {
      this.tableType = (tableType == null ? "" : tableType);
      this.tableCat = (tableCat == null ? "" : tableCat);
      this.tableSchem = (tableSchem == null ? "" : tableSchem);
      this.tableName = (tableName == null ? "" : tableName);
    }
    
    public int compareTo(TableMetaDataKey tablesKey)
    {
      int compareResult;
      if ((compareResult = tableType.compareTo(tableType)) != 0) {
        return compareResult;
      }
      if ((compareResult = tableCat.compareTo(tableCat)) != 0) {
        return compareResult;
      }
      if ((compareResult = tableSchem.compareTo(tableSchem)) != 0) {
        return compareResult;
      }
      return tableName.compareTo(tableName);
    }
    
    public boolean equals(Object obj)
    {
      if (obj == null) {
        return false;
      }
      if (obj == this) {
        return true;
      }
      if (!(obj instanceof TableMetaDataKey)) {
        return false;
      }
      return compareTo((TableMetaDataKey)obj) == 0;
    }
    
    public int hashCode()
    {
      if (!$assertionsDisabled) {
        throw new AssertionError("hashCode not designed");
      }
      return 0;
    }
  }
  
  protected class ComparableWrapper<K,  extends Comparable<? super K>, V>
    implements Comparable<ComparableWrapper<K, V>>
  {
    K key;
    V value;
    
    public ComparableWrapper(V key)
    {
      this.key = key;
      this.value = value;
    }
    
    public K getKey()
    {
      return (K)key;
    }
    
    public V getValue()
    {
      return (V)value;
    }
    
    public int compareTo(ComparableWrapper<K, V> other)
    {
      return ((Comparable)getKey()).compareTo(other.getKey());
    }
    
    public boolean equals(Object obj)
    {
      if (obj == null) {
        return false;
      }
      if (obj == this) {
        return true;
      }
      if (!(obj instanceof ComparableWrapper)) {
        return false;
      }
      Object otherKey = ((ComparableWrapper)obj).getKey();
      return key.equals(otherKey);
    }
    
    public int hashCode()
    {
      if (!$assertionsDisabled) {
        throw new AssertionError("hashCode not designed");
      }
      return 0;
    }
    
    public String toString()
    {
      return "{KEY:" + key + "; VALUE:" + value + "}";
    }
  }
  
  protected static enum TableType
  {
    LOCAL_TEMPORARY("LOCAL TEMPORARY"),  SYSTEM_TABLE("SYSTEM TABLE"),  SYSTEM_VIEW("SYSTEM VIEW"),  TABLE("TABLE", new String[] { "BASE TABLE" }),  VIEW("VIEW"),  UNKNOWN("UNKNOWN");
    
    private String name;
    private byte[] nameAsBytes;
    private String[] synonyms;
    
    private TableType(String tableTypeName)
    {
      this(tableTypeName, null);
    }
    
    private TableType(String tableTypeName, String[] tableTypeSynonyms)
    {
      name = tableTypeName;
      nameAsBytes = tableTypeName.getBytes();
      synonyms = tableTypeSynonyms;
    }
    
    String getName()
    {
      return name;
    }
    
    byte[] asBytes()
    {
      return nameAsBytes;
    }
    
    boolean equalsTo(String tableTypeName)
    {
      return name.equalsIgnoreCase(tableTypeName);
    }
    
    static TableType getTableTypeEqualTo(String tableTypeName)
    {
      for (TableType tableType : ) {
        if (tableType.equalsTo(tableTypeName)) {
          return tableType;
        }
      }
      return UNKNOWN;
    }
    
    boolean compliesWith(String tableTypeName)
    {
      if (equalsTo(tableTypeName)) {
        return true;
      }
      if (synonyms != null) {
        for (String synonym : synonyms) {
          if (synonym.equalsIgnoreCase(tableTypeName)) {
            return true;
          }
        }
      }
      return false;
    }
    
    static TableType getTableTypeCompliantWith(String tableTypeName)
    {
      for (TableType tableType : ) {
        if (tableType.compliesWith(tableTypeName)) {
          return tableType;
        }
      }
      return UNKNOWN;
    }
  }
  
  protected static enum ProcedureType
  {
    PROCEDURE,  FUNCTION;
    
    private ProcedureType() {}
  }
  
  protected static final byte[] TABLE_AS_BYTES = "TABLE".getBytes();
  protected static final byte[] SYSTEM_TABLE_AS_BYTES = "SYSTEM TABLE".getBytes();
  protected static final byte[] VIEW_AS_BYTES = "VIEW".getBytes();
  private static final String[] MYSQL_KEYWORDS = { "ACCESSIBLE", "ADD", "ALL", "ALTER", "ANALYZE", "AND", "AS", "ASC", "ASENSITIVE", "BEFORE", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOTH", "BY", "CALL", "CASCADE", "CASE", "CHANGE", "CHAR", "CHARACTER", "CHECK", "COLLATE", "COLUMN", "CONDITION", "CONSTRAINT", "CONTINUE", "CONVERT", "CREATE", "CROSS", "CUBE", "CUME_DIST", "CURRENT_DATE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_USER", "CURSOR", "DATABASE", "DATABASES", "DAY_HOUR", "DAY_MICROSECOND", "DAY_MINUTE", "DAY_SECOND", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELAYED", "DELETE", "DENSE_RANK", "DESC", "DESCRIBE", "DETERMINISTIC", "DISTINCT", "DISTINCTROW", "DIV", "DOUBLE", "DROP", "DUAL", "EACH", "ELSE", "ELSEIF", "EMPTY", "ENCLOSED", "ESCAPED", "EXCEPT", "EXISTS", "EXIT", "EXPLAIN", "FALSE", "FETCH", "FIRST_VALUE", "FLOAT", "FLOAT4", "FLOAT8", "FOR", "FORCE", "FOREIGN", "FROM", "FULLTEXT", "FUNCTION", "GENERATED", "GET", "GRANT", "GROUP", "GROUPING", "GROUPS", "HAVING", "HIGH_PRIORITY", "HOUR_MICROSECOND", "HOUR_MINUTE", "HOUR_SECOND", "IF", "IGNORE", "IN", "INDEX", "INFILE", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INT1", "INT2", "INT3", "INT4", "INT8", "INTEGER", "INTERVAL", "INTO", "IO_AFTER_GTIDS", "IO_BEFORE_GTIDS", "IS", "ITERATE", "JOIN", "JSON_TABLE", "KEY", "KEYS", "KILL", "LAG", "LAST_VALUE", "LEAD", "LEADING", "LEAVE", "LEFT", "LIKE", "LIMIT", "LINEAR", "LINES", "LOAD", "LOCALTIME", "LOCALTIMESTAMP", "LOCK", "LONG", "LONGBLOB", "LONGTEXT", "LOOP", "LOW_PRIORITY", "MASTER_BIND", "MASTER_SSL_VERIFY_SERVER_CERT", "MATCH", "MAXVALUE", "MEDIUMBLOB", "MEDIUMINT", "MEDIUMTEXT", "MIDDLEINT", "MINUTE_MICROSECOND", "MINUTE_SECOND", "MOD", "MODIFIES", "NATURAL", "NOT", "NO_WRITE_TO_BINLOG", "NTH_VALUE", "NTILE", "NULL", "NUMERIC", "OF", "ON", "OPTIMIZE", "OPTIMIZER_COSTS", "OPTION", "OPTIONALLY", "OR", "ORDER", "OUT", "OUTER", "OUTFILE", "OVER", "PARTITION", "PERCENT_RANK", "PERSIST", "PERSIST_ONLY", "PRECISION", "PRIMARY", "PROCEDURE", "PURGE", "RANGE", "RANK", "READ", "READS", "READ_WRITE", "REAL", "RECURSIVE", "REFERENCES", "REGEXP", "RELEASE", "RENAME", "REPEAT", "REPLACE", "REQUIRE", "RESIGNAL", "RESTRICT", "RETURN", "REVOKE", "RIGHT", "RLIKE", "ROW", "ROWS", "ROW_NUMBER", "SCHEMA", "SCHEMAS", "SECOND_MICROSECOND", "SELECT", "SENSITIVE", "SEPARATOR", "SET", "SHOW", "SIGNAL", "SMALLINT", "SPATIAL", "SPECIFIC", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQL_BIG_RESULT", "SQL_CALC_FOUND_ROWS", "SQL_SMALL_RESULT", "SSL", "STARTING", "STORED", "STRAIGHT_JOIN", "SYSTEM", "TABLE", "TERMINATED", "THEN", "TINYBLOB", "TINYINT", "TINYTEXT", "TO", "TRAILING", "TRIGGER", "TRUE", "UNDO", "UNION", "UNIQUE", "UNLOCK", "UNSIGNED", "UPDATE", "USAGE", "USE", "USING", "UTC_DATE", "UTC_TIME", "UTC_TIMESTAMP", "VALUES", "VARBINARY", "VARCHAR", "VARCHARACTER", "VARYING", "VIRTUAL", "WHEN", "WHERE", "WHILE", "WINDOW", "WITH", "WRITE", "XOR", "YEAR_MONTH", "ZEROFILL" };
  static final List<String> SQL2003_KEYWORDS = Arrays.asList(new String[] { "ABS", "ALL", "ALLOCATE", "ALTER", "AND", "ANY", "ARE", "ARRAY", "AS", "ASENSITIVE", "ASYMMETRIC", "AT", "ATOMIC", "AUTHORIZATION", "AVG", "BEGIN", "BETWEEN", "BIGINT", "BINARY", "BLOB", "BOOLEAN", "BOTH", "BY", "CALL", "CALLED", "CARDINALITY", "CASCADED", "CASE", "CAST", "CEIL", "CEILING", "CHAR", "CHARACTER", "CHARACTER_LENGTH", "CHAR_LENGTH", "CHECK", "CLOB", "CLOSE", "COALESCE", "COLLATE", "COLLECT", "COLUMN", "COMMIT", "CONDITION", "CONNECT", "CONSTRAINT", "CONVERT", "CORR", "CORRESPONDING", "COUNT", "COVAR_POP", "COVAR_SAMP", "CREATE", "CROSS", "CUBE", "CUME_DIST", "CURRENT", "CURRENT_DATE", "CURRENT_DEFAULT_TRANSFORM_GROUP", "CURRENT_PATH", "CURRENT_ROLE", "CURRENT_TIME", "CURRENT_TIMESTAMP", "CURRENT_TRANSFORM_GROUP_FOR_TYPE", "CURRENT_USER", "CURSOR", "CYCLE", "DATE", "DAY", "DEALLOCATE", "DEC", "DECIMAL", "DECLARE", "DEFAULT", "DELETE", "DENSE_RANK", "DEREF", "DESCRIBE", "DETERMINISTIC", "DISCONNECT", "DISTINCT", "DOUBLE", "DROP", "DYNAMIC", "EACH", "ELEMENT", "ELSE", "END", "END-EXEC", "ESCAPE", "EVERY", "EXCEPT", "EXEC", "EXECUTE", "EXISTS", "EXP", "EXTERNAL", "EXTRACT", "FALSE", "FETCH", "FILTER", "FLOAT", "FLOOR", "FOR", "FOREIGN", "FREE", "FROM", "FULL", "FUNCTION", "FUSION", "GET", "GLOBAL", "GRANT", "GROUP", "GROUPING", "HAVING", "HOLD", "HOUR", "IDENTITY", "IN", "INDICATOR", "INNER", "INOUT", "INSENSITIVE", "INSERT", "INT", "INTEGER", "INTERSECT", "INTERSECTION", "INTERVAL", "INTO", "IS", "JOIN", "LANGUAGE", "LARGE", "LATERAL", "LEADING", "LEFT", "LIKE", "LN", "LOCAL", "LOCALTIME", "LOCALTIMESTAMP", "LOWER", "MATCH", "MAX", "MEMBER", "MERGE", "METHOD", "MIN", "MINUTE", "MOD", "MODIFIES", "MODULE", "MONTH", "MULTISET", "NATIONAL", "NATURAL", "NCHAR", "NCLOB", "NEW", "NO", "NONE", "NORMALIZE", "NOT", "NULL", "NULLIF", "NUMERIC", "OCTET_LENGTH", "OF", "OLD", "ON", "ONLY", "OPEN", "OR", "ORDER", "OUT", "OUTER", "OVER", "OVERLAPS", "OVERLAY", "PARAMETER", "PARTITION", "PERCENTILE_CONT", "PERCENTILE_DISC", "PERCENT_RANK", "POSITION", "POWER", "PRECISION", "PREPARE", "PRIMARY", "PROCEDURE", "RANGE", "RANK", "READS", "REAL", "RECURSIVE", "REF", "REFERENCES", "REFERENCING", "REGR_AVGX", "REGR_AVGY", "REGR_COUNT", "REGR_INTERCEPT", "REGR_R2", "REGR_SLOPE", "REGR_SXX", "REGR_SXY", "REGR_SYY", "RELEASE", "RESULT", "RETURN", "RETURNS", "REVOKE", "RIGHT", "ROLLBACK", "ROLLUP", "ROW", "ROWS", "ROW_NUMBER", "SAVEPOINT", "SCOPE", "SCROLL", "SEARCH", "SECOND", "SELECT", "SENSITIVE", "SESSION_USER", "SET", "SIMILAR", "SMALLINT", "SOME", "SPECIFIC", "SPECIFICTYPE", "SQL", "SQLEXCEPTION", "SQLSTATE", "SQLWARNING", "SQRT", "START", "STATIC", "STDDEV_POP", "STDDEV_SAMP", "SUBMULTISET", "SUBSTRING", "SUM", "SYMMETRIC", "SYSTEM", "SYSTEM_USER", "TABLE", "TABLESAMPLE", "THEN", "TIME", "TIMESTAMP", "TIMEZONE_HOUR", "TIMEZONE_MINUTE", "TO", "TRAILING", "TRANSLATE", "TRANSLATION", "TREAT", "TRIGGER", "TRIM", "TRUE", "UESCAPE", "UNION", "UNIQUE", "UNKNOWN", "UNNEST", "UPDATE", "UPPER", "USER", "USING", "VALUE", "VALUES", "VARCHAR", "VARYING", "VAR_POP", "VAR_SAMP", "WHEN", "WHENEVER", "WHERE", "WIDTH_BUCKET", "WINDOW", "WITH", "WITHIN", "WITHOUT", "YEAR" });
  private static volatile String mysqlKeywords = null;
  protected JdbcConnection conn;
  protected NativeSession session;
  protected String database = null;
  protected final String quotedId;
  protected boolean pedantic;
  protected boolean tinyInt1isBit;
  protected boolean transformedBitIsBoolean;
  protected boolean useHostsInPrivileges;
  protected RuntimeProperty<PropertyDefinitions.DatabaseTerm> databaseTerm;
  protected RuntimeProperty<Boolean> nullDatabaseMeansCurrent;
  protected ResultSetFactory resultSetFactory;
  private String metadataEncoding;
  private int metadataCollationIndex;
  private ExceptionInterceptor exceptionInterceptor;
  
  protected static DatabaseMetaData getInstance(JdbcConnection connToSet, String databaseToSet, boolean checkForInfoSchema, ResultSetFactory resultSetFactory)
    throws SQLException
  {
    if ((checkForInfoSchema) && (((Boolean)connToSet.getPropertySet().getBooleanProperty(PropertyKey.useInformationSchema).getValue()).booleanValue())) {
      return new DatabaseMetaDataUsingInfoSchema(connToSet, databaseToSet, resultSetFactory);
    }
    return new DatabaseMetaData(connToSet, databaseToSet, resultSetFactory);
  }
  
  protected DatabaseMetaData(JdbcConnection connToSet, String databaseToSet, ResultSetFactory resultSetFactory)
  {
    conn = connToSet;
    session = ((NativeSession)connToSet.getSession());
    database = databaseToSet;
    this.resultSetFactory = resultSetFactory;
    exceptionInterceptor = conn.getExceptionInterceptor();
    databaseTerm = conn.getPropertySet().getEnumProperty(PropertyKey.databaseTerm);
    nullDatabaseMeansCurrent = conn.getPropertySet().getBooleanProperty(PropertyKey.nullDatabaseMeansCurrent);
    pedantic = ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.pedantic).getValue()).booleanValue();
    tinyInt1isBit = ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.tinyInt1isBit).getValue()).booleanValue();
    transformedBitIsBoolean = ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.transformedBitIsBoolean).getValue()).booleanValue();
    useHostsInPrivileges = ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.useHostsInPrivileges).getValue()).booleanValue();
    quotedId = session.getIdentifierQuoteString();
  }
  
  public boolean allProceduresAreCallable()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean allTablesAreSelectable()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void convertToJdbcFunctionList(ResultSet proceduresRs, List<ComparableWrapper<String, Row>> procedureRows, Field[] fields)
    throws SQLException
  {
    while (proceduresRs.next())
    {
      String procDb = proceduresRs.getString("db");
      String functionName = proceduresRs.getString("name");
      
      byte[][] rowData = (byte[][])null;
      if ((fields != null) && (fields.length == 9))
      {
        rowData = new byte[9][];
        rowData[0] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b("def") : s2b(procDb));
        rowData[1] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b(procDb) : null);
        rowData[2] = s2b(functionName);
        rowData[3] = null;
        rowData[4] = null;
        rowData[5] = null;
        rowData[6] = s2b(proceduresRs.getString("comment"));
        rowData[7] = s2b(Integer.toString(2));
        rowData[8] = s2b(functionName);
      }
      else
      {
        rowData = new byte[6][];
        
        rowData[0] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b("def") : s2b(procDb));
        rowData[1] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b(procDb) : null);
        rowData[2] = s2b(functionName);
        rowData[3] = s2b(proceduresRs.getString("comment"));
        rowData[4] = s2b(Integer.toString(1));
        rowData[5] = s2b(functionName);
      }
      procedureRows.add(new ComparableWrapper(StringUtils.getFullyQualifiedName(procDb, functionName, quotedId, pedantic), new ByteArrayRow(rowData, 
        getExceptionInterceptor())));
    }
  }
  
  protected void convertToJdbcProcedureList(boolean fromSelect, ResultSet proceduresRs, List<ComparableWrapper<String, Row>> procedureRows)
    throws SQLException
  {
    while (proceduresRs.next())
    {
      String procDb = proceduresRs.getString("db");
      String procedureName = proceduresRs.getString("name");
      byte[][] rowData = new byte[9][];
      rowData[0] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b("def") : s2b(procDb));
      rowData[1] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b(procDb) : null);
      rowData[2] = s2b(procedureName);
      rowData[3] = null;
      rowData[4] = null;
      rowData[5] = null;
      rowData[6] = s2b(proceduresRs.getString("comment"));
      
      boolean isFunction = fromSelect ? "FUNCTION".equalsIgnoreCase(proceduresRs.getString("type")) : false;
      rowData[7] = s2b(isFunction ? Integer.toString(2) : Integer.toString(1));
      
      rowData[8] = s2b(procedureName);
      
      procedureRows.add(new ComparableWrapper(StringUtils.getFullyQualifiedName(procDb, procedureName, quotedId, pedantic), new ByteArrayRow(rowData, 
        getExceptionInterceptor())));
    }
  }
  
  private Row convertTypeDescriptorToProcedureRow(byte[] procNameAsBytes, byte[] procCatAsBytes, String paramName, boolean isOutParam, boolean isInParam, boolean isReturnParam, TypeDescriptor typeDesc, boolean forGetFunctionColumns, int ordinal)
    throws SQLException
  {
    byte[][] row = forGetFunctionColumns ? new byte[17][] : new byte[20][];
    row[0] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b("def") : procCatAsBytes);
    row[1] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? procCatAsBytes : null);
    row[2] = procNameAsBytes;
    row[3] = s2b(paramName);
    row[4] = s2b(String.valueOf(getColumnType(isOutParam, isInParam, isReturnParam, forGetFunctionColumns)));
    row[5] = s2b(Short.toString((short)mysqlType.getJdbcType()));
    row[6] = s2b(mysqlType.getName());
    row[7] = (datetimePrecision == null ? s2b(columnSize.toString()) : s2b(datetimePrecision.toString()));
    row[8] = (columnSize == null ? null : s2b(columnSize.toString()));
    row[9] = (decimalDigits == null ? null : s2b(decimalDigits.toString()));
    row[10] = s2b(Integer.toString(numPrecRadix));
    switch (nullability)
    {
    case 0: 
      row[11] = s2b(String.valueOf(0));
      break;
    case 1: 
      row[11] = s2b(String.valueOf(1));
      break;
    case 2: 
      row[11] = s2b(String.valueOf(2));
      break;
    default: 
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.1"), "S1000", 
        getExceptionInterceptor());
    }
    row[12] = null;
    if (forGetFunctionColumns)
    {
      row[13] = null;
      row[14] = s2b(String.valueOf(ordinal));
      row[15] = s2b(isNullable);
      row[16] = procNameAsBytes;
    }
    else
    {
      row[13] = null;
      row[14] = null;
      row[15] = null;
      
      row[16] = null;
      row[17] = s2b(String.valueOf(ordinal));
      row[18] = s2b(isNullable);
      row[19] = procNameAsBytes;
    }
    return new ByteArrayRow(row, getExceptionInterceptor());
  }
  
  protected int getColumnType(boolean isOutParam, boolean isInParam, boolean isReturnParam, boolean forGetFunctionColumns)
  {
    return getProcedureOrFunctionColumnType(isOutParam, isInParam, isReturnParam, forGetFunctionColumns);
  }
  
  protected static int getProcedureOrFunctionColumnType(boolean isOutParam, boolean isInParam, boolean isReturnParam, boolean forGetFunctionColumns)
  {
    if ((isInParam) && (isOutParam)) {
      return forGetFunctionColumns ? 2 : 2;
    }
    if (isInParam) {
      return forGetFunctionColumns ? 1 : 1;
    }
    if (isOutParam) {
      return forGetFunctionColumns ? 3 : 4;
    }
    if (isReturnParam) {
      return forGetFunctionColumns ? 4 : 5;
    }
    return forGetFunctionColumns ? 0 : 0;
  }
  
  protected ExceptionInterceptor getExceptionInterceptor()
  {
    return exceptionInterceptor;
  }
  
  public boolean dataDefinitionCausesTransactionCommit()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean dataDefinitionIgnoredInTransactions()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean deletesAreDetected(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean doesMaxRowSizeIncludeBlobs()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public List<Row> extractForeignKeyForTable(ArrayList<Row> rows, ResultSet rs, String dbName)
    throws SQLException
  {
    byte[][] row = new byte[3][];
    row[0] = rs.getBytes(1);
    row[1] = s2b("SUPPORTS_FK");
    
    String createTableString = rs.getString(2);
    StringTokenizer lineTokenizer = new StringTokenizer(createTableString, "\n");
    StringBuilder commentBuf = new StringBuilder("comment; ");
    boolean firstTime = true;
    while (lineTokenizer.hasMoreTokens())
    {
      String line = lineTokenizer.nextToken().trim();
      
      String constraintName = null;
      if (StringUtils.startsWithIgnoreCase(line, "CONSTRAINT"))
      {
        boolean usingBackTicks = true;
        int beginPos = StringUtils.indexOfQuoteDoubleAware(line, quotedId, 0);
        if (beginPos == -1)
        {
          beginPos = line.indexOf("\"");
          usingBackTicks = false;
        }
        if (beginPos != -1)
        {
          int endPos = -1;
          if (usingBackTicks) {
            endPos = StringUtils.indexOfQuoteDoubleAware(line, quotedId, beginPos + 1);
          } else {
            endPos = StringUtils.indexOfQuoteDoubleAware(line, "\"", beginPos + 1);
          }
          if (endPos != -1)
          {
            constraintName = line.substring(beginPos + 1, endPos);
            line = line.substring(endPos + 1, line.length()).trim();
          }
        }
      }
      if (line.startsWith("FOREIGN KEY"))
      {
        if (line.endsWith(",")) {
          line = line.substring(0, line.length() - 1);
        }
        int indexOfFK = line.indexOf("FOREIGN KEY");
        
        String localColumnName = null;
        String referencedDbName = StringUtils.quoteIdentifier(dbName, quotedId, pedantic);
        String referencedTableName = null;
        String referencedColumnName = null;
        if (indexOfFK != -1)
        {
          int afterFk = indexOfFK + "FOREIGN KEY".length();
          
          int indexOfRef = StringUtils.indexOfIgnoreCase(afterFk, line, "REFERENCES", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
          if (indexOfRef != -1)
          {
            int indexOfParenOpen = line.indexOf('(', afterFk);
            int indexOfParenClose = StringUtils.indexOfIgnoreCase(indexOfParenOpen, line, ")", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
            if ((indexOfParenOpen != -1) && (indexOfParenClose == -1)) {}
            localColumnName = line.substring(indexOfParenOpen + 1, indexOfParenClose);
            
            int afterRef = indexOfRef + "REFERENCES".length();
            
            int referencedColumnBegin = StringUtils.indexOfIgnoreCase(afterRef, line, "(", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
            if (referencedColumnBegin != -1)
            {
              referencedTableName = line.substring(afterRef, referencedColumnBegin);
              
              int referencedColumnEnd = StringUtils.indexOfIgnoreCase(referencedColumnBegin + 1, line, ")", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
              if (referencedColumnEnd != -1) {
                referencedColumnName = line.substring(referencedColumnBegin + 1, referencedColumnEnd);
              }
              int indexOfDbSep = StringUtils.indexOfIgnoreCase(0, referencedTableName, ".", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
              if (indexOfDbSep != -1)
              {
                referencedDbName = referencedTableName.substring(0, indexOfDbSep);
                referencedTableName = referencedTableName.substring(indexOfDbSep + 1);
              }
            }
          }
        }
        if (!firstTime) {
          commentBuf.append("; ");
        } else {
          firstTime = false;
        }
        if (constraintName != null) {
          commentBuf.append(constraintName);
        } else {
          commentBuf.append("not_available");
        }
        commentBuf.append("(");
        commentBuf.append(localColumnName);
        commentBuf.append(") REFER ");
        commentBuf.append(referencedDbName);
        commentBuf.append("/");
        commentBuf.append(referencedTableName);
        commentBuf.append("(");
        commentBuf.append(referencedColumnName);
        commentBuf.append(")");
        
        int lastParenIndex = line.lastIndexOf(")");
        if (lastParenIndex != line.length() - 1)
        {
          String cascadeOptions = line.substring(lastParenIndex + 1);
          commentBuf.append(" ");
          commentBuf.append(cascadeOptions);
        }
      }
    }
    row[2] = s2b(commentBuf.toString());
    rows.add(new ByteArrayRow(row, getExceptionInterceptor()));
    
    return rows;
  }
  
  public ResultSet extractForeignKeyFromCreateTable(String dbName, String tableName)
    throws SQLException
  {
    ArrayList<String> tableList = new ArrayList();
    ResultSet rs = null;
    Statement stmt = null;
    if (tableName != null) {
      tableList.add(tableName);
    } else {
      try
      {
        rs = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? getTables(null, dbName, null, new String[] { "TABLE" }) : getTables(dbName, null, null, new String[] { "TABLE" });
        while (rs.next()) {
          tableList.add(rs.getString("TABLE_NAME"));
        }
      }
      finally
      {
        if (rs != null) {
          rs.close();
        }
        rs = null;
      }
    }
    Object rows = new ArrayList();
    Field[] fields = new Field[3];
    fields[0] = new Field("", "Name", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, Integer.MAX_VALUE);
    fields[1] = new Field("", "Type", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[2] = new Field("", "Comment", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, Integer.MAX_VALUE);
    
    int numTables = tableList.size();
    stmt = conn.getMetadataSafeStatement();
    try
    {
      for (int i = 0; i < numTables; i++)
      {
        String tableToExtract = (String)tableList.get(i);
        
        String query = "SHOW CREATE TABLE " + StringUtils.getFullyQualifiedName(dbName, tableToExtract, quotedId, pedantic);
        try
        {
          rs = stmt.executeQuery(query);
        }
        catch (SQLException sqlEx)
        {
          String sqlState = sqlEx.getSQLState();
          if ((!"42S02".equals(sqlState)) && (sqlEx.getErrorCode() != 1146) && 
            (sqlEx.getErrorCode() != 1049)) {
            throw sqlEx;
          }
          continue;
        }
        while ((rs != null) && (rs.next())) {
          extractForeignKeyForTable((ArrayList)rows, rs, dbName);
        }
      }
    }
    finally
    {
      if (rs != null) {
        rs.close();
      }
      rs = null;
      if (stmt != null) {
        stmt.close();
      }
      stmt = null;
    }
    return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic((List)rows, new DefaultColumnDefinition(fields)));
  }
  
  public ResultSet getAttributes(String arg0, String arg1, String arg2, String arg3)
    throws SQLException
  {
    try
    {
      Field[] fields = new Field[21];
      fields[0] = new Field("", "TYPE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[1] = new Field("", "TYPE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[2] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[3] = new Field("", "ATTR_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[4] = new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 32);
      fields[5] = new Field("", "ATTR_TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[6] = new Field("", "ATTR_SIZE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[7] = new Field("", "DECIMAL_DIGITS", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[8] = new Field("", "NUM_PREC_RADIX", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[9] = new Field("", "NULLABLE ", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[10] = new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[11] = new Field("", "ATTR_DEF", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[12] = new Field("", "SQL_DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[13] = new Field("", "SQL_DATETIME_SUB", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[14] = new Field("", "CHAR_OCTET_LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[15] = new Field("", "ORDINAL_POSITION", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[16] = new Field("", "IS_NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[17] = new Field("", "SCOPE_CATALOG", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[18] = new Field("", "SCOPE_SCHEMA", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[19] = new Field("", "SCOPE_TABLE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[20] = new Field("", "SOURCE_DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 32);
      
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(new ArrayList(), new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getBestRowIdentifier(String catalog, String schema, final String table, int scope, boolean nullable)
    throws SQLException
  {
    try
    {
      if (table == null) {
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
          getExceptionInterceptor());
      }
      Field[] fields = new Field[8];
      fields[0] = new Field("", "SCOPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
      fields[1] = new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[2] = new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32);
      fields[3] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[4] = new Field("", "COLUMN_SIZE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
      fields[5] = new Field("", "BUFFER_LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
      fields[6] = new Field("", "DECIMAL_DIGITS", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 10);
      fields[7] = new Field("", "PSEUDO_COLUMN", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
      
      final ArrayList<Row> rows = new ArrayList();
      final Statement stmt = conn.getMetadataSafeStatement();
      
      String db = getDatabase(catalog, schema);
      try
      {
        new IterateBlock(getDatabaseIterator(db))
        {
          void forEach(String dbStr)
            throws SQLException
          {
            ResultSet results = null;
            try
            {
              StringBuilder queryBuf = new StringBuilder("SHOW COLUMNS FROM ");
              queryBuf.append(StringUtils.quoteIdentifier(table, quotedId, pedantic));
              queryBuf.append(" FROM ");
              queryBuf.append(StringUtils.quoteIdentifier(dbStr, quotedId, pedantic));
              try
              {
                results = stmt.executeQuery(queryBuf.toString());
              }
              catch (SQLException sqlEx)
              {
                String sqlState = sqlEx.getSQLState();
                int errorCode = sqlEx.getErrorCode();
                if ((!"42S02".equals(sqlState)) && (errorCode != 1146) && (errorCode != 1049)) {
                  throw sqlEx;
                }
              }
              while ((results != null) && (results.next()))
              {
                String keyType = results.getString("Key");
                if ((keyType != null) && 
                  (StringUtils.startsWithIgnoreCase(keyType, "PRI")))
                {
                  byte[][] rowVal = new byte[8][];
                  rowVal[0] = Integer.toString(2).getBytes();
                  rowVal[1] = results.getBytes("Field");
                  
                  String type = results.getString("Type");
                  int size = stmt.getMaxFieldSize();
                  int decimals = 0;
                  if (type.indexOf("enum") != -1)
                  {
                    String temp = type.substring(type.indexOf("("), type.indexOf(")"));
                    StringTokenizer tokenizer = new StringTokenizer(temp, ",");
                    int maxLength = 0;
                    while (tokenizer.hasMoreTokens()) {
                      maxLength = Math.max(maxLength, tokenizer.nextToken().length() - 2);
                    }
                    size = maxLength;
                    decimals = 0;
                    type = "enum";
                  }
                  else if (type.indexOf("(") != -1)
                  {
                    if (type.indexOf(",") != -1)
                    {
                      size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(",")));
                      decimals = Integer.parseInt(type.substring(type.indexOf(",") + 1, type.indexOf(")")));
                    }
                    else
                    {
                      size = Integer.parseInt(type.substring(type.indexOf("(") + 1, type.indexOf(")")));
                    }
                    type = type.substring(0, type.indexOf("("));
                  }
                  MysqlType ft = MysqlType.getByName(type.toUpperCase());
                  rowVal[2] = s2b(String.valueOf(ft.getJdbcType()));
                  rowVal[3] = s2b(type);
                  rowVal[4] = Integer.toString(size + decimals).getBytes();
                  rowVal[5] = Integer.toString(size + decimals).getBytes();
                  rowVal[6] = Integer.toString(decimals).getBytes();
                  rowVal[7] = Integer.toString(1).getBytes();
                  
                  rows.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
                }
              }
            }
            catch (SQLException sqlEx)
            {
              if (!"42S02".equals(sqlEx.getSQLState())) {
                throw sqlEx;
              }
            }
            finally
            {
              if (results != null)
              {
                try
                {
                  results.close();
                }
                catch (Exception localException2) {}
                results = null;
              }
            }
          }
        }.doForAll();
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rows, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void getCallStmtParameterTypes(String db, String quotedProcName, ProcedureType procType, String parameterNamePattern, List<Row> resultRows, boolean forGetFunctionColumns)
    throws SQLException
  {
    Statement paramRetrievalStmt = null;
    ResultSet paramRetrievalRs = null;
    
    String parameterDef = null;
    
    byte[] procNameAsBytes = null;
    byte[] procCatAsBytes = null;
    
    boolean isProcedureInAnsiMode = false;
    String storageDefnDelims = null;
    String storageDefnClosures = null;
    try
    {
      paramRetrievalStmt = conn.getMetadataSafeStatement();
      String oldDb = conn.getDatabase();
      if ((conn.lowerCaseTableNames()) && (db != null) && (db.length() != 0) && (oldDb != null) && (oldDb.length() != 0))
      {
        ResultSet rs = null;
        try
        {
          conn.setDatabase(StringUtils.unQuoteIdentifier(db, quotedId));
          rs = paramRetrievalStmt.executeQuery("SELECT DATABASE()");
          rs.next();
          
          db = rs.getString(1);
        }
        finally
        {
          conn.setDatabase(oldDb);
          if (rs != null) {
            rs.close();
          }
        }
      }
      if (paramRetrievalStmt.getMaxRows() != 0) {
        paramRetrievalStmt.setMaxRows(0);
      }
      int dotIndex = " ".equals(quotedId) ? quotedProcName.indexOf(".") : StringUtils.indexOfIgnoreCase(0, quotedProcName, ".", quotedId, quotedId, session
        .getServerSession().isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
      
      String dbName = null;
      if ((dotIndex != -1) && (dotIndex + 1 < quotedProcName.length()))
      {
        dbName = quotedProcName.substring(0, dotIndex);
        quotedProcName = quotedProcName.substring(dotIndex + 1);
      }
      else
      {
        dbName = StringUtils.quoteIdentifier(db, quotedId, pedantic);
      }
      String tmpProcName = StringUtils.unQuoteIdentifier(quotedProcName, quotedId);
      procNameAsBytes = StringUtils.getBytes(tmpProcName, "UTF-8");
      
      tmpProcName = StringUtils.unQuoteIdentifier(dbName, quotedId);
      procCatAsBytes = StringUtils.getBytes(tmpProcName, "UTF-8");
      
      StringBuilder procNameBuf = new StringBuilder();
      procNameBuf.append(dbName);
      procNameBuf.append('.');
      procNameBuf.append(quotedProcName);
      
      String fieldName = null;
      if (procType == ProcedureType.PROCEDURE)
      {
        paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE PROCEDURE " + procNameBuf.toString());
        fieldName = "Create Procedure";
      }
      else
      {
        paramRetrievalRs = paramRetrievalStmt.executeQuery("SHOW CREATE FUNCTION " + procNameBuf.toString());
        fieldName = "Create Function";
      }
      if (paramRetrievalRs.next())
      {
        String procedureDef = paramRetrievalRs.getString(fieldName);
        if ((!((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.noAccessToProcedureBodies).getValue()).booleanValue()) && ((procedureDef == null) || 
          (procedureDef.length() == 0))) {
          throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.4"), "S1000", 
            getExceptionInterceptor());
        }
        try
        {
          String sqlMode = paramRetrievalRs.getString("sql_mode");
          if (StringUtils.indexOfIgnoreCase(sqlMode, "ANSI") != -1) {
            isProcedureInAnsiMode = true;
          }
        }
        catch (SQLException localSQLException1) {}
        String identifierMarkers = isProcedureInAnsiMode ? "`\"" : "`";
        String identifierAndStringMarkers = "'" + identifierMarkers;
        storageDefnDelims = "(" + identifierMarkers;
        storageDefnClosures = ")" + identifierMarkers;
        if ((procedureDef != null) && (procedureDef.length() != 0))
        {
          procedureDef = StringUtils.stripComments(procedureDef, identifierAndStringMarkers, identifierAndStringMarkers, true, false, true, true);
          
          int openParenIndex = StringUtils.indexOfIgnoreCase(0, procedureDef, "(", quotedId, quotedId, session
            .getServerSession().isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
          int endOfParamDeclarationIndex = 0;
          
          endOfParamDeclarationIndex = endPositionOfParameterDeclaration(openParenIndex, procedureDef, quotedId);
          if (procType == ProcedureType.FUNCTION)
          {
            int returnsIndex = StringUtils.indexOfIgnoreCase(0, procedureDef, " RETURNS ", quotedId, quotedId, session
              .getServerSession().isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
            
            int endReturnsDef = findEndOfReturnsClause(procedureDef, returnsIndex);
            
            int declarationStart = returnsIndex + "RETURNS ".length();
            while ((declarationStart < procedureDef.length()) && 
              (Character.isWhitespace(procedureDef.charAt(declarationStart)))) {
              declarationStart++;
            }
            String returnsDefn = procedureDef.substring(declarationStart, endReturnsDef).trim();
            TypeDescriptor returnDescriptor = new TypeDescriptor(returnsDefn, "YES");
            
            resultRows.add(convertTypeDescriptorToProcedureRow(procNameAsBytes, procCatAsBytes, "", false, false, true, returnDescriptor, forGetFunctionColumns, 0));
          }
          if ((openParenIndex == -1) || (endOfParamDeclarationIndex == -1)) {
            throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.5"), "S1000", 
              getExceptionInterceptor());
          }
          parameterDef = procedureDef.substring(openParenIndex + 1, endOfParamDeclarationIndex);
        }
      }
    }
    finally
    {
      SQLException sqlExRethrow;
      SQLException sqlExRethrow = null;
      if (paramRetrievalRs != null)
      {
        try
        {
          paramRetrievalRs.close();
        }
        catch (SQLException sqlEx)
        {
          sqlExRethrow = sqlEx;
        }
        paramRetrievalRs = null;
      }
      if (paramRetrievalStmt != null)
      {
        try
        {
          paramRetrievalStmt.close();
        }
        catch (SQLException sqlEx)
        {
          sqlExRethrow = sqlEx;
        }
        paramRetrievalStmt = null;
      }
      if (sqlExRethrow != null) {
        throw sqlExRethrow;
      }
    }
    if (parameterDef != null)
    {
      int ordinal = 1;
      
      List<String> parseList = StringUtils.split(parameterDef, ",", storageDefnDelims, storageDefnClosures, true);
      
      int parseListLen = parseList.size();
      for (int i = 0; i < parseListLen; i++)
      {
        String declaration = (String)parseList.get(i);
        if (declaration.trim().length() == 0) {
          break;
        }
        declaration = declaration.replaceAll("[\\t\\n\\x0B\\f\\r]", " ");
        StringTokenizer declarationTok = new StringTokenizer(declaration, " \t");
        
        String paramName = null;
        boolean isOutParam = false;
        boolean isInParam = false;
        if (declarationTok.hasMoreTokens())
        {
          String possibleParamName = declarationTok.nextToken();
          if (possibleParamName.equalsIgnoreCase("OUT"))
          {
            isOutParam = true;
            if (declarationTok.hasMoreTokens()) {
              paramName = declarationTok.nextToken();
            } else {
              throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.6"), "S1000", 
                getExceptionInterceptor());
            }
          }
          else if (possibleParamName.equalsIgnoreCase("INOUT"))
          {
            isOutParam = true;
            isInParam = true;
            if (declarationTok.hasMoreTokens()) {
              paramName = declarationTok.nextToken();
            } else {
              throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.6"), "S1000", 
                getExceptionInterceptor());
            }
          }
          else if (possibleParamName.equalsIgnoreCase("IN"))
          {
            isOutParam = false;
            isInParam = true;
            if (declarationTok.hasMoreTokens()) {
              paramName = declarationTok.nextToken();
            } else {
              throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.6"), "S1000", 
                getExceptionInterceptor());
            }
          }
          else
          {
            isOutParam = false;
            isInParam = true;
            
            paramName = possibleParamName;
          }
          TypeDescriptor typeDesc = null;
          if (declarationTok.hasMoreTokens())
          {
            StringBuilder typeInfoBuf = new StringBuilder(declarationTok.nextToken());
            while (declarationTok.hasMoreTokens())
            {
              typeInfoBuf.append(" ");
              typeInfoBuf.append(declarationTok.nextToken());
            }
            String typeInfo = typeInfoBuf.toString();
            
            typeDesc = new TypeDescriptor(typeInfo, "YES");
          }
          else
          {
            throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.7"), "S1000", 
              getExceptionInterceptor());
          }
          if (((paramName.startsWith("`")) && (paramName.endsWith("`"))) || ((isProcedureInAnsiMode) && 
            (paramName.startsWith("\"")) && (paramName.endsWith("\"")))) {
            paramName = paramName.substring(1, paramName.length() - 1);
          }
          if ((parameterNamePattern == null) || (StringUtils.wildCompareIgnoreCase(paramName, parameterNamePattern)))
          {
            Row row = convertTypeDescriptorToProcedureRow(procNameAsBytes, procCatAsBytes, paramName, isOutParam, isInParam, false, typeDesc, forGetFunctionColumns, ordinal++);
            
            resultRows.add(row);
          }
        }
        else
        {
          throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.8"), "S1000", 
            getExceptionInterceptor());
        }
      }
    }
  }
  
  private int endPositionOfParameterDeclaration(int beginIndex, String procedureDef, String quoteChar)
    throws SQLException
  {
    int currentPos = beginIndex + 1;
    int parenDepth = 1;
    while ((parenDepth > 0) && (currentPos < procedureDef.length()))
    {
      int closedParenIndex = StringUtils.indexOfIgnoreCase(currentPos, procedureDef, ")", quoteChar, quoteChar, session
        .getServerSession().isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
      if (closedParenIndex != -1)
      {
        int nextOpenParenIndex = StringUtils.indexOfIgnoreCase(currentPos, procedureDef, "(", quoteChar, quoteChar, session
          .getServerSession().isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
        if ((nextOpenParenIndex != -1) && (nextOpenParenIndex < closedParenIndex))
        {
          parenDepth++;
          currentPos = closedParenIndex + 1;
        }
        else
        {
          parenDepth--;
          currentPos = closedParenIndex;
        }
      }
      else
      {
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.5"), "S1000", 
          getExceptionInterceptor());
      }
    }
    return currentPos;
  }
  
  private int findEndOfReturnsClause(String procedureDefn, int positionOfReturnKeyword)
    throws SQLException
  {
    String openingMarkers = quotedId + "(";
    String closingMarkers = quotedId + ")";
    
    String[] tokens = { "LANGUAGE", "NOT", "DETERMINISTIC", "CONTAINS", "NO", "READ", "MODIFIES", "SQL", "COMMENT", "BEGIN", "RETURN" };
    
    int startLookingAt = positionOfReturnKeyword + "RETURNS".length() + 1;
    
    int endOfReturn = -1;
    for (int i = 0; i < tokens.length; i++)
    {
      int nextEndOfReturn = StringUtils.indexOfIgnoreCase(startLookingAt, procedureDefn, tokens[i], openingMarkers, closingMarkers, session
        .getServerSession().isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
      if ((nextEndOfReturn != -1) && (
        (endOfReturn == -1) || (nextEndOfReturn < endOfReturn))) {
        endOfReturn = nextEndOfReturn;
      }
    }
    if (endOfReturn != -1) {
      return endOfReturn;
    }
    endOfReturn = StringUtils.indexOfIgnoreCase(startLookingAt, procedureDefn, ":", openingMarkers, closingMarkers, session
      .getServerSession().isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
    if (endOfReturn != -1) {
      for (int i = endOfReturn; i > 0; i--) {
        if (Character.isWhitespace(procedureDefn.charAt(i))) {
          return i;
        }
      }
    }
    throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.5"), "S1000", getExceptionInterceptor());
  }
  
  private int getCascadeDeleteOption(String cascadeOptions)
  {
    int onDeletePos = cascadeOptions.indexOf("ON DELETE");
    if (onDeletePos != -1)
    {
      String deleteOptions = cascadeOptions.substring(onDeletePos, cascadeOptions.length());
      if (deleteOptions.startsWith("ON DELETE CASCADE")) {
        return 0;
      }
      if (deleteOptions.startsWith("ON DELETE SET NULL")) {
        return 2;
      }
    }
    return 1;
  }
  
  private int getCascadeUpdateOption(String cascadeOptions)
  {
    int onUpdatePos = cascadeOptions.indexOf("ON UPDATE");
    if (onUpdatePos != -1)
    {
      String updateOptions = cascadeOptions.substring(onUpdatePos, cascadeOptions.length());
      if (updateOptions.startsWith("ON UPDATE CASCADE")) {
        return 0;
      }
      if (updateOptions.startsWith("ON UPDATE SET NULL")) {
        return 2;
      }
    }
    return 1;
  }
  
  protected IteratorWithCleanup<String> getDatabaseIterator(String dbSpec)
    throws SQLException
  {
    if (dbSpec == null) {
      return ((Boolean)nullDatabaseMeansCurrent.getValue()).booleanValue() ? new SingleStringIterator(database) : new StringListIterator(getDatabases());
    }
    return new SingleStringIterator(pedantic ? dbSpec : StringUtils.unQuoteIdentifier(dbSpec, quotedId));
  }
  
  protected IteratorWithCleanup<String> getSchemaPatternIterator(String schemaPattern)
    throws SQLException
  {
    if (schemaPattern == null) {
      return ((Boolean)nullDatabaseMeansCurrent.getValue()).booleanValue() ? new SingleStringIterator(database) : new StringListIterator(getDatabases());
    }
    return new StringListIterator(getDatabases(schemaPattern));
  }
  
  protected List<String> getDatabases()
    throws SQLException
  {
    return getDatabases(null);
  }
  
  protected List<String> getDatabases(String dbPattern)
    throws SQLException
  {
    PreparedStatement pStmt = null;
    ResultSet results = null;
    Statement stmt = null;
    try
    {
      stmt = conn.getMetadataSafeStatement();
      StringBuilder queryBuf = new StringBuilder("SHOW DATABASES");
      if (dbPattern != null) {
        queryBuf.append(" LIKE ?");
      }
      pStmt = prepareMetaDataSafeStatement(queryBuf.toString());
      if (dbPattern != null) {
        pStmt.setString(1, dbPattern);
      }
      results = pStmt.executeQuery();
      
      int dbCount = 0;
      if (results.last())
      {
        dbCount = results.getRow();
        results.beforeFirst();
      }
      List<String> resultsAsList = new ArrayList(dbCount);
      while (results.next()) {
        resultsAsList.add(results.getString(1));
      }
      Collections.sort(resultsAsList);
      
      return resultsAsList;
    }
    finally
    {
      if (results != null)
      {
        try
        {
          results.close();
        }
        catch (SQLException sqlEx)
        {
          AssertionFailedException.shouldNotHappen(sqlEx);
        }
        results = null;
      }
      if (pStmt != null)
      {
        try
        {
          pStmt.close();
        }
        catch (Exception localException1) {}
        pStmt = null;
      }
      if (stmt != null)
      {
        try
        {
          stmt.close();
        }
        catch (SQLException sqlEx)
        {
          AssertionFailedException.shouldNotHappen(sqlEx);
        }
        stmt = null;
      }
    }
  }
  
  public ResultSet getCatalogs()
    throws SQLException
  {
    try
    {
      List<String> resultsAsList = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? new ArrayList() : getDatabases();
      
      Field[] fields = new Field[1];
      fields[0] = new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 0);
      
      ArrayList<Row> tuples = new ArrayList(resultsAsList.size());
      for (String cat : resultsAsList)
      {
        byte[][] rowVal = new byte[1][];
        rowVal[0] = s2b(cat);
        tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(tuples, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getCatalogSeparator()
    throws SQLException
  {
    try
    {
      return ".";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getCatalogTerm()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? "CATALOG" : "database";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected String getDatabase(String catalog, String schema)
  {
    if (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA) {
      return (schema == null) && (((Boolean)nullDatabaseMeansCurrent.getValue()).booleanValue()) ? database : schema;
    }
    return (catalog == null) && (((Boolean)nullDatabaseMeansCurrent.getValue()).booleanValue()) ? database : catalog;
  }
  
  protected Field[] getColumnPrivilegesFields()
  {
    Field[] fields = new Field[8];
    fields[0] = new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
    fields[1] = new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 1);
    fields[2] = new Field("", "TABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
    fields[3] = new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
    fields[4] = new Field("", "GRANTOR", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 77);
    fields[5] = new Field("", "GRANTEE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 77);
    fields[6] = new Field("", "PRIVILEGE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
    fields[7] = new Field("", "IS_GRANTABLE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 3);
    return fields;
  }
  
  public ResultSet getColumnPrivileges(String catalog, String schema, String table, String columnNamePattern)
    throws SQLException
  {
    try
    {
      String db = getDatabase(catalog, schema);
      
      StringBuilder grantQueryBuf = new StringBuilder("SELECT c.host, c.db, t.grantor, c.user, c.table_name, c.column_name, c.column_priv");
      grantQueryBuf.append(" FROM mysql.columns_priv c, mysql.tables_priv t");
      grantQueryBuf.append(" WHERE c.host = t.host AND c.db = t.db AND c.table_name = t.table_name");
      if (db != null) {
        grantQueryBuf.append(" AND c.db = ?");
      }
      grantQueryBuf.append(" AND c.table_name = ?");
      if (columnNamePattern != null) {
        grantQueryBuf.append(" AND c.column_name LIKE ?");
      }
      PreparedStatement pStmt = null;
      ResultSet results = null;
      ArrayList<Row> grantRows = new ArrayList();
      try
      {
        pStmt = prepareMetaDataSafeStatement(grantQueryBuf.toString());
        int nextId = 1;
        if (db != null) {
          pStmt.setString(nextId++, db);
        }
        pStmt.setString(nextId++, table);
        if (columnNamePattern != null) {
          pStmt.setString(nextId, columnNamePattern);
        }
        results = pStmt.executeQuery();
        while (results.next())
        {
          String host = results.getString(1);
          db = results.getString(2);
          String grantor = results.getString(3);
          String user = results.getString(4);
          if ((user == null) || (user.length() == 0)) {
            user = "%";
          }
          StringBuilder fullUser = new StringBuilder(user);
          if ((host != null) && (useHostsInPrivileges))
          {
            fullUser.append("@");
            fullUser.append(host);
          }
          String columnName = results.getString(6);
          String allPrivileges = results.getString(7);
          if (allPrivileges != null)
          {
            allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
            
            StringTokenizer st = new StringTokenizer(allPrivileges, ",");
            while (st.hasMoreTokens())
            {
              String privilege = st.nextToken().trim();
              byte[][] tuple = new byte[8][];
              tuple[0] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b("def") : s2b(db));
              tuple[1] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b(db) : null);
              tuple[2] = s2b(table);
              tuple[3] = s2b(columnName);
              tuple[4] = (grantor != null ? s2b(grantor) : null);
              tuple[5] = s2b(fullUser.toString());
              tuple[6] = s2b(privilege);
              tuple[7] = null;
              grantRows.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
            }
          }
        }
      }
      finally
      {
        if (results != null)
        {
          try
          {
            results.close();
          }
          catch (Exception localException2) {}
          results = null;
        }
        if (pStmt != null)
        {
          try
          {
            pStmt.close();
          }
          catch (Exception localException3) {}
          pStmt = null;
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(grantRows, new DefaultColumnDefinition(
        getColumnPrivilegesFields())));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getColumns(String catalog, final String schemaPattern, final String tableNamePattern, String columnNamePattern)
    throws SQLException
  {
    try
    {
      String db = getDatabase(catalog, schemaPattern);
      
      final String colPattern = columnNamePattern;
      
      Field[] fields = createColumnsFields();
      
      final ArrayList<Row> rows = new ArrayList();
      final Statement stmt = conn.getMetadataSafeStatement();
      
      final boolean dbMapsToSchema = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
      try
      {
        new IterateBlock(dbMapsToSchema ? getSchemaPatternIterator(db) : getDatabaseIterator(db))
        {
          void forEach(String dbStr)
            throws SQLException
          {
            ArrayList<String> tableNameList = new ArrayList();
            
            ResultSet tables = null;
            try
            {
              tables = dbMapsToSchema ? getTables(null, dbStr, tableNamePattern, new String[0]) : getTables(dbStr, schemaPattern, tableNamePattern, new String[0]);
              while (tables.next())
              {
                String tableNameFromList = tables.getString("TABLE_NAME");
                tableNameList.add(tableNameFromList);
              }
            }
            finally
            {
              if (tables != null)
              {
                try
                {
                  tables.close();
                }
                catch (Exception sqlEx)
                {
                  AssertionFailedException.shouldNotHappen(sqlEx);
                }
                tables = null;
              }
            }
            for (String tableName : tableNameList)
            {
              ResultSet results = null;
              try
              {
                StringBuilder queryBuf = new StringBuilder("SHOW FULL COLUMNS FROM ");
                queryBuf.append(StringUtils.quoteIdentifier(tableName, quotedId, pedantic));
                queryBuf.append(" FROM ");
                queryBuf.append(StringUtils.quoteIdentifier(dbStr, quotedId, pedantic));
                if (colPattern != null)
                {
                  queryBuf.append(" LIKE ");
                  queryBuf.append(StringUtils.quoteIdentifier(colPattern, "'", true));
                }
                boolean fixUpOrdinalsRequired = false;
                Map<String, Integer> ordinalFixUpMap = null;
                if ((colPattern != null) && (!colPattern.equals("%")))
                {
                  fixUpOrdinalsRequired = true;
                  
                  StringBuilder fullColumnQueryBuf = new StringBuilder("SHOW FULL COLUMNS FROM ");
                  fullColumnQueryBuf
                    .append(StringUtils.quoteIdentifier(tableName, quotedId, pedantic));
                  fullColumnQueryBuf.append(" FROM ");
                  fullColumnQueryBuf.append(StringUtils.quoteIdentifier(dbStr, quotedId, pedantic));
                  
                  results = stmt.executeQuery(fullColumnQueryBuf.toString());
                  
                  ordinalFixUpMap = new HashMap();
                  
                  int fullOrdinalPos = 1;
                  while (results.next())
                  {
                    String fullOrdColName = results.getString("Field");
                    
                    ordinalFixUpMap.put(fullOrdColName, Integer.valueOf(fullOrdinalPos++));
                  }
                  results.close();
                }
                results = stmt.executeQuery(queryBuf.toString());
                
                int ordPos = 1;
                while (results.next())
                {
                  DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(DatabaseMetaData.this, results.getString("Type"), results.getString("Null"));
                  
                  byte[][] rowVal = new byte[24][];
                  rowVal[0] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b("def") : s2b(dbStr));
                  rowVal[1] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b(dbStr) : null);
                  rowVal[2] = s2b(tableName);
                  rowVal[3] = results.getBytes("Field");
                  rowVal[4] = Short.toString((short)mysqlType.getJdbcType()).getBytes();
                  rowVal[5] = s2b(mysqlType.getName());
                  if (columnSize == null)
                  {
                    rowVal[6] = null;
                  }
                  else
                  {
                    String collation = results.getString("Collation");
                    int mbminlen = 1;
                    if (collation != null) {
                      if ((collation.indexOf("ucs2") > -1) || (collation.indexOf("utf16") > -1)) {
                        mbminlen = 2;
                      } else if (collation.indexOf("utf32") > -1) {
                        mbminlen = 4;
                      }
                    }
                    rowVal[6] = (mbminlen == 1 ? s2b(columnSize.toString()) : s2b(Integer.valueOf(columnSize.intValue() / mbminlen).toString()));
                  }
                  rowVal[7] = s2b(Integer.toString(bufferLength));
                  rowVal[8] = (decimalDigits == null ? null : s2b(decimalDigits.toString()));
                  rowVal[9] = s2b(Integer.toString(numPrecRadix));
                  rowVal[10] = s2b(Integer.toString(nullability));
                  try
                  {
                    rowVal[11] = results.getBytes("Comment");
                  }
                  catch (Exception E)
                  {
                    rowVal[11] = new byte[0];
                  }
                  rowVal[12] = results.getBytes("Default");
                  rowVal[13] = { 48 };
                  rowVal[14] = { 48 };
                  if ((StringUtils.indexOfIgnoreCase(mysqlType.getName(), "CHAR") != -1) || 
                    (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "BLOB") != -1) || 
                    (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "TEXT") != -1) || 
                    (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "ENUM") != -1) || 
                    (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "SET") != -1) || 
                    (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "BINARY") != -1)) {
                    rowVal[15] = rowVal[6];
                  } else {
                    rowVal[15] = null;
                  }
                  if (!fixUpOrdinalsRequired)
                  {
                    rowVal[16] = Integer.toString(ordPos++).getBytes();
                  }
                  else
                  {
                    String origColName = results.getString("Field");
                    Integer realOrdinal = (Integer)ordinalFixUpMap.get(origColName);
                    if (realOrdinal != null) {
                      rowVal[16] = realOrdinal.toString().getBytes();
                    } else {
                      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.10"), "S1000", 
                        getExceptionInterceptor());
                    }
                  }
                  rowVal[17] = s2b(isNullable);
                  
                  rowVal[18] = null;
                  rowVal[19] = null;
                  rowVal[20] = null;
                  rowVal[21] = null;
                  
                  rowVal[22] = s2b("");
                  
                  String extra = results.getString("Extra");
                  if (extra != null)
                  {
                    rowVal[22] = s2b(StringUtils.indexOfIgnoreCase(extra, "auto_increment") != -1 ? "YES" : "NO");
                    rowVal[23] = s2b(StringUtils.indexOfIgnoreCase(extra, "generated") != -1 ? "YES" : "NO");
                  }
                  rows.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
                }
              }
              finally
              {
                if (results != null)
                {
                  try
                  {
                    results.close();
                  }
                  catch (Exception localException2) {}
                  results = null;
                }
              }
            }
          }
        }.doForAll();
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rows, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected Field[] createColumnsFields()
  {
    Field[] fields = new Field[24];
    fields[0] = new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[1] = new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[2] = new Field("", "TABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[3] = new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    fields[4] = new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 5);
    fields[5] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 16);
    fields[6] = new Field("", "COLUMN_SIZE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 
      Integer.toString(Integer.MAX_VALUE).length());
    fields[7] = new Field("", "BUFFER_LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
    fields[8] = new Field("", "DECIMAL_DIGITS", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
    fields[9] = new Field("", "NUM_PREC_RADIX", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
    fields[10] = new Field("", "NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
    fields[11] = new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[12] = new Field("", "COLUMN_DEF", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[13] = new Field("", "SQL_DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
    fields[14] = new Field("", "SQL_DATETIME_SUB", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
    fields[15] = new Field("", "CHAR_OCTET_LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 
      Integer.toString(Integer.MAX_VALUE).length());
    fields[16] = new Field("", "ORDINAL_POSITION", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
    fields[17] = new Field("", "IS_NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 3);
    fields[18] = new Field("", "SCOPE_CATALOG", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[19] = new Field("", "SCOPE_SCHEMA", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[20] = new Field("", "SCOPE_TABLE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[21] = new Field("", "SOURCE_DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 10);
    fields[22] = new Field("", "IS_AUTOINCREMENT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 3);
    fields[23] = new Field("", "IS_GENERATEDCOLUMN", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 3);
    return fields;
  }
  
  public Connection getConnection()
    throws SQLException
  {
    try
    {
      return conn;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getCrossReference(String primaryCatalog, String primarySchema, final String primaryTable, String foreignCatalog, String foreignSchema, final String foreignTable)
    throws SQLException
  {
    try
    {
      if (primaryTable == null) {
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
          getExceptionInterceptor());
      }
      String foreignDb = getDatabase(foreignCatalog, foreignSchema);
      
      Field[] fields = createFkMetadataFields();
      
      final ArrayList<Row> tuples = new ArrayList();
      
      Statement stmt = conn.getMetadataSafeStatement();
      
      final boolean dbMapsToSchema = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
      try
      {
        new IterateBlock(getDatabaseIterator(foreignDb))
        {
          void forEach(String dbStr)
            throws SQLException
          {
            ResultSet fkresults = null;
            try
            {
              fkresults = extractForeignKeyFromCreateTable(dbStr, null);
              
              String foreignTableWithCase = getTableNameWithCase(foreignTable);
              String primaryTableWithCase = getTableNameWithCase(primaryTable);
              while (fkresults.next())
              {
                String tableType = fkresults.getString("Type");
                if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
                {
                  String comment = fkresults.getString("Comment").trim();
                  if (comment != null)
                  {
                    StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
                    if (commentTokens.hasMoreTokens()) {
                      String str1 = commentTokens.nextToken();
                    }
                    while (commentTokens.hasMoreTokens())
                    {
                      String keys = commentTokens.nextToken();
                      DatabaseMetaData.LocalAndReferencedColumns parsedInfo = parseTableStatusIntoLocalAndReferencedColumns(keys);
                      
                      int keySeq = 1;
                      
                      Iterator<String> referencingColumns = localColumnsList.iterator();
                      Iterator<String> referencedColumns = referencedColumnsList.iterator();
                      while (referencingColumns.hasNext())
                      {
                        String referencingColumn = StringUtils.unQuoteIdentifier((String)referencingColumns.next(), quotedId);
                        
                        String dummy = fkresults.getString("Name");
                        if ((dummy.compareTo(foreignTableWithCase) == 0) && 
                        
                          (referencedTable.compareTo(primaryTableWithCase) == 0))
                        {
                          byte[][] tuple = new byte[14][];
                          tuple[0] = (dbMapsToSchema ? s2b("def") : s2b(referencedDatabase));
                          tuple[1] = (dbMapsToSchema ? s2b(referencedDatabase) : null);
                          tuple[2] = s2b(referencedTable);
                          tuple[3] = s2b(StringUtils.unQuoteIdentifier((String)referencedColumns.next(), quotedId));
                          tuple[4] = (dbMapsToSchema ? s2b("def") : s2b(dbStr));
                          tuple[5] = (dbMapsToSchema ? s2b(dbStr) : null);
                          tuple[6] = s2b(dummy);
                          tuple[7] = s2b(referencingColumn);
                          tuple[8] = Integer.toString(keySeq).getBytes();
                          
                          int[] actions = getForeignKeyActions(keys);
                          tuple[9] = Integer.toString(actions[1]).getBytes();
                          tuple[10] = Integer.toString(actions[0]).getBytes();
                          
                          tuple[11] = s2b(constraintName);
                          tuple[12] = null;
                          tuple[13] = Integer.toString(7).getBytes();
                          tuples.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
                          keySeq++;
                        }
                      }
                    }
                  }
                }
              }
            }
            finally
            {
              if (fkresults != null)
              {
                try
                {
                  fkresults.close();
                }
                catch (Exception sqlEx)
                {
                  AssertionFailedException.shouldNotHappen(sqlEx);
                }
                fkresults = null;
              }
            }
          }
        }.doForAll();
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(tuples, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected Field[] createFkMetadataFields()
  {
    Field[] fields = new Field[14];
    fields[0] = new Field("", "PKTABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[1] = new Field("", "PKTABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[2] = new Field("", "PKTABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[3] = new Field("", "PKCOLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    fields[4] = new Field("", "FKTABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[5] = new Field("", "FKTABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[6] = new Field("", "FKTABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[7] = new Field("", "FKCOLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    fields[8] = new Field("", "KEY_SEQ", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 2);
    fields[9] = new Field("", "UPDATE_RULE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 2);
    fields[10] = new Field("", "DELETE_RULE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 2);
    fields[11] = new Field("", "FK_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[12] = new Field("", "PK_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[13] = new Field("", "DEFERRABILITY", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 2);
    return fields;
  }
  
  public int getDatabaseMajorVersion()
    throws SQLException
  {
    try
    {
      return conn.getServerVersion().getMajor();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getDatabaseMinorVersion()
    throws SQLException
  {
    try
    {
      return conn.getServerVersion().getMinor();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getDatabaseProductName()
    throws SQLException
  {
    try
    {
      return "MySQL";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getDatabaseProductVersion()
    throws SQLException
  {
    try
    {
      return conn.getServerVersion().toString();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getDefaultTransactionIsolation()
    throws SQLException
  {
    try
    {
      return 2;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getDriverMajorVersion()
  {
    return NonRegisteringDriver.getMajorVersionInternal();
  }
  
  public int getDriverMinorVersion()
  {
    return NonRegisteringDriver.getMinorVersionInternal();
  }
  
  public String getDriverName()
    throws SQLException
  {
    try
    {
      return "MySQL Connector/J";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getDriverVersion()
    throws SQLException
  {
    try
    {
      return "mysql-connector-java-8.0.17 (Revision: 16a712ddb3f826a1933ab42b0039f7fb9eebc6ec)";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getExportedKeys(String catalog, String schema, final String table)
    throws SQLException
  {
    try
    {
      if (table == null) {
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
          getExceptionInterceptor());
      }
      Field[] fields = createFkMetadataFields();
      
      final ArrayList<Row> rows = new ArrayList();
      
      Statement stmt = conn.getMetadataSafeStatement();
      
      String db = getDatabase(catalog, schema);
      try
      {
        new IterateBlock(getDatabaseIterator(db))
        {
          void forEach(String dbStr)
            throws SQLException
          {
            ResultSet fkresults = null;
            try
            {
              fkresults = extractForeignKeyFromCreateTable(dbStr, null);
              
              String tableNameWithCase = getTableNameWithCase(table);
              while (fkresults.next())
              {
                String tableType = fkresults.getString("Type");
                if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
                {
                  String comment = fkresults.getString("Comment").trim();
                  if (comment != null)
                  {
                    StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
                    if (commentTokens.hasMoreTokens())
                    {
                      commentTokens.nextToken();
                      while (commentTokens.hasMoreTokens())
                      {
                        String keysComment = commentTokens.nextToken();
                        populateKeyResults(dbStr, tableNameWithCase, keysComment, rows, fkresults.getString("Name"), true);
                      }
                    }
                  }
                }
              }
            }
            finally
            {
              if (fkresults != null)
              {
                try
                {
                  fkresults.close();
                }
                catch (SQLException sqlEx)
                {
                  AssertionFailedException.shouldNotHappen(sqlEx);
                }
                fkresults = null;
              }
            }
          }
        }.doForAll();
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rows, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getExtraNameCharacters()
    throws SQLException
  {
    try
    {
      return "#@";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected int[] getForeignKeyActions(String commentString)
  {
    int[] actions = { 1, 1 };
    
    int lastParenIndex = commentString.lastIndexOf(")");
    if (lastParenIndex != commentString.length() - 1)
    {
      String cascadeOptions = commentString.substring(lastParenIndex + 1).trim().toUpperCase(Locale.ENGLISH);
      
      actions[0] = getCascadeDeleteOption(cascadeOptions);
      actions[1] = getCascadeUpdateOption(cascadeOptions);
    }
    return actions;
  }
  
  public String getIdentifierQuoteString()
    throws SQLException
  {
    try
    {
      return session.getIdentifierQuoteString();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getImportedKeys(String catalog, String schema, final String table)
    throws SQLException
  {
    try
    {
      if (table == null) {
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
          getExceptionInterceptor());
      }
      Field[] fields = createFkMetadataFields();
      
      final ArrayList<Row> rows = new ArrayList();
      
      Statement stmt = conn.getMetadataSafeStatement();
      
      String db = getDatabase(catalog, schema);
      try
      {
        new IterateBlock(getDatabaseIterator(db))
        {
          void forEach(String dbStr)
            throws SQLException
          {
            ResultSet fkresults = null;
            try
            {
              fkresults = extractForeignKeyFromCreateTable(dbStr, table);
              while (fkresults.next())
              {
                String tableType = fkresults.getString("Type");
                if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
                {
                  String comment = fkresults.getString("Comment").trim();
                  if (comment != null)
                  {
                    StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
                    if (commentTokens.hasMoreTokens())
                    {
                      commentTokens.nextToken();
                      while (commentTokens.hasMoreTokens())
                      {
                        String keysComment = commentTokens.nextToken();
                        populateKeyResults(dbStr, table, keysComment, rows, null, false);
                      }
                    }
                  }
                }
              }
            }
            finally
            {
              if (fkresults != null)
              {
                try
                {
                  fkresults.close();
                }
                catch (SQLException sqlEx)
                {
                  AssertionFailedException.shouldNotHappen(sqlEx);
                }
                fkresults = null;
              }
            }
          }
        }.doForAll();
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rows, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getIndexInfo(String catalog, String schema, final String table, final boolean unique, boolean approximate)
    throws SQLException
  {
    try
    {
      Field[] fields = createIndexInfoFields();
      
      final SortedMap<IndexMetaDataKey, Row> sortedRows = new TreeMap();
      ArrayList<Row> rows = new ArrayList();
      final Statement stmt = conn.getMetadataSafeStatement();
      
      String db = getDatabase(catalog, schema);
      final boolean dbMapsToSchema = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
      try
      {
        new IterateBlock(getDatabaseIterator(db))
        {
          void forEach(String dbStr)
            throws SQLException
          {
            ResultSet results = null;
            try
            {
              StringBuilder queryBuf = new StringBuilder("SHOW INDEX FROM ");
              queryBuf.append(StringUtils.quoteIdentifier(table, quotedId, pedantic));
              queryBuf.append(" FROM ");
              queryBuf.append(StringUtils.quoteIdentifier(dbStr, quotedId, pedantic));
              try
              {
                results = stmt.executeQuery(queryBuf.toString());
              }
              catch (SQLException sqlEx)
              {
                String sqlState = sqlEx.getSQLState();
                int errorCode = sqlEx.getErrorCode();
                if ((!"42S02".equals(sqlState)) && (errorCode != 1146) && (errorCode != 1049)) {
                  throw sqlEx;
                }
              }
              while ((results != null) && (results.next()))
              {
                byte[][] row = new byte[14][];
                row[0] = (dbMapsToSchema ? s2b("def") : s2b(dbStr));
                row[1] = (dbMapsToSchema ? s2b(dbStr) : null);
                row[2] = results.getBytes("Table");
                
                boolean indexIsUnique = results.getInt("Non_unique") == 0;
                
                row[3] = (!indexIsUnique ? s2b("true") : s2b("false"));
                row[4] = null;
                row[5] = results.getBytes("Key_name");
                short indexType = 3;
                row[6] = Integer.toString(indexType).getBytes();
                row[7] = results.getBytes("Seq_in_index");
                row[8] = results.getBytes("Column_name");
                row[9] = results.getBytes("Collation");
                
                long cardinality = results.getLong("Cardinality");
                
                row[10] = s2b(String.valueOf(cardinality));
                row[11] = s2b("0");
                row[12] = null;
                
                DatabaseMetaData.IndexMetaDataKey indexInfoKey = new DatabaseMetaData.IndexMetaDataKey(DatabaseMetaData.this, !indexIsUnique, indexType, results.getString("Key_name").toLowerCase(), results.getShort("Seq_in_index"));
                if (unique)
                {
                  if (indexIsUnique) {
                    sortedRows.put(indexInfoKey, new ByteArrayRow(row, getExceptionInterceptor()));
                  }
                }
                else {
                  sortedRows.put(indexInfoKey, new ByteArrayRow(row, getExceptionInterceptor()));
                }
              }
            }
            finally
            {
              if (results != null)
              {
                try
                {
                  results.close();
                }
                catch (Exception localException1) {}
                results = null;
              }
            }
          }
        }.doForAll();
        Iterator<Row> sortedRowsIterator = sortedRows.values().iterator();
        while (sortedRowsIterator.hasNext()) {
          rows.add(sortedRowsIterator.next());
        }
        ResultSet indexInfo = resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rows, new DefaultColumnDefinition(fields)));
        
        return indexInfo;
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected Field[] createIndexInfoFields()
  {
    Field[] fields = new Field[13];
    fields[0] = new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[1] = new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[2] = new Field("", "TABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[3] = new Field("", "NON_UNIQUE", metadataCollationIndex, metadataEncoding, MysqlType.BOOLEAN, 4);
    fields[4] = new Field("", "INDEX_QUALIFIER", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 1);
    fields[5] = new Field("", "INDEX_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    fields[6] = new Field("", "TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 32);
    fields[7] = new Field("", "ORDINAL_POSITION", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
    fields[8] = new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    fields[9] = new Field("", "ASC_OR_DESC", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 1);
    fields[10] = new Field("", "CARDINALITY", metadataCollationIndex, metadataEncoding, MysqlType.BIGINT, 20);
    fields[11] = new Field("", "PAGES", metadataCollationIndex, metadataEncoding, MysqlType.BIGINT, 20);
    fields[12] = new Field("", "FILTER_CONDITION", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    return fields;
  }
  
  public int getJDBCMajorVersion()
    throws SQLException
  {
    try
    {
      return 4;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getJDBCMinorVersion()
    throws SQLException
  {
    try
    {
      return 2;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxBinaryLiteralLength()
    throws SQLException
  {
    try
    {
      return 16777208;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxCatalogNameLength()
    throws SQLException
  {
    try
    {
      return 32;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxCharLiteralLength()
    throws SQLException
  {
    try
    {
      return 16777208;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxColumnNameLength()
    throws SQLException
  {
    try
    {
      return 64;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxColumnsInGroupBy()
    throws SQLException
  {
    try
    {
      return 64;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxColumnsInIndex()
    throws SQLException
  {
    try
    {
      return 16;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxColumnsInOrderBy()
    throws SQLException
  {
    try
    {
      return 64;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxColumnsInSelect()
    throws SQLException
  {
    try
    {
      return 256;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxColumnsInTable()
    throws SQLException
  {
    try
    {
      return 512;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxConnections()
    throws SQLException
  {
    try
    {
      return 0;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxCursorNameLength()
    throws SQLException
  {
    try
    {
      return 64;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxIndexLength()
    throws SQLException
  {
    try
    {
      return 256;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxProcedureNameLength()
    throws SQLException
  {
    try
    {
      return 0;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxRowSize()
    throws SQLException
  {
    try
    {
      return 2147483639;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxSchemaNameLength()
    throws SQLException
  {
    try
    {
      return 0;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxStatementLength()
    throws SQLException
  {
    try
    {
      return maxBufferSize - 4;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxStatements()
    throws SQLException
  {
    try
    {
      return 0;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxTableNameLength()
    throws SQLException
  {
    try
    {
      return 64;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxTablesInSelect()
    throws SQLException
  {
    try
    {
      return 256;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getMaxUserNameLength()
    throws SQLException
  {
    try
    {
      return 16;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getNumericFunctions()
    throws SQLException
  {
    try
    {
      return "ABS,ACOS,ASIN,ATAN,ATAN2,BIT_COUNT,CEILING,COS,COT,DEGREES,EXP,FLOOR,LOG,LOG10,MAX,MIN,MOD,PI,POW,POWER,RADIANS,RAND,ROUND,SIN,SQRT,TAN,TRUNCATE";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected Field[] getPrimaryKeysFields()
  {
    Field[] fields = new Field[6];
    fields[0] = new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[1] = new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[2] = new Field("", "TABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[3] = new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    fields[4] = new Field("", "KEY_SEQ", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
    fields[5] = new Field("", "PK_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    return fields;
  }
  
  public ResultSet getPrimaryKeys(String catalog, String schema, final String table)
    throws SQLException
  {
    try
    {
      if (table == null) {
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
          getExceptionInterceptor());
      }
      String db = getDatabase(catalog, schema);
      final boolean dbMapsToSchema = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
      
      final ArrayList<Row> rows = new ArrayList();
      final Statement stmt = conn.getMetadataSafeStatement();
      try
      {
        new IterateBlock(getDatabaseIterator(db))
        {
          void forEach(String dbStr)
            throws SQLException
          {
            ResultSet rs = null;
            try
            {
              StringBuilder queryBuf = new StringBuilder("SHOW KEYS FROM ");
              queryBuf.append(StringUtils.quoteIdentifier(table, quotedId, pedantic));
              queryBuf.append(" FROM ");
              queryBuf.append(StringUtils.quoteIdentifier(dbStr, quotedId, pedantic));
              try
              {
                rs = stmt.executeQuery(queryBuf.toString());
              }
              catch (SQLException sqlEx)
              {
                String sqlState = sqlEx.getSQLState();
                int errorCode = sqlEx.getErrorCode();
                if ((!"42S02".equals(sqlState)) && (errorCode != 1146) && (errorCode != 1049)) {
                  throw sqlEx;
                }
              }
              TreeMap<String, byte[][]> sortMap = new TreeMap();
              while ((rs != null) && (rs.next()))
              {
                String keyType = rs.getString("Key_name");
                if ((keyType != null) && (
                  (keyType.equalsIgnoreCase("PRIMARY")) || (keyType.equalsIgnoreCase("PRI"))))
                {
                  byte[][] tuple = new byte[6][];
                  tuple[0] = (dbMapsToSchema ? s2b("def") : s2b(dbStr));
                  tuple[1] = (dbMapsToSchema ? s2b(dbStr) : null);
                  tuple[2] = s2b(table);
                  
                  String columnName = rs.getString("Column_name");
                  tuple[3] = s2b(columnName);
                  tuple[4] = s2b(rs.getString("Seq_in_index"));
                  tuple[5] = s2b(keyType);
                  sortMap.put(columnName, tuple);
                }
              }
              Iterator<byte[][]> sortedIterator = sortMap.values().iterator();
              while (sortedIterator.hasNext()) {
                rows.add(new ByteArrayRow((byte[][])sortedIterator.next(), getExceptionInterceptor()));
              }
            }
            finally
            {
              if (rs != null)
              {
                try
                {
                  rs.close();
                }
                catch (Exception localException1) {}
                rs = null;
              }
            }
          }
        }.doForAll();
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rows, new DefaultColumnDefinition(
        getPrimaryKeysFields())));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getProcedureColumns(String catalog, String schemaPattern, String procedureNamePattern, String columnNamePattern)
    throws SQLException
  {
    try
    {
      return getProcedureOrFunctionColumns(createProcedureColumnsFields(), catalog, schemaPattern, procedureNamePattern, columnNamePattern, true, 
        ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.getProceduresReturnsFunctions).getValue()).booleanValue());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected Field[] createProcedureColumnsFields()
  {
    Field[] fields = new Field[20];
    fields[0] = new Field("", "PROCEDURE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 512);
    fields[1] = new Field("", "PROCEDURE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 512);
    fields[2] = new Field("", "PROCEDURE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 512);
    fields[3] = new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 512);
    fields[4] = new Field("", "COLUMN_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
    fields[5] = new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 6);
    fields[6] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
    fields[7] = new Field("", "PRECISION", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12);
    fields[8] = new Field("", "LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12);
    fields[9] = new Field("", "SCALE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 12);
    fields[10] = new Field("", "RADIX", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 6);
    fields[11] = new Field("", "NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 6);
    fields[12] = new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 512);
    fields[13] = new Field("", "COLUMN_DEF", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 512);
    fields[14] = new Field("", "SQL_DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12);
    fields[15] = new Field("", "SQL_DATETIME_SUB", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12);
    fields[16] = new Field("", "CHAR_OCTET_LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12);
    fields[17] = new Field("", "ORDINAL_POSITION", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12);
    fields[18] = new Field("", "IS_NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 512);
    fields[19] = new Field("", "SPECIFIC_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 512);
    return fields;
  }
  
  protected ResultSet getProcedureOrFunctionColumns(Field[] fields, String catalog, String schemaPattern, String procedureOrFunctionNamePattern, String columnNamePattern, boolean returnProcedures, boolean returnFunctions)
    throws SQLException
  {
    String db = getDatabase(catalog, schemaPattern);
    boolean dbMapsToSchema = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
    
    List<ComparableWrapper<String, ProcedureType>> procsOrFuncsToExtractList = new ArrayList();
    
    ResultSet procsAndOrFuncsRs = null;
    try
    {
      String tmpProcedureOrFunctionNamePattern = null;
      if ((procedureOrFunctionNamePattern != null) && (!procedureOrFunctionNamePattern.equals("%"))) {
        tmpProcedureOrFunctionNamePattern = StringUtils.sanitizeProcOrFuncName(procedureOrFunctionNamePattern);
      }
      if (tmpProcedureOrFunctionNamePattern == null)
      {
        tmpProcedureOrFunctionNamePattern = procedureOrFunctionNamePattern;
      }
      else
      {
        String tmpDb = db;
        List<String> parseList = StringUtils.splitDBdotName(tmpProcedureOrFunctionNamePattern, tmpDb, quotedId, session
          .getServerSession().isNoBackslashEscapesSet());
        if (parseList.size() == 2)
        {
          tmpDb = (String)parseList.get(0);
          tmpProcedureOrFunctionNamePattern = (String)parseList.get(1);
        }
      }
      procsAndOrFuncsRs = getProceduresAndOrFunctions(createFieldMetadataForGetProcedures(), catalog, schemaPattern, tmpProcedureOrFunctionNamePattern, returnProcedures, returnFunctions);
      
      boolean hasResults = false;
      while (procsAndOrFuncsRs.next())
      {
        procsOrFuncsToExtractList.add(new ComparableWrapper(
          StringUtils.getFullyQualifiedName(dbMapsToSchema ? procsAndOrFuncsRs.getString(2) : procsAndOrFuncsRs.getString(1), procsAndOrFuncsRs
          .getString(3), quotedId, pedantic), procsAndOrFuncsRs
          .getShort(8) == 1 ? ProcedureType.PROCEDURE : ProcedureType.FUNCTION));
        hasResults = true;
      }
      if (hasResults) {
        Collections.sort(procsOrFuncsToExtractList);
      }
    }
    finally
    {
      SQLException rethrowSqlEx;
      SQLException rethrowSqlEx = null;
      if (procsAndOrFuncsRs != null) {
        try
        {
          procsAndOrFuncsRs.close();
        }
        catch (SQLException sqlEx)
        {
          rethrowSqlEx = sqlEx;
        }
      }
      if (rethrowSqlEx != null) {
        throw rethrowSqlEx;
      }
    }
    ArrayList<Row> resultRows = new ArrayList();
    int idx = 0;
    String procNameToCall = "";
    for (ComparableWrapper<String, ProcedureType> procOrFunc : procsOrFuncsToExtractList)
    {
      String procName = (String)procOrFunc.getKey();
      ProcedureType procType = (ProcedureType)procOrFunc.getValue();
      if (!" ".equals(quotedId)) {
        idx = StringUtils.indexOfIgnoreCase(0, procName, ".", quotedId, quotedId, session
          .getServerSession().isNoBackslashEscapesSet() ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
      } else {
        idx = procName.indexOf(".");
      }
      if (idx > 0)
      {
        db = StringUtils.unQuoteIdentifier(procName.substring(0, idx), quotedId);
        procNameToCall = procName;
      }
      else
      {
        procNameToCall = procName;
      }
      getCallStmtParameterTypes(db, procNameToCall, procType, columnNamePattern, resultRows, fields.length == 17);
    }
    return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(resultRows, new DefaultColumnDefinition(fields)));
  }
  
  public ResultSet getProcedures(String catalog, String schemaPattern, String procedureNamePattern)
    throws SQLException
  {
    try
    {
      return getProceduresAndOrFunctions(createFieldMetadataForGetProcedures(), catalog, schemaPattern, procedureNamePattern, true, 
        ((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.getProceduresReturnsFunctions).getValue()).booleanValue());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected Field[] createFieldMetadataForGetProcedures()
  {
    Field[] fields = new Field[9];
    fields[0] = new Field("", "PROCEDURE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[1] = new Field("", "PROCEDURE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[2] = new Field("", "PROCEDURE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[3] = new Field("", "reserved1", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[4] = new Field("", "reserved2", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[5] = new Field("", "reserved3", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
    fields[6] = new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[7] = new Field("", "PROCEDURE_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 6);
    fields[8] = new Field("", "SPECIFIC_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    
    return fields;
  }
  
  protected ResultSet getProceduresAndOrFunctions(final Field[] fields, String catalog, String schemaPattern, final String procedureNamePattern, final boolean returnProcedures, final boolean returnFunctions)
    throws SQLException
  {
    ArrayList<Row> procedureRows = new ArrayList();
    
    String db = getDatabase(catalog, schemaPattern);
    final boolean dbMapsToSchema = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
    
    final List<ComparableWrapper<String, Row>> procedureRowsToSort = new ArrayList();
    
    new IterateBlock(dbMapsToSchema ? getSchemaPatternIterator(db) : getDatabaseIterator(db))
    {
      /* Error */
      void forEach(String dbPattern)
        throws SQLException
      {
        // Byte code:
        //   0: aconst_null
        //   1: astore_2
        //   2: new 9	java/lang/StringBuilder
        //   5: dup
        //   6: invokespecial 10	java/lang/StringBuilder:<init>	()V
        //   9: astore_3
        //   10: aload_3
        //   11: ldc 11
        //   13: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   16: pop
        //   17: aload_0
        //   18: getfield 2	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnProcedures	Z
        //   21: ifeq +20 -> 41
        //   24: aload_0
        //   25: getfield 3	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnFunctions	Z
        //   28: ifne +13 -> 41
        //   31: aload_3
        //   32: ldc 13
        //   34: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   37: pop
        //   38: goto +24 -> 62
        //   41: aload_0
        //   42: getfield 2	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnProcedures	Z
        //   45: ifne +17 -> 62
        //   48: aload_0
        //   49: getfield 3	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnFunctions	Z
        //   52: ifeq +10 -> 62
        //   55: aload_3
        //   56: ldc 14
        //   58: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   61: pop
        //   62: aload_3
        //   63: aload_0
        //   64: getfield 4	com/mysql/cj/jdbc/DatabaseMetaData$8:val$dbMapsToSchema	Z
        //   67: ifeq +8 -> 75
        //   70: ldc 15
        //   72: goto +5 -> 77
        //   75: ldc 16
        //   77: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   80: pop
        //   81: aload_0
        //   82: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   85: ifnull +20 -> 105
        //   88: aload_0
        //   89: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   92: invokevirtual 17	java/lang/String:length	()I
        //   95: ifle +10 -> 105
        //   98: aload_3
        //   99: ldc 18
        //   101: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   104: pop
        //   105: aload_3
        //   106: ldc 19
        //   108: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   111: pop
        //   112: aload_0
        //   113: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
        //   116: aload_3
        //   117: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
        //   120: invokevirtual 21	com/mysql/cj/jdbc/DatabaseMetaData:prepareMetaDataSafeStatement	(Ljava/lang/String;)Ljava/sql/PreparedStatement;
        //   123: astore 4
        //   125: aload_0
        //   126: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
        //   129: getfield 22	com/mysql/cj/jdbc/DatabaseMetaData:conn	Lcom/mysql/cj/jdbc/JdbcConnection;
        //   132: invokeinterface 23 1 0
        //   137: ifeq +8 -> 145
        //   140: aload_1
        //   141: invokevirtual 24	java/lang/String:toLowerCase	()Ljava/lang/String;
        //   144: astore_1
        //   145: aload 4
        //   147: iconst_1
        //   148: aload_1
        //   149: invokeinterface 25 3 0
        //   154: aload_0
        //   155: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   158: ifnull +25 -> 183
        //   161: aload_0
        //   162: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   165: invokevirtual 17	java/lang/String:length	()I
        //   168: ifle +15 -> 183
        //   171: aload 4
        //   173: iconst_2
        //   174: aload_0
        //   175: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   178: invokeinterface 25 3 0
        //   183: aload 4
        //   185: invokeinterface 26 1 0
        //   190: astore_2
        //   191: aload_0
        //   192: getfield 2	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnProcedures	Z
        //   195: ifeq +16 -> 211
        //   198: aload_0
        //   199: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
        //   202: iconst_1
        //   203: aload_2
        //   204: aload_0
        //   205: getfield 6	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureRowsToSort	Ljava/util/List;
        //   208: invokevirtual 27	com/mysql/cj/jdbc/DatabaseMetaData:convertToJdbcProcedureList	(ZLjava/sql/ResultSet;Ljava/util/List;)V
        //   211: aload_0
        //   212: getfield 3	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnFunctions	Z
        //   215: ifeq +19 -> 234
        //   218: aload_0
        //   219: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
        //   222: aload_2
        //   223: aload_0
        //   224: getfield 6	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureRowsToSort	Ljava/util/List;
        //   227: aload_0
        //   228: getfield 7	com/mysql/cj/jdbc/DatabaseMetaData$8:val$fields	[Lcom/mysql/cj/result/Field;
        //   231: invokevirtual 28	com/mysql/cj/jdbc/DatabaseMetaData:convertToJdbcFunctionList	(Ljava/sql/ResultSet;Ljava/util/List;[Lcom/mysql/cj/result/Field;)V
        //   234: goto +322 -> 556
        //   237: astore 5
        //   239: aload_0
        //   240: getfield 3	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnFunctions	Z
        //   243: ifeq +156 -> 399
        //   246: aload 4
        //   248: invokeinterface 30 1 0
        //   253: new 9	java/lang/StringBuilder
        //   256: dup
        //   257: invokespecial 10	java/lang/StringBuilder:<init>	()V
        //   260: ldc 31
        //   262: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   265: aload_0
        //   266: getfield 4	com/mysql/cj/jdbc/DatabaseMetaData$8:val$dbMapsToSchema	Z
        //   269: ifeq +8 -> 277
        //   272: ldc 32
        //   274: goto +5 -> 279
        //   277: ldc 33
        //   279: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   282: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
        //   285: astore 6
        //   287: aload_0
        //   288: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   291: ifnull +35 -> 326
        //   294: aload_0
        //   295: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   298: invokevirtual 17	java/lang/String:length	()I
        //   301: ifle +25 -> 326
        //   304: new 9	java/lang/StringBuilder
        //   307: dup
        //   308: invokespecial 10	java/lang/StringBuilder:<init>	()V
        //   311: aload 6
        //   313: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   316: ldc 34
        //   318: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   321: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
        //   324: astore 6
        //   326: aload_0
        //   327: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
        //   330: aload 6
        //   332: invokevirtual 21	com/mysql/cj/jdbc/DatabaseMetaData:prepareMetaDataSafeStatement	(Ljava/lang/String;)Ljava/sql/PreparedStatement;
        //   335: astore 4
        //   337: aload 4
        //   339: iconst_1
        //   340: aload_1
        //   341: invokeinterface 25 3 0
        //   346: aload_0
        //   347: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   350: ifnull +25 -> 375
        //   353: aload_0
        //   354: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   357: invokevirtual 17	java/lang/String:length	()I
        //   360: ifle +15 -> 375
        //   363: aload 4
        //   365: iconst_2
        //   366: aload_0
        //   367: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   370: invokeinterface 25 3 0
        //   375: aload 4
        //   377: invokeinterface 26 1 0
        //   382: astore_2
        //   383: aload_0
        //   384: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
        //   387: aload_2
        //   388: aload_0
        //   389: getfield 6	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureRowsToSort	Ljava/util/List;
        //   392: aload_0
        //   393: getfield 7	com/mysql/cj/jdbc/DatabaseMetaData$8:val$fields	[Lcom/mysql/cj/result/Field;
        //   396: invokevirtual 28	com/mysql/cj/jdbc/DatabaseMetaData:convertToJdbcFunctionList	(Ljava/sql/ResultSet;Ljava/util/List;[Lcom/mysql/cj/result/Field;)V
        //   399: aload_0
        //   400: getfield 2	com/mysql/cj/jdbc/DatabaseMetaData$8:val$returnProcedures	Z
        //   403: ifeq +153 -> 556
        //   406: aload 4
        //   408: invokeinterface 30 1 0
        //   413: new 9	java/lang/StringBuilder
        //   416: dup
        //   417: invokespecial 10	java/lang/StringBuilder:<init>	()V
        //   420: ldc 35
        //   422: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   425: aload_0
        //   426: getfield 4	com/mysql/cj/jdbc/DatabaseMetaData$8:val$dbMapsToSchema	Z
        //   429: ifeq +8 -> 437
        //   432: ldc 32
        //   434: goto +5 -> 439
        //   437: ldc 33
        //   439: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   442: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
        //   445: astore 6
        //   447: aload_0
        //   448: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   451: ifnull +35 -> 486
        //   454: aload_0
        //   455: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   458: invokevirtual 17	java/lang/String:length	()I
        //   461: ifle +25 -> 486
        //   464: new 9	java/lang/StringBuilder
        //   467: dup
        //   468: invokespecial 10	java/lang/StringBuilder:<init>	()V
        //   471: aload 6
        //   473: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   476: ldc 34
        //   478: invokevirtual 12	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
        //   481: invokevirtual 20	java/lang/StringBuilder:toString	()Ljava/lang/String;
        //   484: astore 6
        //   486: aload_0
        //   487: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
        //   490: aload 6
        //   492: invokevirtual 21	com/mysql/cj/jdbc/DatabaseMetaData:prepareMetaDataSafeStatement	(Ljava/lang/String;)Ljava/sql/PreparedStatement;
        //   495: astore 4
        //   497: aload 4
        //   499: iconst_1
        //   500: aload_1
        //   501: invokeinterface 25 3 0
        //   506: aload_0
        //   507: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   510: ifnull +25 -> 535
        //   513: aload_0
        //   514: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   517: invokevirtual 17	java/lang/String:length	()I
        //   520: ifle +15 -> 535
        //   523: aload 4
        //   525: iconst_2
        //   526: aload_0
        //   527: getfield 5	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureNamePattern	Ljava/lang/String;
        //   530: invokeinterface 25 3 0
        //   535: aload 4
        //   537: invokeinterface 26 1 0
        //   542: astore_2
        //   543: aload_0
        //   544: getfield 1	com/mysql/cj/jdbc/DatabaseMetaData$8:this$0	Lcom/mysql/cj/jdbc/DatabaseMetaData;
        //   547: iconst_0
        //   548: aload_2
        //   549: aload_0
        //   550: getfield 6	com/mysql/cj/jdbc/DatabaseMetaData$8:val$procedureRowsToSort	Ljava/util/List;
        //   553: invokevirtual 27	com/mysql/cj/jdbc/DatabaseMetaData:convertToJdbcProcedureList	(ZLjava/sql/ResultSet;Ljava/util/List;)V
        //   556: aconst_null
        //   557: astore 5
        //   559: aload_2
        //   560: ifnull +18 -> 578
        //   563: aload_2
        //   564: invokeinterface 36 1 0
        //   569: goto +9 -> 578
        //   572: astore 6
        //   574: aload 6
        //   576: astore 5
        //   578: aload 4
        //   580: ifnull +19 -> 599
        //   583: aload 4
        //   585: invokeinterface 30 1 0
        //   590: goto +9 -> 599
        //   593: astore 6
        //   595: aload 6
        //   597: astore 5
        //   599: aload 5
        //   601: ifnull +6 -> 607
        //   604: aload 5
        //   606: athrow
        //   607: goto +59 -> 666
        //   610: astore 7
        //   612: aconst_null
        //   613: astore 8
        //   615: aload_2
        //   616: ifnull +18 -> 634
        //   619: aload_2
        //   620: invokeinterface 36 1 0
        //   625: goto +9 -> 634
        //   628: astore 9
        //   630: aload 9
        //   632: astore 8
        //   634: aload 4
        //   636: ifnull +19 -> 655
        //   639: aload 4
        //   641: invokeinterface 30 1 0
        //   646: goto +9 -> 655
        //   649: astore 9
        //   651: aload 9
        //   653: astore 8
        //   655: aload 8
        //   657: ifnull +6 -> 663
        //   660: aload 8
        //   662: athrow
        //   663: aload 7
        //   665: athrow
        //   666: return
        // Line number table:
        //   Java source line #3205	-> byte code offset #0
        //   Java source line #3207	-> byte code offset #2
        //   Java source line #3209	-> byte code offset #10
        //   Java source line #3210	-> byte code offset #17
        //   Java source line #3211	-> byte code offset #31
        //   Java source line #3212	-> byte code offset #41
        //   Java source line #3213	-> byte code offset #55
        //   Java source line #3216	-> byte code offset #62
        //   Java source line #3218	-> byte code offset #81
        //   Java source line #3219	-> byte code offset #98
        //   Java source line #3222	-> byte code offset #105
        //   Java source line #3224	-> byte code offset #112
        //   Java source line #3229	-> byte code offset #125
        //   Java source line #3230	-> byte code offset #140
        //   Java source line #3232	-> byte code offset #145
        //   Java source line #3234	-> byte code offset #154
        //   Java source line #3235	-> byte code offset #171
        //   Java source line #3239	-> byte code offset #183
        //   Java source line #3241	-> byte code offset #191
        //   Java source line #3242	-> byte code offset #198
        //   Java source line #3245	-> byte code offset #211
        //   Java source line #3246	-> byte code offset #218
        //   Java source line #3288	-> byte code offset #234
        //   Java source line #3249	-> byte code offset #237
        //   Java source line #3254	-> byte code offset #239
        //   Java source line #3255	-> byte code offset #246
        //   Java source line #3257	-> byte code offset #253
        //   Java source line #3258	-> byte code offset #287
        //   Java source line #3259	-> byte code offset #304
        //   Java source line #3261	-> byte code offset #326
        //   Java source line #3262	-> byte code offset #337
        //   Java source line #3263	-> byte code offset #346
        //   Java source line #3264	-> byte code offset #363
        //   Java source line #3266	-> byte code offset #375
        //   Java source line #3268	-> byte code offset #383
        //   Java source line #3272	-> byte code offset #399
        //   Java source line #3273	-> byte code offset #406
        //   Java source line #3275	-> byte code offset #413
        //   Java source line #3276	-> byte code offset #447
        //   Java source line #3277	-> byte code offset #464
        //   Java source line #3279	-> byte code offset #486
        //   Java source line #3280	-> byte code offset #497
        //   Java source line #3281	-> byte code offset #506
        //   Java source line #3282	-> byte code offset #523
        //   Java source line #3284	-> byte code offset #535
        //   Java source line #3286	-> byte code offset #543
        //   Java source line #3291	-> byte code offset #556
        //   Java source line #3293	-> byte code offset #559
        //   Java source line #3295	-> byte code offset #563
        //   Java source line #3298	-> byte code offset #569
        //   Java source line #3296	-> byte code offset #572
        //   Java source line #3297	-> byte code offset #574
        //   Java source line #3301	-> byte code offset #578
        //   Java source line #3303	-> byte code offset #583
        //   Java source line #3306	-> byte code offset #590
        //   Java source line #3304	-> byte code offset #593
        //   Java source line #3305	-> byte code offset #595
        //   Java source line #3309	-> byte code offset #599
        //   Java source line #3310	-> byte code offset #604
        //   Java source line #3312	-> byte code offset #607
        //   Java source line #3291	-> byte code offset #610
        //   Java source line #3293	-> byte code offset #615
        //   Java source line #3295	-> byte code offset #619
        //   Java source line #3298	-> byte code offset #625
        //   Java source line #3296	-> byte code offset #628
        //   Java source line #3297	-> byte code offset #630
        //   Java source line #3301	-> byte code offset #634
        //   Java source line #3303	-> byte code offset #639
        //   Java source line #3306	-> byte code offset #646
        //   Java source line #3304	-> byte code offset #649
        //   Java source line #3305	-> byte code offset #651
        //   Java source line #3309	-> byte code offset #655
        //   Java source line #3310	-> byte code offset #660
        //   Java source line #3312	-> byte code offset #663
        //   Java source line #3313	-> byte code offset #666
        // Local variable table:
        //   start	length	slot	name	signature
        //   0	667	0	this	8
        //   0	667	1	dbPattern	String
        //   1	619	2	proceduresRs	ResultSet
        //   9	108	3	selectFromMySQLProcSQL	StringBuilder
        //   123	517	4	proceduresStmt	PreparedStatement
        //   237	3	5	sqlEx	SQLException
        //   557	48	5	rethrowSqlEx	SQLException
        //   285	46	6	sql	String
        //   445	46	6	sql	String
        //   572	3	6	sqlEx	SQLException
        //   593	3	6	sqlEx	SQLException
        //   610	54	7	localObject	Object
        //   613	48	8	rethrowSqlEx	SQLException
        //   628	3	9	sqlEx	SQLException
        //   649	3	9	sqlEx	SQLException
        // Exception table:
        //   from	to	target	type
        //   183	234	237	java/sql/SQLException
        //   563	569	572	java/sql/SQLException
        //   583	590	593	java/sql/SQLException
        //   125	556	610	finally
        //   610	612	610	finally
        //   619	625	628	java/sql/SQLException
        //   639	646	649	java/sql/SQLException
      }
    }.doForAll();
    Collections.sort(procedureRowsToSort);
    for (ComparableWrapper<String, Row> procRow : procedureRowsToSort) {
      procedureRows.add(procRow.getValue());
    }
    return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(procedureRows, new DefaultColumnDefinition(fields)));
  }
  
  public String getProcedureTerm()
    throws SQLException
  {
    try
    {
      return "PROCEDURE";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getResultSetHoldability()
    throws SQLException
  {
    try
    {
      return 1;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  void populateKeyResults(String db, String table, String keysComment, List<Row> resultRows, String fkTableName, boolean isExport)
    throws SQLException
  {
    LocalAndReferencedColumns parsedInfo = parseTableStatusIntoLocalAndReferencedColumns(keysComment);
    if ((isExport) && (!referencedTable.equals(table))) {
      return;
    }
    if (localColumnsList.size() != referencedColumnsList.size()) {
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.12"), "S1000", getExceptionInterceptor());
    }
    Iterator<String> localColumnNames = localColumnsList.iterator();
    Iterator<String> referColumnNames = referencedColumnsList.iterator();
    
    int keySeqIndex = 1;
    
    boolean dbMapsToSchema = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
    while (localColumnNames.hasNext())
    {
      byte[][] tuple = new byte[14][];
      String lColumnName = StringUtils.unQuoteIdentifier((String)localColumnNames.next(), quotedId);
      String rColumnName = StringUtils.unQuoteIdentifier((String)referColumnNames.next(), quotedId);
      
      tuple[0] = (dbMapsToSchema ? s2b("def") : s2b(referencedDatabase));
      tuple[1] = (dbMapsToSchema ? s2b(referencedDatabase) : null);
      tuple[2] = s2b(isExport ? table : referencedTable);
      tuple[3] = s2b(rColumnName);
      tuple[4] = (dbMapsToSchema ? s2b("def") : s2b(db));
      tuple[5] = (dbMapsToSchema ? s2b(db) : null);
      tuple[6] = s2b(isExport ? fkTableName : table);
      tuple[7] = s2b(lColumnName);
      tuple[8] = s2b(Integer.toString(keySeqIndex++));
      
      int[] actions = getForeignKeyActions(keysComment);
      tuple[9] = s2b(Integer.toString(actions[1]));
      tuple[10] = s2b(Integer.toString(actions[0]));
      
      tuple[11] = s2b(constraintName);
      tuple[12] = null;
      tuple[13] = s2b(Integer.toString(7));
      resultRows.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
    }
  }
  
  public ResultSet getSchemas()
    throws SQLException
  {
    try
    {
      return getSchemas(null, null);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getSchemas(String catalog, String schemaPattern)
    throws SQLException
  {
    try
    {
      List<String> dbList = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? getDatabases(schemaPattern) : new ArrayList();
      
      Field[] fields = new Field[2];
      fields[0] = new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
      fields[1] = new Field("", "TABLE_CATALOG", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 0);
      
      ArrayList<Row> tuples = new ArrayList(dbList.size());
      for (String db : dbList)
      {
        byte[][] rowVal = new byte[2][];
        rowVal[0] = s2b(db);
        rowVal[1] = s2b("def");
        tuples.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(tuples, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getSchemaTerm()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? "SCHEMA" : "";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getSearchStringEscape()
    throws SQLException
  {
    try
    {
      return "\\";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getSQLKeywords()
    throws SQLException
  {
    try
    {
      if (mysqlKeywords != null) {
        return mysqlKeywords;
      }
      synchronized (DatabaseMetaData.class)
      {
        if (mysqlKeywords != null) {
          return mysqlKeywords;
        }
        Set<String> mysqlKeywordSet = new TreeSet();
        StringBuilder mysqlKeywordsBuffer = new StringBuilder();
        
        Collections.addAll(mysqlKeywordSet, MYSQL_KEYWORDS);
        mysqlKeywordSet.removeAll(SQL2003_KEYWORDS);
        for (String keyword : mysqlKeywordSet) {
          mysqlKeywordsBuffer.append(",").append(keyword);
        }
        mysqlKeywords = mysqlKeywordsBuffer.substring(1);
        return mysqlKeywords;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getSQLStateType()
    throws SQLException
  {
    try
    {
      return 2;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getStringFunctions()
    throws SQLException
  {
    try
    {
      return "ASCII,BIN,BIT_LENGTH,CHAR,CHARACTER_LENGTH,CHAR_LENGTH,CONCAT,CONCAT_WS,CONV,ELT,EXPORT_SET,FIELD,FIND_IN_SET,HEX,INSERT,INSTR,LCASE,LEFT,LENGTH,LOAD_FILE,LOCATE,LOCATE,LOWER,LPAD,LTRIM,MAKE_SET,MATCH,MID,OCT,OCTET_LENGTH,ORD,POSITION,QUOTE,REPEAT,REPLACE,REVERSE,RIGHT,RPAD,RTRIM,SOUNDEX,SPACE,STRCMP,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING,SUBSTRING_INDEX,TRIM,UCASE,UPPER";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getSuperTables(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      Field[] fields = new Field[4];
      fields[0] = new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[1] = new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[2] = new Field("", "TABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[3] = new Field("", "SUPERTABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(new ArrayList(), new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getSuperTypes(String arg0, String arg1, String arg2)
    throws SQLException
  {
    try
    {
      Field[] fields = new Field[6];
      fields[0] = new Field("", "TYPE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[1] = new Field("", "TYPE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[2] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[3] = new Field("", "SUPERTYPE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[4] = new Field("", "SUPERTYPE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[5] = new Field("", "SUPERTYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(new ArrayList(), new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getSystemFunctions()
    throws SQLException
  {
    try
    {
      return "DATABASE,USER,SYSTEM_USER,SESSION_USER,PASSWORD,ENCRYPT,LAST_INSERT_ID,VERSION";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected String getTableNameWithCase(String table)
  {
    String tableNameWithCase = conn.lowerCaseTableNames() ? table.toLowerCase() : table;
    
    return tableNameWithCase;
  }
  
  public ResultSet getTablePrivileges(String catalog, String schemaPattern, String tableNamePattern)
    throws SQLException
  {
    try
    {
      Field[] fields = new Field[7];
      fields[0] = new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
      fields[1] = new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 1);
      fields[2] = new Field("", "TABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
      fields[3] = new Field("", "GRANTOR", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 77);
      fields[4] = new Field("", "GRANTEE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 77);
      fields[5] = new Field("", "PRIVILEGE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 64);
      fields[6] = new Field("", "IS_GRANTABLE", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 3);
      
      String dbPattern = getDatabase(catalog, schemaPattern);
      
      StringBuilder grantQueryBuf = new StringBuilder("SELECT host,db,table_name,grantor,user,table_priv FROM mysql.tables_priv");
      
      StringBuilder conditionBuf = new StringBuilder();
      if (dbPattern != null) {
        conditionBuf.append(databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? " db LIKE ?" : " db = ?");
      }
      if (tableNamePattern != null)
      {
        if (conditionBuf.length() > 0) {
          conditionBuf.append(" AND");
        }
        conditionBuf.append(" table_name LIKE ?");
      }
      if (conditionBuf.length() > 0)
      {
        grantQueryBuf.append(" WHERE");
        grantQueryBuf.append(conditionBuf);
      }
      ResultSet results = null;
      ArrayList<Row> grantRows = new ArrayList();
      PreparedStatement pStmt = null;
      try
      {
        pStmt = prepareMetaDataSafeStatement(grantQueryBuf.toString());
        int nextId = 1;
        if (dbPattern != null) {
          pStmt.setString(nextId++, dbPattern);
        }
        if (tableNamePattern != null) {
          pStmt.setString(nextId, tableNamePattern);
        }
        results = pStmt.executeQuery();
        while (results.next())
        {
          String host = results.getString(1);
          String db = results.getString(2);
          String table = results.getString(3);
          String grantor = results.getString(4);
          String user = results.getString(5);
          if ((user == null) || (user.length() == 0)) {
            user = "%";
          }
          StringBuilder fullUser = new StringBuilder(user);
          if ((host != null) && (useHostsInPrivileges))
          {
            fullUser.append("@");
            fullUser.append(host);
          }
          String allPrivileges = results.getString(6);
          if (allPrivileges != null)
          {
            allPrivileges = allPrivileges.toUpperCase(Locale.ENGLISH);
            
            StringTokenizer st = new StringTokenizer(allPrivileges, ",");
            for (;;)
            {
              if (st.hasMoreTokens())
              {
                String privilege = st.nextToken().trim();
                
                ResultSet columnResults = null;
                try
                {
                  columnResults = getColumns(catalog, schemaPattern, table, null);
                  while (columnResults.next())
                  {
                    byte[][] tuple = new byte[8][];
                    tuple[0] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b("def") : s2b(db));
                    tuple[1] = (databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? s2b(db) : null);
                    tuple[2] = s2b(table);
                    tuple[3] = (grantor != null ? s2b(grantor) : null);
                    tuple[4] = s2b(fullUser.toString());
                    tuple[5] = s2b(privilege);
                    tuple[6] = null;
                    grantRows.add(new ByteArrayRow(tuple, getExceptionInterceptor()));
                  }
                  if (columnResults != null) {
                    try
                    {
                      columnResults.close();
                    }
                    catch (Exception localException) {}
                  }
                }
                finally
                {
                  if (columnResults != null) {
                    try
                    {
                      columnResults.close();
                    }
                    catch (Exception localException1) {}
                  }
                }
              }
            }
          }
        }
      }
      finally
      {
        if (results != null)
        {
          try
          {
            results.close();
          }
          catch (Exception localException4) {}
          results = null;
        }
        if (pStmt != null)
        {
          try
          {
            pStmt.close();
          }
          catch (Exception localException5) {}
          pStmt = null;
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(grantRows, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getTables(String catalog, String schemaPattern, String tableNamePattern, final String[] types)
    throws SQLException
  {
    try
    {
      final SortedMap<TableMetaDataKey, Row> sortedRows = new TreeMap();
      ArrayList<Row> tuples = new ArrayList();
      
      final Statement stmt = conn.getMetadataSafeStatement();
      
      String db = getDatabase(catalog, schemaPattern);
      
      final boolean dbMapsToSchema = databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
      if (tableNamePattern != null)
      {
        List<String> parseList = StringUtils.splitDBdotName(tableNamePattern, db, quotedId, session.getServerSession().isNoBackslashEscapesSet());
        if (parseList.size() == 2) {
          tableNamePattern = (String)parseList.get(1);
        }
      }
      final String tableNamePat = tableNamePattern;
      try
      {
        new IterateBlock(dbMapsToSchema ? getSchemaPatternIterator(db) : getDatabaseIterator(db))
        {
          void forEach(String dbPattern)
            throws SQLException
          {
            boolean operatingOnSystemDB = ("information_schema".equalsIgnoreCase(dbPattern)) || ("mysql".equalsIgnoreCase(dbPattern)) || ("performance_schema".equalsIgnoreCase(dbPattern));
            
            ResultSet results = null;
            try
            {
              try
              {
                StringBuilder sqlBuf = new StringBuilder("SHOW FULL TABLES FROM ");
                sqlBuf.append(StringUtils.quoteIdentifier(dbPattern, quotedId, pedantic));
                if (tableNamePat != null)
                {
                  sqlBuf.append(" LIKE ");
                  sqlBuf.append(StringUtils.quoteIdentifier(tableNamePat, "'", true));
                }
                results = stmt.executeQuery(sqlBuf.toString());
              }
              catch (SQLException sqlEx)
              {
                if ("08S01".equals(sqlEx.getSQLState())) {
                  throw sqlEx;
                }
                return;
              }
              boolean shouldReportTables = false;
              boolean shouldReportViews = false;
              boolean shouldReportSystemTables = false;
              boolean shouldReportSystemViews = false;
              boolean shouldReportLocalTemporaries = false;
              if ((types == null) || (types.length == 0))
              {
                shouldReportTables = true;
                shouldReportViews = true;
                shouldReportSystemTables = true;
                shouldReportSystemViews = true;
                shouldReportLocalTemporaries = true;
              }
              else
              {
                for (int i = 0; i < types.length; i++) {
                  if (DatabaseMetaData.TableType.TABLE.equalsTo(types[i])) {
                    shouldReportTables = true;
                  } else if (DatabaseMetaData.TableType.VIEW.equalsTo(types[i])) {
                    shouldReportViews = true;
                  } else if (DatabaseMetaData.TableType.SYSTEM_TABLE.equalsTo(types[i])) {
                    shouldReportSystemTables = true;
                  } else if (DatabaseMetaData.TableType.SYSTEM_VIEW.equalsTo(types[i])) {
                    shouldReportSystemViews = true;
                  } else if (DatabaseMetaData.TableType.LOCAL_TEMPORARY.equalsTo(types[i])) {
                    shouldReportLocalTemporaries = true;
                  }
                }
              }
              int typeColumnIndex = 0;
              boolean hasTableTypes = false;
              try
              {
                typeColumnIndex = results.findColumn("table_type");
                hasTableTypes = true;
              }
              catch (SQLException sqlEx)
              {
                try
                {
                  typeColumnIndex = results.findColumn("Type");
                  hasTableTypes = true;
                }
                catch (SQLException sqlEx2)
                {
                  hasTableTypes = false;
                }
              }
              while (results.next())
              {
                byte[][] row = new byte[10][];
                row[0] = (dbMapsToSchema ? s2b("def") : s2b(dbPattern));
                row[1] = (dbMapsToSchema ? s2b(dbPattern) : null);
                row[2] = results.getBytes(1);
                row[4] = new byte[0];
                row[5] = null;
                row[6] = null;
                row[7] = null;
                row[8] = null;
                row[9] = null;
                if (hasTableTypes)
                {
                  String tableType = results.getString(typeColumnIndex);
                  switch (DatabaseMetaData.11.$SwitchMap$com$mysql$cj$jdbc$DatabaseMetaData$TableType[DatabaseMetaData.TableType.getTableTypeCompliantWith(tableType).ordinal()])
                  {
                  case 1: 
                    boolean reportTable = false;
                    DatabaseMetaData.TableMetaDataKey tablesKey = null;
                    if ((operatingOnSystemDB) && (shouldReportSystemTables))
                    {
                      row[3] = DatabaseMetaData.TableType.SYSTEM_TABLE.asBytes();
                      tablesKey = new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.SYSTEM_TABLE.getName(), dbPattern, null, results.getString(1));
                      reportTable = true;
                    }
                    else if ((!operatingOnSystemDB) && (shouldReportTables))
                    {
                      row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
                      tablesKey = new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.TABLE.getName(), dbPattern, null, results.getString(1));
                      reportTable = true;
                    }
                    if (reportTable) {
                      sortedRows.put(tablesKey, new ByteArrayRow(row, getExceptionInterceptor()));
                    }
                    break;
                  case 2: 
                    if (shouldReportViews)
                    {
                      row[3] = DatabaseMetaData.TableType.VIEW.asBytes();
                      sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.VIEW.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, 
                        getExceptionInterceptor()));
                    }
                    break;
                  case 3: 
                    if (shouldReportSystemTables)
                    {
                      row[3] = DatabaseMetaData.TableType.SYSTEM_TABLE.asBytes();
                      sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.SYSTEM_TABLE.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, 
                        getExceptionInterceptor()));
                    }
                    break;
                  case 4: 
                    if (shouldReportSystemViews)
                    {
                      row[3] = DatabaseMetaData.TableType.SYSTEM_VIEW.asBytes();
                      sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.SYSTEM_VIEW.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, 
                        getExceptionInterceptor()));
                    }
                    break;
                  case 5: 
                    if (shouldReportLocalTemporaries)
                    {
                      row[3] = DatabaseMetaData.TableType.LOCAL_TEMPORARY.asBytes();
                      sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.LOCAL_TEMPORARY.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, 
                        getExceptionInterceptor()));
                    }
                    break;
                  default: 
                    row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
                    sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.TABLE.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, 
                      getExceptionInterceptor()));
                  }
                }
                else if (shouldReportTables)
                {
                  row[3] = DatabaseMetaData.TableType.TABLE.asBytes();
                  sortedRows.put(new DatabaseMetaData.TableMetaDataKey(DatabaseMetaData.this, DatabaseMetaData.TableType.TABLE.getName(), dbPattern, null, results.getString(1)), new ByteArrayRow(row, 
                    getExceptionInterceptor()));
                }
              }
            }
            finally
            {
              if (results != null)
              {
                try
                {
                  results.close();
                }
                catch (Exception localException2) {}
                results = null;
              }
            }
          }
        }.doForAll();
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
      tuples.addAll(sortedRows.values());
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(tuples, 
        createTablesFields()));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected ColumnDefinition createTablesFields()
  {
    Field[] fields = new Field[10];
    fields[0] = new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 255);
    fields[1] = new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 0);
    fields[2] = new Field("", "TABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 255);
    fields[3] = new Field("", "TABLE_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 5);
    fields[4] = new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 0);
    fields[5] = new Field("", "TYPE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 0);
    fields[6] = new Field("", "TYPE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 0);
    fields[7] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 0);
    fields[8] = new Field("", "SELF_REFERENCING_COL_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 0);
    fields[9] = new Field("", "REF_GENERATION", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 0);
    return new DefaultColumnDefinition(fields);
  }
  
  public ResultSet getTableTypes()
    throws SQLException
  {
    try
    {
      ArrayList<Row> tuples = new ArrayList();
      Field[] fields = { new Field("", "TABLE_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 256) };
      
      tuples.add(new ByteArrayRow(new byte[][] { TableType.LOCAL_TEMPORARY.asBytes() }, getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(new byte[][] { TableType.SYSTEM_TABLE.asBytes() }, getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(new byte[][] { TableType.SYSTEM_VIEW.asBytes() }, getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(new byte[][] { TableType.TABLE.asBytes() }, getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(new byte[][] { TableType.VIEW.asBytes() }, getExceptionInterceptor()));
      
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(tuples, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getTimeDateFunctions()
    throws SQLException
  {
    try
    {
      return "DAYOFWEEK,WEEKDAY,DAYOFMONTH,DAYOFYEAR,MONTH,DAYNAME,MONTHNAME,QUARTER,WEEK,YEAR,HOUR,MINUTE,SECOND,PERIOD_ADD,PERIOD_DIFF,TO_DAYS,FROM_DAYS,DATE_FORMAT,TIME_FORMAT,CURDATE,CURRENT_DATE,CURTIME,CURRENT_TIME,NOW,SYSDATE,CURRENT_TIMESTAMP,UNIX_TIMESTAMP,FROM_UNIXTIME,SEC_TO_TIME,TIME_TO_SEC";
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private byte[][] getTypeInfo(String mysqlTypeName)
    throws SQLException
  {
    MysqlType mt = MysqlType.getByName(mysqlTypeName);
    byte[][] rowVal = new byte[18][];
    
    rowVal[0] = s2b(mysqlTypeName);
    rowVal[1] = Integer.toString(mt.getJdbcType()).getBytes();
    
    rowVal[2] = Integer.toString(mt.getPrecision().longValue() > 2147483647L ? Integer.MAX_VALUE : mt.getPrecision().intValue()).getBytes();
    switch (mt)
    {
    case ENUM: 
    case SET: 
    case CHAR: 
    case VARCHAR: 
    case TINYTEXT: 
    case MEDIUMTEXT: 
    case LONGTEXT: 
    case JSON: 
    case TEXT: 
    case TINYBLOB: 
    case MEDIUMBLOB: 
    case LONGBLOB: 
    case BLOB: 
    case BINARY: 
    case VARBINARY: 
    case DATE: 
    case TIME: 
    case DATETIME: 
    case TIMESTAMP: 
    case GEOMETRY: 
    case UNKNOWN: 
      rowVal[3] = s2b("'");
      rowVal[4] = s2b("'");
      break;
    case BIT: 
    case TINYINT: 
    case TINYINT_UNSIGNED: 
    case BOOLEAN: 
    case NULL: 
    default: 
      rowVal[3] = s2b("");
      rowVal[4] = s2b("");
    }
    rowVal[5] = s2b(mt.getCreateParams());
    rowVal[6] = Integer.toString(1).getBytes();
    rowVal[7] = s2b("true");
    rowVal[8] = Integer.toString(3).getBytes();
    rowVal[9] = s2b(mt.isAllowed(32) ? "true" : "false");
    rowVal[10] = s2b("false");
    rowVal[11] = s2b("false");
    rowVal[12] = s2b(mt.getName());
    switch (mt)
    {
    case DECIMAL: 
    case DECIMAL_UNSIGNED: 
    case DOUBLE: 
    case DOUBLE_UNSIGNED: 
      rowVal[13] = s2b("-308");
      rowVal[14] = s2b("308");
      break;
    case FLOAT: 
    case FLOAT_UNSIGNED: 
      rowVal[13] = s2b("-38");
      rowVal[14] = s2b("38");
      break;
    default: 
      rowVal[13] = s2b("0");
      rowVal[14] = s2b("0");
    }
    rowVal[15] = s2b("0");
    rowVal[16] = s2b("0");
    rowVal[17] = s2b("10");
    
    return rowVal;
  }
  
  public ResultSet getTypeInfo()
    throws SQLException
  {
    try
    {
      Field[] fields = new Field[18];
      fields[0] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[1] = new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 5);
      fields[2] = new Field("", "PRECISION", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
      fields[3] = new Field("", "LITERAL_PREFIX", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 4);
      fields[4] = new Field("", "LITERAL_SUFFIX", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 4);
      fields[5] = new Field("", "CREATE_PARAMS", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[6] = new Field("", "NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
      fields[7] = new Field("", "CASE_SENSITIVE", metadataCollationIndex, metadataEncoding, MysqlType.BOOLEAN, 3);
      fields[8] = new Field("", "SEARCHABLE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 3);
      fields[9] = new Field("", "UNSIGNED_ATTRIBUTE", metadataCollationIndex, metadataEncoding, MysqlType.BOOLEAN, 3);
      fields[10] = new Field("", "FIXED_PREC_SCALE", metadataCollationIndex, metadataEncoding, MysqlType.BOOLEAN, 3);
      fields[11] = new Field("", "AUTO_INCREMENT", metadataCollationIndex, metadataEncoding, MysqlType.BOOLEAN, 3);
      fields[12] = new Field("", "LOCAL_TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
      fields[13] = new Field("", "MINIMUM_SCALE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
      fields[14] = new Field("", "MAXIMUM_SCALE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
      fields[15] = new Field("", "SQL_DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
      fields[16] = new Field("", "SQL_DATETIME_SUB", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
      fields[17] = new Field("", "NUM_PREC_RADIX", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
      
      ArrayList<Row> tuples = new ArrayList();
      
      tuples.add(new ByteArrayRow(getTypeInfo("BIT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("BOOL"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("TINYINT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("TINYINT UNSIGNED"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("BIGINT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("BIGINT UNSIGNED"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("LONG VARBINARY"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("MEDIUMBLOB"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("LONGBLOB"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("BLOB"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("VARBINARY"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("TINYBLOB"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("BINARY"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("LONG VARCHAR"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("MEDIUMTEXT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("LONGTEXT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("TEXT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("CHAR"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("ENUM"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("SET"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("DECIMAL"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("NUMERIC"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("INTEGER"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("INTEGER UNSIGNED"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("INT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("INT UNSIGNED"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("MEDIUMINT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("MEDIUMINT UNSIGNED"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("SMALLINT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("SMALLINT UNSIGNED"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("FLOAT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("DOUBLE"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("DOUBLE PRECISION"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("REAL"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("VARCHAR"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("TINYTEXT"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("DATE"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("YEAR"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("TIME"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("DATETIME"), getExceptionInterceptor()));
      tuples.add(new ByteArrayRow(getTypeInfo("TIMESTAMP"), getExceptionInterceptor()));
      
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(tuples, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getUDTs(String catalog, String schemaPattern, String typeNamePattern, int[] types)
    throws SQLException
  {
    try
    {
      Field[] fields = new Field[7];
      fields[0] = new Field("", "TYPE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 32);
      fields[1] = new Field("", "TYPE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 32);
      fields[2] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 32);
      fields[3] = new Field("", "CLASS_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 32);
      fields[4] = new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
      fields[5] = new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 32);
      fields[6] = new Field("", "BASE_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 10);
      
      ArrayList<Row> tuples = new ArrayList();
      
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(tuples, new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getURL()
    throws SQLException
  {
    try
    {
      return conn.getURL();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getUserName()
    throws SQLException
  {
    try
    {
      if (useHostsInPrivileges)
      {
        Statement stmt = null;
        ResultSet rs = null;
        try
        {
          stmt = conn.getMetadataSafeStatement();
          
          rs = stmt.executeQuery("SELECT USER()");
          rs.next();
          
          return rs.getString(1);
        }
        finally
        {
          if (rs != null)
          {
            try
            {
              rs.close();
            }
            catch (Exception ex)
            {
              AssertionFailedException.shouldNotHappen(ex);
            }
            rs = null;
          }
          if (stmt != null)
          {
            try
            {
              stmt.close();
            }
            catch (Exception ex)
            {
              AssertionFailedException.shouldNotHappen(ex);
            }
            stmt = null;
          }
        }
      }
      return conn.getUser();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected Field[] getVersionColumnsFields()
  {
    Field[] fields = new Field[8];
    fields[0] = new Field("", "SCOPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
    fields[1] = new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 32);
    fields[2] = new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 5);
    fields[3] = new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 16);
    fields[4] = new Field("", "COLUMN_SIZE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 16);
    fields[5] = new Field("", "BUFFER_LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 16);
    fields[6] = new Field("", "DECIMAL_DIGITS", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 16);
    fields[7] = new Field("", "PSEUDO_COLUMN", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 5);
    return fields;
  }
  
  public ResultSet getVersionColumns(String catalog, String schema, final String table)
    throws SQLException
  {
    try
    {
      if (table == null) {
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.2"), "S1009", 
          getExceptionInterceptor());
      }
      final ArrayList<Row> rows = new ArrayList();
      
      final Statement stmt = conn.getMetadataSafeStatement();
      
      String db = getDatabase(catalog, schema);
      try
      {
        new IterateBlock(getDatabaseIterator(db))
        {
          void forEach(String dbStr)
            throws SQLException
          {
            ResultSet results = null;
            try
            {
              StringBuilder whereBuf = new StringBuilder(" Extra LIKE '%on update CURRENT_TIMESTAMP%'");
              List<String> rsFields = new ArrayList();
              if ((whereBuf.length() > 0) || (rsFields.size() > 0))
              {
                StringBuilder queryBuf = new StringBuilder("SHOW COLUMNS FROM ");
                queryBuf.append(StringUtils.quoteIdentifier(table, quotedId, pedantic));
                queryBuf.append(" FROM ");
                queryBuf.append(StringUtils.quoteIdentifier(dbStr, quotedId, pedantic));
                queryBuf.append(" WHERE");
                queryBuf.append(whereBuf.toString());
                try
                {
                  results = stmt.executeQuery(queryBuf.toString());
                }
                catch (SQLException sqlEx)
                {
                  String sqlState = sqlEx.getSQLState();
                  int errorCode = sqlEx.getErrorCode();
                  if ((!"42S02".equals(sqlState)) && (errorCode != 1146) && (errorCode != 1049)) {
                    throw sqlEx;
                  }
                }
                while ((results != null) && (results.next()))
                {
                  DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(DatabaseMetaData.this, results.getString("Type"), results.getString("Null"));
                  byte[][] rowVal = new byte[8][];
                  rowVal[0] = null;
                  rowVal[1] = results.getBytes("Field");
                  rowVal[2] = Short.toString((short)mysqlType.getJdbcType()).getBytes();
                  rowVal[3] = s2b(mysqlType.getName());
                  rowVal[4] = (columnSize == null ? null : s2b(columnSize.toString()));
                  rowVal[5] = s2b(Integer.toString(bufferLength));
                  rowVal[6] = (decimalDigits == null ? null : s2b(decimalDigits.toString()));
                  rowVal[7] = Integer.toString(1).getBytes();
                  rows.add(new ByteArrayRow(rowVal, getExceptionInterceptor()));
                }
              }
            }
            catch (SQLException sqlEx)
            {
              if (!"42S02".equals(sqlEx.getSQLState())) {
                throw sqlEx;
              }
            }
            finally
            {
              if (results != null)
              {
                try
                {
                  results.close();
                }
                catch (Exception localException2) {}
                results = null;
              }
            }
          }
        }.doForAll();
      }
      finally
      {
        if (stmt != null) {
          stmt.close();
        }
      }
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rows, new DefaultColumnDefinition(
        getVersionColumnsFields())));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean insertsAreDetected(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isCatalogAtStart()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isReadOnly()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean locatorsUpdateCopy()
    throws SQLException
  {
    try
    {
      return !((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.emulateLocators).getValue()).booleanValue();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean nullPlusNonNullIsNull()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean nullsAreSortedAtEnd()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean nullsAreSortedAtStart()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean nullsAreSortedHigh()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean nullsAreSortedLow()
    throws SQLException
  {
    try
    {
      return !nullsAreSortedHigh();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean othersDeletesAreVisible(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean othersInsertsAreVisible(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean othersUpdatesAreVisible(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean ownDeletesAreVisible(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean ownInsertsAreVisible(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean ownUpdatesAreVisible(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected LocalAndReferencedColumns parseTableStatusIntoLocalAndReferencedColumns(String keysComment)
    throws SQLException
  {
    String columnsDelimitter = ",";
    
    int indexOfOpenParenLocalColumns = StringUtils.indexOfIgnoreCase(0, keysComment, "(", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
    if (indexOfOpenParenLocalColumns == -1) {
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.14"), "S1000", getExceptionInterceptor());
    }
    String constraintName = StringUtils.unQuoteIdentifier(keysComment.substring(0, indexOfOpenParenLocalColumns).trim(), quotedId);
    keysComment = keysComment.substring(indexOfOpenParenLocalColumns, keysComment.length());
    
    String keysCommentTrimmed = keysComment.trim();
    
    int indexOfCloseParenLocalColumns = StringUtils.indexOfIgnoreCase(0, keysCommentTrimmed, ")", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
    if (indexOfCloseParenLocalColumns == -1) {
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.15"), "S1000", getExceptionInterceptor());
    }
    String localColumnNamesString = keysCommentTrimmed.substring(1, indexOfCloseParenLocalColumns);
    
    int indexOfRefer = StringUtils.indexOfIgnoreCase(0, keysCommentTrimmed, "REFER ", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
    if (indexOfRefer == -1) {
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.16"), "S1000", getExceptionInterceptor());
    }
    int indexOfOpenParenReferCol = StringUtils.indexOfIgnoreCase(indexOfRefer, keysCommentTrimmed, "(", quotedId, quotedId, StringUtils.SEARCH_MODE__MRK_COM_WS);
    if (indexOfOpenParenReferCol == -1) {
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.17"), "S1000", getExceptionInterceptor());
    }
    String referDbTableString = keysCommentTrimmed.substring(indexOfRefer + "REFER ".length(), indexOfOpenParenReferCol);
    
    int indexOfSlash = StringUtils.indexOfIgnoreCase(0, referDbTableString, "/", quotedId, quotedId, StringUtils.SEARCH_MODE__MRK_COM_WS);
    if (indexOfSlash == -1) {
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.18"), "S1000", getExceptionInterceptor());
    }
    String referDb = StringUtils.unQuoteIdentifier(referDbTableString.substring(0, indexOfSlash), quotedId);
    String referTable = StringUtils.unQuoteIdentifier(referDbTableString.substring(indexOfSlash + 1).trim(), quotedId);
    
    int indexOfCloseParenRefer = StringUtils.indexOfIgnoreCase(indexOfOpenParenReferCol, keysCommentTrimmed, ")", quotedId, quotedId, StringUtils.SEARCH_MODE__ALL);
    if (indexOfCloseParenRefer == -1) {
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.19"), "S1000", getExceptionInterceptor());
    }
    String referColumnNamesString = keysCommentTrimmed.substring(indexOfOpenParenReferCol + 1, indexOfCloseParenRefer);
    
    List<String> referColumnsList = StringUtils.split(referColumnNamesString, columnsDelimitter, quotedId, quotedId, false);
    List<String> localColumnsList = StringUtils.split(localColumnNamesString, columnsDelimitter, quotedId, quotedId, false);
    
    return new LocalAndReferencedColumns(localColumnsList, referColumnsList, constraintName, referDb, referTable);
  }
  
  protected byte[] s2b(String s)
    throws SQLException
  {
    if (s == null) {
      return null;
    }
    try
    {
      return StringUtils.getBytes(s, conn.getCharacterSetMetadata());
    }
    catch (CJException e)
    {
      throw SQLExceptionsMapping.translateException(e, getExceptionInterceptor());
    }
  }
  
  public boolean storesLowerCaseIdentifiers()
    throws SQLException
  {
    try
    {
      return conn.storesLowerCaseTableName();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean storesLowerCaseQuotedIdentifiers()
    throws SQLException
  {
    try
    {
      return conn.storesLowerCaseTableName();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean storesMixedCaseIdentifiers()
    throws SQLException
  {
    try
    {
      return !conn.storesLowerCaseTableName();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean storesMixedCaseQuotedIdentifiers()
    throws SQLException
  {
    try
    {
      return !conn.storesLowerCaseTableName();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean storesUpperCaseIdentifiers()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean storesUpperCaseQuotedIdentifiers()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsAlterTableWithAddColumn()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsAlterTableWithDropColumn()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsANSI92EntryLevelSQL()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsANSI92FullSQL()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsANSI92IntermediateSQL()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsBatchUpdates()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsCatalogsInDataManipulation()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.CATALOG;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsCatalogsInIndexDefinitions()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.CATALOG;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsCatalogsInPrivilegeDefinitions()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.CATALOG;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsCatalogsInProcedureCalls()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.CATALOG;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsCatalogsInTableDefinitions()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.CATALOG;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsColumnAliasing()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsConvert()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsConvert(int fromType, int toType)
    throws SQLException
  {
    try
    {
      return MysqlType.supportsConvert(fromType, toType);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsCoreSQLGrammar()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsCorrelatedSubqueries()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsDataDefinitionAndDataManipulationTransactions()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsDataManipulationTransactionsOnly()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsDifferentTableCorrelationNames()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsExpressionsInOrderBy()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsExtendedSQLGrammar()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsFullOuterJoins()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsGetGeneratedKeys()
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsGroupBy()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsGroupByBeyondSelect()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsGroupByUnrelated()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsIntegrityEnhancementFacility()
    throws SQLException
  {
    try
    {
      if (!((Boolean)conn.getPropertySet().getBooleanProperty(PropertyKey.overrideSupportsIntegrityEnhancementFacility).getValue()).booleanValue()) {
        return false;
      }
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsLikeEscapeClause()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsLimitedOuterJoins()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsMinimumSQLGrammar()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsMixedCaseIdentifiers()
    throws SQLException
  {
    try
    {
      return !conn.lowerCaseTableNames();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsMixedCaseQuotedIdentifiers()
    throws SQLException
  {
    try
    {
      return !conn.lowerCaseTableNames();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsMultipleOpenResults()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsMultipleResultSets()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsMultipleTransactions()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsNamedParameters()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsNonNullableColumns()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsOpenCursorsAcrossCommit()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsOpenCursorsAcrossRollback()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsOpenStatementsAcrossCommit()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsOpenStatementsAcrossRollback()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsOrderByUnrelated()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsOuterJoins()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsPositionedDelete()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsPositionedUpdate()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsResultSetConcurrency(int type, int concurrency)
    throws SQLException
  {
    try
    {
      switch (type)
      {
      case 1004: 
        if ((concurrency == 1007) || (concurrency == 1008)) {
          return true;
        }
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.20"), "S1009", 
          getExceptionInterceptor());
      case 1003: 
        if ((concurrency == 1007) || (concurrency == 1008)) {
          return true;
        }
        throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.20"), "S1009", 
          getExceptionInterceptor());
      case 1005: 
        return false;
      }
      throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.20"), "S1009", 
        getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsResultSetHoldability(int holdability)
    throws SQLException
  {
    try
    {
      return holdability == 1;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsResultSetType(int type)
    throws SQLException
  {
    try
    {
      return type == 1004;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSavepoints()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSchemasInDataManipulation()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSchemasInIndexDefinitions()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSchemasInPrivilegeDefinitions()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSchemasInProcedureCalls()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSchemasInTableDefinitions()
    throws SQLException
  {
    try
    {
      return databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSelectForUpdate()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsStatementPooling()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsStoredProcedures()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSubqueriesInComparisons()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSubqueriesInExists()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSubqueriesInIns()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsSubqueriesInQuantifieds()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsTableCorrelationNames()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsTransactionIsolationLevel(int level)
    throws SQLException
  {
    try
    {
      switch (level)
      {
      case 1: 
      case 2: 
      case 4: 
      case 8: 
        return true;
      }
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsTransactions()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsUnion()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean supportsUnionAll()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean updatesAreDetected(int type)
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean usesLocalFilePerTable()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean usesLocalFiles()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getClientInfoProperties()
    throws SQLException
  {
    try
    {
      Field[] fields = new Field[4];
      fields[0] = new Field("", "NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 255);
      fields[1] = new Field("", "MAX_LEN", metadataCollationIndex, metadataEncoding, MysqlType.INT, 10);
      fields[2] = new Field("", "DEFAULT_VALUE", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 255);
      fields[3] = new Field("", "DESCRIPTION", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 255);
      
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(new ArrayList(), new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public ResultSet getFunctionColumns(String catalog, String schemaPattern, String functionNamePattern, String columnNamePattern)
    throws SQLException
  {
    try
    {
      return getProcedureOrFunctionColumns(createFunctionColumnsFields(), catalog, schemaPattern, functionNamePattern, columnNamePattern, false, true);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected Field[] createFunctionColumnsFields()
  {
    Field[] fields = { new Field("", "FUNCTION_CAT", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "FUNCTION_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "FUNCTION_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "COLUMN_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 64), new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 6), new Field("", "TYPE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 64), new Field("", "PRECISION", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12), new Field("", "LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12), new Field("", "SCALE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 12), new Field("", "RADIX", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 6), new Field("", "NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 6), new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "CHAR_OCTET_LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32), new Field("", "ORDINAL_POSITION", metadataCollationIndex, metadataEncoding, MysqlType.INT, 32), new Field("", "IS_NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 12), new Field("", "SPECIFIC_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 64) };
    
    return fields;
  }
  
  protected Field[] getFunctionsFields()
  {
    Field[] fields = new Field[6];
    fields[0] = new Field("", "FUNCTION_CAT", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[1] = new Field("", "FUNCTION_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[2] = new Field("", "FUNCTION_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[3] = new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    fields[4] = new Field("", "FUNCTION_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.SMALLINT, 6);
    fields[5] = new Field("", "SPECIFIC_NAME", metadataCollationIndex, metadataEncoding, MysqlType.CHAR, 255);
    return fields;
  }
  
  public ResultSet getFunctions(String catalog, String schemaPattern, String functionNamePattern)
    throws SQLException
  {
    try
    {
      return getProceduresAndOrFunctions(getFunctionsFields(), catalog, schemaPattern, functionNamePattern, false, true);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean providesQueryObjectGenerator()
    throws SQLException
  {
    return false;
  }
  
  public boolean supportsStoredFunctionsUsingCallSyntax()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected PreparedStatement prepareMetaDataSafeStatement(String sql)
    throws SQLException
  {
    PreparedStatement pStmt = conn.clientPrepareStatement(sql);
    if (pStmt.getMaxRows() != 0) {
      pStmt.setMaxRows(0);
    }
    ((JdbcStatement)pStmt).setHoldResultsOpenOverClose(true);
    
    return pStmt;
  }
  
  public ResultSet getPseudoColumns(String catalog, String schemaPattern, String tableNamePattern, String columnNamePattern)
    throws SQLException
  {
    try
    {
      Field[] fields = { new Field("", "TABLE_CAT", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "TABLE_SCHEM", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "TABLE_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "COLUMN_NAME", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "DATA_TYPE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12), new Field("", "COLUMN_SIZE", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12), new Field("", "DECIMAL_DIGITS", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12), new Field("", "NUM_PREC_RADIX", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12), new Field("", "COLUMN_USAGE", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "REMARKS", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512), new Field("", "CHAR_OCTET_LENGTH", metadataCollationIndex, metadataEncoding, MysqlType.INT, 12), new Field("", "IS_NULLABLE", metadataCollationIndex, metadataEncoding, MysqlType.VARCHAR, 512) };
      
      return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(new ArrayList(), new DefaultColumnDefinition(fields)));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean generatedKeyAlwaysReturned()
    throws SQLException
  {
    try
    {
      return true;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      try
      {
        return (T)iface.cast(this);
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", conn
          .getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    try
    {
      return iface.isInstance(this);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public RowIdLifetime getRowIdLifetime()
    throws SQLException
  {
    try
    {
      return RowIdLifetime.ROWID_UNSUPPORTED;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean autoCommitFailureClosesAllResultSets()
    throws SQLException
  {
    try
    {
      return false;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getMetadataEncoding()
  {
    return metadataEncoding;
  }
  
  public void setMetadataEncoding(String metadataEncoding)
  {
    this.metadataEncoding = metadataEncoding;
  }
  
  public int getMetadataCollationIndex()
  {
    return metadataCollationIndex;
  }
  
  public void setMetadataCollationIndex(int metadataCollationIndex)
  {
    this.metadataCollationIndex = metadataCollationIndex;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */