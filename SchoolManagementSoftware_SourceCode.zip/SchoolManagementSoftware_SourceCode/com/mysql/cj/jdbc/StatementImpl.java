package com.mysql.cj.jdbc;

import com.mysql.cj.CancelQueryTask;
import com.mysql.cj.CharsetMapping;
import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.NativeSession;
import com.mysql.cj.ParseInfo;
import com.mysql.cj.PingTarget;
import com.mysql.cj.Query;
import com.mysql.cj.Query.CancelStatus;
import com.mysql.cj.Session;
import com.mysql.cj.SimpleQuery;
import com.mysql.cj.TransactionEventHandler;
import com.mysql.cj.conf.HostInfo;
import com.mysql.cj.conf.PropertyDefinition;
import com.mysql.cj.conf.PropertyDefinitions;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.AssertionFailedException;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.CJTimeoutException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.OperationCancelledException;
import com.mysql.cj.exceptions.StatementIsClosedException;
import com.mysql.cj.jdbc.exceptions.MySQLStatementCancelledException;
import com.mysql.cj.jdbc.exceptions.MySQLTimeoutException;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.jdbc.result.CachedResultSetMetaData;
import com.mysql.cj.jdbc.result.ResultSetFactory;
import com.mysql.cj.jdbc.result.ResultSetImpl;
import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
import com.mysql.cj.log.ProfilerEventHandler;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.Resultset.Type;
import com.mysql.cj.protocol.ServerCapabilities;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.a.NativeMessageBuilder;
import com.mysql.cj.protocol.a.NativeProtocol;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
import com.mysql.cj.result.DefaultColumnDefinition;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.Row;
import com.mysql.cj.util.StringUtils;
import com.mysql.cj.util.Util;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigInteger;
import java.sql.BatchUpdateException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

public class StatementImpl
  implements JdbcStatement
{
  protected static final String PING_MARKER = "/* ping */";
  protected NativeMessageBuilder commandBuilder = new NativeMessageBuilder();
  public static final byte USES_VARIABLES_FALSE = 0;
  public static final byte USES_VARIABLES_TRUE = 1;
  public static final byte USES_VARIABLES_UNKNOWN = -1;
  protected String charEncoding = null;
  protected volatile JdbcConnection connection = null;
  protected boolean doEscapeProcessing = true;
  protected boolean isClosed = false;
  protected long lastInsertId = -1L;
  protected int maxFieldSize = ((Integer)PropertyDefinitions.getPropertyDefinition(PropertyKey.maxAllowedPacket).getDefaultValue()).intValue();
  public int maxRows = -1;
  protected Set<ResultSetInternalMethods> openResults = new HashSet();
  protected boolean pedantic = false;
  protected boolean profileSQL = false;
  protected ResultSetInternalMethods results = null;
  protected ResultSetInternalMethods generatedKeysResults = null;
  protected int resultSetConcurrency = 0;
  protected long updateCount = -1L;
  protected boolean useUsageAdvisor = false;
  protected SQLWarning warningChain = null;
  protected boolean holdResultsOpenOverClose = false;
  protected ArrayList<Row> batchedGeneratedKeys = null;
  protected boolean retrieveGeneratedKeys = false;
  protected boolean continueBatchOnError = false;
  protected PingTarget pingTarget = null;
  protected ExceptionInterceptor exceptionInterceptor;
  protected boolean lastQueryIsOnDupKeyUpdate = false;
  private boolean isImplicitlyClosingResults = false;
  protected RuntimeProperty<Boolean> dontTrackOpenResources;
  protected RuntimeProperty<Boolean> dumpQueriesOnException;
  protected boolean logSlowQueries = false;
  protected RuntimeProperty<Boolean> rewriteBatchedStatements;
  protected RuntimeProperty<Integer> maxAllowedPacket;
  protected boolean dontCheckOnDuplicateKeyUpdateInSQL;
  protected RuntimeProperty<Boolean> sendFractionalSeconds;
  protected ResultSetFactory resultSetFactory;
  protected Query query;
  protected NativeSession session = null;
  
  public StatementImpl(JdbcConnection c, String db)
    throws SQLException
  {
    if ((c == null) || (c.isClosed())) {
      throw SQLError.createSQLException(Messages.getString("Statement.0"), "08003", null);
    }
    connection = c;
    session = ((NativeSession)c.getSession());
    exceptionInterceptor = c.getExceptionInterceptor();
    try
    {
      initQuery();
    }
    catch (CJException e)
    {
      throw SQLExceptionsMapping.translateException(e, getExceptionInterceptor());
    }
    query.setCurrentDatabase(db);
    
    JdbcPropertySet pset = c.getPropertySet();
    
    dontTrackOpenResources = pset.getBooleanProperty(PropertyKey.dontTrackOpenResources);
    dumpQueriesOnException = pset.getBooleanProperty(PropertyKey.dumpQueriesOnException);
    continueBatchOnError = ((Boolean)pset.getBooleanProperty(PropertyKey.continueBatchOnError).getValue()).booleanValue();
    pedantic = ((Boolean)pset.getBooleanProperty(PropertyKey.pedantic).getValue()).booleanValue();
    rewriteBatchedStatements = pset.getBooleanProperty(PropertyKey.rewriteBatchedStatements);
    charEncoding = ((String)pset.getStringProperty(PropertyKey.characterEncoding).getValue());
    profileSQL = ((Boolean)pset.getBooleanProperty(PropertyKey.profileSQL).getValue()).booleanValue();
    useUsageAdvisor = ((Boolean)pset.getBooleanProperty(PropertyKey.useUsageAdvisor).getValue()).booleanValue();
    logSlowQueries = ((Boolean)pset.getBooleanProperty(PropertyKey.logSlowQueries).getValue()).booleanValue();
    maxAllowedPacket = pset.getIntegerProperty(PropertyKey.maxAllowedPacket);
    dontCheckOnDuplicateKeyUpdateInSQL = ((Boolean)pset.getBooleanProperty(PropertyKey.dontCheckOnDuplicateKeyUpdateInSQL).getValue()).booleanValue();
    sendFractionalSeconds = pset.getBooleanProperty(PropertyKey.sendFractionalSeconds);
    doEscapeProcessing = ((Boolean)pset.getBooleanProperty(PropertyKey.enableEscapeProcessing).getValue()).booleanValue();
    
    maxFieldSize = ((Integer)maxAllowedPacket.getValue()).intValue();
    if (!((Boolean)dontTrackOpenResources.getValue()).booleanValue()) {
      c.registerStatement(this);
    }
    int defaultFetchSize = ((Integer)pset.getIntegerProperty(PropertyKey.defaultFetchSize).getValue()).intValue();
    if (defaultFetchSize != 0) {
      setFetchSize(defaultFetchSize);
    }
    int maxRowsConn = ((Integer)pset.getIntegerProperty(PropertyKey.maxRows).getValue()).intValue();
    if (maxRowsConn != -1) {
      setMaxRows(maxRowsConn);
    }
    holdResultsOpenOverClose = ((Boolean)pset.getBooleanProperty(PropertyKey.holdResultsOpenOverStatementClose).getValue()).booleanValue();
    
    resultSetFactory = new ResultSetFactory(connection, this);
  }
  
  protected void initQuery()
  {
    query = new SimpleQuery(session);
  }
  
  public void addBatch(String sql)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (sql != null) {
          query.addBatch(sql);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void addBatch(Object batch)
  {
    query.addBatch(batch);
  }
  
  public List<Object> getBatchedArgs()
  {
    return query.getBatchedArgs();
  }
  
  public void cancel()
    throws SQLException
  {
    try
    {
      if (!query.getStatementExecuting().get()) {
        return;
      }
      if ((!isClosed) && (connection != null))
      {
        JdbcConnection cancelConn = null;
        Statement cancelStmt = null;
        try
        {
          HostInfo hostInfo = session.getHostInfo();
          String database = hostInfo.getDatabase();
          String user = StringUtils.isNullOrEmpty(hostInfo.getUser()) ? "" : hostInfo.getUser();
          String password = StringUtils.isNullOrEmpty(hostInfo.getPassword()) ? "" : hostInfo.getPassword();
          NativeSession newSession = new NativeSession(session.getHostInfo(), session.getPropertySet());
          newSession.connect(hostInfo, user, password, database, 30000, new TransactionEventHandler()
          {
            public void transactionCompleted() {}
            
            public void transactionBegun() {}
          });
          newSession.sendCommand(new NativeMessageBuilder().buildComQuery(newSession.getSharedSendPacket(), "KILL QUERY " + session.getThreadId()), false, 0);
          
          setCancelStatus(Query.CancelStatus.CANCELED_BY_USER);
        }
        catch (IOException e)
        {
          throw SQLExceptionsMapping.translateException(e, exceptionInterceptor);
        }
        finally
        {
          if (cancelStmt != null) {
            cancelStmt.close();
          }
          if (cancelConn != null) {
            cancelConn.close();
          }
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected JdbcConnection checkClosed()
  {
    JdbcConnection c = connection;
    if (c == null) {
      throw ((StatementIsClosedException)ExceptionFactory.createException(StatementIsClosedException.class, Messages.getString("Statement.AlreadyClosed"), getExceptionInterceptor()));
    }
    return c;
  }
  
  protected void checkForDml(String sql, char firstStatementChar)
    throws SQLException
  {
    if ((firstStatementChar == 'I') || (firstStatementChar == 'U') || (firstStatementChar == 'D') || (firstStatementChar == 'A') || (firstStatementChar == 'C') || (firstStatementChar == 'T') || (firstStatementChar == 'R'))
    {
      String noCommentSql = StringUtils.stripComments(sql, "'\"", "'\"", true, false, true, true);
      if ((StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "INSERT")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "UPDATE")) || 
        (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DELETE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "DROP")) || 
        (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "CREATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "ALTER")) || 
        (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "TRUNCATE")) || (StringUtils.startsWithIgnoreCaseAndWs(noCommentSql, "RENAME"))) {
        throw SQLError.createSQLException(Messages.getString("Statement.57"), "S1009", getExceptionInterceptor());
      }
    }
  }
  
  protected void checkNullOrEmptyQuery(String sql)
    throws SQLException
  {
    if (sql == null) {
      throw SQLError.createSQLException(Messages.getString("Statement.59"), "S1009", getExceptionInterceptor());
    }
    if (sql.length() == 0) {
      throw SQLError.createSQLException(Messages.getString("Statement.61"), "S1009", getExceptionInterceptor());
    }
  }
  
  public void clearBatch()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        query.clearBatchedArgs();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void clearBatchedArgs()
  {
    query.clearBatchedArgs();
  }
  
  public void clearWarnings()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        setClearWarningsCalled(true);
        warningChain = null;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void close()
    throws SQLException
  {
    try
    {
      realClose(true, true);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void closeAllOpenResults()
    throws SQLException
  {
    JdbcConnection locallyScopedConn = connection;
    if (locallyScopedConn == null) {
      return;
    }
    synchronized (locallyScopedConn.getConnectionMutex())
    {
      if (openResults != null)
      {
        for (ResultSetInternalMethods element : openResults) {
          try
          {
            element.realClose(false);
          }
          catch (SQLException sqlEx)
          {
            AssertionFailedException.shouldNotHappen(sqlEx);
          }
        }
        openResults.clear();
      }
    }
  }
  
  /* Error */
  protected void implicitlyCloseAllOpenResults()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: iconst_1
    //   2: putfield 36	com/mysql/cj/jdbc/StatementImpl:isImplicitlyClosingResults	Z
    //   5: aload_0
    //   6: getfield 30	com/mysql/cj/jdbc/StatementImpl:holdResultsOpenOverClose	Z
    //   9: ifne +59 -> 68
    //   12: aload_0
    //   13: getfield 63	com/mysql/cj/jdbc/StatementImpl:dontTrackOpenResources	Lcom/mysql/cj/conf/RuntimeProperty;
    //   16: invokeinterface 67 1 0
    //   21: checkcast 68	java/lang/Boolean
    //   24: invokevirtual 69	java/lang/Boolean:booleanValue	()Z
    //   27: ifne +41 -> 68
    //   30: aload_0
    //   31: getfield 24	com/mysql/cj/jdbc/StatementImpl:results	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   34: ifnull +13 -> 47
    //   37: aload_0
    //   38: getfield 24	com/mysql/cj/jdbc/StatementImpl:results	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   41: iconst_0
    //   42: invokeinterface 155 2 0
    //   47: aload_0
    //   48: getfield 25	com/mysql/cj/jdbc/StatementImpl:generatedKeysResults	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   51: ifnull +13 -> 64
    //   54: aload_0
    //   55: getfield 25	com/mysql/cj/jdbc/StatementImpl:generatedKeysResults	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   58: iconst_0
    //   59: invokeinterface 155 2 0
    //   64: aload_0
    //   65: invokevirtual 159	com/mysql/cj/jdbc/StatementImpl:closeAllOpenResults	()V
    //   68: aload_0
    //   69: iconst_0
    //   70: putfield 36	com/mysql/cj/jdbc/StatementImpl:isImplicitlyClosingResults	Z
    //   73: goto +11 -> 84
    //   76: astore_1
    //   77: aload_0
    //   78: iconst_0
    //   79: putfield 36	com/mysql/cj/jdbc/StatementImpl:isImplicitlyClosingResults	Z
    //   82: aload_1
    //   83: athrow
    //   84: return
    // Line number table:
    //   Java source line #466	-> byte code offset #0
    //   Java source line #468	-> byte code offset #5
    //   Java source line #469	-> byte code offset #30
    //   Java source line #470	-> byte code offset #37
    //   Java source line #472	-> byte code offset #47
    //   Java source line #473	-> byte code offset #54
    //   Java source line #475	-> byte code offset #64
    //   Java source line #478	-> byte code offset #68
    //   Java source line #479	-> byte code offset #73
    //   Java source line #478	-> byte code offset #76
    //   Java source line #479	-> byte code offset #82
    //   Java source line #480	-> byte code offset #84
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	85	0	this	StatementImpl
    //   76	7	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   5	68	76	finally
  }
  
  public void removeOpenResultSet(ResultSetInternalMethods rs)
  {
    try
    {
      try
      {
        synchronized (checkClosed().getConnectionMutex())
        {
          if (openResults != null) {
            openResults.remove(rs);
          }
          boolean hasMoreResults = rs.getNextResultset() != null;
          if ((results == rs) && (!hasMoreResults)) {
            results = null;
          }
          if (generatedKeysResults == rs) {
            generatedKeysResults = null;
          }
          if ((!isImplicitlyClosingResults) && (!hasMoreResults)) {
            checkAndPerformCloseOnCompletionAction();
          }
        }
      }
      catch (StatementIsClosedException localStatementIsClosedException) {}
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public int getOpenResultSetCount()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 21	com/mysql/cj/jdbc/StatementImpl:openResults	Ljava/util/Set;
    //   16: ifnull +15 -> 31
    //   19: aload_0
    //   20: getfield 21	com/mysql/cj/jdbc/StatementImpl:openResults	Ljava/util/Set;
    //   23: invokeinterface 163 1 0
    //   28: aload_1
    //   29: monitorexit
    //   30: ireturn
    //   31: iconst_0
    //   32: aload_1
    //   33: monitorexit
    //   34: ireturn
    //   35: astore_2
    //   36: aload_1
    //   37: monitorexit
    //   38: aload_2
    //   39: athrow
    //   40: astore_1
    //   41: iconst_0
    //   42: ireturn
    //   43: astore_3
    //   44: aload_3
    //   45: aload_0
    //   46: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   49: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   52: athrow
    // Line number table:
    //   Java source line #515	-> byte code offset #0
    //   Java source line #516	-> byte code offset #12
    //   Java source line #517	-> byte code offset #19
    //   Java source line #520	-> byte code offset #31
    //   Java source line #521	-> byte code offset #35
    //   Java source line #522	-> byte code offset #40
    //   Java source line #525	-> byte code offset #41
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	46	0	this	StatementImpl
    //   40	2	1	e	StatementIsClosedException
    //   35	4	2	localObject1	Object
    //   43	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	30	35	finally
    //   31	34	35	finally
    //   35	38	35	finally
    //   0	30	40	com/mysql/cj/exceptions/StatementIsClosedException
    //   31	34	40	com/mysql/cj/exceptions/StatementIsClosedException
    //   35	40	40	com/mysql/cj/exceptions/StatementIsClosedException
    //   0	43	43	com/mysql/cj/exceptions/CJException
  }
  
  private void checkAndPerformCloseOnCompletionAction()
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if ((isCloseOnCompletion()) && (!((Boolean)dontTrackOpenResources.getValue()).booleanValue()) && (getOpenResultSetCount() == 0) && ((results == null) || 
          (!results.hasRows()) || (results.isClosed())) && ((generatedKeysResults == null) || 
          (!generatedKeysResults.hasRows()) || (generatedKeysResults.isClosed()))) {
          realClose(false, false);
        }
      }
    }
    catch (SQLException localSQLException) {}
  }
  
  private ResultSetInternalMethods createResultSetUsingServerFetch(String sql)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        PreparedStatement pStmt = connection.prepareStatement(sql, query.getResultType().getIntValue(), resultSetConcurrency);
        
        pStmt.setFetchSize(query.getResultFetchSize());
        if (maxRows > -1) {
          pStmt.setMaxRows(maxRows);
        }
        statementBegins();
        
        pStmt.execute();
        
        ResultSetInternalMethods rs = ((StatementImpl)pStmt).getResultSetInternal();
        
        rs.setStatementUsedForFetchingRows((ClientPreparedStatement)pStmt);
        
        results = rs;
        
        return rs;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected boolean createStreamingResultSet()
  {
    return (query.getResultType() == Resultset.Type.FORWARD_ONLY) && (resultSetConcurrency == 1007) && 
      (query.getResultFetchSize() == Integer.MIN_VALUE);
  }
  
  private Resultset.Type originalResultSetType = Resultset.Type.FORWARD_ONLY;
  private int originalFetchSize = 0;
  
  public void enableStreamingResults()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        originalResultSetType = query.getResultType();
        originalFetchSize = query.getResultFetchSize();
        
        setFetchSize(Integer.MIN_VALUE);
        setResultSetType(Resultset.Type.FORWARD_ONLY);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void disableStreamingResults()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if ((query.getResultFetchSize() == Integer.MIN_VALUE) && (query.getResultType() == Resultset.Type.FORWARD_ONLY))
        {
          setFetchSize(originalFetchSize);
          setResultSetType(originalResultSetType);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void setupStreamingTimeout(JdbcConnection con)
    throws SQLException
  {
    int netTimeoutForStreamingResults = ((Integer)session.getPropertySet().getIntegerProperty(PropertyKey.netTimeoutForStreamingResults).getValue()).intValue();
    if ((createStreamingResultSet()) && (netTimeoutForStreamingResults > 0)) {
      executeSimpleNonQuery(con, "SET net_write_timeout=" + netTimeoutForStreamingResults);
    }
  }
  
  public CancelQueryTask startQueryTimer(Query stmtToCancel, int timeout)
  {
    return query.startQueryTimer(stmtToCancel, timeout);
  }
  
  public void stopQueryTimer(CancelQueryTask timeoutTask, boolean rethrowCancelReason, boolean checkCancelTimeout)
  {
    query.stopQueryTimer(timeoutTask, rethrowCancelReason, checkCancelTimeout);
  }
  
  public boolean execute(String sql)
    throws SQLException
  {
    try
    {
      return executeInternal(sql, false);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private boolean executeInternal(String sql, boolean returnGeneratedKeys)
    throws SQLException
  {
    try
    {
      JdbcConnection locallyScopedConn = checkClosed();
      synchronized (locallyScopedConn.getConnectionMutex())
      {
        checkClosed();
        
        checkNullOrEmptyQuery(sql);
        
        resetCancelledState();
        
        implicitlyCloseAllOpenResults();
        if ((sql.charAt(0) == '/') && 
          (sql.startsWith("/* ping */")))
        {
          doPingInstead();
          
          return true;
        }
        char firstNonWsChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
        boolean maybeSelect = firstNonWsChar == 'S';
        
        retrieveGeneratedKeys = returnGeneratedKeys;
        
        lastQueryIsOnDupKeyUpdate = ((returnGeneratedKeys) && (firstNonWsChar == 'I') && (containsOnDuplicateKeyInString(sql)));
        if ((!maybeSelect) && (locallyScopedConn.isReadOnly())) {
          throw SQLError.createSQLException(Messages.getString("Statement.27") + Messages.getString("Statement.28"), "S1009", 
            getExceptionInterceptor());
        }
        try
        {
          setupStreamingTimeout(locallyScopedConn);
          if (doEscapeProcessing)
          {
            Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, session.getServerSession().getDefaultTimeZone(), session
              .getServerSession().getCapabilities().serverSupportsFracSecs(), session
              .getServerSession().isServerTruncatesFracSecs(), getExceptionInterceptor());
            sql = (escapedSqlResult instanceof String) ? (String)escapedSqlResult : escapedSql;
          }
          CachedResultSetMetaData cachedMetaData = null;
          
          ResultSetInternalMethods rs = null;
          
          batchedGeneratedKeys = null;
          if (useServerFetch())
          {
            rs = createResultSetUsingServerFetch(sql);
          }
          else
          {
            timeoutTask = null;
            
            String oldDb = null;
            try
            {
              timeoutTask = startQueryTimer(this, getTimeoutInMillis());
              if (!locallyScopedConn.getDatabase().equals(getCurrentDatabase()))
              {
                oldDb = locallyScopedConn.getDatabase();
                locallyScopedConn.setDatabase(getCurrentDatabase());
              }
              if (((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue()) {
                cachedMetaData = locallyScopedConn.getCachedMetaData(sql);
              }
              locallyScopedConn.setSessionMaxRows(maybeSelect ? maxRows : -1);
              
              statementBegins();
              
              rs = (ResultSetInternalMethods)((NativeSession)locallyScopedConn.getSession()).execSQL(this, sql, maxRows, null, createStreamingResultSet(), 
                getResultSetFactory(), cachedMetaData, false);
              if (timeoutTask != null)
              {
                stopQueryTimer(timeoutTask, true, true);
                timeoutTask = null;
              }
            }
            catch (CJTimeoutException|OperationCancelledException e)
            {
              throw SQLExceptionsMapping.translateException(e, exceptionInterceptor);
            }
            finally
            {
              stopQueryTimer(timeoutTask, false, false);
              if (oldDb != null) {
                locallyScopedConn.setDatabase(oldDb);
              }
            }
          }
          if (rs != null)
          {
            lastInsertId = rs.getUpdateID();
            
            results = rs;
            
            rs.setFirstCharOfQuery(firstNonWsChar);
            if (rs.hasRows()) {
              if (cachedMetaData != null) {
                locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, results);
              } else if (((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue()) {
                locallyScopedConn.initializeResultsMetadataFromCache(sql, null, results);
              }
            }
          }
          CancelQueryTask timeoutTask = (rs != null) && (rs.hasRows()) ? 1 : 0;
          
          query.getStatementExecuting().set(false);return timeoutTask;
        }
        finally
        {
          query.getStatementExecuting().set(false);
        }
      }
    }
    catch (CJException localCJException1)
    {
      throw SQLExceptionsMapping.translateException(localCJException1, getExceptionInterceptor());
    }
  }
  
  public void statementBegins()
  {
    query.statementBegins();
  }
  
  public void resetCancelledState()
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        query.resetCancelledState();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean execute(String sql, int returnGeneratedKeys)
    throws SQLException
  {
    try
    {
      return executeInternal(sql, returnGeneratedKeys == 1);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean execute(String sql, int[] generatedKeyIndices)
    throws SQLException
  {
    try
    {
      return executeInternal(sql, (generatedKeyIndices != null) && (generatedKeyIndices.length > 0));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean execute(String sql, String[] generatedKeyNames)
    throws SQLException
  {
    try
    {
      return executeInternal(sql, (generatedKeyNames != null) && (generatedKeyNames.length > 0));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int[] executeBatch()
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(executeBatchInternal());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected long[] executeBatchInternal()
    throws SQLException
  {
    JdbcConnection locallyScopedConn = checkClosed();
    synchronized (locallyScopedConn.getConnectionMutex())
    {
      if (locallyScopedConn.isReadOnly()) {
        throw SQLError.createSQLException(Messages.getString("Statement.34") + Messages.getString("Statement.35"), "S1009", 
          getExceptionInterceptor());
      }
      implicitlyCloseAllOpenResults();
      
      List<Object> batchedArgs = query.getBatchedArgs();
      if ((batchedArgs == null) || (batchedArgs.size() == 0)) {
        return new long[0];
      }
      int individualStatementTimeout = getTimeoutInMillis();
      setTimeoutInMillis(0);
      
      CancelQueryTask timeoutTask = null;
      try
      {
        resetCancelledState();
        
        statementBegins();
        try
        {
          retrieveGeneratedKeys = true;
          
          long[] updateCounts = null;
          if (batchedArgs != null)
          {
            nbrCommands = batchedArgs.size();
            
            batchedGeneratedKeys = new ArrayList(batchedArgs.size());
            
            boolean multiQueriesEnabled = ((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.allowMultiQueries).getValue()).booleanValue();
            if ((multiQueriesEnabled) || ((((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.rewriteBatchedStatements).getValue()).booleanValue()) && (nbrCommands > 4)))
            {
              long[] arrayOfLong1 = executeBatchUsingMultiQueries(multiQueriesEnabled, nbrCommands, individualStatementTimeout);
              
              query.getStatementExecuting().set(false);
              
              stopQueryTimer(timeoutTask, false, false);
              resetCancelledState();
              
              setTimeoutInMillis(individualStatementTimeout);
              
              clearBatch();return arrayOfLong1;
            }
            timeoutTask = startQueryTimer(this, individualStatementTimeout);
            
            updateCounts = new long[nbrCommands];
            for (int i = 0; i < nbrCommands; i++) {
              updateCounts[i] = -3L;
            }
            SQLException sqlEx = null;
            
            int commandIndex = 0;
            for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++) {
              try
              {
                String sql = (String)batchedArgs.get(commandIndex);
                updateCounts[commandIndex] = executeUpdateInternal(sql, true, true);
                if (timeoutTask != null) {
                  checkCancelTimeout();
                }
                getBatchedGeneratedKeys((results.getFirstCharOfQuery() == 'I') && (containsOnDuplicateKeyInString(sql)) ? 1 : 0);
              }
              catch (SQLException ex)
              {
                updateCounts[commandIndex] = -3L;
                if ((continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && 
                  (!hasDeadlockOrTimeoutRolledBackTx(ex)))
                {
                  sqlEx = ex;
                }
                else
                {
                  long[] newUpdateCounts = new long[commandIndex];
                  if (hasDeadlockOrTimeoutRolledBackTx(ex)) {
                    for (int i = 0; i < newUpdateCounts.length; i++) {
                      newUpdateCounts[i] = -3L;
                    }
                  } else {
                    System.arraycopy(updateCounts, 0, newUpdateCounts, 0, commandIndex);
                  }
                  sqlEx = ex;
                  break;
                }
              }
            }
            if (sqlEx != null) {
              throw SQLError.createBatchUpdateException(sqlEx, updateCounts, getExceptionInterceptor());
            }
          }
          if (timeoutTask != null)
          {
            stopQueryTimer(timeoutTask, true, true);
            timeoutTask = null;
          }
          int nbrCommands = updateCounts != null ? updateCounts : new long[0];
          
          query.getStatementExecuting().set(false);
          
          stopQueryTimer(timeoutTask, false, false);
          resetCancelledState();
          
          setTimeoutInMillis(individualStatementTimeout);
          
          clearBatch();return nbrCommands;
        }
        finally
        {
          query.getStatementExecuting().set(false);
        }
        localObject3 = finally;
      }
      finally
      {
        stopQueryTimer(timeoutTask, false, false);
        resetCancelledState();
        
        setTimeoutInMillis(individualStatementTimeout);
        
        clearBatch();
      }
    }
  }
  
  protected final boolean hasDeadlockOrTimeoutRolledBackTx(SQLException ex)
  {
    int vendorCode = ex.getErrorCode();
    switch (vendorCode)
    {
    case 1206: 
    case 1213: 
      return true;
    case 1205: 
      return false;
    }
    return false;
  }
  
  private long[] executeBatchUsingMultiQueries(boolean multiQueriesEnabled, int nbrCommands, int individualStatementTimeout)
    throws SQLException
  {
    try
    {
      JdbcConnection locallyScopedConn = checkClosed();
      synchronized (locallyScopedConn.getConnectionMutex())
      {
        if (!multiQueriesEnabled) {
          session.enableMultiQueries();
        }
        Statement batchStmt = null;
        
        CancelQueryTask timeoutTask = null;
        try
        {
          long[] updateCounts = new long[nbrCommands];
          for (int i = 0; i < nbrCommands; i++) {
            updateCounts[i] = -3L;
          }
          int commandIndex = 0;
          
          StringBuilder queryBuf = new StringBuilder();
          
          batchStmt = locallyScopedConn.createStatement();
          
          timeoutTask = startQueryTimer((StatementImpl)batchStmt, individualStatementTimeout);
          
          int counter = 0;
          
          String connectionEncoding = (String)locallyScopedConn.getPropertySet().getStringProperty(PropertyKey.characterEncoding).getValue();
          
          int numberOfBytesPerChar = CharsetMapping.isMultibyteCharset(connectionEncoding) ? 2 : StringUtils.startsWithIgnoreCase(connectionEncoding, "utf") ? 3 : 1;
          
          int escapeAdjust = 1;
          
          batchStmt.setEscapeProcessing(doEscapeProcessing);
          if (doEscapeProcessing) {
            escapeAdjust = 2;
          }
          SQLException sqlEx = null;
          
          int argumentSetsInBatchSoFar = 0;
          for (commandIndex = 0; commandIndex < nbrCommands; commandIndex++)
          {
            String nextQuery = (String)query.getBatchedArgs().get(commandIndex);
            if (((queryBuf.length() + nextQuery.length()) * numberOfBytesPerChar + 1 + 4) * escapeAdjust + 32 > ((Integer)maxAllowedPacket.getValue()).intValue())
            {
              try
              {
                batchStmt.execute(queryBuf.toString(), 1);
              }
              catch (SQLException ex)
              {
                sqlEx = handleExceptionForBatch(commandIndex, argumentSetsInBatchSoFar, updateCounts, ex);
              }
              counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
              
              queryBuf = new StringBuilder();
              argumentSetsInBatchSoFar = 0;
            }
            queryBuf.append(nextQuery);
            queryBuf.append(";");
            argumentSetsInBatchSoFar++;
          }
          if (queryBuf.length() > 0)
          {
            try
            {
              batchStmt.execute(queryBuf.toString(), 1);
            }
            catch (SQLException ex)
            {
              sqlEx = handleExceptionForBatch(commandIndex - 1, argumentSetsInBatchSoFar, updateCounts, ex);
            }
            counter = processMultiCountsAndKeys((StatementImpl)batchStmt, counter, updateCounts);
          }
          if (timeoutTask != null)
          {
            stopQueryTimer(timeoutTask, true, true);
            timeoutTask = null;
          }
          if (sqlEx != null) {
            throw SQLError.createBatchUpdateException(sqlEx, updateCounts, getExceptionInterceptor());
          }
          ex = updateCounts != null ? updateCounts : new long[0];
          
          stopQueryTimer(timeoutTask, false, false);
          resetCancelledState();
          try
          {
            if (batchStmt != null) {
              batchStmt.close();
            }
          }
          finally
          {
            if (!multiQueriesEnabled) {
              session.disableMultiQueries();
            }
          }
          return ex;
        }
        finally
        {
          stopQueryTimer(timeoutTask, false, false);
          resetCancelledState();
          try
          {
            if (batchStmt != null) {
              batchStmt.close();
            }
          }
          finally
          {
            if (!multiQueriesEnabled) {
              session.disableMultiQueries();
            }
          }
        }
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected int processMultiCountsAndKeys(StatementImpl batchedStatement, int updateCountCounter, long[] updateCounts)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        updateCounts[(updateCountCounter++)] = batchedStatement.getLargeUpdateCount();
        
        boolean doGenKeys = batchedGeneratedKeys != null;
        
        byte[][] row = (byte[][])null;
        if (doGenKeys)
        {
          long generatedKey = batchedStatement.getLastInsertID();
          
          row = new byte[1][];
          row[0] = StringUtils.getBytes(Long.toString(generatedKey));
          batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
        }
        while ((batchedStatement.getMoreResults()) || (batchedStatement.getLargeUpdateCount() != -1L))
        {
          updateCounts[(updateCountCounter++)] = batchedStatement.getLargeUpdateCount();
          if (doGenKeys)
          {
            long generatedKey = batchedStatement.getLastInsertID();
            
            row = new byte[1][];
            row[0] = StringUtils.getBytes(Long.toString(generatedKey));
            batchedGeneratedKeys.add(new ByteArrayRow(row, getExceptionInterceptor()));
          }
        }
        return updateCountCounter;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected SQLException handleExceptionForBatch(int endOfBatchIndex, int numValuesPerBatch, long[] updateCounts, SQLException ex)
    throws BatchUpdateException, SQLException
  {
    for (int j = endOfBatchIndex; j > endOfBatchIndex - numValuesPerBatch; j--) {
      updateCounts[j] = -3L;
    }
    if ((continueBatchOnError) && (!(ex instanceof MySQLTimeoutException)) && (!(ex instanceof MySQLStatementCancelledException)) && 
      (!hasDeadlockOrTimeoutRolledBackTx(ex))) {
      return ex;
    }
    long[] newUpdateCounts = new long[endOfBatchIndex];
    System.arraycopy(updateCounts, 0, newUpdateCounts, 0, endOfBatchIndex);
    
    throw SQLError.createBatchUpdateException(ex, newUpdateCounts, getExceptionInterceptor());
  }
  
  public ResultSet executeQuery(String sql)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        JdbcConnection locallyScopedConn = connection;
        
        retrieveGeneratedKeys = false;
        
        checkNullOrEmptyQuery(sql);
        
        resetCancelledState();
        
        implicitlyCloseAllOpenResults();
        if ((sql.charAt(0) == '/') && 
          (sql.startsWith("/* ping */")))
        {
          doPingInstead();
          
          return results;
        }
        setupStreamingTimeout(locallyScopedConn);
        if (doEscapeProcessing)
        {
          Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, session.getServerSession().getDefaultTimeZone(), session
            .getServerSession().getCapabilities().serverSupportsFracSecs(), session.getServerSession().isServerTruncatesFracSecs(), 
            getExceptionInterceptor());
          sql = (escapedSqlResult instanceof String) ? (String)escapedSqlResult : escapedSql;
        }
        char firstStatementChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
        
        checkForDml(sql, firstStatementChar);
        
        CachedResultSetMetaData cachedMetaData = null;
        if (useServerFetch())
        {
          results = createResultSetUsingServerFetch(sql);
          
          return results;
        }
        CancelQueryTask timeoutTask = null;
        
        String oldDb = null;
        try
        {
          timeoutTask = startQueryTimer(this, getTimeoutInMillis());
          if (!locallyScopedConn.getDatabase().equals(getCurrentDatabase()))
          {
            oldDb = locallyScopedConn.getDatabase();
            locallyScopedConn.setDatabase(getCurrentDatabase());
          }
          if (((Boolean)locallyScopedConn.getPropertySet().getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue()) {
            cachedMetaData = locallyScopedConn.getCachedMetaData(sql);
          }
          locallyScopedConn.setSessionMaxRows(maxRows);
          
          statementBegins();
          
          results = ((ResultSetInternalMethods)((NativeSession)locallyScopedConn.getSession()).execSQL(this, sql, maxRows, null, createStreamingResultSet(), 
            getResultSetFactory(), cachedMetaData, false));
          if (timeoutTask != null)
          {
            stopQueryTimer(timeoutTask, true, true);
            timeoutTask = null;
          }
        }
        catch (CJTimeoutException|OperationCancelledException e)
        {
          throw SQLExceptionsMapping.translateException(e, exceptionInterceptor);
        }
        finally
        {
          query.getStatementExecuting().set(false);
          
          stopQueryTimer(timeoutTask, false, false);
          if (oldDb != null) {
            locallyScopedConn.setDatabase(oldDb);
          }
        }
        lastInsertId = results.getUpdateID();
        if (cachedMetaData != null) {
          locallyScopedConn.initializeResultsMetadataFromCache(sql, cachedMetaData, results);
        } else if (((Boolean)connection.getPropertySet().getBooleanProperty(PropertyKey.cacheResultSetMetadata).getValue()).booleanValue()) {
          locallyScopedConn.initializeResultsMetadataFromCache(sql, null, results);
        }
        return results;
      }
    }
    catch (CJException localCJException1)
    {
      throw SQLExceptionsMapping.translateException(localCJException1, getExceptionInterceptor());
    }
  }
  
  protected void doPingInstead()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (pingTarget != null) {
          try
          {
            pingTarget.doPing();
          }
          catch (SQLException e)
          {
            throw e;
          }
          catch (Exception e)
          {
            throw SQLError.createSQLException(e.getMessage(), "08S01", e, getExceptionInterceptor());
          }
        } else {
          connection.ping();
        }
        ResultSetInternalMethods fakeSelectOneResultSet = generatePingResultSet();
        results = fakeSelectOneResultSet;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected ResultSetInternalMethods generatePingResultSet()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        String encoding = session.getServerSession().getCharacterSetMetadata();
        int collationIndex = session.getServerSession().getMetadataCollationIndex();
        Field[] fields = { new Field(null, "1", collationIndex, encoding, MysqlType.BIGINT, 1) };
        ArrayList<Row> rows = new ArrayList();
        byte[] colVal = { 49 };
        
        rows.add(new ByteArrayRow(new byte[][] { colVal }, getExceptionInterceptor()));
        
        return resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rows, new DefaultColumnDefinition(fields)));
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void executeSimpleNonQuery(JdbcConnection c, String nonQuery)
    throws SQLException
  {
    try
    {
      synchronized (c.getConnectionMutex())
      {
        ((ResultSetImpl)((NativeSession)c.getSession()).execSQL(this, nonQuery, -1, null, false, getResultSetFactory(), null, false)).close();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int executeUpdate(String sql)
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(executeLargeUpdate(sql));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected long executeUpdateInternal(String sql, boolean isBatch, boolean returnGeneratedKeys)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        JdbcConnection locallyScopedConn = connection;
        
        checkNullOrEmptyQuery(sql);
        
        resetCancelledState();
        
        char firstStatementChar = StringUtils.firstAlphaCharUc(sql, findStartOfStatement(sql));
        
        retrieveGeneratedKeys = returnGeneratedKeys;
        
        lastQueryIsOnDupKeyUpdate = ((returnGeneratedKeys) && (firstStatementChar == 'I') && (containsOnDuplicateKeyInString(sql)));
        
        ResultSetInternalMethods rs = null;
        if (doEscapeProcessing)
        {
          Object escapedSqlResult = EscapeProcessor.escapeSQL(sql, session.getServerSession().getDefaultTimeZone(), session
            .getServerSession().getCapabilities().serverSupportsFracSecs(), session.getServerSession().isServerTruncatesFracSecs(), 
            getExceptionInterceptor());
          sql = (escapedSqlResult instanceof String) ? (String)escapedSqlResult : escapedSql;
        }
        if (locallyScopedConn.isReadOnly(false)) {
          throw SQLError.createSQLException(Messages.getString("Statement.42") + Messages.getString("Statement.43"), "S1009", 
            getExceptionInterceptor());
        }
        if (StringUtils.startsWithIgnoreCaseAndWs(sql, "select")) {
          throw SQLError.createSQLException(Messages.getString("Statement.46"), "01S03", getExceptionInterceptor());
        }
        implicitlyCloseAllOpenResults();
        
        CancelQueryTask timeoutTask = null;
        
        String oldDb = null;
        try
        {
          timeoutTask = startQueryTimer(this, getTimeoutInMillis());
          if (!locallyScopedConn.getDatabase().equals(getCurrentDatabase()))
          {
            oldDb = locallyScopedConn.getDatabase();
            locallyScopedConn.setDatabase(getCurrentDatabase());
          }
          locallyScopedConn.setSessionMaxRows(-1);
          
          statementBegins();
          
          rs = (ResultSetInternalMethods)((NativeSession)locallyScopedConn.getSession()).execSQL(this, sql, -1, null, false, getResultSetFactory(), null, isBatch);
          if (timeoutTask != null)
          {
            stopQueryTimer(timeoutTask, true, true);
            timeoutTask = null;
          }
        }
        catch (CJTimeoutException|OperationCancelledException e)
        {
          throw SQLExceptionsMapping.translateException(e, exceptionInterceptor);
        }
        finally
        {
          stopQueryTimer(timeoutTask, false, false);
          if (oldDb != null) {
            locallyScopedConn.setDatabase(oldDb);
          }
          if (!isBatch) {
            query.getStatementExecuting().set(false);
          }
        }
        results = rs;
        
        rs.setFirstCharOfQuery(firstStatementChar);
        
        updateCount = rs.getUpdateCount();
        
        lastInsertId = rs.getUpdateID();
        
        return updateCount;
      }
    }
    catch (CJException localCJException1)
    {
      throw SQLExceptionsMapping.translateException(localCJException1, getExceptionInterceptor());
    }
  }
  
  public int executeUpdate(String sql, int autoGeneratedKeys)
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(executeLargeUpdate(sql, autoGeneratedKeys));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int executeUpdate(String sql, int[] columnIndexes)
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(executeLargeUpdate(sql, columnIndexes));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int executeUpdate(String sql, String[] columnNames)
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(executeLargeUpdate(sql, columnNames));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public java.sql.Connection getConnection()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 6	com/mysql/cj/jdbc/StatementImpl:connection	Lcom/mysql/cj/jdbc/JdbcConnection;
    //   16: aload_1
    //   17: monitorexit
    //   18: areturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #1355	-> byte code offset #0
    //   Java source line #1356	-> byte code offset #12
    //   Java source line #1357	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	StatementImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  public int getFetchDirection()
    throws SQLException
  {
    try
    {
      return 1000;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public int getFetchSize()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 58	com/mysql/cj/jdbc/StatementImpl:query	Lcom/mysql/cj/Query;
    //   16: invokeinterface 171 1 0
    //   21: aload_1
    //   22: monitorexit
    //   23: ireturn
    //   24: astore_2
    //   25: aload_1
    //   26: monitorexit
    //   27: aload_2
    //   28: athrow
    //   29: astore_3
    //   30: aload_3
    //   31: aload_0
    //   32: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   35: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   38: athrow
    // Line number table:
    //   Java source line #1367	-> byte code offset #0
    //   Java source line #1368	-> byte code offset #12
    //   Java source line #1369	-> byte code offset #24
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	32	0	this	StatementImpl
    //   10	16	1	Ljava/lang/Object;	Object
    //   24	4	2	localObject1	Object
    //   29	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	23	24	finally
    //   24	27	24	finally
    //   0	29	29	com/mysql/cj/exceptions/CJException
  }
  
  public ResultSet getGeneratedKeys()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!retrieveGeneratedKeys) {
          throw SQLError.createSQLException(Messages.getString("Statement.GeneratedKeysNotRequested"), "S1009", 
            getExceptionInterceptor());
        }
        if (batchedGeneratedKeys == null)
        {
          if (lastQueryIsOnDupKeyUpdate) {
            return generatedKeysResults = getGeneratedKeysInternal(1L);
          }
          return generatedKeysResults = getGeneratedKeysInternal();
        }
        String encoding = session.getServerSession().getCharacterSetMetadata();
        int collationIndex = session.getServerSession().getMetadataCollationIndex();
        Field[] fields = new Field[1];
        fields[0] = new Field("", "GENERATED_KEY", collationIndex, encoding, MysqlType.BIGINT_UNSIGNED, 20);
        
        generatedKeysResults = resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(batchedGeneratedKeys, new DefaultColumnDefinition(fields)));
        
        return generatedKeysResults;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected ResultSetInternalMethods getGeneratedKeysInternal()
    throws SQLException
  {
    long numKeys = getLargeUpdateCount();
    return getGeneratedKeysInternal(numKeys);
  }
  
  protected ResultSetInternalMethods getGeneratedKeysInternal(long numKeys)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        String encoding = session.getServerSession().getCharacterSetMetadata();
        int collationIndex = session.getServerSession().getMetadataCollationIndex();
        Field[] fields = new Field[1];
        fields[0] = new Field("", "GENERATED_KEY", collationIndex, encoding, MysqlType.BIGINT_UNSIGNED, 20);
        
        ArrayList<Row> rowSet = new ArrayList();
        
        long beginAt = getLastInsertID();
        if (results != null)
        {
          String serverInfo = results.getServerInfo();
          if ((numKeys > 0L) && (results.getFirstCharOfQuery() == 'R') && (serverInfo != null) && (serverInfo.length() > 0)) {
            numKeys = getRecordCountFromInfo(serverInfo);
          }
          if ((beginAt != 0L) && (numKeys > 0L)) {
            for (int i = 0; i < numKeys; i++)
            {
              byte[][] row = new byte[1][];
              if (beginAt > 0L)
              {
                row[0] = StringUtils.getBytes(Long.toString(beginAt));
              }
              else
              {
                byte[] asBytes = new byte[8];
                asBytes[7] = ((byte)(int)(beginAt & 0xFF));
                asBytes[6] = ((byte)(int)(beginAt >>> 8));
                asBytes[5] = ((byte)(int)(beginAt >>> 16));
                asBytes[4] = ((byte)(int)(beginAt >>> 24));
                asBytes[3] = ((byte)(int)(beginAt >>> 32));
                asBytes[2] = ((byte)(int)(beginAt >>> 40));
                asBytes[1] = ((byte)(int)(beginAt >>> 48));
                asBytes[0] = ((byte)(int)(beginAt >>> 56));
                
                BigInteger val = new BigInteger(1, asBytes);
                
                row[0] = val.toString().getBytes();
              }
              rowSet.add(new ByteArrayRow(row, getExceptionInterceptor()));
              beginAt += connection.getAutoIncrementIncrement();
            }
          }
        }
        ResultSetImpl gkRs = resultSetFactory.createFromResultsetRows(1007, 1004, new ResultsetRowsStatic(rowSet, new DefaultColumnDefinition(fields)));
        
        return gkRs;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public long getLastInsertID()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 11	com/mysql/cj/jdbc/StatementImpl:lastInsertId	J
    //   16: aload_1
    //   17: monitorexit
    //   18: lreturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #1475	-> byte code offset #0
    //   Java source line #1476	-> byte code offset #12
    //   Java source line #1477	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	StatementImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  public long getLongUpdateCount()
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (results == null) {
          return -1L;
        }
        if (results.hasRows()) {
          return -1L;
        }
        return updateCount;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public int getMaxFieldSize()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 17	com/mysql/cj/jdbc/StatementImpl:maxFieldSize	I
    //   16: aload_1
    //   17: monitorexit
    //   18: ireturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #1507	-> byte code offset #0
    //   Java source line #1508	-> byte code offset #12
    //   Java source line #1509	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	StatementImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  public int getMaxRows()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (maxRows <= 0) {
          return 0;
        }
        return maxRows;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean getMoreResults()
    throws SQLException
  {
    try
    {
      return getMoreResults(1);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean getMoreResults(int current)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (results == null) {
          return false;
        }
        boolean streamingMode = createStreamingResultSet();
        while ((streamingMode) && 
          (results.hasRows()) && 
          (results.next())) {}
        ResultSetInternalMethods nextResultSet = (ResultSetInternalMethods)results.getNextResultset();
        switch (current)
        {
        case 1: 
          if (results != null)
          {
            if ((!streamingMode) && (!((Boolean)dontTrackOpenResources.getValue()).booleanValue())) {
              results.realClose(false);
            }
            results.clearNextResultset();
          }
          break;
        case 3: 
          if (results != null)
          {
            if ((!streamingMode) && (!((Boolean)dontTrackOpenResources.getValue()).booleanValue())) {
              results.realClose(false);
            }
            results.clearNextResultset();
          }
          closeAllOpenResults();
          
          break;
        case 2: 
          if (!((Boolean)dontTrackOpenResources.getValue()).booleanValue()) {
            openResults.add(results);
          }
          results.clearNextResultset();
          
          break;
        default: 
          throw SQLError.createSQLException(Messages.getString("Statement.19"), "S1009", 
            getExceptionInterceptor());
        }
        results = nextResultSet;
        if (results == null)
        {
          updateCount = -1L;
          lastInsertId = -1L;
        }
        else if (results.hasRows())
        {
          updateCount = -1L;
          lastInsertId = -1L;
        }
        else
        {
          updateCount = results.getUpdateCount();
          lastInsertId = results.getUpdateID();
        }
        boolean moreResults = (results != null) && (results.hasRows());
        if (!moreResults) {
          checkAndPerformCloseOnCompletionAction();
        }
        return moreResults;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public int getQueryTimeout()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: invokevirtual 216	com/mysql/cj/jdbc/StatementImpl:getTimeoutInMillis	()I
    //   16: sipush 1000
    //   19: idiv
    //   20: aload_1
    //   21: monitorexit
    //   22: ireturn
    //   23: astore_2
    //   24: aload_1
    //   25: monitorexit
    //   26: aload_2
    //   27: athrow
    //   28: astore_3
    //   29: aload_3
    //   30: aload_0
    //   31: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   34: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   37: athrow
    // Line number table:
    //   Java source line #1611	-> byte code offset #0
    //   Java source line #1612	-> byte code offset #12
    //   Java source line #1613	-> byte code offset #23
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	31	0	this	StatementImpl
    //   10	15	1	Ljava/lang/Object;	Object
    //   23	4	2	localObject1	Object
    //   28	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	22	23	finally
    //   23	26	23	finally
    //   0	28	28	com/mysql/cj/exceptions/CJException
  }
  
  private long getRecordCountFromInfo(String serverInfo)
  {
    StringBuilder recordsBuf = new StringBuilder();
    long recordsCount = 0L;
    long duplicatesCount = 0L;
    
    char c = '\000';
    
    int length = serverInfo.length();
    for (int i = 0; i < length; i++)
    {
      c = serverInfo.charAt(i);
      if (Character.isDigit(c)) {
        break;
      }
    }
    recordsBuf.append(c);
    i++;
    for (; i < length; i++)
    {
      c = serverInfo.charAt(i);
      if (!Character.isDigit(c)) {
        break;
      }
      recordsBuf.append(c);
    }
    recordsCount = Long.parseLong(recordsBuf.toString());
    
    StringBuilder duplicatesBuf = new StringBuilder();
    for (; i < length; i++)
    {
      c = serverInfo.charAt(i);
      if (Character.isDigit(c)) {
        break;
      }
    }
    duplicatesBuf.append(c);
    i++;
    for (; i < length; i++)
    {
      c = serverInfo.charAt(i);
      if (!Character.isDigit(c)) {
        break;
      }
      duplicatesBuf.append(c);
    }
    duplicatesCount = Long.parseLong(duplicatesBuf.toString());
    
    return recordsCount - duplicatesCount;
  }
  
  public ResultSet getResultSet()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        return (results != null) && (results.hasRows()) ? results : null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public int getResultSetConcurrency()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 26	com/mysql/cj/jdbc/StatementImpl:resultSetConcurrency	I
    //   16: aload_1
    //   17: monitorexit
    //   18: ireturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #1693	-> byte code offset #0
    //   Java source line #1694	-> byte code offset #12
    //   Java source line #1695	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	StatementImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  public int getResultSetHoldability()
    throws SQLException
  {
    try
    {
      return 1;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  protected ResultSetInternalMethods getResultSetInternal()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 24	com/mysql/cj/jdbc/StatementImpl:results	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   16: aload_1
    //   17: monitorexit
    //   18: areturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_1
    //   25: aload_0
    //   26: getfield 24	com/mysql/cj/jdbc/StatementImpl:results	Lcom/mysql/cj/jdbc/result/ResultSetInternalMethods;
    //   29: areturn
    //   30: astore_3
    //   31: aload_3
    //   32: aload_0
    //   33: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   36: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   39: athrow
    // Line number table:
    //   Java source line #1705	-> byte code offset #0
    //   Java source line #1706	-> byte code offset #12
    //   Java source line #1707	-> byte code offset #19
    //   Java source line #1708	-> byte code offset #24
    //   Java source line #1709	-> byte code offset #25
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	33	0	this	StatementImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   24	2	1	e	StatementIsClosedException
    //   19	4	2	localObject1	Object
    //   30	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	18	24	com/mysql/cj/exceptions/StatementIsClosedException
    //   19	24	24	com/mysql/cj/exceptions/StatementIsClosedException
    //   0	30	30	com/mysql/cj/exceptions/CJException
  }
  
  /* Error */
  public int getResultSetType()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 58	com/mysql/cj/jdbc/StatementImpl:query	Lcom/mysql/cj/Query;
    //   16: invokeinterface 168 1 0
    //   21: invokevirtual 169	com/mysql/cj/protocol/Resultset$Type:getIntValue	()I
    //   24: aload_1
    //   25: monitorexit
    //   26: ireturn
    //   27: astore_2
    //   28: aload_1
    //   29: monitorexit
    //   30: aload_2
    //   31: athrow
    //   32: astore_3
    //   33: aload_3
    //   34: aload_0
    //   35: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   38: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   41: athrow
    // Line number table:
    //   Java source line #1715	-> byte code offset #0
    //   Java source line #1716	-> byte code offset #12
    //   Java source line #1717	-> byte code offset #27
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	35	0	this	StatementImpl
    //   10	19	1	Ljava/lang/Object;	Object
    //   27	4	2	localObject1	Object
    //   32	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	26	27	finally
    //   27	30	27	finally
    //   0	32	32	com/mysql/cj/exceptions/CJException
  }
  
  public int getUpdateCount()
    throws SQLException
  {
    try
    {
      return Util.truncateAndConvertToInt(getLargeUpdateCount());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public SQLWarning getWarnings()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (isClearWarningsCalled()) {
          return null;
        }
        SQLWarning pendingWarningsFromServer = session.getProtocol().convertShowWarningsToSQLWarnings(0, false);
        if (warningChain != null) {
          warningChain.setNextWarning(pendingWarningsFromServer);
        } else {
          warningChain = pendingWarningsFromServer;
        }
        return warningChain;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void realClose(boolean calledExplicitly, boolean closeOpenResults)
    throws SQLException
  {
    JdbcConnection locallyScopedConn = connection;
    if ((locallyScopedConn == null) || (isClosed)) {
      return;
    }
    if (!((Boolean)dontTrackOpenResources.getValue()).booleanValue()) {
      locallyScopedConn.unregisterStatement(this);
    }
    if ((useUsageAdvisor) && 
      (!calledExplicitly)) {
      session.getProfilerEventHandler().processEvent((byte)0, session, this, null, 0L, new Throwable(), 
        Messages.getString("Statement.63"));
    }
    if (closeOpenResults) {
      closeOpenResults = (!holdResultsOpenOverClose) && (!((Boolean)dontTrackOpenResources.getValue()).booleanValue());
    }
    if (closeOpenResults)
    {
      if (results != null) {
        try
        {
          results.close();
        }
        catch (Exception localException) {}
      }
      if (generatedKeysResults != null) {
        try
        {
          generatedKeysResults.close();
        }
        catch (Exception localException1) {}
      }
      closeAllOpenResults();
    }
    isClosed = true;
    
    closeQuery();
    
    results = null;
    generatedKeysResults = null;
    connection = null;
    session = null;
    warningChain = null;
    openResults = null;
    batchedGeneratedKeys = null;
    pingTarget = null;
    resultSetFactory = null;
  }
  
  public void setCursorName(String name)
    throws SQLException
  {
    try {}catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setEscapeProcessing(boolean enable)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        doEscapeProcessing = enable;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setFetchDirection(int direction)
    throws SQLException
  {
    try
    {
      switch (direction)
      {
      case 1000: 
      case 1001: 
      case 1002: 
        break;
      default: 
        throw SQLError.createSQLException(Messages.getString("Statement.5"), "S1009", getExceptionInterceptor());
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setFetchSize(int rows)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (((rows < 0) && (rows != Integer.MIN_VALUE)) || ((maxRows > 0) && (rows > getMaxRows()))) {
          throw SQLError.createSQLException(Messages.getString("Statement.7"), "S1009", getExceptionInterceptor());
        }
        query.setResultFetchSize(rows);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setHoldResultsOpenOverClose(boolean holdResultsOpenOverClose)
  {
    try
    {
      try
      {
        synchronized (checkClosed().getConnectionMutex())
        {
          this.holdResultsOpenOverClose = holdResultsOpenOverClose;
        }
      }
      catch (StatementIsClosedException localStatementIsClosedException) {}
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setMaxFieldSize(int max)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (max < 0) {
          throw SQLError.createSQLException(Messages.getString("Statement.11"), "S1009", getExceptionInterceptor());
        }
        int maxBuf = ((Integer)maxAllowedPacket.getValue()).intValue();
        if (max > maxBuf) {
          throw SQLError.createSQLException(Messages.getString("Statement.13", new Object[] { Long.valueOf(maxBuf) }), "S1009", 
            getExceptionInterceptor());
        }
        maxFieldSize = max;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setMaxRows(int max)
    throws SQLException
  {
    try
    {
      setLargeMaxRows(max);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setQueryTimeout(int seconds)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (seconds < 0) {
          throw SQLError.createSQLException(Messages.getString("Statement.21"), "S1009", getExceptionInterceptor());
        }
        setTimeoutInMillis(seconds * 1000);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  void setResultSetConcurrency(int concurrencyFlag)
    throws SQLException
  {
    try
    {
      try
      {
        synchronized (checkClosed().getConnectionMutex())
        {
          resultSetConcurrency = concurrencyFlag;
          
          resultSetFactory = new ResultSetFactory(connection, this);
        }
      }
      catch (StatementIsClosedException localStatementIsClosedException) {}
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  void setResultSetType(Resultset.Type typeFlag)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        query.setResultType(typeFlag);
        
        resultSetFactory = new ResultSetFactory(connection, this);
      }
    }
    catch (StatementIsClosedException localStatementIsClosedException) {}
  }
  
  void setResultSetType(int typeFlag)
    throws SQLException
  {
    Resultset.Type.fromValue(typeFlag, Resultset.Type.FORWARD_ONLY);
  }
  
  protected void getBatchedGeneratedKeys(Statement batchedStatement)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (retrieveGeneratedKeys)
        {
          ResultSet rs = null;
          try
          {
            rs = batchedStatement.getGeneratedKeys();
            while (rs.next()) {
              batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
            }
          }
          finally
          {
            if (rs != null) {
              rs.close();
            }
          }
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void getBatchedGeneratedKeys(int maxKeys)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (retrieveGeneratedKeys)
        {
          ResultSet rs = null;
          try
          {
            rs = maxKeys == 0 ? getGeneratedKeysInternal() : getGeneratedKeysInternal(maxKeys);
            while (rs.next()) {
              batchedGeneratedKeys.add(new ByteArrayRow(new byte[][] { rs.getBytes(1) }, getExceptionInterceptor()));
            }
          }
          finally
          {
            isImplicitlyClosingResults = true;
            try
            {
              if (rs != null) {
                rs.close();
              }
            }
            finally
            {
              isImplicitlyClosingResults = false;
            }
          }
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private boolean useServerFetch()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        return (((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.useCursorFetch).getValue()).booleanValue()) && (query.getResultFetchSize() > 0) && 
          (query.getResultType() == Resultset.Type.FORWARD_ONLY);
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private boolean isPoolable = false;
  
  /* Error */
  public boolean isClosed()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 6	com/mysql/cj/jdbc/StatementImpl:connection	Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnonnull +5 -> 11
    //   9: iconst_1
    //   10: ireturn
    //   11: aload_1
    //   12: invokeinterface 98 1 0
    //   17: dup
    //   18: astore_2
    //   19: monitorenter
    //   20: aload_0
    //   21: getfield 8	com/mysql/cj/jdbc/StatementImpl:isClosed	Z
    //   24: aload_2
    //   25: monitorexit
    //   26: ireturn
    //   27: astore_3
    //   28: aload_2
    //   29: monitorexit
    //   30: aload_3
    //   31: athrow
    //   32: astore 4
    //   34: aload 4
    //   36: aload_0
    //   37: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   40: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   43: athrow
    // Line number table:
    //   Java source line #1992	-> byte code offset #0
    //   Java source line #1993	-> byte code offset #5
    //   Java source line #1994	-> byte code offset #9
    //   Java source line #1996	-> byte code offset #11
    //   Java source line #1997	-> byte code offset #20
    //   Java source line #1998	-> byte code offset #27
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	37	0	this	StatementImpl
    //   4	8	1	locallyScopedConn	JdbcConnection
    //   18	11	2	Ljava/lang/Object;	Object
    //   27	4	3	localObject1	Object
    //   32	3	4	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   20	26	27	finally
    //   27	30	27	finally
    //   0	32	32	com/mysql/cj/exceptions/CJException
  }
  
  public boolean isPoolable()
    throws SQLException
  {
    try
    {
      checkClosed();
      return isPoolable;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setPoolable(boolean poolable)
    throws SQLException
  {
    try
    {
      checkClosed();
      isPoolable = poolable;
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    try
    {
      checkClosed();
      
      return iface.isInstance(this);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      try
      {
        return (T)iface.cast(this);
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected static int findStartOfStatement(String sql)
  {
    int statementStartPos = 0;
    if (StringUtils.startsWithIgnoreCaseAndWs(sql, "/*"))
    {
      statementStartPos = sql.indexOf("*/");
      if (statementStartPos == -1) {
        statementStartPos = 0;
      } else {
        statementStartPos += 2;
      }
    }
    else if ((StringUtils.startsWithIgnoreCaseAndWs(sql, "--")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "#")))
    {
      statementStartPos = sql.indexOf('\n');
      if (statementStartPos == -1)
      {
        statementStartPos = sql.indexOf('\r');
        if (statementStartPos == -1) {
          statementStartPos = 0;
        }
      }
    }
    return statementStartPos;
  }
  
  public InputStream getLocalInfileInputStream()
  {
    return session.getLocalInfileInputStream();
  }
  
  public void setLocalInfileInputStream(InputStream stream)
  {
    session.setLocalInfileInputStream(stream);
  }
  
  public void setPingTarget(PingTarget pingTarget)
  {
    this.pingTarget = pingTarget;
  }
  
  public ExceptionInterceptor getExceptionInterceptor()
  {
    return exceptionInterceptor;
  }
  
  protected boolean containsOnDuplicateKeyInString(String sql)
  {
    return ParseInfo.getOnDuplicateKeyLocation(sql, dontCheckOnDuplicateKeyUpdateInSQL, ((Boolean)rewriteBatchedStatements.getValue()).booleanValue(), session
      .getServerSession().isNoBackslashEscapesSet()) != -1;
  }
  
  private boolean closeOnCompletion = false;
  
  public void closeOnCompletion()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        closeOnCompletion = true;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public boolean isCloseOnCompletion()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 97	com/mysql/cj/jdbc/StatementImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 98 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 43	com/mysql/cj/jdbc/StatementImpl:closeOnCompletion	Z
    //   16: aload_1
    //   17: monitorexit
    //   18: ireturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1458	com/mysql/cj/jdbc/StatementImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 57	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #2096	-> byte code offset #0
    //   Java source line #2097	-> byte code offset #12
    //   Java source line #2098	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	StatementImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  public long[] executeLargeBatch()
    throws SQLException
  {
    try
    {
      return executeBatchInternal();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long executeLargeUpdate(String sql)
    throws SQLException
  {
    try
    {
      return executeUpdateInternal(sql, false, false);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long executeLargeUpdate(String sql, int autoGeneratedKeys)
    throws SQLException
  {
    try
    {
      return executeUpdateInternal(sql, false, autoGeneratedKeys == 1);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long executeLargeUpdate(String sql, int[] columnIndexes)
    throws SQLException
  {
    try
    {
      return executeUpdateInternal(sql, false, (columnIndexes != null) && (columnIndexes.length > 0));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long executeLargeUpdate(String sql, String[] columnNames)
    throws SQLException
  {
    try
    {
      return executeUpdateInternal(sql, false, (columnNames != null) && (columnNames.length > 0));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long getLargeMaxRows()
    throws SQLException
  {
    try
    {
      return getMaxRows();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long getLargeUpdateCount()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (results == null) {
          return -1L;
        }
        if (results.hasRows()) {
          return -1L;
        }
        return results.getUpdateCount();
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setLargeMaxRows(long max)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if ((max > 50000000L) || (max < 0L)) {
          throw SQLError.createSQLException(Messages.getString("Statement.15") + max + " > " + 50000000 + ".", "S1009", 
            getExceptionInterceptor());
        }
        if (max == 0L) {
          max = -1L;
        }
        maxRows = ((int)max);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getCurrentDatabase()
  {
    return query.getCurrentDatabase();
  }
  
  public long getServerStatementId()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("Statement.65")));
  }
  
  public <T extends Resultset, M extends Message> ProtocolEntityFactory<T, M> getResultSetFactory()
  {
    return resultSetFactory;
  }
  
  public int getId()
  {
    return query.getId();
  }
  
  public void setCancelStatus(Query.CancelStatus cs)
  {
    query.setCancelStatus(cs);
  }
  
  public void checkCancelTimeout()
  {
    try
    {
      query.checkCancelTimeout();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Session getSession()
  {
    return session;
  }
  
  public Object getCancelTimeoutMutex()
  {
    return query.getCancelTimeoutMutex();
  }
  
  public void closeQuery()
  {
    if (query != null) {
      query.closeQuery();
    }
  }
  
  public int getResultFetchSize()
  {
    return query.getResultFetchSize();
  }
  
  public void setResultFetchSize(int fetchSize)
  {
    query.setResultFetchSize(fetchSize);
  }
  
  public Resultset.Type getResultType()
  {
    return query.getResultType();
  }
  
  public void setResultType(Resultset.Type resultSetType)
  {
    query.setResultType(resultSetType);
  }
  
  public int getTimeoutInMillis()
  {
    return query.getTimeoutInMillis();
  }
  
  public void setTimeoutInMillis(int timeoutInMillis)
  {
    query.setTimeoutInMillis(timeoutInMillis);
  }
  
  public AtomicBoolean getStatementExecuting()
  {
    return query.getStatementExecuting();
  }
  
  public void setCurrentDatabase(String currentDb)
  {
    query.setCurrentDatabase(currentDb);
  }
  
  public boolean isClearWarningsCalled()
  {
    return query.isClearWarningsCalled();
  }
  
  public void setClearWarningsCalled(boolean clearWarningsCalled)
  {
    query.setClearWarningsCalled(clearWarningsCalled);
  }
  
  public Query getQuery()
  {
    return query;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.StatementImpl
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */