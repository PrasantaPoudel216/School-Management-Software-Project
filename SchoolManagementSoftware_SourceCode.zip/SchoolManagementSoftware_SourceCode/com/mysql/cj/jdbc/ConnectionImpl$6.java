package com.mysql.cj.jdbc;

import com.mysql.cj.jdbc.interceptors.ConnectionLifecycleInterceptor;
import java.sql.SQLException;
import java.util.Iterator;

class ConnectionImpl$6
  extends IterateBlock<ConnectionLifecycleInterceptor>
{
  ConnectionImpl$6(ConnectionImpl this$0, Iterator i, String paramString)
  {
    super(i);
  }
  
  void forEach(ConnectionLifecycleInterceptor each)
    throws SQLException
  {
    if (!each.setDatabase(val$db)) {
      stopIterating = true;
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionImpl.6
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */