package com.mysql.cj.jdbc;

import java.io.Reader;
import java.io.StringReader;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

class MysqlSQLXML$SimpleSaxToReader
  extends DefaultHandler
{
  StringBuilder buf = new StringBuilder();
  
  MysqlSQLXML$SimpleSaxToReader(MysqlSQLXML this$0) {}
  
  public void startDocument()
    throws SAXException
  {
    buf.append("<?xml version='1.0' encoding='UTF-8'?>");
  }
  
  public void endDocument()
    throws SAXException
  {}
  
  public void startElement(String namespaceURI, String sName, String qName, Attributes attrs)
    throws SAXException
  {
    buf.append("<");
    buf.append(qName);
    if (attrs != null) {
      for (int i = 0; i < attrs.getLength(); i++)
      {
        buf.append(" ");
        buf.append(attrs.getQName(i)).append("=\"");
        escapeCharsForXml(attrs.getValue(i), true);
        buf.append("\"");
      }
    }
    buf.append(">");
  }
  
  public void characters(char[] buffer, int offset, int len)
    throws SAXException
  {
    if (!inCDATA) {
      escapeCharsForXml(buffer, offset, len, false);
    } else {
      buf.append(buffer, offset, len);
    }
  }
  
  public void ignorableWhitespace(char[] ch, int start, int length)
    throws SAXException
  {
    characters(ch, start, length);
  }
  
  private boolean inCDATA = false;
  
  public void startCDATA()
    throws SAXException
  {
    buf.append("<![CDATA[");
    inCDATA = true;
  }
  
  public void endCDATA()
    throws SAXException
  {
    inCDATA = false;
    buf.append("]]>");
  }
  
  public void comment(char[] ch, int start, int length)
    throws SAXException
  {
    buf.append("<!--");
    for (int i = 0; i < length; i++) {
      buf.append(ch[(start + i)]);
    }
    buf.append("-->");
  }
  
  Reader toReader()
  {
    return new StringReader(buf.toString());
  }
  
  private void escapeCharsForXml(String str, boolean isAttributeData)
  {
    if (str == null) {
      return;
    }
    int strLen = str.length();
    for (int i = 0; i < strLen; i++) {
      escapeCharsForXml(str.charAt(i), isAttributeData);
    }
  }
  
  private void escapeCharsForXml(char[] buffer, int offset, int len, boolean isAttributeData)
  {
    if (buffer == null) {
      return;
    }
    for (int i = 0; i < len; i++) {
      escapeCharsForXml(buffer[(offset + i)], isAttributeData);
    }
  }
  
  private void escapeCharsForXml(char c, boolean isAttributeData)
  {
    switch (c)
    {
    case '<': 
      buf.append("&lt;");
      break;
    case '>': 
      buf.append("&gt;");
      break;
    case '&': 
      buf.append("&amp;");
      break;
    case '"': 
      if (!isAttributeData) {
        buf.append("\"");
      } else {
        buf.append("&quot;");
      }
      break;
    case '\r': 
      buf.append("&#xD;");
      break;
    default: 
      if (((c >= '\001') && (c <= '\037') && (c != '\t') && (c != '\n')) || ((c >= '') && (c <= '?')) || (c == '?') || ((isAttributeData) && ((c == '\t') || (c == '\n'))))
      {
        buf.append("&#x");
        buf.append(Integer.toHexString(c).toUpperCase());
        buf.append(";");
      }
      else
      {
        buf.append(c);
      }
      break;
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.MysqlSQLXML.SimpleSaxToReader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */