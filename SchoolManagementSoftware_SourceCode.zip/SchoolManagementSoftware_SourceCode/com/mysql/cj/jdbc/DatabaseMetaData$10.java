package com.mysql.cj.jdbc;

import com.mysql.cj.MysqlType;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.util.StringUtils;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

class DatabaseMetaData$10
  extends IterateBlock<String>
{
  DatabaseMetaData$10(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, String paramString, Statement paramStatement, ArrayList paramArrayList)
  {
    super(i);
  }
  
  void forEach(String dbStr)
    throws SQLException
  {
    ResultSet results = null;
    try
    {
      StringBuilder whereBuf = new StringBuilder(" Extra LIKE '%on update CURRENT_TIMESTAMP%'");
      List<String> rsFields = new ArrayList();
      if ((whereBuf.length() > 0) || (rsFields.size() > 0))
      {
        StringBuilder queryBuf = new StringBuilder("SHOW COLUMNS FROM ");
        queryBuf.append(StringUtils.quoteIdentifier(val$table, this$0.quotedId, this$0.pedantic));
        queryBuf.append(" FROM ");
        queryBuf.append(StringUtils.quoteIdentifier(dbStr, this$0.quotedId, this$0.pedantic));
        queryBuf.append(" WHERE");
        queryBuf.append(whereBuf.toString());
        try
        {
          results = val$stmt.executeQuery(queryBuf.toString());
        }
        catch (SQLException sqlEx)
        {
          String sqlState = sqlEx.getSQLState();
          int errorCode = sqlEx.getErrorCode();
          if ((!"42S02".equals(sqlState)) && (errorCode != 1146) && (errorCode != 1049)) {
            throw sqlEx;
          }
        }
        while ((results != null) && (results.next()))
        {
          DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(this$0, results.getString("Type"), results.getString("Null"));
          byte[][] rowVal = new byte[8][];
          rowVal[0] = null;
          rowVal[1] = results.getBytes("Field");
          rowVal[2] = Short.toString((short)mysqlType.getJdbcType()).getBytes();
          rowVal[3] = this$0.s2b(mysqlType.getName());
          rowVal[4] = (columnSize == null ? null : this$0.s2b(columnSize.toString()));
          rowVal[5] = this$0.s2b(Integer.toString(bufferLength));
          rowVal[6] = (decimalDigits == null ? null : this$0.s2b(decimalDigits.toString()));
          rowVal[7] = Integer.toString(1).getBytes();
          val$rows.add(new ByteArrayRow(rowVal, this$0.getExceptionInterceptor()));
        }
      }
    }
    catch (SQLException sqlEx)
    {
      if (!"42S02".equals(sqlEx.getSQLState())) {
        throw sqlEx;
      }
    }
    finally
    {
      if (results != null)
      {
        try
        {
          results.close();
        }
        catch (Exception localException2) {}
        results = null;
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.10
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */