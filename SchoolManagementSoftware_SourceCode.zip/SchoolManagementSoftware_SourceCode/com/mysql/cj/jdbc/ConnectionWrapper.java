package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.MysqlConnection;
import com.mysql.cj.ServerVersion;
import com.mysql.cj.Session;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ConnectionIsClosedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.interceptors.QueryInterceptor;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.jdbc.result.CachedResultSetMetaData;
import com.mysql.cj.jdbc.result.ResultSetInternalMethods;
import java.lang.reflect.Proxy;
import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Wrapper;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.Executor;

public class ConnectionWrapper
  extends WrapperBase
  implements JdbcConnection
{
  protected JdbcConnection mc = null;
  private String invalidHandleStr = "Logical handle no longer valid";
  private boolean closed;
  private boolean isForXa;
  
  protected static ConnectionWrapper getInstance(MysqlPooledConnection mysqlPooledConnection, JdbcConnection mysqlConnection, boolean forXa)
    throws SQLException
  {
    return new ConnectionWrapper(mysqlPooledConnection, mysqlConnection, forXa);
  }
  
  public ConnectionWrapper(MysqlPooledConnection mysqlPooledConnection, JdbcConnection mysqlConnection, boolean forXa)
    throws SQLException
  {
    super(mysqlPooledConnection);
    
    mc = mysqlConnection;
    closed = false;
    isForXa = forXa;
    if (isForXa) {
      setInGlobalTx(false);
    }
  }
  
  public void setAutoCommit(boolean autoCommit)
    throws SQLException
  {
    try
    {
      checkClosed();
      if ((autoCommit) && (isInGlobalTx())) {
        throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.0"), "2D000", 1401, exceptionInterceptor);
      }
      try
      {
        mc.setAutoCommit(autoCommit);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean getAutoCommit()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getAutoCommit();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return false;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setDatabase(String dbName)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.setDatabase(dbName);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public String getDatabase()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getDatabase();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setCatalog(String catalog)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.setCatalog(catalog);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public String getCatalog()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getCatalog();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean isClosed()
    throws SQLException
  {
    try
    {
      return (closed) || (mc.isClosed());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean isMasterConnection()
  {
    return mc.isMasterConnection();
  }
  
  public void setHoldability(int arg0)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.setHoldability(arg0);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getHoldability()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getHoldability();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return 1;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public long getIdleFor()
  {
    return mc.getIdleFor();
  }
  
  public DatabaseMetaData getMetaData()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getMetaData();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setReadOnly(boolean readOnly)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.setReadOnly(readOnly);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean isReadOnly()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.isReadOnly();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return false;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Savepoint setSavepoint()
    throws SQLException
  {
    try
    {
      checkClosed();
      if (isInGlobalTx()) {
        throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.0"), "2D000", 1401, exceptionInterceptor);
      }
      try
      {
        return mc.setSavepoint();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Savepoint setSavepoint(String arg0)
    throws SQLException
  {
    try
    {
      checkClosed();
      if (isInGlobalTx()) {
        throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.0"), "2D000", 1401, exceptionInterceptor);
      }
      try
      {
        return mc.setSavepoint(arg0);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setTransactionIsolation(int level)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.setTransactionIsolation(level);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getTransactionIsolation()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getTransactionIsolation();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return 4;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Map<String, Class<?>> getTypeMap()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getTypeMap();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public SQLWarning getWarnings()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getWarnings();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void clearWarnings()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.clearWarnings();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  /* Error */
  public void close()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: iconst_1
    //   2: invokevirtual 42	com/mysql/cj/jdbc/ConnectionWrapper:close	(Z)V
    //   5: aload_0
    //   6: aconst_null
    //   7: putfield 43	com/mysql/cj/jdbc/ConnectionWrapper:unwrappedInterfaces	Ljava/util/Map;
    //   10: goto +11 -> 21
    //   13: astore_1
    //   14: aload_0
    //   15: aconst_null
    //   16: putfield 43	com/mysql/cj/jdbc/ConnectionWrapper:unwrappedInterfaces	Ljava/util/Map;
    //   19: aload_1
    //   20: athrow
    //   21: return
    //   22: astore_2
    //   23: aload_2
    //   24: aload_0
    //   25: getfield 756	com/mysql/cj/jdbc/WrapperBase:exceptionInterceptor	Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   28: invokestatic 762	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   31: athrow
    // Line number table:
    //   Java source line #339	-> byte code offset #0
    //   Java source line #341	-> byte code offset #5
    //   Java source line #342	-> byte code offset #10
    //   Java source line #341	-> byte code offset #13
    //   Java source line #342	-> byte code offset #19
    //   Java source line #343	-> byte code offset #21
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	25	0	this	ConnectionWrapper
    //   13	7	1	localObject	Object
    //   22	2	2	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   0	5	13	finally
    //   0	22	22	com/mysql/cj/exceptions/CJException
  }
  
  public void commit()
    throws SQLException
  {
    try
    {
      checkClosed();
      if (isInGlobalTx()) {
        throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.1"), "2D000", 1401, exceptionInterceptor);
      }
      try
      {
        mc.commit();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Statement createStatement()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return StatementWrapper.getInstance(this, pooledConnection, mc.createStatement());
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Statement createStatement(int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return StatementWrapper.getInstance(this, pooledConnection, mc.createStatement(resultSetType, resultSetConcurrency));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Statement createStatement(int arg0, int arg1, int arg2)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return StatementWrapper.getInstance(this, pooledConnection, mc.createStatement(arg0, arg1, arg2));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public String nativeSQL(String sql)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.nativeSQL(sql);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public CallableStatement prepareCall(String sql)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return CallableStatementWrapper.getInstance(this, pooledConnection, mc.prepareCall(sql));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return CallableStatementWrapper.getInstance(this, pooledConnection, mc.prepareCall(sql, resultSetType, resultSetConcurrency));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public CallableStatement prepareCall(String arg0, int arg1, int arg2, int arg3)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return CallableStatementWrapper.getInstance(this, pooledConnection, mc.prepareCall(arg0, arg1, arg2, arg3));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement clientPrepare(String sql)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return new PreparedStatementWrapper(this, pooledConnection, mc.clientPrepareStatement(sql));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement clientPrepare(String sql, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return new PreparedStatementWrapper(this, pooledConnection, mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement prepareStatement(String sql)
    throws SQLException
  {
    try
    {
      checkClosed();PreparedStatement res = null;
      try
      {
        res = PreparedStatementWrapper.getInstance(this, pooledConnection, mc.prepareStatement(sql));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return res;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement prepareStatement(String sql, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.prepareStatement(sql, resultSetType, resultSetConcurrency));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement prepareStatement(String arg0, int arg1, int arg2, int arg3)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.prepareStatement(arg0, arg1, arg2, arg3));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement prepareStatement(String arg0, int arg1)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.prepareStatement(arg0, arg1));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement prepareStatement(String arg0, int[] arg1)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.prepareStatement(arg0, arg1));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement prepareStatement(String arg0, String[] arg1)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.prepareStatement(arg0, arg1));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void releaseSavepoint(Savepoint arg0)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.releaseSavepoint(arg0);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void rollback()
    throws SQLException
  {
    try
    {
      checkClosed();
      if (isInGlobalTx()) {
        throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.2"), "2D000", 1401, exceptionInterceptor);
      }
      try
      {
        mc.rollback();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void rollback(Savepoint arg0)
    throws SQLException
  {
    try
    {
      checkClosed();
      if (isInGlobalTx()) {
        throw SQLError.createSQLException(Messages.getString("ConnectionWrapper.2"), "2D000", 1401, exceptionInterceptor);
      }
      try
      {
        mc.rollback(arg0);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean isSameResource(JdbcConnection c)
  {
    if ((c instanceof ConnectionWrapper)) {
      return mc.isSameResource(mc);
    }
    return mc.isSameResource(c);
  }
  
  protected void close(boolean fireClosedEvent)
    throws SQLException
  {
    synchronized (pooledConnection)
    {
      if (closed) {
        return;
      }
      if ((!isInGlobalTx()) && (((Boolean)mc.getPropertySet().getBooleanProperty(PropertyKey.rollbackOnPooledClose).getValue()).booleanValue()) && (!getAutoCommit())) {
        rollback();
      }
      if (fireClosedEvent) {
        pooledConnection.callConnectionEventListeners(2, null);
      }
      closed = true;
    }
  }
  
  public void checkClosed()
  {
    if (closed) {
      throw ((ConnectionIsClosedException)ExceptionFactory.createException(ConnectionIsClosedException.class, invalidHandleStr, exceptionInterceptor));
    }
  }
  
  public boolean isInGlobalTx()
  {
    return mc.isInGlobalTx();
  }
  
  public void setInGlobalTx(boolean flag)
  {
    mc.setInGlobalTx(flag);
  }
  
  public void ping()
    throws SQLException
  {
    try
    {
      if (mc != null) {
        mc.ping();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void changeUser(String userName, String newPassword)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.changeUser(userName, newPassword);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  @Deprecated
  public void clearHasTriedMaster()
  {
    mc.clearHasTriedMaster();
  }
  
  public PreparedStatement clientPrepareStatement(String sql)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.clientPrepareStatement(sql));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement clientPrepareStatement(String sql, int autoGenKeyIndex)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.clientPrepareStatement(sql, autoGenKeyIndex));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.clientPrepareStatement(sql, resultSetType, resultSetConcurrency));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement clientPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc
          .clientPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement clientPrepareStatement(String sql, int[] autoGenKeyIndexes)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.clientPrepareStatement(sql, autoGenKeyIndexes));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement clientPrepareStatement(String sql, String[] autoGenKeyColNames)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.clientPrepareStatement(sql, autoGenKeyColNames));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getActiveStatementCount()
  {
    return mc.getActiveStatementCount();
  }
  
  public String getStatementComment()
  {
    return mc.getStatementComment();
  }
  
  @Deprecated
  public boolean hasTriedMaster()
  {
    return mc.hasTriedMaster();
  }
  
  public boolean lowerCaseTableNames()
  {
    return mc.lowerCaseTableNames();
  }
  
  public void resetServerState()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.resetServerState();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement serverPrepareStatement(String sql)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.serverPrepareStatement(sql));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement serverPrepareStatement(String sql, int autoGenKeyIndex)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.serverPrepareStatement(sql, autoGenKeyIndex));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.serverPrepareStatement(sql, resultSetType, resultSetConcurrency));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement serverPrepareStatement(String sql, int resultSetType, int resultSetConcurrency, int resultSetHoldability)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc
          .serverPrepareStatement(sql, resultSetType, resultSetConcurrency, resultSetHoldability));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement serverPrepareStatement(String sql, int[] autoGenKeyIndexes)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.serverPrepareStatement(sql, autoGenKeyIndexes));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public PreparedStatement serverPrepareStatement(String sql, String[] autoGenKeyColNames)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return PreparedStatementWrapper.getInstance(this, pooledConnection, mc.serverPrepareStatement(sql, autoGenKeyColNames));
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setFailedOver(boolean flag)
  {
    mc.setFailedOver(flag);
  }
  
  public void setStatementComment(String comment)
  {
    mc.setStatementComment(comment);
  }
  
  public void shutdownServer()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.shutdownServer();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getAutoIncrementIncrement()
  {
    return mc.getAutoIncrementIncrement();
  }
  
  public ExceptionInterceptor getExceptionInterceptor()
  {
    return pooledConnection.getExceptionInterceptor();
  }
  
  public boolean hasSameProperties(JdbcConnection c)
  {
    return mc.hasSameProperties(c);
  }
  
  public Properties getProperties()
  {
    return mc.getProperties();
  }
  
  public String getHost()
  {
    return mc.getHost();
  }
  
  public void setProxy(JdbcConnection conn)
  {
    mc.setProxy(conn);
  }
  
  public void setTypeMap(Map<String, Class<?>> map)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        mc.setTypeMap(map);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean isServerLocal()
    throws SQLException
  {
    try
    {
      return mc.isServerLocal();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setSchema(String schema)
    throws SQLException
  {
    try
    {
      checkClosed();mc.setSchema(schema);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public String getSchema()
    throws SQLException
  {
    try
    {
      return mc.getSchema();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void abort(Executor executor)
    throws SQLException
  {
    try
    {
      mc.abort(executor);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setNetworkTimeout(Executor executor, int milliseconds)
    throws SQLException
  {
    try
    {
      mc.setNetworkTimeout(executor, milliseconds);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public int getNetworkTimeout()
    throws SQLException
  {
    try
    {
      return mc.getNetworkTimeout();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void abortInternal()
    throws SQLException
  {
    try
    {
      mc.abortInternal();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Object getConnectionMutex()
  {
    return mc.getConnectionMutex();
  }
  
  public int getSessionMaxRows()
  {
    return mc.getSessionMaxRows();
  }
  
  public void setSessionMaxRows(int max)
    throws SQLException
  {
    try
    {
      mc.setSessionMaxRows(max);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Clob createClob()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.createClob();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Blob createBlob()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.createBlob();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public NClob createNClob()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.createNClob();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public SQLXML createSQLXML()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.createSQLXML();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized boolean isValid(int timeout)
    throws SQLException
  {
    try
    {
      try
      {
        return mc.isValid(timeout);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return false;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setClientInfo(String name, String value)
    throws SQLClientInfoException
  {
    try
    {
      try
      {
        checkClosed();
        
        mc.setClientInfo(name, value);
      }
      catch (SQLException sqlException)
      {
        try
        {
          checkAndFireConnectionError(sqlException);
        }
        catch (SQLException sqlEx2)
        {
          SQLClientInfoException clientEx = new SQLClientInfoException();
          clientEx.initCause(sqlEx2);
          
          throw clientEx;
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void setClientInfo(Properties properties)
    throws SQLClientInfoException
  {
    try
    {
      try
      {
        checkClosed();
        
        mc.setClientInfo(properties);
      }
      catch (SQLException sqlException)
      {
        try
        {
          checkAndFireConnectionError(sqlException);
        }
        catch (SQLException sqlEx2)
        {
          SQLClientInfoException clientEx = new SQLClientInfoException();
          clientEx.initCause(sqlEx2);
          
          throw clientEx;
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public String getClientInfo(String name)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getClientInfo(name);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Properties getClientInfo()
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.getClientInfo();
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Array createArrayOf(String typeName, Object[] elements)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.createArrayOf(typeName, elements);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Struct createStruct(String typeName, Object[] attributes)
    throws SQLException
  {
    try
    {
      checkClosed();
      try
      {
        return mc.createStruct(typeName, attributes);
      }
      catch (SQLException sqlException)
      {
        checkAndFireConnectionError(sqlException);
        
        return null;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public synchronized <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      try
      {
        if (("java.sql.Connection".equals(iface.getName())) || ("java.sql.Wrapper.class".equals(iface.getName()))) {
          return (T)iface.cast(this);
        }
        if (unwrappedInterfaces == null) {
          unwrappedInterfaces = new HashMap();
        }
        Object cachedUnwrapped = unwrappedInterfaces.get(iface);
        if (cachedUnwrapped == null)
        {
          cachedUnwrapped = Proxy.newProxyInstance(mc.getClass().getClassLoader(), new Class[] { iface }, new WrapperBase.ConnectionErrorFiringInvocationHandler(this, mc));
          
          unwrappedInterfaces.put(iface, cachedUnwrapped);
        }
        return (T)iface.cast(cachedUnwrapped);
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", exceptionInterceptor);
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    try
    {
      boolean isInstance = iface.isInstance(this);
      if (isInstance) {
        return true;
      }
      return (iface.getName().equals(JdbcConnection.class.getName())) || (iface.getName().equals(MysqlConnection.class.getName())) || 
        (iface.getName().equals(Connection.class.getName())) || (iface.getName().equals(Wrapper.class.getName())) || 
        (iface.getName().equals(AutoCloseable.class.getName()));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public Session getSession()
  {
    return mc.getSession();
  }
  
  public long getId()
  {
    return mc.getId();
  }
  
  public String getURL()
  {
    return mc.getURL();
  }
  
  public String getUser()
  {
    return mc.getUser();
  }
  
  public void createNewIO(boolean isForReconnect)
  {
    mc.createNewIO(isForReconnect);
  }
  
  public boolean isProxySet()
  {
    return mc.isProxySet();
  }
  
  public JdbcPropertySet getPropertySet()
  {
    return mc.getPropertySet();
  }
  
  public CachedResultSetMetaData getCachedMetaData(String sql)
  {
    return mc.getCachedMetaData(sql);
  }
  
  public String getCharacterSetMetadata()
  {
    return mc.getCharacterSetMetadata();
  }
  
  public Statement getMetadataSafeStatement()
    throws SQLException
  {
    try
    {
      return mc.getMetadataSafeStatement();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public ServerVersion getServerVersion()
  {
    return mc.getServerVersion();
  }
  
  public List<QueryInterceptor> getQueryInterceptorsInstances()
  {
    return mc.getQueryInterceptorsInstances();
  }
  
  public void initializeResultsMetadataFromCache(String sql, CachedResultSetMetaData cachedMetaData, ResultSetInternalMethods resultSet)
    throws SQLException
  {
    try
    {
      mc.initializeResultsMetadataFromCache(sql, cachedMetaData, resultSet);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void initializeSafeQueryInterceptors()
    throws SQLException
  {
    try
    {
      mc.initializeSafeQueryInterceptors();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean isReadOnly(boolean useSessionStatus)
    throws SQLException
  {
    try
    {
      checkClosed();return mc.isReadOnly(useSessionStatus);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void pingInternal(boolean checkForClosedConnection, int timeoutMillis)
    throws SQLException
  {
    try
    {
      mc.pingInternal(checkForClosedConnection, timeoutMillis);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void realClose(boolean calledExplicitly, boolean issueRollback, boolean skipLocalTeardown, Throwable reason)
    throws SQLException
  {
    try
    {
      mc.realClose(calledExplicitly, issueRollback, skipLocalTeardown, reason);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void recachePreparedStatement(JdbcPreparedStatement pstmt)
    throws SQLException
  {
    try
    {
      mc.recachePreparedStatement(pstmt);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void decachePreparedStatement(JdbcPreparedStatement pstmt)
    throws SQLException
  {
    try
    {
      mc.decachePreparedStatement(pstmt);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void registerStatement(JdbcStatement stmt)
  {
    mc.registerStatement(stmt);
  }
  
  public void setReadOnlyInternal(boolean readOnlyFlag)
    throws SQLException
  {
    try
    {
      mc.setReadOnlyInternal(readOnlyFlag);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public boolean storesLowerCaseTableName()
  {
    return mc.storesLowerCaseTableName();
  }
  
  public void throwConnectionClosedException()
    throws SQLException
  {
    try
    {
      mc.throwConnectionClosedException();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public void transactionBegun()
  {
    mc.transactionBegun();
  }
  
  public void transactionCompleted()
  {
    mc.transactionCompleted();
  }
  
  public void unregisterStatement(JdbcStatement stmt)
  {
    mc.unregisterStatement(stmt);
  }
  
  public void unSafeQueryInterceptors()
    throws SQLException
  {
    try
    {
      mc.unSafeQueryInterceptors();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public JdbcConnection getMultiHostSafeProxy()
  {
    return mc.getMultiHostSafeProxy();
  }
  
  public JdbcConnection getActiveMySQLConnection()
  {
    return mc.getActiveMySQLConnection();
  }
  
  public ClientInfoProvider getClientInfoProviderImpl()
    throws SQLException
  {
    try
    {
      return mc.getClientInfoProviderImpl();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, exceptionInterceptor);
    }
  }
  
  public String getHostPortPair()
  {
    return mc.getHostPortPair();
  }
  
  public void normalClose()
  {
    mc.normalClose();
  }
  
  public void cleanup(Throwable whyCleanedUp)
  {
    mc.cleanup(whyCleanedUp);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionWrapper
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */