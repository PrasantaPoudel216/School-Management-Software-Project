package com.mysql.cj.jdbc;

import com.mysql.cj.MysqlType;
import com.mysql.cj.ParseInfo;
import com.mysql.cj.QueryBindings;
import java.math.BigInteger;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public abstract interface JdbcPreparedStatement
  extends PreparedStatement, JdbcStatement
{
  public abstract void realClose(boolean paramBoolean1, boolean paramBoolean2)
    throws SQLException;
  
  public abstract QueryBindings<?> getQueryBindings();
  
  public abstract byte[] getBytesRepresentation(int paramInt)
    throws SQLException;
  
  public abstract ParseInfo getParseInfo();
  
  public abstract boolean isNull(int paramInt)
    throws SQLException;
  
  public abstract String getPreparedSql();
  
  public abstract void setBytes(int paramInt, byte[] paramArrayOfByte, boolean paramBoolean1, boolean paramBoolean2)
    throws SQLException;
  
  public abstract void setBytesNoEscape(int paramInt, byte[] paramArrayOfByte)
    throws SQLException;
  
  public abstract void setBytesNoEscapeNoQuotes(int paramInt, byte[] paramArrayOfByte)
    throws SQLException;
  
  public abstract void setBigInteger(int paramInt, BigInteger paramBigInteger)
    throws SQLException;
  
  public abstract void setNull(int paramInt, MysqlType paramMysqlType)
    throws SQLException;
  
  public abstract ParameterBindings getParameterBindings()
    throws SQLException;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.JdbcPreparedStatement
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */