package com.mysql.cj.jdbc;

import java.sql.Connection;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.util.Enumeration;
import java.util.Properties;

public class CommentClientInfoProvider
  implements ClientInfoProvider
{
  private Properties clientInfo;
  
  public synchronized void initialize(Connection conn, Properties configurationProps)
    throws SQLException
  {
    clientInfo = new Properties();
  }
  
  public synchronized void destroy()
    throws SQLException
  {
    clientInfo = null;
  }
  
  public synchronized Properties getClientInfo(Connection conn)
    throws SQLException
  {
    return clientInfo;
  }
  
  public synchronized String getClientInfo(Connection conn, String name)
    throws SQLException
  {
    return clientInfo.getProperty(name);
  }
  
  public synchronized void setClientInfo(Connection conn, Properties properties)
    throws SQLClientInfoException
  {
    clientInfo = new Properties();
    
    Enumeration<?> propNames = properties.propertyNames();
    while (propNames.hasMoreElements())
    {
      String name = (String)propNames.nextElement();
      
      clientInfo.put(name, properties.getProperty(name));
    }
    setComment(conn);
  }
  
  public synchronized void setClientInfo(Connection conn, String name, String value)
    throws SQLClientInfoException
  {
    clientInfo.setProperty(name, value);
    setComment(conn);
  }
  
  private synchronized void setComment(Connection conn)
  {
    StringBuilder commentBuf = new StringBuilder();
    
    Enumeration<?> propNames = clientInfo.propertyNames();
    while (propNames.hasMoreElements())
    {
      String name = (String)propNames.nextElement();
      if (commentBuf.length() > 0) {
        commentBuf.append(", ");
      }
      commentBuf.append("" + name);
      commentBuf.append("=");
      commentBuf.append("" + clientInfo.getProperty(name));
    }
    ((JdbcConnection)conn).setStatementComment(commentBuf.toString());
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.CommentClientInfoProvider
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */