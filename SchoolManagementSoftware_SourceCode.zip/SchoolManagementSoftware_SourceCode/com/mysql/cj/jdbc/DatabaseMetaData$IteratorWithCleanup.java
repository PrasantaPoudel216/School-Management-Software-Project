package com.mysql.cj.jdbc;

import java.sql.SQLException;

public abstract class DatabaseMetaData$IteratorWithCleanup<T>
{
  protected DatabaseMetaData$IteratorWithCleanup(DatabaseMetaData this$0) {}
  
  abstract void close()
    throws SQLException;
  
  abstract boolean hasNext()
    throws SQLException;
  
  abstract T next()
    throws SQLException;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.IteratorWithCleanup
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */