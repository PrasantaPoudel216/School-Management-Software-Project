package com.mysql.cj.jdbc;

public enum DatabaseMetaData$TableType
{
  LOCAL_TEMPORARY("LOCAL TEMPORARY"),  SYSTEM_TABLE("SYSTEM TABLE"),  SYSTEM_VIEW("SYSTEM VIEW"),  TABLE("TABLE", new String[] { "BASE TABLE" }),  VIEW("VIEW"),  UNKNOWN("UNKNOWN");
  
  private String name;
  private byte[] nameAsBytes;
  private String[] synonyms;
  
  private DatabaseMetaData$TableType(String tableTypeName)
  {
    this(tableTypeName, null);
  }
  
  private DatabaseMetaData$TableType(String tableTypeName, String[] tableTypeSynonyms)
  {
    name = tableTypeName;
    nameAsBytes = tableTypeName.getBytes();
    synonyms = tableTypeSynonyms;
  }
  
  String getName()
  {
    return name;
  }
  
  byte[] asBytes()
  {
    return nameAsBytes;
  }
  
  boolean equalsTo(String tableTypeName)
  {
    return name.equalsIgnoreCase(tableTypeName);
  }
  
  static TableType getTableTypeEqualTo(String tableTypeName)
  {
    for (TableType tableType : ) {
      if (tableType.equalsTo(tableTypeName)) {
        return tableType;
      }
    }
    return UNKNOWN;
  }
  
  boolean compliesWith(String tableTypeName)
  {
    if (equalsTo(tableTypeName)) {
      return true;
    }
    if (synonyms != null) {
      for (String synonym : synonyms) {
        if (synonym.equalsIgnoreCase(tableTypeName)) {
          return true;
        }
      }
    }
    return false;
  }
  
  static TableType getTableTypeCompliantWith(String tableTypeName)
  {
    for (TableType tableType : ) {
      if (tableType.compliesWith(tableTypeName)) {
        return tableType;
      }
    }
    return UNKNOWN;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.TableType
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */