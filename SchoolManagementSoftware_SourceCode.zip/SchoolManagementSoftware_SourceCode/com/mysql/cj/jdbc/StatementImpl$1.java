package com.mysql.cj.jdbc;

import com.mysql.cj.TransactionEventHandler;

class StatementImpl$1
  implements TransactionEventHandler
{
  StatementImpl$1(StatementImpl this$0) {}
  
  public void transactionCompleted() {}
  
  public void transactionBegun() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.StatementImpl.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */