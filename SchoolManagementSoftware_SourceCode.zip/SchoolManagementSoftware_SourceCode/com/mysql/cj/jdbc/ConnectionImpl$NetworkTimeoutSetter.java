package com.mysql.cj.jdbc;

import com.mysql.cj.NativeSession;
import java.lang.ref.WeakReference;

class ConnectionImpl$NetworkTimeoutSetter
  implements Runnable
{
  private final WeakReference<JdbcConnection> connRef;
  private final int milliseconds;
  
  public ConnectionImpl$NetworkTimeoutSetter(JdbcConnection conn, int milliseconds)
  {
    connRef = new WeakReference(conn);
    this.milliseconds = milliseconds;
  }
  
  public void run()
  {
    JdbcConnection conn = (JdbcConnection)connRef.get();
    if (conn != null) {
      synchronized (conn.getConnectionMutex())
      {
        ((NativeSession)conn.getSession()).setSocketTimeout(milliseconds);
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionImpl.NetworkTimeoutSetter
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */