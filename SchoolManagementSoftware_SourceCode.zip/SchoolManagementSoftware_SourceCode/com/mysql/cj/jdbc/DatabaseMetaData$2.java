package com.mysql.cj.jdbc;

import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.conf.PropertyDefinitions.DatabaseTerm;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.AssertionFailedException;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.util.StringUtils;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

class DatabaseMetaData$2
  extends IterateBlock<String>
{
  DatabaseMetaData$2(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, boolean paramBoolean, String paramString1, String paramString2, String paramString3, Statement paramStatement, ArrayList paramArrayList)
  {
    super(i);
  }
  
  void forEach(String dbStr)
    throws SQLException
  {
    ArrayList<String> tableNameList = new ArrayList();
    
    ResultSet tables = null;
    try
    {
      tables = val$dbMapsToSchema ? this$0.getTables(null, dbStr, val$tableNamePattern, new String[0]) : this$0.getTables(dbStr, val$schemaPattern, val$tableNamePattern, new String[0]);
      while (tables.next())
      {
        String tableNameFromList = tables.getString("TABLE_NAME");
        tableNameList.add(tableNameFromList);
      }
    }
    finally
    {
      if (tables != null)
      {
        try
        {
          tables.close();
        }
        catch (Exception sqlEx)
        {
          AssertionFailedException.shouldNotHappen(sqlEx);
        }
        tables = null;
      }
    }
    for (String tableName : tableNameList)
    {
      ResultSet results = null;
      try
      {
        StringBuilder queryBuf = new StringBuilder("SHOW FULL COLUMNS FROM ");
        queryBuf.append(StringUtils.quoteIdentifier(tableName, this$0.quotedId, this$0.pedantic));
        queryBuf.append(" FROM ");
        queryBuf.append(StringUtils.quoteIdentifier(dbStr, this$0.quotedId, this$0.pedantic));
        if (val$colPattern != null)
        {
          queryBuf.append(" LIKE ");
          queryBuf.append(StringUtils.quoteIdentifier(val$colPattern, "'", true));
        }
        boolean fixUpOrdinalsRequired = false;
        Map<String, Integer> ordinalFixUpMap = null;
        if ((val$colPattern != null) && (!val$colPattern.equals("%")))
        {
          fixUpOrdinalsRequired = true;
          
          StringBuilder fullColumnQueryBuf = new StringBuilder("SHOW FULL COLUMNS FROM ");
          fullColumnQueryBuf
            .append(StringUtils.quoteIdentifier(tableName, this$0.quotedId, this$0.pedantic));
          fullColumnQueryBuf.append(" FROM ");
          fullColumnQueryBuf.append(StringUtils.quoteIdentifier(dbStr, this$0.quotedId, this$0.pedantic));
          
          results = val$stmt.executeQuery(fullColumnQueryBuf.toString());
          
          ordinalFixUpMap = new HashMap();
          
          int fullOrdinalPos = 1;
          while (results.next())
          {
            String fullOrdColName = results.getString("Field");
            
            ordinalFixUpMap.put(fullOrdColName, Integer.valueOf(fullOrdinalPos++));
          }
          results.close();
        }
        results = val$stmt.executeQuery(queryBuf.toString());
        
        int ordPos = 1;
        while (results.next())
        {
          DatabaseMetaData.TypeDescriptor typeDesc = new DatabaseMetaData.TypeDescriptor(this$0, results.getString("Type"), results.getString("Null"));
          
          byte[][] rowVal = new byte[24][];
          rowVal[0] = (this$0.databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? this$0.s2b("def") : this$0.s2b(dbStr));
          rowVal[1] = (this$0.databaseTerm.getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? this$0.s2b(dbStr) : null);
          rowVal[2] = this$0.s2b(tableName);
          rowVal[3] = results.getBytes("Field");
          rowVal[4] = Short.toString((short)mysqlType.getJdbcType()).getBytes();
          rowVal[5] = this$0.s2b(mysqlType.getName());
          if (columnSize == null)
          {
            rowVal[6] = null;
          }
          else
          {
            String collation = results.getString("Collation");
            int mbminlen = 1;
            if (collation != null) {
              if ((collation.indexOf("ucs2") > -1) || (collation.indexOf("utf16") > -1)) {
                mbminlen = 2;
              } else if (collation.indexOf("utf32") > -1) {
                mbminlen = 4;
              }
            }
            rowVal[6] = (mbminlen == 1 ? this$0.s2b(columnSize.toString()) : this$0.s2b(Integer.valueOf(columnSize.intValue() / mbminlen).toString()));
          }
          rowVal[7] = this$0.s2b(Integer.toString(bufferLength));
          rowVal[8] = (decimalDigits == null ? null : this$0.s2b(decimalDigits.toString()));
          rowVal[9] = this$0.s2b(Integer.toString(numPrecRadix));
          rowVal[10] = this$0.s2b(Integer.toString(nullability));
          try
          {
            rowVal[11] = results.getBytes("Comment");
          }
          catch (Exception E)
          {
            rowVal[11] = new byte[0];
          }
          rowVal[12] = results.getBytes("Default");
          rowVal[13] = { 48 };
          rowVal[14] = { 48 };
          if ((StringUtils.indexOfIgnoreCase(mysqlType.getName(), "CHAR") != -1) || 
            (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "BLOB") != -1) || 
            (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "TEXT") != -1) || 
            (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "ENUM") != -1) || 
            (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "SET") != -1) || 
            (StringUtils.indexOfIgnoreCase(mysqlType.getName(), "BINARY") != -1)) {
            rowVal[15] = rowVal[6];
          } else {
            rowVal[15] = null;
          }
          if (!fixUpOrdinalsRequired)
          {
            rowVal[16] = Integer.toString(ordPos++).getBytes();
          }
          else
          {
            String origColName = results.getString("Field");
            Integer realOrdinal = (Integer)ordinalFixUpMap.get(origColName);
            if (realOrdinal != null) {
              rowVal[16] = realOrdinal.toString().getBytes();
            } else {
              throw SQLError.createSQLException(Messages.getString("DatabaseMetaData.10"), "S1000", this$0
                .getExceptionInterceptor());
            }
          }
          rowVal[17] = this$0.s2b(isNullable);
          
          rowVal[18] = null;
          rowVal[19] = null;
          rowVal[20] = null;
          rowVal[21] = null;
          
          rowVal[22] = this$0.s2b("");
          
          String extra = results.getString("Extra");
          if (extra != null)
          {
            rowVal[22] = this$0.s2b(StringUtils.indexOfIgnoreCase(extra, "auto_increment") != -1 ? "YES" : "NO");
            rowVal[23] = this$0.s2b(StringUtils.indexOfIgnoreCase(extra, "generated") != -1 ? "YES" : "NO");
          }
          val$rows.add(new ByteArrayRow(rowVal, this$0.getExceptionInterceptor()));
        }
      }
      finally
      {
        if (results != null)
        {
          try
          {
            results.close();
          }
          catch (Exception localException2) {}
          results = null;
        }
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.2
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */