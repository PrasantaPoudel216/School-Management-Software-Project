package com.mysql.cj.jdbc;

import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import java.sql.Connection;
import java.sql.SQLException;
import javax.sql.ConnectionPoolDataSource;
import javax.sql.PooledConnection;

public class MysqlConnectionPoolDataSource
  extends MysqlDataSource
  implements ConnectionPoolDataSource
{
  static final long serialVersionUID = -7767325445592304961L;
  
  public synchronized PooledConnection getPooledConnection()
    throws SQLException
  {
    try
    {
      Connection connection = getConnection();
      return MysqlPooledConnection.getInstance((JdbcConnection)connection);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public synchronized PooledConnection getPooledConnection(String u, String p)
    throws SQLException
  {
    try
    {
      Connection connection = getConnection(u, p);
      return MysqlPooledConnection.getInstance((JdbcConnection)connection);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.MysqlConnectionPoolDataSource
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */