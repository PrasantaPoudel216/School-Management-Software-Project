package com.mysql.cj.jdbc;

class ConnectionImpl$CompoundCacheKey
{
  final String componentOne;
  final String componentTwo;
  final int hashCode;
  
  ConnectionImpl$CompoundCacheKey(String partOne, String partTwo)
  {
    componentOne = partOne;
    componentTwo = partTwo;
    
    int hc = 17;
    hc = 31 * hc + (componentOne != null ? componentOne.hashCode() : 0);
    hc = 31 * hc + (componentTwo != null ? componentTwo.hashCode() : 0);
    hashCode = hc;
  }
  
  public boolean equals(Object obj)
  {
    if (this == obj) {
      return true;
    }
    if ((obj != null) && (CompoundCacheKey.class.isAssignableFrom(obj.getClass())))
    {
      CompoundCacheKey another = (CompoundCacheKey)obj;
      if (componentOne == null ? componentOne == null : componentOne.equals(componentOne)) {
        return componentTwo == null ? false : componentTwo == null ? true : componentTwo.equals(componentTwo);
      }
    }
    return false;
  }
  
  public int hashCode()
  {
    return hashCode;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.ConnectionImpl.CompoundCacheKey
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */