package com.mysql.cj.jdbc;

import java.util.List;

class DatabaseMetaData$LocalAndReferencedColumns
{
  String constraintName;
  List<String> localColumnsList;
  String referencedDatabase;
  List<String> referencedColumnsList;
  String referencedTable;
  
  DatabaseMetaData$LocalAndReferencedColumns(List<String> this$0, List<String> localColumns, String refColumns, String constName, String refDatabase)
  {
    localColumnsList = localColumns;
    referencedColumnsList = refColumns;
    constraintName = constName;
    referencedTable = refTable;
    referencedDatabase = refDatabase;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.LocalAndReferencedColumns
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */