package com.mysql.cj.jdbc;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;
import javax.sql.XAConnection;
import javax.transaction.xa.XAException;
import javax.transaction.xa.XAResource;
import javax.transaction.xa.Xid;

public class SuspendableXAConnection
  extends MysqlPooledConnection
  implements XAConnection, XAResource
{
  protected static SuspendableXAConnection getInstance(JdbcConnection mysqlConnection)
    throws SQLException
  {
    return new SuspendableXAConnection(mysqlConnection);
  }
  
  public SuspendableXAConnection(JdbcConnection connection)
  {
    super(connection);
    underlyingConnection = connection;
  }
  
  private static final Map<Xid, XAConnection> XIDS_TO_PHYSICAL_CONNECTIONS = new HashMap();
  private Xid currentXid;
  private XAConnection currentXAConnection;
  private XAResource currentXAResource;
  private JdbcConnection underlyingConnection;
  
  private static synchronized XAConnection findConnectionForXid(JdbcConnection connectionToWrap, Xid xid)
    throws SQLException
  {
    XAConnection conn = (XAConnection)XIDS_TO_PHYSICAL_CONNECTIONS.get(xid);
    if (conn == null)
    {
      conn = new MysqlXAConnection(connectionToWrap, ((Boolean)connectionToWrap.getPropertySet().getBooleanProperty(PropertyKey.logXaCommands).getValue()).booleanValue());
      XIDS_TO_PHYSICAL_CONNECTIONS.put(xid, conn);
    }
    return conn;
  }
  
  private static synchronized void removeXAConnectionMapping(Xid xid)
  {
    XIDS_TO_PHYSICAL_CONNECTIONS.remove(xid);
  }
  
  private synchronized void switchToXid(Xid xid)
    throws XAException
  {
    if (xid == null) {
      throw new XAException();
    }
    try
    {
      if (!xid.equals(currentXid))
      {
        XAConnection toSwitchTo = findConnectionForXid(underlyingConnection, xid);
        currentXAConnection = toSwitchTo;
        currentXid = xid;
        currentXAResource = toSwitchTo.getXAResource();
      }
    }
    catch (SQLException sqlEx)
    {
      throw new XAException();
    }
  }
  
  public XAResource getXAResource()
    throws SQLException
  {
    try
    {
      return this;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public void commit(Xid xid, boolean arg1)
    throws XAException
  {
    switchToXid(xid);
    currentXAResource.commit(xid, arg1);
    removeXAConnectionMapping(xid);
  }
  
  public void end(Xid xid, int arg1)
    throws XAException
  {
    switchToXid(xid);
    currentXAResource.end(xid, arg1);
  }
  
  public void forget(Xid xid)
    throws XAException
  {
    switchToXid(xid);
    currentXAResource.forget(xid);
    
    removeXAConnectionMapping(xid);
  }
  
  public int getTransactionTimeout()
    throws XAException
  {
    return 0;
  }
  
  public boolean isSameRM(XAResource xaRes)
    throws XAException
  {
    return xaRes == this;
  }
  
  public int prepare(Xid xid)
    throws XAException
  {
    switchToXid(xid);
    return currentXAResource.prepare(xid);
  }
  
  public Xid[] recover(int flag)
    throws XAException
  {
    return MysqlXAConnection.recover(underlyingConnection, flag);
  }
  
  public void rollback(Xid xid)
    throws XAException
  {
    switchToXid(xid);
    currentXAResource.rollback(xid);
    removeXAConnectionMapping(xid);
  }
  
  public boolean setTransactionTimeout(int arg0)
    throws XAException
  {
    return false;
  }
  
  public void start(Xid xid, int arg1)
    throws XAException
  {
    switchToXid(xid);
    if (arg1 != 2097152)
    {
      currentXAResource.start(xid, arg1);
      
      return;
    }
    currentXAResource.start(xid, 134217728);
  }
  
  public synchronized Connection getConnection()
    throws SQLException
  {
    try
    {
      if (currentXAConnection == null) {
        return getConnection(false, true);
      }
      return currentXAConnection.getConnection();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
  
  public void close()
    throws SQLException
  {
    try
    {
      if (currentXAConnection == null)
      {
        super.close();
      }
      else
      {
        removeXAConnectionMapping(currentXid);
        currentXAConnection.close();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.SuspendableXAConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */