package com.mysql.cj.jdbc;

import com.mysql.cj.exceptions.AssertionFailedException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.StringTokenizer;

class DatabaseMetaData$4
  extends IterateBlock<String>
{
  DatabaseMetaData$4(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, String paramString, ArrayList paramArrayList)
  {
    super(i);
  }
  
  void forEach(String dbStr)
    throws SQLException
  {
    ResultSet fkresults = null;
    try
    {
      fkresults = this$0.extractForeignKeyFromCreateTable(dbStr, null);
      
      String tableNameWithCase = this$0.getTableNameWithCase(val$table);
      while (fkresults.next())
      {
        String tableType = fkresults.getString("Type");
        if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
        {
          String comment = fkresults.getString("Comment").trim();
          if (comment != null)
          {
            StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
            if (commentTokens.hasMoreTokens())
            {
              commentTokens.nextToken();
              while (commentTokens.hasMoreTokens())
              {
                String keysComment = commentTokens.nextToken();
                this$0.populateKeyResults(dbStr, tableNameWithCase, keysComment, val$rows, fkresults.getString("Name"), true);
              }
            }
          }
        }
      }
    }
    finally
    {
      if (fkresults != null)
      {
        try
        {
          fkresults.close();
        }
        catch (SQLException sqlEx)
        {
          AssertionFailedException.shouldNotHappen(sqlEx);
        }
        fkresults = null;
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.4
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */