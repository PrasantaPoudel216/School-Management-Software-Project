package com.mysql.cj.jdbc.integration.c3p0;

import com.mchange.v2.c3p0.QueryConnectionTester;
import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.jdbc.JdbcConnection;
import com.mysql.cj.jdbc.exceptions.CommunicationsException;
import java.lang.reflect.Method;
import java.sql.Connection;
import java.sql.SQLException;

public final class MysqlConnectionTester
  implements QueryConnectionTester
{
  private static final long serialVersionUID = 3256444690067896368L;
  private static final Object[] NO_ARGS_ARRAY = new Object[0];
  private transient Method pingMethod;
  
  public MysqlConnectionTester()
  {
    try
    {
      pingMethod = JdbcConnection.class.getMethod("ping", (Class[])null);
    }
    catch (Exception localException) {}
  }
  
  /* Error */
  public int activeCheckConnection(Connection con)
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 6	com/mysql/cj/jdbc/integration/c3p0/MysqlConnectionTester:pingMethod	Ljava/lang/reflect/Method;
    //   4: ifnull +47 -> 51
    //   7: aload_1
    //   8: instanceof 2
    //   11: ifeq +15 -> 26
    //   14: aload_1
    //   15: checkcast 2	com/mysql/cj/jdbc/JdbcConnection
    //   18: invokeinterface 8 1 0
    //   23: goto +76 -> 99
    //   26: aload_1
    //   27: checkcast 9	com/mchange/v2/c3p0/C3P0ProxyConnection
    //   30: astore_2
    //   31: aload_2
    //   32: aload_0
    //   33: getfield 6	com/mysql/cj/jdbc/integration/c3p0/MysqlConnectionTester:pingMethod	Ljava/lang/reflect/Method;
    //   36: getstatic 10	com/mchange/v2/c3p0/C3P0ProxyConnection:RAW_CONNECTION	Ljava/lang/Object;
    //   39: getstatic 11	com/mysql/cj/jdbc/integration/c3p0/MysqlConnectionTester:NO_ARGS_ARRAY	[Ljava/lang/Object;
    //   42: invokeinterface 12 4 0
    //   47: pop
    //   48: goto +51 -> 99
    //   51: aconst_null
    //   52: astore_2
    //   53: aload_1
    //   54: invokeinterface 13 1 0
    //   59: astore_2
    //   60: aload_2
    //   61: ldc 14
    //   63: invokeinterface 15 2 0
    //   68: invokeinterface 16 1 0
    //   73: aload_2
    //   74: ifnull +25 -> 99
    //   77: aload_2
    //   78: invokeinterface 17 1 0
    //   83: goto +16 -> 99
    //   86: astore_3
    //   87: aload_2
    //   88: ifnull +9 -> 97
    //   91: aload_2
    //   92: invokeinterface 17 1 0
    //   97: aload_3
    //   98: athrow
    //   99: iconst_0
    //   100: ireturn
    //   101: astore_2
    //   102: iconst_m1
    //   103: ireturn
    // Line number table:
    //   Java source line #66	-> byte code offset #0
    //   Java source line #67	-> byte code offset #7
    //   Java source line #69	-> byte code offset #14
    //   Java source line #72	-> byte code offset #26
    //   Java source line #73	-> byte code offset #31
    //   Java source line #74	-> byte code offset #48
    //   Java source line #76	-> byte code offset #51
    //   Java source line #79	-> byte code offset #53
    //   Java source line #80	-> byte code offset #60
    //   Java source line #82	-> byte code offset #73
    //   Java source line #83	-> byte code offset #77
    //   Java source line #82	-> byte code offset #86
    //   Java source line #83	-> byte code offset #91
    //   Java source line #85	-> byte code offset #97
    //   Java source line #88	-> byte code offset #99
    //   Java source line #89	-> byte code offset #101
    //   Java source line #90	-> byte code offset #102
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	104	0	this	MysqlConnectionTester
    //   0	104	1	con	Connection
    //   30	2	2	castCon	com.mchange.v2.c3p0.C3P0ProxyConnection
    //   52	40	2	pingStatement	java.sql.Statement
    //   101	2	2	ex	Exception
    //   86	12	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   53	73	86	finally
    //   0	100	101	java/lang/Exception
  }
  
  public int statusOnException(Connection arg0, Throwable throwable)
  {
    if (((throwable instanceof CommunicationsException)) || ((throwable instanceof CJCommunicationsException))) {
      return -1;
    }
    if ((throwable instanceof SQLException))
    {
      String sqlState = ((SQLException)throwable).getSQLState();
      if ((sqlState != null) && (sqlState.startsWith("08"))) {
        return -1;
      }
      return 0;
    }
    return -1;
  }
  
  public int activeCheckConnection(Connection arg0, String arg1)
  {
    return 0;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.integration.c3p0.MysqlConnectionTester
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */