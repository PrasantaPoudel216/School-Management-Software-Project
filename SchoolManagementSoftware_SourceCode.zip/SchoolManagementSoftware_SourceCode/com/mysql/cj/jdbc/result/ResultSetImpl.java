package com.mysql.cj.jdbc.result;

import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.NativeSession;
import com.mysql.cj.Query;
import com.mysql.cj.Session;
import com.mysql.cj.WarningListener;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.jdbc.BlobFromLocator;
import com.mysql.cj.jdbc.JdbcConnection;
import com.mysql.cj.jdbc.JdbcPreparedStatement;
import com.mysql.cj.jdbc.JdbcPropertySet;
import com.mysql.cj.jdbc.JdbcStatement;
import com.mysql.cj.jdbc.MysqlSQLXML;
import com.mysql.cj.jdbc.StatementImpl;
import com.mysql.cj.jdbc.exceptions.NotUpdatable;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.log.BaseMetricsHolder;
import com.mysql.cj.log.ProfilerEventHandler;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.a.NativeProtocol;
import com.mysql.cj.protocol.a.result.NativeResultset;
import com.mysql.cj.protocol.a.result.OkPacket;
import com.mysql.cj.result.BigDecimalValueFactory;
import com.mysql.cj.result.BinaryStreamValueFactory;
import com.mysql.cj.result.BooleanValueFactory;
import com.mysql.cj.result.ByteValueFactory;
import com.mysql.cj.result.DoubleValueFactory;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.FloatValueFactory;
import com.mysql.cj.result.IntegerValueFactory;
import com.mysql.cj.result.LocalDateTimeValueFactory;
import com.mysql.cj.result.LocalDateValueFactory;
import com.mysql.cj.result.LocalTimeValueFactory;
import com.mysql.cj.result.LongValueFactory;
import com.mysql.cj.result.Row;
import com.mysql.cj.result.ShortValueFactory;
import com.mysql.cj.result.SqlDateValueFactory;
import com.mysql.cj.result.SqlTimeValueFactory;
import com.mysql.cj.result.SqlTimestampValueFactory;
import com.mysql.cj.result.StringValueFactory;
import com.mysql.cj.result.ValueFactory;
import com.mysql.cj.util.LogUtils;
import com.mysql.cj.util.StringUtils;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Array;
import java.sql.Date;
import java.sql.Ref;
import java.sql.RowId;
import java.sql.SQLException;
import java.sql.SQLFeatureNotSupportedException;
import java.sql.SQLType;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Statement;
import java.sql.Struct;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.format.DateTimeParseException;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;

public class ResultSetImpl
  extends NativeResultset
  implements ResultSetInternalMethods, WarningListener
{
  static int resultCounter = 1;
  protected String db = null;
  protected boolean[] columnUsed = null;
  protected volatile JdbcConnection connection;
  protected NativeSession session = null;
  protected int currentRow = -1;
  protected ProfilerEventHandler eventSink = null;
  Calendar fastDefaultCal = null;
  Calendar fastClientCal = null;
  protected int fetchDirection = 1000;
  protected int fetchSize = 0;
  protected char firstCharOfQuery;
  protected boolean isClosed = false;
  private StatementImpl owningStatement;
  private String pointOfOrigin;
  protected int resultSetConcurrency = 0;
  protected int resultSetType = 0;
  JdbcPreparedStatement statementUsedForFetchingRows;
  protected boolean useUsageAdvisor = false;
  protected boolean gatherPerfMetrics = false;
  protected SQLWarning warningChain = null;
  protected Statement wrapperStatement;
  private boolean padCharsWithSpace = false;
  private boolean useColumnNamesInFindColumn;
  private ExceptionInterceptor exceptionInterceptor;
  private ValueFactory<Boolean> booleanValueFactory;
  private ValueFactory<Byte> byteValueFactory;
  private ValueFactory<Short> shortValueFactory;
  private ValueFactory<Integer> integerValueFactory;
  private ValueFactory<Long> longValueFactory;
  private ValueFactory<Float> floatValueFactory;
  private ValueFactory<Double> doubleValueFactory;
  private ValueFactory<BigDecimal> bigDecimalValueFactory;
  private ValueFactory<InputStream> binaryStreamValueFactory;
  private ValueFactory<Date> defaultDateValueFactory;
  private ValueFactory<Time> defaultTimeValueFactory;
  private ValueFactory<Timestamp> defaultTimestampValueFactory;
  private ValueFactory<LocalDate> defaultLocalDateValueFactory;
  private ValueFactory<LocalDateTime> defaultLocalDateTimeValueFactory;
  private ValueFactory<LocalTime> defaultLocalTimeValueFactory;
  protected RuntimeProperty<Boolean> emulateLocators;
  protected boolean yearIsDateType = true;
  
  public ResultSetImpl(OkPacket ok, JdbcConnection conn, StatementImpl creatorStmt)
  {
    super(ok);
    
    connection = conn;
    owningStatement = creatorStmt;
    if (connection != null)
    {
      exceptionInterceptor = connection.getExceptionInterceptor();
      
      padCharsWithSpace = ((Boolean)connection.getPropertySet().getBooleanProperty(PropertyKey.padCharsWithSpace).getValue()).booleanValue();
    }
  }
  
  public ResultSetImpl(ResultsetRows tuples, JdbcConnection conn, StatementImpl creatorStmt)
    throws SQLException
  {
    connection = conn;
    session = ((NativeSession)conn.getSession());
    
    db = (creatorStmt != null ? creatorStmt.getCurrentDatabase() : conn.getDatabase());
    owningStatement = creatorStmt;
    
    exceptionInterceptor = connection.getExceptionInterceptor();
    
    PropertySet pset = connection.getPropertySet();
    emulateLocators = pset.getBooleanProperty(PropertyKey.emulateLocators);
    padCharsWithSpace = ((Boolean)pset.getBooleanProperty(PropertyKey.padCharsWithSpace).getValue()).booleanValue();
    yearIsDateType = ((Boolean)pset.getBooleanProperty(PropertyKey.yearIsDateType).getValue()).booleanValue();
    useUsageAdvisor = ((Boolean)pset.getBooleanProperty(PropertyKey.useUsageAdvisor).getValue()).booleanValue();
    gatherPerfMetrics = ((Boolean)pset.getBooleanProperty(PropertyKey.gatherPerfMetrics).getValue()).booleanValue();
    
    booleanValueFactory = new BooleanValueFactory(pset);
    byteValueFactory = new ByteValueFactory(pset);
    shortValueFactory = new ShortValueFactory(pset);
    integerValueFactory = new IntegerValueFactory(pset);
    longValueFactory = new LongValueFactory(pset);
    floatValueFactory = new FloatValueFactory(pset);
    doubleValueFactory = new DoubleValueFactory(pset);
    bigDecimalValueFactory = new BigDecimalValueFactory(pset);
    binaryStreamValueFactory = new BinaryStreamValueFactory(pset);
    
    defaultDateValueFactory = new SqlDateValueFactory(pset, null, session.getServerSession().getDefaultTimeZone(), this);
    defaultTimeValueFactory = new SqlTimeValueFactory(pset, null, session.getServerSession().getDefaultTimeZone(), this);
    defaultTimestampValueFactory = new SqlTimestampValueFactory(pset, null, session.getServerSession().getDefaultTimeZone());
    
    defaultLocalDateValueFactory = new LocalDateValueFactory(pset, this);
    defaultLocalTimeValueFactory = new LocalTimeValueFactory(pset, this);
    defaultLocalDateTimeValueFactory = new LocalDateTimeValueFactory(pset);
    
    columnDefinition = tuples.getMetadata();
    rowData = tuples;
    updateCount = rowData.size();
    if (rowData.size() > 0)
    {
      if ((updateCount == 1L) && 
        (thisRow == null))
      {
        rowData.close();
        updateCount = -1L;
      }
    }
    else {
      thisRow = null;
    }
    rowData.setOwner(this);
    if (columnDefinition.getFields() != null) {
      initializeWithMetadata();
    }
    useColumnNamesInFindColumn = ((Boolean)pset.getBooleanProperty(PropertyKey.useColumnNamesInFindColumn).getValue()).booleanValue();
    
    setRowPositionValidity();
  }
  
  public void initializeWithMetadata()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        initRowsWithMetadata();
        if (useUsageAdvisor)
        {
          columnUsed = new boolean[columnDefinition.getFields().length];
          pointOfOrigin = LogUtils.findCallingClassAndMethod(new Throwable());
          resultId = (resultCounter++);
          eventSink = session.getProfilerEventHandler();
        }
        if (gatherPerfMetrics)
        {
          session.getProtocol().getMetricsHolder().incrementNumberOfResultSetsCreated();
          
          Set<String> tableNamesSet = new HashSet();
          for (int i = 0; i < columnDefinition.getFields().length; i++)
          {
            Field f = columnDefinition.getFields()[i];
            
            String tableName = f.getOriginalTableName();
            if (tableName == null) {
              tableName = f.getTableName();
            }
            if (tableName != null)
            {
              if (connection.lowerCaseTableNames()) {
                tableName = tableName.toLowerCase();
              }
              tableNamesSet.add(tableName);
            }
          }
          session.getProtocol().getMetricsHolder().reportNumberOfTablesAccessed(tableNamesSet.size());
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean absolute(int row)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        boolean b;
        boolean b;
        if (rowData.size() == 0)
        {
          b = false;
        }
        else
        {
          boolean b;
          if (row == 0)
          {
            beforeFirst();
            b = false;
          }
          else
          {
            boolean b;
            if (row == 1)
            {
              b = first();
            }
            else
            {
              boolean b;
              if (row == -1)
              {
                b = last();
              }
              else
              {
                boolean b;
                if (row > rowData.size())
                {
                  afterLast();
                  b = false;
                }
                else
                {
                  boolean b;
                  if (row < 0)
                  {
                    int newRowPosition = rowData.size() + row + 1;
                    boolean b;
                    if (newRowPosition <= 0)
                    {
                      beforeFirst();
                      b = false;
                    }
                    else
                    {
                      b = absolute(newRowPosition);
                    }
                  }
                  else
                  {
                    row--;
                    rowData.setCurrentRow(row);
                    thisRow = rowData.get(row);
                    b = true;
                  }
                }
              }
            }
          }
        }
        setRowPositionValidity();
        
        return b;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void afterLast()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (rowData.size() != 0)
        {
          rowData.afterLast();
          thisRow = null;
        }
        setRowPositionValidity();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void beforeFirst()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (rowData.size() == 0) {
          return;
        }
        rowData.beforeFirst();
        thisRow = null;
        
        setRowPositionValidity();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void cancelRowUpdates()
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected final JdbcConnection checkClosed()
    throws SQLException
  {
    JdbcConnection c = connection;
    if (c == null) {
      throw SQLError.createSQLException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), "S1000", 
        getExceptionInterceptor());
    }
    return c;
  }
  
  protected final void checkColumnBounds(int columnIndex)
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      if (columnIndex < 1) {
        throw SQLError.createSQLException(
          Messages.getString("ResultSet.Column_Index_out_of_range_low", new Object[] {
          Integer.valueOf(columnIndex), Integer.valueOf(columnDefinition.getFields().length) }), "S1009", 
          getExceptionInterceptor());
      }
      if (columnIndex > columnDefinition.getFields().length) {
        throw SQLError.createSQLException(
          Messages.getString("ResultSet.Column_Index_out_of_range_high", new Object[] {
          Integer.valueOf(columnIndex), Integer.valueOf(columnDefinition.getFields().length) }), "S1009", 
          getExceptionInterceptor());
      }
      if (useUsageAdvisor) {
        columnUsed[(columnIndex - 1)] = true;
      }
    }
  }
  
  protected void checkRowPos()
    throws SQLException
  {
    checkClosed();
    if (!onValidRow) {
      throw SQLError.createSQLException(invalidRowReason, "S1000", getExceptionInterceptor());
    }
  }
  
  private boolean onValidRow = false;
  private String invalidRowReason = null;
  private TimeZone lastTsCustomTz;
  private ValueFactory<Timestamp> customTsVf;
  
  private void setRowPositionValidity()
    throws SQLException
  {
    if ((!rowData.isDynamic()) && (rowData.size() == 0))
    {
      invalidRowReason = Messages.getString("ResultSet.Illegal_operation_on_empty_result_set");
      onValidRow = false;
    }
    else if (rowData.isBeforeFirst())
    {
      invalidRowReason = Messages.getString("ResultSet.Before_start_of_result_set_146");
      onValidRow = false;
    }
    else if (rowData.isAfterLast())
    {
      invalidRowReason = Messages.getString("ResultSet.After_end_of_result_set_148");
      onValidRow = false;
    }
    else
    {
      onValidRow = true;
      invalidRowReason = null;
    }
  }
  
  public void clearWarnings()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        warningChain = null;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void close()
    throws SQLException
  {
    try
    {
      realClose(true);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void populateCachedMetaData(CachedResultSetMetaData cachedMetaData)
    throws SQLException
  {
    try
    {
      columnDefinition.exportTo(cachedMetaData);
      cachedMetaData.setMetadata(getMetaData());
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void deleteRow()
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int findColumn(String columnName)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        Integer index = Integer.valueOf(columnDefinition.findColumn(columnName, useColumnNamesInFindColumn, 1));
        if (index.intValue() == -1) {
          throw SQLError.createSQLException(
            Messages.getString("ResultSet.Column____112") + columnName + Messages.getString("ResultSet.___not_found._113"), "S0022", 
            getExceptionInterceptor());
        }
        return index.intValue();
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean first()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        boolean b = true;
        if (rowData.isEmpty())
        {
          b = false;
        }
        else
        {
          rowData.beforeFirst();
          thisRow = ((Row)rowData.next());
        }
        setRowPositionValidity();
        
        return b;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Array getArray(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Array getArray(String colName)
    throws SQLException
  {
    try
    {
      return getArray(findColumn(colName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public InputStream getAsciiStream(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      return getBinaryStream(columnIndex);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public InputStream getAsciiStream(String columnName)
    throws SQLException
  {
    try
    {
      return getAsciiStream(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public BigDecimal getBigDecimal(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      return (BigDecimal)thisRow.getValue(columnIndex - 1, bigDecimalValueFactory);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  @Deprecated
  public BigDecimal getBigDecimal(int columnIndex, int scale)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      ValueFactory<BigDecimal> vf = new BigDecimalValueFactory(session.getPropertySet(), scale);
      vf.setPropertySet(connection.getPropertySet());
      return (BigDecimal)thisRow.getValue(columnIndex - 1, vf);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public BigDecimal getBigDecimal(String columnName)
    throws SQLException
  {
    try
    {
      return getBigDecimal(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  @Deprecated
  public BigDecimal getBigDecimal(String columnName, int scale)
    throws SQLException
  {
    try
    {
      return getBigDecimal(findColumn(columnName), scale);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public InputStream getBinaryStream(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      return (InputStream)thisRow.getValue(columnIndex - 1, binaryStreamValueFactory);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public InputStream getBinaryStream(String columnName)
    throws SQLException
  {
    try
    {
      return getBinaryStream(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.Blob getBlob(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      if (thisRow.getNull(columnIndex - 1)) {
        return null;
      }
      if (!((Boolean)emulateLocators.getValue()).booleanValue()) {
        return new com.mysql.cj.jdbc.Blob(thisRow.getBytes(columnIndex - 1), getExceptionInterceptor());
      }
      return new BlobFromLocator(this, columnIndex, getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.Blob getBlob(String colName)
    throws SQLException
  {
    try
    {
      return getBlob(findColumn(colName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean getBoolean(int columnIndex)
    throws SQLException
  {
    try
    {
      Boolean res = (Boolean)getObject(columnIndex, Boolean.TYPE);
      return res == null ? false : res.booleanValue();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean getBoolean(String columnName)
    throws SQLException
  {
    try
    {
      return getBoolean(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public byte getByte(int columnIndex)
    throws SQLException
  {
    try
    {
      Byte res = (Byte)getObject(columnIndex, Byte.TYPE);
      return res == null ? 0 : res.byteValue();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public byte getByte(String columnName)
    throws SQLException
  {
    try
    {
      return getByte(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public byte[] getBytes(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      return thisRow.getBytes(columnIndex - 1);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public byte[] getBytes(String columnName)
    throws SQLException
  {
    try
    {
      return getBytes(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getCharacterStream(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      InputStream stream = getBinaryStream(columnIndex);
      if (stream == null) {
        return null;
      }
      Field f = columnDefinition.getFields()[(columnIndex - 1)];
      try
      {
        return new InputStreamReader(stream, f.getEncoding());
      }
      catch (UnsupportedEncodingException e)
      {
        SQLException sqlEx = SQLError.createSQLException("Cannot read value with encoding: " + f.getEncoding(), exceptionInterceptor);
        sqlEx.initCause(e);
        throw sqlEx;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getCharacterStream(String columnName)
    throws SQLException
  {
    try
    {
      return getCharacterStream(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.Clob getClob(int columnIndex)
    throws SQLException
  {
    try
    {
      String asString = getStringForClob(columnIndex);
      if (asString == null) {
        return null;
      }
      return new com.mysql.cj.jdbc.Clob(asString, getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.Clob getClob(String colName)
    throws SQLException
  {
    try
    {
      return getClob(findColumn(colName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Date getDate(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      return (Date)thisRow.getValue(columnIndex - 1, defaultDateValueFactory);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Date getDate(int columnIndex, Calendar cal)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      ValueFactory<Date> vf = new SqlDateValueFactory(session.getPropertySet(), cal, cal != null ? cal.getTimeZone() : session.getServerSession().getDefaultTimeZone(), this);
      return (Date)thisRow.getValue(columnIndex - 1, vf);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Date getDate(String columnName)
    throws SQLException
  {
    try
    {
      return getDate(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Date getDate(String columnName, Calendar cal)
    throws SQLException
  {
    try
    {
      return getDate(findColumn(columnName), cal);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public double getDouble(int columnIndex)
    throws SQLException
  {
    try
    {
      Double res = (Double)getObject(columnIndex, Double.TYPE);
      return res == null ? 0.0D : res.doubleValue();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public double getDouble(String columnName)
    throws SQLException
  {
    try
    {
      return getDouble(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public float getFloat(int columnIndex)
    throws SQLException
  {
    try
    {
      Float res = (Float)getObject(columnIndex, Float.TYPE);
      return res == null ? 0.0F : res.floatValue();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public float getFloat(String columnName)
    throws SQLException
  {
    try
    {
      return getFloat(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getInt(int columnIndex)
    throws SQLException
  {
    try
    {
      Integer res = (Integer)getObject(columnIndex, Integer.TYPE);
      return res == null ? 0 : res.intValue();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public BigInteger getBigInteger(int columnIndex)
    throws SQLException
  {
    try
    {
      String stringVal = getString(columnIndex);
      if (stringVal == null) {
        return null;
      }
      try
      {
        return new BigInteger(stringVal);
      }
      catch (NumberFormatException nfe)
      {
        throw SQLError.createSQLException(
          Messages.getString("ResultSet.Bad_format_for_BigInteger", new Object[] {Integer.valueOf(columnIndex), stringVal }), "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getInt(String columnName)
    throws SQLException
  {
    try
    {
      return getInt(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long getLong(int columnIndex)
    throws SQLException
  {
    try
    {
      Long res = (Long)getObject(columnIndex, Long.TYPE);
      return res == null ? 0L : res.longValue();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public long getLong(String columnName)
    throws SQLException
  {
    try
    {
      return getLong(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public short getShort(int columnIndex)
    throws SQLException
  {
    try
    {
      Short res = (Short)getObject(columnIndex, Short.TYPE);
      return res == null ? 0 : res.shortValue();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public short getShort(String columnName)
    throws SQLException
  {
    try
    {
      return getShort(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getString(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      Field f = columnDefinition.getFields()[(columnIndex - 1)];
      ValueFactory<String> vf = new StringValueFactory(session.getPropertySet());
      String stringVal = (String)thisRow.getValue(columnIndex - 1, vf);
      if ((padCharsWithSpace) && (stringVal != null) && (f.getMysqlTypeId() == 254))
      {
        int maxBytesPerChar = session.getServerSession().getMaxBytesPerChar(Integer.valueOf(f.getCollationIndex()), f.getEncoding());
        int fieldLength = (int)f.getLength() / maxBytesPerChar;
        return StringUtils.padString(stringVal, fieldLength);
      }
      return stringVal;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getString(String columnName)
    throws SQLException
  {
    try
    {
      return getString(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private String getStringForClob(int columnIndex)
    throws SQLException
  {
    String asString = null;
    
    String forcedEncoding = connection.getPropertySet().getStringProperty(PropertyKey.clobCharacterEncoding).getStringValue();
    if (forcedEncoding == null)
    {
      asString = getString(columnIndex);
    }
    else
    {
      byte[] asBytes = getBytes(columnIndex);
      if (asBytes != null) {
        asString = StringUtils.toString(asBytes, forcedEncoding);
      }
    }
    return asString;
  }
  
  public Time getTime(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      return (Time)thisRow.getValue(columnIndex - 1, defaultTimeValueFactory);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Time getTime(int columnIndex, Calendar cal)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      ValueFactory<Time> vf = new SqlTimeValueFactory(session.getPropertySet(), cal, cal != null ? cal.getTimeZone() : session.getServerSession().getDefaultTimeZone());
      return (Time)thisRow.getValue(columnIndex - 1, vf);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Time getTime(String columnName)
    throws SQLException
  {
    try
    {
      return getTime(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Time getTime(String columnName, Calendar cal)
    throws SQLException
  {
    try
    {
      return getTime(findColumn(columnName), cal);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Timestamp getTimestamp(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      return (Timestamp)thisRow.getValue(columnIndex - 1, defaultTimestampValueFactory);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public LocalDate getLocalDate(int columnIndex)
    throws SQLException
  {
    checkRowPos();
    checkColumnBounds(columnIndex);
    return (LocalDate)thisRow.getValue(columnIndex - 1, defaultLocalDateValueFactory);
  }
  
  public LocalDateTime getLocalDateTime(int columnIndex)
    throws SQLException
  {
    checkRowPos();
    checkColumnBounds(columnIndex);
    return (LocalDateTime)thisRow.getValue(columnIndex - 1, defaultLocalDateTimeValueFactory);
  }
  
  public LocalTime getLocalTime(int columnIndex)
    throws SQLException
  {
    checkRowPos();
    checkColumnBounds(columnIndex);
    return (LocalTime)thisRow.getValue(columnIndex - 1, defaultLocalTimeValueFactory);
  }
  
  public Timestamp getTimestamp(int columnIndex, Calendar cal)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      TimeZone tz = cal != null ? cal.getTimeZone() : session.getServerSession().getDefaultTimeZone();
      if ((customTsVf != null) && (tz == lastTsCustomTz)) {
        return (Timestamp)thisRow.getValue(columnIndex - 1, customTsVf);
      }
      ValueFactory<Timestamp> vf = new SqlTimestampValueFactory(session.getPropertySet(), cal, tz);
      lastTsCustomTz = tz;
      customTsVf = vf;
      return (Timestamp)thisRow.getValue(columnIndex - 1, vf);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Timestamp getTimestamp(String columnName)
    throws SQLException
  {
    try
    {
      return getTimestamp(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Timestamp getTimestamp(String columnName, Calendar cal)
    throws SQLException
  {
    try
    {
      return getTimestamp(findColumn(columnName), cal);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getNCharacterStream(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      String fieldEncoding = columnDefinition.getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException("Can not call getNCharacterStream() when field's charset isn't UTF-8");
      }
      return getCharacterStream(columnIndex);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getNCharacterStream(String columnName)
    throws SQLException
  {
    try
    {
      return getNCharacterStream(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.NClob getNClob(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      String fieldEncoding = columnDefinition.getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException("Can not call getNClob() when field's charset isn't UTF-8");
      }
      String asString = getStringForNClob(columnIndex);
      if (asString == null) {
        return null;
      }
      return new com.mysql.cj.jdbc.NClob(asString, getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.NClob getNClob(String columnName)
    throws SQLException
  {
    try
    {
      return getNClob(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private String getStringForNClob(int columnIndex)
    throws SQLException
  {
    String asString = null;
    
    String forcedEncoding = "UTF-8";
    try
    {
      byte[] asBytes = getBytes(columnIndex);
      if (asBytes != null) {
        asString = new String(asBytes, forcedEncoding);
      }
    }
    catch (UnsupportedEncodingException uee)
    {
      throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", 
        getExceptionInterceptor());
    }
    return asString;
  }
  
  public String getNString(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      String fieldEncoding = columnDefinition.getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException("Can not call getNString() when field's charset isn't UTF-8");
      }
      return getString(columnIndex);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getNString(String columnName)
    throws SQLException
  {
    try
    {
      return getNString(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getConcurrency()
    throws SQLException
  {
    try
    {
      return 1007;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getCursorName()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLException(Messages.getString("ResultSet.Positioned_Update_not_supported"), "S1C00", 
        getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public int getFetchDirection()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 10	com/mysql/cj/jdbc/result/ResultSetImpl:fetchDirection	I
    //   16: aload_1
    //   17: monitorexit
    //   18: ireturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1580	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 1583	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #1046	-> byte code offset #0
    //   Java source line #1047	-> byte code offset #12
    //   Java source line #1048	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	ResultSetImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  /* Error */
  public int getFetchSize()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 11	com/mysql/cj/jdbc/result/ResultSetImpl:fetchSize	I
    //   16: aload_1
    //   17: monitorexit
    //   18: ireturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1580	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 1583	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #1053	-> byte code offset #0
    //   Java source line #1054	-> byte code offset #12
    //   Java source line #1055	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	ResultSetImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  /* Error */
  public char getFirstCharOfQuery()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 285	com/mysql/cj/jdbc/result/ResultSetImpl:firstCharOfQuery	C
    //   16: aload_1
    //   17: monitorexit
    //   18: ireturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_1
    //   25: new 286	java/lang/RuntimeException
    //   28: dup
    //   29: aload_1
    //   30: invokespecial 287	java/lang/RuntimeException:<init>	(Ljava/lang/Throwable;)V
    //   33: athrow
    // Line number table:
    //   Java source line #1061	-> byte code offset #0
    //   Java source line #1062	-> byte code offset #12
    //   Java source line #1063	-> byte code offset #19
    //   Java source line #1064	-> byte code offset #24
    //   Java source line #1065	-> byte code offset #25
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	34	0	this	ResultSetImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   24	6	1	e	SQLException
    //   19	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	18	24	java/sql/SQLException
    //   19	24	24	java/sql/SQLException
  }
  
  public java.sql.ResultSetMetaData getMetaData()
    throws SQLException
  {
    try
    {
      checkClosed();
      
      return new ResultSetMetaData(session, columnDefinition.getFields(), 
        ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.useOldAliasMetadataBehavior).getValue()).booleanValue(), yearIsDateType, 
        getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObject(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      int columnIndexMinusOne = columnIndex - 1;
      if (thisRow.getNull(columnIndexMinusOne)) {
        return null;
      }
      Field field = columnDefinition.getFields()[columnIndexMinusOne];
      switch (field.getMysqlType())
      {
      case BIT: 
        if ((field.isBinary()) || (field.isBlob()))
        {
          byte[] data = getBytes(columnIndex);
          if (((Boolean)connection.getPropertySet().getBooleanProperty(PropertyKey.autoDeserialize).getValue()).booleanValue())
          {
            Object obj = data;
            if ((data != null) && (data.length >= 2)) {
              if ((data[0] == -84) && (data[1] == -19)) {
                try
                {
                  ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
                  ObjectInputStream objIn = new ObjectInputStream(bytesIn);
                  obj = objIn.readObject();
                  objIn.close();
                  bytesIn.close();
                }
                catch (ClassNotFoundException cnfe)
                {
                  throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + 
                    Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
                }
                catch (IOException ex)
                {
                  obj = data;
                }
              } else {
                return getString(columnIndex);
              }
            }
            return obj;
          }
          return data;
        }
        return field.isSingleBit() ? Boolean.valueOf(getBoolean(columnIndex)) : getBytes(columnIndex);
      case BOOLEAN: 
        return Boolean.valueOf(getBoolean(columnIndex));
      case TINYINT: 
        return Integer.valueOf(getByte(columnIndex));
      case TINYINT_UNSIGNED: 
      case SMALLINT: 
      case SMALLINT_UNSIGNED: 
      case MEDIUMINT: 
      case MEDIUMINT_UNSIGNED: 
      case INT: 
        return Integer.valueOf(getInt(columnIndex));
      case INT_UNSIGNED: 
      case BIGINT: 
        return Long.valueOf(getLong(columnIndex));
      case BIGINT_UNSIGNED: 
        return getBigInteger(columnIndex);
      case DECIMAL: 
      case DECIMAL_UNSIGNED: 
        String stringVal = getString(columnIndex);
        if (stringVal != null)
        {
          if (stringVal.length() == 0) {
            return new BigDecimal(0);
          }
          try
          {
            return new BigDecimal(stringVal);
          }
          catch (NumberFormatException ex)
          {
            throw SQLError.createSQLException(
              Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", 
              getExceptionInterceptor());
          }
        }
        return null;
      case FLOAT: 
      case FLOAT_UNSIGNED: 
        return new Float(getFloat(columnIndex));
      case DOUBLE: 
      case DOUBLE_UNSIGNED: 
        return new Double(getDouble(columnIndex));
      case CHAR: 
      case ENUM: 
      case SET: 
      case VARCHAR: 
      case TINYTEXT: 
        return getString(columnIndex);
      case TEXT: 
      case MEDIUMTEXT: 
      case LONGTEXT: 
      case JSON: 
        return getStringForClob(columnIndex);
      case GEOMETRY: 
        return getBytes(columnIndex);
      case BINARY: 
      case VARBINARY: 
      case TINYBLOB: 
      case MEDIUMBLOB: 
      case LONGBLOB: 
      case BLOB: 
        if ((field.isBinary()) || (field.isBlob()))
        {
          byte[] data = getBytes(columnIndex);
          if (((Boolean)connection.getPropertySet().getBooleanProperty(PropertyKey.autoDeserialize).getValue()).booleanValue())
          {
            Object obj = data;
            if ((data != null) && (data.length >= 2)) {
              if ((data[0] == -84) && (data[1] == -19)) {
                try
                {
                  ByteArrayInputStream bytesIn = new ByteArrayInputStream(data);
                  ObjectInputStream objIn = new ObjectInputStream(bytesIn);
                  obj = objIn.readObject();
                  objIn.close();
                  bytesIn.close();
                }
                catch (ClassNotFoundException cnfe)
                {
                  throw SQLError.createSQLException(Messages.getString("ResultSet.Class_not_found___91") + cnfe.toString() + 
                    Messages.getString("ResultSet._while_reading_serialized_object_92"), getExceptionInterceptor());
                }
                catch (IOException ex)
                {
                  obj = data;
                }
              } else {
                return getString(columnIndex);
              }
            }
            return obj;
          }
          return data;
        }
        return getBytes(columnIndex);
      case YEAR: 
        return yearIsDateType ? getDate(columnIndex) : Short.valueOf(getShort(columnIndex));
      case DATE: 
        return getDate(columnIndex);
      case TIME: 
        return getTime(columnIndex);
      case TIMESTAMP: 
      case DATETIME: 
        return getTimestamp(columnIndex);
      }
      return getString(columnIndex);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T getObject(int columnIndex, Class<T> type)
    throws SQLException
  {
    try
    {
      if (type == null) {
        throw SQLError.createSQLException("Type parameter can not be null", "S1009", getExceptionInterceptor());
      }
      synchronized (checkClosed().getConnectionMutex())
      {
        if (type.equals(String.class)) {
          return getString(columnIndex);
        }
        if (type.equals(BigDecimal.class)) {
          return getBigDecimal(columnIndex);
        }
        if (type.equals(BigInteger.class)) {
          return getBigInteger(columnIndex);
        }
        if ((type.equals(Boolean.class)) || (type.equals(Boolean.TYPE)))
        {
          checkRowPos();
          checkColumnBounds(columnIndex);
          return (T)thisRow.getValue(columnIndex - 1, booleanValueFactory);
        }
        if ((type.equals(Byte.class)) || (type.equals(Byte.TYPE)))
        {
          checkRowPos();
          checkColumnBounds(columnIndex);
          return (T)thisRow.getValue(columnIndex - 1, byteValueFactory);
        }
        if ((type.equals(Short.class)) || (type.equals(Short.TYPE)))
        {
          checkRowPos();
          checkColumnBounds(columnIndex);
          return (T)thisRow.getValue(columnIndex - 1, shortValueFactory);
        }
        if ((type.equals(Integer.class)) || (type.equals(Integer.TYPE)))
        {
          checkRowPos();
          checkColumnBounds(columnIndex);
          return (T)thisRow.getValue(columnIndex - 1, integerValueFactory);
        }
        if ((type.equals(Long.class)) || (type.equals(Long.TYPE)))
        {
          checkRowPos();
          checkColumnBounds(columnIndex);
          return (T)thisRow.getValue(columnIndex - 1, longValueFactory);
        }
        if ((type.equals(Float.class)) || (type.equals(Float.TYPE)))
        {
          checkRowPos();
          checkColumnBounds(columnIndex);
          return (T)thisRow.getValue(columnIndex - 1, floatValueFactory);
        }
        if ((type.equals(Double.class)) || (type.equals(Double.TYPE)))
        {
          checkRowPos();
          checkColumnBounds(columnIndex);
          return (T)thisRow.getValue(columnIndex - 1, doubleValueFactory);
        }
        if (type.equals(byte[].class)) {
          return getBytes(columnIndex);
        }
        if (type.equals(Date.class)) {
          return getDate(columnIndex);
        }
        if (type.equals(Time.class)) {
          return getTime(columnIndex);
        }
        if (type.equals(Timestamp.class)) {
          return getTimestamp(columnIndex);
        }
        if (type.equals(com.mysql.cj.jdbc.Clob.class)) {
          return getClob(columnIndex);
        }
        if (type.equals(com.mysql.cj.jdbc.Blob.class)) {
          return getBlob(columnIndex);
        }
        if (type.equals(Array.class)) {
          return getArray(columnIndex);
        }
        if (type.equals(Ref.class)) {
          return getRef(columnIndex);
        }
        if (type.equals(URL.class)) {
          return getURL(columnIndex);
        }
        if (type.equals(Struct.class)) {
          throw new SQLFeatureNotSupportedException();
        }
        if (type.equals(RowId.class)) {
          return getRowId(columnIndex);
        }
        if (type.equals(java.sql.NClob.class)) {
          return getNClob(columnIndex);
        }
        if (type.equals(SQLXML.class)) {
          return getSQLXML(columnIndex);
        }
        if (type.equals(LocalDate.class)) {
          return getLocalDate(columnIndex);
        }
        if (type.equals(LocalDateTime.class)) {
          return getLocalDateTime(columnIndex);
        }
        if (type.equals(LocalTime.class)) {
          return getLocalTime(columnIndex);
        }
        if (type.equals(OffsetDateTime.class)) {
          try
          {
            String odt = getString(columnIndex);
            return odt == null ? null : OffsetDateTime.parse(odt);
          }
          catch (DateTimeParseException localDateTimeParseException) {}
        } else if (type.equals(OffsetTime.class)) {
          try
          {
            String ot = getString(columnIndex);
            return ot == null ? null : OffsetTime.parse(getString(columnIndex));
          }
          catch (DateTimeParseException localDateTimeParseException1) {}
        }
        if (((Boolean)connection.getPropertySet().getBooleanProperty(PropertyKey.autoDeserialize).getValue()).booleanValue()) {
          try
          {
            return (T)getObject(columnIndex);
          }
          catch (ClassCastException cce)
          {
            SQLException sqlEx = SQLError.createSQLException("Conversion not supported for type " + type.getName(), "S1009", 
              getExceptionInterceptor());
            sqlEx.initCause(cce);
            
            throw sqlEx;
          }
        }
        throw SQLError.createSQLException("Conversion not supported for type " + type.getName(), "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T getObject(String columnLabel, Class<T> type)
    throws SQLException
  {
    try
    {
      return (T)getObject(findColumn(columnLabel), type);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObject(int i, Map<String, Class<?>> map)
    throws SQLException
  {
    try
    {
      return getObject(i);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObject(String columnName)
    throws SQLException
  {
    try
    {
      return getObject(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObject(String colName, Map<String, Class<?>> map)
    throws SQLException
  {
    try
    {
      return getObject(findColumn(colName), map);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObjectStoredProc(int columnIndex, int desiredSqlType)
    throws SQLException
  {
    try
    {
      checkRowPos();
      checkColumnBounds(columnIndex);
      
      Object value = thisRow.getBytes(columnIndex - 1);
      if (value == null) {
        return null;
      }
      Field field = columnDefinition.getFields()[(columnIndex - 1)];
      
      MysqlType desiredMysqlType = MysqlType.getByJdbcType(desiredSqlType);
      switch (desiredMysqlType)
      {
      case BIT: 
      case BOOLEAN: 
        return Boolean.valueOf(getBoolean(columnIndex));
      case TINYINT: 
      case TINYINT_UNSIGNED: 
        return Integer.valueOf(getInt(columnIndex));
      case SMALLINT: 
      case SMALLINT_UNSIGNED: 
        return Integer.valueOf(getInt(columnIndex));
      case MEDIUMINT: 
      case MEDIUMINT_UNSIGNED: 
      case INT: 
      case INT_UNSIGNED: 
        if ((!field.isUnsigned()) || (field.getMysqlTypeId() == 9)) {
          return Integer.valueOf(getInt(columnIndex));
        }
        return Long.valueOf(getLong(columnIndex));
      case BIGINT: 
        return Long.valueOf(getLong(columnIndex));
      case BIGINT_UNSIGNED: 
        return getBigInteger(columnIndex);
      case DECIMAL: 
      case DECIMAL_UNSIGNED: 
        String stringVal = getString(columnIndex);
        if (stringVal != null)
        {
          if (stringVal.length() == 0) {
            return new BigDecimal(0);
          }
          try
          {
            val = new BigDecimal(stringVal);
          }
          catch (NumberFormatException ex)
          {
            BigDecimal val;
            throw SQLError.createSQLException(
              Messages.getString("ResultSet.Bad_format_for_BigDecimal", new Object[] { stringVal, Integer.valueOf(columnIndex) }), "S1009", 
              getExceptionInterceptor());
          }
          BigDecimal val;
          return val;
        }
        return null;
      case FLOAT: 
      case FLOAT_UNSIGNED: 
        return new Float(getFloat(columnIndex));
      case DOUBLE: 
      case DOUBLE_UNSIGNED: 
        return new Double(getDouble(columnIndex));
      case CHAR: 
      case ENUM: 
      case SET: 
      case VARCHAR: 
      case TINYTEXT: 
        return getString(columnIndex);
      case TEXT: 
      case MEDIUMTEXT: 
      case LONGTEXT: 
      case JSON: 
        return getStringForClob(columnIndex);
      case GEOMETRY: 
      case BINARY: 
      case VARBINARY: 
      case TINYBLOB: 
      case MEDIUMBLOB: 
      case LONGBLOB: 
      case BLOB: 
        return getBytes(columnIndex);
      case YEAR: 
      case DATE: 
        if ((field.getMysqlType() == MysqlType.YEAR) && (!yearIsDateType)) {
          return Short.valueOf(getShort(columnIndex));
        }
        return getDate(columnIndex);
      case TIME: 
        return getTime(columnIndex);
      case TIMESTAMP: 
        return getTimestamp(columnIndex);
      }
      return getString(columnIndex);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObjectStoredProc(int i, Map<Object, Object> map, int desiredSqlType)
    throws SQLException
  {
    try
    {
      return getObjectStoredProc(i, desiredSqlType);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObjectStoredProc(String columnName, int desiredSqlType)
    throws SQLException
  {
    try
    {
      return getObjectStoredProc(findColumn(columnName), desiredSqlType);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Object getObjectStoredProc(String colName, Map<Object, Object> map, int desiredSqlType)
    throws SQLException
  {
    try
    {
      return getObjectStoredProc(findColumn(colName), map, desiredSqlType);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Ref getRef(int i)
    throws SQLException
  {
    try
    {
      checkColumnBounds(i);
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Ref getRef(String colName)
    throws SQLException
  {
    try
    {
      return getRef(findColumn(colName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getRow()
    throws SQLException
  {
    try
    {
      checkClosed();
      
      int currentRowNumber = rowData.getPosition();
      int row = 0;
      if (!rowData.isDynamic()) {
        if ((currentRowNumber < 0) || (rowData.isAfterLast()) || (rowData.isEmpty())) {
          row = 0;
        } else {
          row = currentRowNumber + 1;
        }
      }
      return currentRowNumber + 1;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public Statement getStatement()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 355	com/mysql/cj/jdbc/result/ResultSetImpl:wrapperStatement	Ljava/sql/Statement;
    //   16: ifnull +10 -> 26
    //   19: aload_0
    //   20: getfield 355	com/mysql/cj/jdbc/result/ResultSetImpl:wrapperStatement	Ljava/sql/Statement;
    //   23: aload_1
    //   24: monitorexit
    //   25: areturn
    //   26: aload_0
    //   27: getfield 23	com/mysql/cj/jdbc/result/ResultSetImpl:owningStatement	Lcom/mysql/cj/jdbc/StatementImpl;
    //   30: aload_1
    //   31: monitorexit
    //   32: areturn
    //   33: astore_2
    //   34: aload_1
    //   35: monitorexit
    //   36: aload_2
    //   37: athrow
    //   38: astore_1
    //   39: ldc_w 356
    //   42: ldc -114
    //   44: aload_0
    //   45: invokevirtual 143	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   48: invokestatic 144	com/mysql/cj/jdbc/exceptions/SQLError:createSQLException	(Ljava/lang/String;Ljava/lang/String;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   51: athrow
    //   52: astore_3
    //   53: aload_3
    //   54: aload_0
    //   55: invokevirtual 1580	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   58: invokestatic 1583	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   61: athrow
    // Line number table:
    //   Java source line #1573	-> byte code offset #0
    //   Java source line #1574	-> byte code offset #12
    //   Java source line #1575	-> byte code offset #19
    //   Java source line #1578	-> byte code offset #26
    //   Java source line #1579	-> byte code offset #33
    //   Java source line #1581	-> byte code offset #38
    //   Java source line #1582	-> byte code offset #39
    //   Java source line #1583	-> byte code offset #45
    //   Java source line #1582	-> byte code offset #48
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	55	0	this	ResultSetImpl
    //   38	2	1	sqlEx	SQLException
    //   33	4	2	localObject1	Object
    //   52	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	25	33	finally
    //   26	32	33	finally
    //   33	36	33	finally
    //   0	25	38	java/sql/SQLException
    //   26	32	38	java/sql/SQLException
    //   33	38	38	java/sql/SQLException
    //   0	52	52	com/mysql/cj/exceptions/CJException
  }
  
  public int getType()
    throws SQLException
  {
    try
    {
      return resultSetType;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  @Deprecated
  public InputStream getUnicodeStream(int columnIndex)
    throws SQLException
  {
    try
    {
      checkRowPos();
      
      return getBinaryStream(columnIndex);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  @Deprecated
  public InputStream getUnicodeStream(String columnName)
    throws SQLException
  {
    try
    {
      return getUnicodeStream(findColumn(columnName));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public URL getURL(int colIndex)
    throws SQLException
  {
    try
    {
      String val = getString(colIndex);
      if (val == null) {
        return null;
      }
      try
      {
        return new URL(val);
      }
      catch (MalformedURLException mfe)
      {
        throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____104") + val + "'", "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public URL getURL(String colName)
    throws SQLException
  {
    try
    {
      String val = getString(colName);
      if (val == null) {
        return null;
      }
      try
      {
        return new URL(val);
      }
      catch (MalformedURLException mfe)
      {
        throw SQLError.createSQLException(Messages.getString("ResultSet.Malformed_URL____107") + val + "'", "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public SQLWarning getWarnings()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 17	com/mysql/cj/jdbc/result/ResultSetImpl:warningChain	Ljava/sql/SQLWarning;
    //   16: aload_1
    //   17: monitorexit
    //   18: areturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1580	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 1583	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #1641	-> byte code offset #0
    //   Java source line #1642	-> byte code offset #12
    //   Java source line #1643	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	ResultSetImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  public void insertRow()
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isAfterLast()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        boolean b = rowData.isAfterLast();
        
        return b;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public boolean isBeforeFirst()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 92	com/mysql/cj/jdbc/result/ResultSetImpl:rowData	Lcom/mysql/cj/protocol/ResultsetRows;
    //   16: invokeinterface 153 1 0
    //   21: aload_1
    //   22: monitorexit
    //   23: ireturn
    //   24: astore_2
    //   25: aload_1
    //   26: monitorexit
    //   27: aload_2
    //   28: athrow
    //   29: astore_3
    //   30: aload_3
    //   31: aload_0
    //   32: invokevirtual 1580	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   35: invokestatic 1583	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   38: athrow
    // Line number table:
    //   Java source line #1662	-> byte code offset #0
    //   Java source line #1663	-> byte code offset #12
    //   Java source line #1664	-> byte code offset #24
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	32	0	this	ResultSetImpl
    //   10	16	1	Ljava/lang/Object;	Object
    //   24	4	2	localObject1	Object
    //   29	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	23	24	finally
    //   24	27	24	finally
    //   0	29	29	com/mysql/cj/exceptions/CJException
  }
  
  /* Error */
  public boolean isFirst()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 92	com/mysql/cj/jdbc/result/ResultSetImpl:rowData	Lcom/mysql/cj/protocol/ResultsetRows;
    //   16: invokeinterface 364 1 0
    //   21: aload_1
    //   22: monitorexit
    //   23: ireturn
    //   24: astore_2
    //   25: aload_1
    //   26: monitorexit
    //   27: aload_2
    //   28: athrow
    //   29: astore_3
    //   30: aload_3
    //   31: aload_0
    //   32: invokevirtual 1580	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   35: invokestatic 1583	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   38: athrow
    // Line number table:
    //   Java source line #1669	-> byte code offset #0
    //   Java source line #1670	-> byte code offset #12
    //   Java source line #1671	-> byte code offset #24
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	32	0	this	ResultSetImpl
    //   10	16	1	Ljava/lang/Object;	Object
    //   24	4	2	localObject1	Object
    //   29	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	23	24	finally
    //   24	27	24	finally
    //   0	29	29	com/mysql/cj/exceptions/CJException
  }
  
  /* Error */
  public boolean isLast()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: getfield 92	com/mysql/cj/jdbc/result/ResultSetImpl:rowData	Lcom/mysql/cj/protocol/ResultsetRows;
    //   16: invokeinterface 365 1 0
    //   21: aload_1
    //   22: monitorexit
    //   23: ireturn
    //   24: astore_2
    //   25: aload_1
    //   26: monitorexit
    //   27: aload_2
    //   28: athrow
    //   29: astore_3
    //   30: aload_3
    //   31: aload_0
    //   32: invokevirtual 1580	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   35: invokestatic 1583	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   38: athrow
    // Line number table:
    //   Java source line #1676	-> byte code offset #0
    //   Java source line #1677	-> byte code offset #12
    //   Java source line #1678	-> byte code offset #24
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	32	0	this	ResultSetImpl
    //   10	16	1	Ljava/lang/Object;	Object
    //   24	4	2	localObject1	Object
    //   29	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	23	24	finally
    //   24	27	24	finally
    //   0	29	29	com/mysql/cj/exceptions/CJException
  }
  
  public boolean last()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        boolean b = true;
        if (rowData.size() == 0)
        {
          b = false;
        }
        else
        {
          rowData.beforeLast();
          thisRow = ((Row)rowData.next());
        }
        setRowPositionValidity();
        
        return b;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void moveToCurrentRow()
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void moveToInsertRow()
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean next()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!hasRows()) {
          throw SQLError.createSQLException(Messages.getString("ResultSet.ResultSet_is_from_UPDATE._No_Data_115"), "S1000", 
            getExceptionInterceptor());
        }
        boolean b;
        boolean b;
        if (rowData.size() == 0)
        {
          b = false;
        }
        else
        {
          thisRow = ((Row)rowData.next());
          boolean b;
          if (thisRow == null)
          {
            b = false;
          }
          else
          {
            clearWarnings();
            
            b = true;
          }
        }
        setRowPositionValidity();
        
        return b;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean prev()
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      int rowIndex = rowData.getPosition();
      
      boolean b = true;
      if (rowIndex - 1 >= 0)
      {
        rowIndex--;
        rowData.setCurrentRow(rowIndex);
        thisRow = rowData.get(rowIndex);
        
        b = true;
      }
      else if (rowIndex - 1 == -1)
      {
        rowIndex--;
        rowData.setCurrentRow(rowIndex);
        thisRow = null;
        
        b = false;
      }
      else
      {
        b = false;
      }
      setRowPositionValidity();
      
      return b;
    }
  }
  
  /* Error */
  public boolean previous()
    throws SQLException
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 105	com/mysql/cj/jdbc/result/ResultSetImpl:checkClosed	()Lcom/mysql/cj/jdbc/JdbcConnection;
    //   4: invokeinterface 106 1 0
    //   9: dup
    //   10: astore_1
    //   11: monitorenter
    //   12: aload_0
    //   13: invokevirtual 370	com/mysql/cj/jdbc/result/ResultSetImpl:prev	()Z
    //   16: aload_1
    //   17: monitorexit
    //   18: ireturn
    //   19: astore_2
    //   20: aload_1
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: astore_3
    //   25: aload_3
    //   26: aload_0
    //   27: invokevirtual 1580	com/mysql/cj/jdbc/result/ResultSetImpl:getExceptionInterceptor	()Lcom/mysql/cj/exceptions/ExceptionInterceptor;
    //   30: invokestatic 1583	com/mysql/cj/jdbc/exceptions/SQLExceptionsMapping:translateException	(Ljava/lang/Throwable;Lcom/mysql/cj/exceptions/ExceptionInterceptor;)Ljava/sql/SQLException;
    //   33: athrow
    // Line number table:
    //   Java source line #1786	-> byte code offset #0
    //   Java source line #1787	-> byte code offset #12
    //   Java source line #1788	-> byte code offset #19
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	27	0	this	ResultSetImpl
    //   10	11	1	Ljava/lang/Object;	Object
    //   19	4	2	localObject1	Object
    //   24	2	3	localCJException	CJException
    // Exception table:
    //   from	to	target	type
    //   12	18	19	finally
    //   19	22	19	finally
    //   0	24	24	com/mysql/cj/exceptions/CJException
  }
  
  public void realClose(boolean calledExplicitly)
    throws SQLException
  {
    try
    {
      JdbcConnection locallyScopedConn = connection;
      if (locallyScopedConn == null) {
        return;
      }
      synchronized (locallyScopedConn.getConnectionMutex())
      {
        if (isClosed) {
          return;
        }
        try
        {
          if (useUsageAdvisor)
          {
            if (!calledExplicitly) {
              eventSink.processEvent((byte)0, session, owningStatement, this, 0L, new Throwable(), 
                Messages.getString("ResultSet.ResultSet_implicitly_closed_by_driver"));
            }
            int resultSetSizeThreshold = ((Integer)locallyScopedConn.getPropertySet().getIntegerProperty(PropertyKey.resultSetSizeThreshold).getValue()).intValue();
            if (rowData.size() > resultSetSizeThreshold) {
              eventSink.processEvent((byte)0, session, owningStatement, this, 0L, new Throwable(), 
                Messages.getString("ResultSet.Too_Large_Result_Set", new Object[] {
                Integer.valueOf(rowData.size()), Integer.valueOf(resultSetSizeThreshold) }));
            }
            if ((!isLast()) && (!isAfterLast()) && (rowData.size() != 0)) {
              eventSink.processEvent((byte)0, session, owningStatement, this, 0L, new Throwable(), 
                Messages.getString("ResultSet.Possible_incomplete_traversal_of_result_set", new Object[] {
                Integer.valueOf(getRow()), Integer.valueOf(rowData.size()) }));
            }
            if ((columnUsed.length > 0) && (!rowData.wasEmpty()))
            {
              StringBuilder buf = new StringBuilder();
              for (int i = 0; i < columnUsed.length; i++) {
                if (columnUsed[i] == 0)
                {
                  if (buf.length() > 0) {
                    buf.append(", ");
                  }
                  buf.append(columnDefinition.getFields()[i].getFullName());
                }
              }
              if (buf.length() > 0) {
                eventSink.processEvent((byte)0, session, owningStatement, this, 0L, new Throwable(), 
                  Messages.getString("ResultSet.The_following_columns_were_never_referenced", new String[] {buf.toString() }));
              }
            }
          }
        }
        finally
        {
          SQLException exceptionDuringClose;
          if ((owningStatement != null) && (calledExplicitly)) {
            owningStatement.removeOpenResultSet(this);
          }
          SQLException exceptionDuringClose = null;
          if (rowData != null) {
            try
            {
              rowData.close();
            }
            catch (CJException sqlEx)
            {
              exceptionDuringClose = SQLExceptionsMapping.translateException(sqlEx);
            }
          }
          if (statementUsedForFetchingRows != null) {
            try
            {
              statementUsedForFetchingRows.realClose(true, false);
            }
            catch (SQLException sqlEx)
            {
              if (exceptionDuringClose != null) {
                exceptionDuringClose.setNextException(sqlEx);
              } else {
                exceptionDuringClose = sqlEx;
              }
            }
          }
          rowData = null;
          columnDefinition = null;
          eventSink = null;
          warningChain = null;
          owningStatement = null;
          db = null;
          serverInfo = null;
          thisRow = null;
          fastDefaultCal = null;
          fastClientCal = null;
          connection = null;
          session = null;
          
          isClosed = true;
          if (exceptionDuringClose != null) {
            throw exceptionDuringClose;
          }
        }
      }
      return;
    }
    catch (CJException localCJException1)
    {
      throw SQLExceptionsMapping.translateException(localCJException1, getExceptionInterceptor());
    }
  }
  
  public boolean isClosed()
    throws SQLException
  {
    try
    {
      return isClosed;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void refreshRow()
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean relative(int rows)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (rowData.size() == 0)
        {
          setRowPositionValidity();
          
          return false;
        }
        rowData.moveRowRelative(rows);
        thisRow = rowData.get(rowData.getPosition());
        
        setRowPositionValidity();
        
        return (!rowData.isAfterLast()) && (!rowData.isBeforeFirst());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean rowDeleted()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean rowInserted()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean rowUpdated()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setFetchDirection(int direction)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if ((direction != 1000) && (direction != 1001) && (direction != 1002)) {
          throw SQLError.createSQLException(Messages.getString("ResultSet.Illegal_value_for_fetch_direction_64"), "S1009", 
            getExceptionInterceptor());
        }
        fetchDirection = direction;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setFetchSize(int rows)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (rows < 0) {
          throw SQLError.createSQLException(Messages.getString("ResultSet.Value_must_be_between_0_and_getMaxRows()_66"), "S1009", 
            getExceptionInterceptor());
        }
        fetchSize = rows;
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setFirstCharOfQuery(char c)
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        firstCharOfQuery = c;
      }
    }
    catch (SQLException e)
    {
      throw new RuntimeException(e);
    }
  }
  
  public void setOwningStatement(JdbcStatement owningStatement)
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        this.owningStatement = ((StatementImpl)owningStatement);
      }
    }
    catch (SQLException e)
    {
      throw new RuntimeException(e);
    }
  }
  
  public synchronized void setResultSetConcurrency(int concurrencyFlag)
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        resultSetConcurrency = concurrencyFlag;
      }
    }
    catch (SQLException e)
    {
      throw new RuntimeException(e);
    }
  }
  
  public synchronized void setResultSetType(int typeFlag)
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        resultSetType = typeFlag;
      }
    }
    catch (SQLException e)
    {
      throw new RuntimeException(e);
    }
  }
  
  public void setServerInfo(String info)
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        serverInfo = info;
      }
    }
    catch (SQLException e)
    {
      throw new RuntimeException(e);
    }
  }
  
  public synchronized void setStatementUsedForFetchingRows(JdbcPreparedStatement stmt)
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        statementUsedForFetchingRows = stmt;
      }
    }
    catch (SQLException e)
    {
      throw new RuntimeException(e);
    }
  }
  
  public synchronized void setWrapperStatement(Statement wrapperStatement)
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        this.wrapperStatement = wrapperStatement;
      }
    }
    catch (SQLException e)
    {
      throw new RuntimeException(e);
    }
  }
  
  public String toString()
  {
    return "Result set representing update count of " + updateCount;
  }
  
  public void updateArray(int columnIndex, Array arg1)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateArray(String columnLabel, Array arg1)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(int columnIndex, InputStream x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(String columnLabel, InputStream x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(int columnIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(String columnName, InputStream x, int length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(int columnIndex, InputStream x, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(String columnLabel, InputStream x, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBigDecimal(int columnIndex, BigDecimal x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBigDecimal(String columnName, BigDecimal x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(int columnIndex, InputStream x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(String columnLabel, InputStream x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(int columnIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(String columnName, InputStream x, int length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(int columnIndex, InputStream x, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(String columnLabel, InputStream x, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(int columnIndex, java.sql.Blob arg1)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(String columnLabel, java.sql.Blob arg1)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(int columnIndex, InputStream inputStream)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(String columnLabel, InputStream inputStream)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(int columnIndex, InputStream inputStream, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(String columnLabel, InputStream inputStream, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBoolean(int columnIndex, boolean x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBoolean(String columnName, boolean x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateByte(int columnIndex, byte x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateByte(String columnName, byte x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBytes(int columnIndex, byte[] x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBytes(String columnName, byte[] x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(int columnIndex, Reader x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(String columnLabel, Reader reader)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(int columnIndex, Reader x, int length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(String columnName, Reader reader, int length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(int columnIndex, Reader x, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(String columnLabel, Reader reader, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(int columnIndex, java.sql.Clob arg1)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(String columnName, java.sql.Clob clob)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(int columnIndex, Reader reader)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(String columnLabel, Reader reader)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(int columnIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(String columnLabel, Reader reader, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateDate(int columnIndex, Date x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateDate(String columnName, Date x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateDouble(int columnIndex, double x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateDouble(String columnName, double x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateFloat(int columnIndex, float x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateFloat(String columnName, float x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateInt(int columnIndex, int x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateInt(String columnName, int x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateLong(int columnIndex, long x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateLong(String columnName, long x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNCharacterStream(int columnIndex, Reader x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNCharacterStream(String columnLabel, Reader reader)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNCharacterStream(int columnIndex, Reader x, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNCharacterStream(String columnLabel, Reader reader, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(int columnIndex, java.sql.NClob nClob)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(String columnName, java.sql.NClob nClob)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(int columnIndex, Reader reader)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(String columnLabel, Reader reader)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(int columnIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(String columnLabel, Reader reader, long length)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNull(int columnIndex)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNull(String columnName)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNString(int columnIndex, String nString)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNString(String columnLabel, String nString)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(int columnIndex, Object x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(String columnName, Object x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(int columnIndex, Object x, int scale)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(String columnName, Object x, int scale)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(int columnIndex, Object x, SQLType targetSqlType)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(int columnIndex, Object x, SQLType targetSqlType, int scaleOrLength)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(String columnLabel, Object x, SQLType targetSqlType)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(String columnLabel, Object x, SQLType targetSqlType, int scaleOrLength)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateRef(int columnIndex, Ref arg1)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateRef(String columnLabel, Ref arg1)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateRow()
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateRowId(int columnIndex, RowId x)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateRowId(String columnName, RowId x)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateShort(int columnIndex, short x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateShort(String columnName, short x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateSQLXML(int columnIndex, SQLXML xmlObject)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateSQLXML(String columnLabel, SQLXML xmlObject)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateString(int columnIndex, String x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateString(String columnName, String x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateTime(int columnIndex, Time x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateTime(String columnName, Time x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateTimestamp(int columnIndex, Timestamp x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateTimestamp(String columnName, Timestamp x)
    throws SQLException
  {
    try
    {
      throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean wasNull()
    throws SQLException
  {
    try
    {
      return thisRow.wasNull();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected ExceptionInterceptor getExceptionInterceptor()
  {
    return exceptionInterceptor;
  }
  
  public int getHoldability()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public RowId getRowId(int columnIndex)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public RowId getRowId(String columnLabel)
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public SQLXML getSQLXML(int columnIndex)
    throws SQLException
  {
    try
    {
      checkColumnBounds(columnIndex);
      
      return new MysqlSQLXML(this, columnIndex, getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public SQLXML getSQLXML(String columnLabel)
    throws SQLException
  {
    try
    {
      return getSQLXML(findColumn(columnLabel));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    try
    {
      checkClosed();
      
      return iface.isInstance(this);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      try
      {
        return (T)iface.cast(this);
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException(Messages.getString("Common.UnableToUnwrap", new Object[] { iface.toString() }), "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public synchronized void warningEncountered(String warning)
  {
    SQLWarning w = new SQLWarning(warning);
    if (warningChain == null) {
      warningChain = w;
    } else {
      warningChain.setNextWarning(w);
    }
  }
  
  public ColumnDefinition getMetadata()
  {
    return columnDefinition;
  }
  
  public StatementImpl getOwningStatement()
  {
    return owningStatement;
  }
  
  public void closeOwner(boolean calledExplicitly)
  {
    try
    {
      realClose(calledExplicitly);
    }
    catch (SQLException e)
    {
      throw ExceptionFactory.createException(e.getMessage(), e);
    }
  }
  
  public JdbcConnection getConnection()
  {
    return connection;
  }
  
  public Session getSession()
  {
    return connection != null ? connection.getSession() : null;
  }
  
  public String getPointOfOrigin()
  {
    return pointOfOrigin;
  }
  
  public int getOwnerFetchSize()
  {
    try
    {
      return getFetchSize();
    }
    catch (SQLException e)
    {
      throw ExceptionFactory.createException(e.getMessage(), e);
    }
  }
  
  public Query getOwningQuery()
  {
    return owningStatement;
  }
  
  public int getOwningStatementMaxRows()
  {
    return owningStatement == null ? -1 : owningStatement.maxRows;
  }
  
  public int getOwningStatementFetchSize()
  {
    try
    {
      return owningStatement == null ? 0 : owningStatement.getFetchSize();
    }
    catch (SQLException e)
    {
      throw ExceptionFactory.createException(e.getMessage(), e);
    }
  }
  
  public long getOwningStatementServerId()
  {
    return owningStatement == null ? 0L : owningStatement.getServerStatementId();
  }
  
  public Object getSyncMutex()
  {
    return connection != null ? connection.getConnectionMutex() : null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.result.ResultSetImpl
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */