package com.mysql.cj.jdbc.result;

import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.NativeSession;
import com.mysql.cj.QueryBindings;
import com.mysql.cj.Session;
import com.mysql.cj.conf.PropertyDefinitions.DatabaseTerm;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.AssertionFailedException;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.FeatureNotAvailableException;
import com.mysql.cj.jdbc.ClientPreparedStatement;
import com.mysql.cj.jdbc.JdbcConnection;
import com.mysql.cj.jdbc.MysqlSQLXML;
import com.mysql.cj.jdbc.StatementImpl;
import com.mysql.cj.jdbc.exceptions.NotUpdatable;
import com.mysql.cj.jdbc.exceptions.SQLError;
import com.mysql.cj.jdbc.exceptions.SQLExceptionsMapping;
import com.mysql.cj.log.ProfilerEventHandler;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ResultsetRow;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.Row;
import com.mysql.cj.util.StringUtils;
import java.io.InputStream;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.DatabaseMetaData;
import java.sql.Date;
import java.sql.JDBCType;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.SQLType;
import java.sql.SQLXML;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

public class UpdatableResultSet
  extends ResultSetImpl
{
  static final byte[] STREAM_DATA_MARKER = StringUtils.getBytes("** STREAM DATA **");
  private String charEncoding;
  private byte[][] defaultColumnValue;
  private ClientPreparedStatement deleter = null;
  private String deleteSQL = null;
  protected ClientPreparedStatement inserter = null;
  private String insertSQL = null;
  private boolean isUpdatable = false;
  private String notUpdatableReason = null;
  private List<Integer> primaryKeyIndicies = null;
  private String qualifiedAndQuotedTableName;
  private String quotedIdChar = null;
  private ClientPreparedStatement refresher;
  private String refreshSQL = null;
  private Row savedCurrentRow;
  protected ClientPreparedStatement updater = null;
  private String updateSQL = null;
  private boolean populateInserterWithDefaultValues = false;
  private boolean pedantic;
  private boolean hasLongColumnInfo = false;
  private Map<String, Map<String, Map<String, Integer>>> databasesUsedToTablesUsed = null;
  private boolean onInsertRow = false;
  protected boolean doingUpdates = false;
  
  public UpdatableResultSet(ResultsetRows tuples, JdbcConnection conn, StatementImpl creatorStmt)
    throws SQLException
  {
    super(tuples, conn, creatorStmt);
    checkUpdatability();
    
    populateInserterWithDefaultValues = ((Boolean)getSession().getPropertySet().getBooleanProperty(PropertyKey.populateInsertRowWithDefaultValues).getValue()).booleanValue();
    pedantic = ((Boolean)getSession().getPropertySet().getBooleanProperty(PropertyKey.pedantic).getValue()).booleanValue();
    hasLongColumnInfo = getSession().getServerSession().hasLongColumnInfo();
  }
  
  public boolean absolute(int row)
    throws SQLException
  {
    try
    {
      if (onInsertRow) {
        onInsertRow = false;
      }
      if (doingUpdates) {
        doingUpdates = false;
      }
      return super.absolute(row);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void afterLast()
    throws SQLException
  {
    try
    {
      if (onInsertRow) {
        onInsertRow = false;
      }
      if (doingUpdates) {
        doingUpdates = false;
      }
      super.afterLast();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void beforeFirst()
    throws SQLException
  {
    try
    {
      if (onInsertRow) {
        onInsertRow = false;
      }
      if (doingUpdates) {
        doingUpdates = false;
      }
      super.beforeFirst();
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void cancelRowUpdates()
    throws SQLException
  {
    try
    {
      if (doingUpdates)
      {
        doingUpdates = false;
        updater.clearParameters();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void checkRowPos()
    throws SQLException
  {
    if (!onInsertRow) {
      super.checkRowPos();
    }
  }
  
  public void checkUpdatability()
    throws SQLException
  {
    try
    {
      if (getMetadata() == null) {
        return;
      }
      String singleTableName = null;
      String dbName = null;
      
      int primaryKeyCount = 0;
      
      Field[] fields = getMetadata().getFields();
      if ((db == null) || (db.length() == 0))
      {
        db = fields[0].getDatabaseName();
        if ((db == null) || (db.length() == 0)) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.43"), "S1009", 
            getExceptionInterceptor());
        }
      }
      if (fields.length > 0)
      {
        singleTableName = fields[0].getOriginalTableName();
        dbName = fields[0].getDatabaseName();
        if (singleTableName == null)
        {
          singleTableName = fields[0].getTableName();
          dbName = db;
        }
        if (singleTableName == null)
        {
          isUpdatable = false;
          notUpdatableReason = Messages.getString("NotUpdatableReason.3");
          
          return;
        }
        if (fields[0].isPrimaryKey()) {
          primaryKeyCount++;
        }
        for (int i = 1; i < fields.length; i++)
        {
          String otherTableName = fields[i].getOriginalTableName();
          String otherDbName = fields[i].getDatabaseName();
          if (otherTableName == null)
          {
            otherTableName = fields[i].getTableName();
            otherDbName = db;
          }
          if (otherTableName == null)
          {
            isUpdatable = false;
            notUpdatableReason = Messages.getString("NotUpdatableReason.3");
            
            return;
          }
          if (!otherTableName.equals(singleTableName))
          {
            isUpdatable = false;
            notUpdatableReason = Messages.getString("NotUpdatableReason.0");
            
            return;
          }
          if ((dbName == null) || (!otherDbName.equals(dbName)))
          {
            isUpdatable = false;
            notUpdatableReason = Messages.getString("NotUpdatableReason.1");
            
            return;
          }
          if (fields[i].isPrimaryKey()) {
            primaryKeyCount++;
          }
        }
      }
      else
      {
        isUpdatable = false;
        notUpdatableReason = Messages.getString("NotUpdatableReason.3");
        
        return;
      }
      if (((Boolean)getSession().getPropertySet().getBooleanProperty(PropertyKey.strictUpdates).getValue()).booleanValue())
      {
        DatabaseMetaData dbmd = getConnection().getMetaData();
        
        ResultSet rs = null;
        HashMap<String, String> primaryKeyNames = new HashMap();
        try
        {
          rs = session.getPropertySet().getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? dbmd.getPrimaryKeys(null, dbName, singleTableName) : dbmd.getPrimaryKeys(dbName, null, singleTableName);
          while (rs.next())
          {
            String keyName = rs.getString(4);
            keyName = keyName.toUpperCase();
            primaryKeyNames.put(keyName, keyName);
          }
        }
        finally
        {
          if (rs != null)
          {
            try
            {
              rs.close();
            }
            catch (Exception ex)
            {
              AssertionFailedException.shouldNotHappen(ex);
            }
            rs = null;
          }
        }
        int existingPrimaryKeysCount = primaryKeyNames.size();
        if (existingPrimaryKeysCount == 0)
        {
          isUpdatable = false;
          notUpdatableReason = Messages.getString("NotUpdatableReason.5");
          
          return;
        }
        for (int i = 0; i < fields.length; i++) {
          if (fields[i].isPrimaryKey())
          {
            String columnNameUC = fields[i].getName().toUpperCase();
            if (primaryKeyNames.remove(columnNameUC) == null)
            {
              String originalName = fields[i].getOriginalName();
              if ((originalName != null) && 
                (primaryKeyNames.remove(originalName.toUpperCase()) == null))
              {
                isUpdatable = false;
                notUpdatableReason = Messages.getString("NotUpdatableReason.6", new Object[] { originalName });
                
                return;
              }
            }
          }
        }
        isUpdatable = primaryKeyNames.isEmpty();
        if (!isUpdatable)
        {
          notUpdatableReason = (existingPrimaryKeysCount > 1 ? Messages.getString("NotUpdatableReason.7") : Messages.getString("NotUpdatableReason.4"));
          return;
        }
      }
      if (primaryKeyCount == 0)
      {
        isUpdatable = false;
        notUpdatableReason = Messages.getString("NotUpdatableReason.4");
        
        return;
      }
      isUpdatable = true;
      notUpdatableReason = null;
      
      return;
    }
    catch (SQLException sqlEx)
    {
      isUpdatable = false;
      notUpdatableReason = sqlEx.getMessage();
    }
  }
  
  public void deleteRow()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!isUpdatable) {
          throw new NotUpdatable(notUpdatableReason);
        }
        if (onInsertRow) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.1"), getExceptionInterceptor());
        }
        if (rowData.size() == 0) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.2"), getExceptionInterceptor());
        }
        if (isBeforeFirst()) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.3"), getExceptionInterceptor());
        }
        if (isAfterLast()) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.4"), getExceptionInterceptor());
        }
        if (deleter == null)
        {
          if (deleteSQL == null) {
            generateStatements();
          }
          deleter = ((ClientPreparedStatement)connection.clientPrepareStatement(deleteSQL));
        }
        deleter.clearParameters();
        
        int numKeys = primaryKeyIndicies.size();
        for (int i = 0; i < numKeys; i++)
        {
          int index = ((Integer)primaryKeyIndicies.get(i)).intValue();
          setParamValue(deleter, i + 1, thisRow, index, getMetadata().getFields()[index]);
        }
        deleter.executeUpdate();
        rowData.remove();
        
        previous();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void setParamValue(ClientPreparedStatement ps, int psIdx, Row row, int rsIdx, Field field)
    throws SQLException
  {
    byte[] val = row.getBytes(rsIdx);
    if (val == null)
    {
      ps.setNull(psIdx, MysqlType.NULL);
      return;
    }
    switch (field.getMysqlType())
    {
    case NULL: 
      ps.setNull(psIdx, MysqlType.NULL);
      break;
    case TINYINT: 
    case TINYINT_UNSIGNED: 
    case SMALLINT: 
    case SMALLINT_UNSIGNED: 
    case MEDIUMINT: 
    case MEDIUMINT_UNSIGNED: 
    case INT: 
    case INT_UNSIGNED: 
    case YEAR: 
      ps.setInt(psIdx, getInt(rsIdx + 1));
      break;
    case BIGINT: 
      ps.setLong(psIdx, getLong(rsIdx + 1));
      break;
    case BIGINT_UNSIGNED: 
      ps.setBigInteger(psIdx, getBigInteger(rsIdx + 1));
      break;
    case CHAR: 
    case ENUM: 
    case SET: 
    case VARCHAR: 
    case JSON: 
    case TINYTEXT: 
    case TEXT: 
    case MEDIUMTEXT: 
    case LONGTEXT: 
    case DECIMAL: 
    case DECIMAL_UNSIGNED: 
      ps.setString(psIdx, getString(rsIdx + 1));
      break;
    case DATE: 
      ps.setDate(psIdx, getDate(rsIdx + 1));
      break;
    case TIMESTAMP: 
    case DATETIME: 
      ps.setTimestamp(psIdx, getTimestamp(rsIdx + 1), null, field.getDecimals());
      break;
    case TIME: 
      ps.setTime(psIdx, getTime(rsIdx + 1));
      break;
    case DOUBLE: 
    case DOUBLE_UNSIGNED: 
    case FLOAT: 
    case FLOAT_UNSIGNED: 
    case BOOLEAN: 
    case BIT: 
      ps.setBytesNoEscapeNoQuotes(psIdx, val);
      break;
    default: 
      ps.setBytes(psIdx, val);
    }
  }
  
  private void extractDefaultValues()
    throws SQLException
  {
    DatabaseMetaData dbmd = getConnection().getMetaData();
    defaultColumnValue = new byte[getMetadata().getFields().length][];
    
    ResultSet columnsResultSet = null;
    for (Map.Entry<String, Map<String, Map<String, Integer>>> dbEntry : databasesUsedToTablesUsed.entrySet()) {
      for (Map.Entry<String, Map<String, Integer>> tableEntry : ((Map)dbEntry.getValue()).entrySet())
      {
        String tableName = (String)tableEntry.getKey();
        Map<String, Integer> columnNamesToIndices = (Map)tableEntry.getValue();
        try
        {
          columnsResultSet = session.getPropertySet().getEnumProperty(PropertyKey.databaseTerm).getValue() == PropertyDefinitions.DatabaseTerm.SCHEMA ? dbmd.getColumns(null, db, tableName, "%") : dbmd.getColumns(db, null, tableName, "%");
          while (columnsResultSet.next())
          {
            String columnName = columnsResultSet.getString("COLUMN_NAME");
            byte[] defaultValue = columnsResultSet.getBytes("COLUMN_DEF");
            if (columnNamesToIndices.containsKey(columnName))
            {
              int localColumnIndex = ((Integer)columnNamesToIndices.get(columnName)).intValue();
              defaultColumnValue[localColumnIndex] = defaultValue;
            }
          }
        }
        finally
        {
          if (columnsResultSet != null)
          {
            columnsResultSet.close();
            columnsResultSet = null;
          }
        }
      }
    }
  }
  
  public boolean first()
    throws SQLException
  {
    try
    {
      if (onInsertRow) {
        onInsertRow = false;
      }
      if (doingUpdates) {
        doingUpdates = false;
      }
      return super.first();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void generateStatements()
    throws SQLException
  {
    try
    {
      if (!isUpdatable)
      {
        doingUpdates = false;
        onInsertRow = false;
        
        throw new NotUpdatable(notUpdatableReason);
      }
      String quotedId = getQuotedIdChar();
      
      Map<String, String> tableNamesSoFar = null;
      if (session.getServerSession().isLowerCaseTableNames())
      {
        tableNamesSoFar = new TreeMap(String.CASE_INSENSITIVE_ORDER);
        databasesUsedToTablesUsed = new TreeMap(String.CASE_INSENSITIVE_ORDER);
      }
      else
      {
        tableNamesSoFar = new TreeMap();
        databasesUsedToTablesUsed = new TreeMap();
      }
      primaryKeyIndicies = new ArrayList();
      
      StringBuilder fieldValues = new StringBuilder();
      StringBuilder keyValues = new StringBuilder();
      StringBuilder columnNames = new StringBuilder();
      StringBuilder insertPlaceHolders = new StringBuilder();
      StringBuilder allTablesBuf = new StringBuilder();
      Map<Integer, String> columnIndicesToTable = new HashMap();
      
      Field[] fields = getMetadata().getFields();
      for (int i = 0; i < fields.length; i++)
      {
        Map<String, Integer> updColumnNameToIndex = null;
        if (fields[i].getOriginalTableName() != null)
        {
          String databaseName = fields[i].getDatabaseName();
          String tableOnlyName = fields[i].getOriginalTableName();
          
          String fqTableName = StringUtils.getFullyQualifiedName(databaseName, tableOnlyName, quotedId, pedantic);
          if (!tableNamesSoFar.containsKey(fqTableName))
          {
            if (!tableNamesSoFar.isEmpty()) {
              allTablesBuf.append(',');
            }
            allTablesBuf.append(fqTableName);
            tableNamesSoFar.put(fqTableName, fqTableName);
          }
          columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
          
          updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(databaseName, tableOnlyName);
        }
        else
        {
          String tableOnlyName = fields[i].getTableName();
          if (tableOnlyName != null)
          {
            String fqTableName = StringUtils.quoteIdentifier(tableOnlyName, quotedId, pedantic);
            if (!tableNamesSoFar.containsKey(fqTableName))
            {
              if (!tableNamesSoFar.isEmpty()) {
                allTablesBuf.append(',');
              }
              allTablesBuf.append(fqTableName);
              tableNamesSoFar.put(fqTableName, fqTableName);
            }
            columnIndicesToTable.put(Integer.valueOf(i), fqTableName);
            
            updColumnNameToIndex = getColumnsToIndexMapForTableAndDB(db, tableOnlyName);
          }
        }
        String originalColumnName = fields[i].getOriginalName();
        
        String columnName = (hasLongColumnInfo) && (originalColumnName != null) && (originalColumnName.length() > 0) ? originalColumnName : fields[i].getName();
        if ((updColumnNameToIndex != null) && (columnName != null)) {
          updColumnNameToIndex.put(columnName, Integer.valueOf(i));
        }
        String originalTableName = fields[i].getOriginalTableName();
        
        String tableName = (hasLongColumnInfo) && (originalTableName != null) && (originalTableName.length() > 0) ? originalTableName : fields[i].getTableName();
        
        String databaseName = fields[i].getDatabaseName();
        
        String qualifiedColumnName = StringUtils.getFullyQualifiedName(databaseName, tableName, quotedId, pedantic) + '.' + StringUtils.quoteIdentifier(columnName, quotedId, pedantic);
        if (fields[i].isPrimaryKey())
        {
          primaryKeyIndicies.add(Integer.valueOf(i));
          if (keyValues.length() > 0) {
            keyValues.append(" AND ");
          }
          keyValues.append(qualifiedColumnName);
          keyValues.append("<=>");
          keyValues.append("?");
        }
        if (fieldValues.length() == 0)
        {
          fieldValues.append("SET ");
        }
        else
        {
          fieldValues.append(",");
          columnNames.append(",");
          insertPlaceHolders.append(",");
        }
        insertPlaceHolders.append("?");
        
        columnNames.append(qualifiedColumnName);
        
        fieldValues.append(qualifiedColumnName);
        fieldValues.append("=?");
      }
      qualifiedAndQuotedTableName = allTablesBuf.toString();
      
      updateSQL = ("UPDATE " + qualifiedAndQuotedTableName + " " + fieldValues.toString() + " WHERE " + keyValues.toString());
      insertSQL = ("INSERT INTO " + qualifiedAndQuotedTableName + " (" + columnNames.toString() + ") VALUES (" + insertPlaceHolders.toString() + ")");
      refreshSQL = ("SELECT " + columnNames.toString() + " FROM " + qualifiedAndQuotedTableName + " WHERE " + keyValues.toString());
      deleteSQL = ("DELETE FROM " + qualifiedAndQuotedTableName + " WHERE " + keyValues.toString());
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private Map<String, Integer> getColumnsToIndexMapForTableAndDB(String databaseName, String tableName)
  {
    Map<String, Map<String, Integer>> tablesUsedToColumnsMap = (Map)databasesUsedToTablesUsed.get(databaseName);
    if (tablesUsedToColumnsMap == null)
    {
      tablesUsedToColumnsMap = session.getServerSession().isLowerCaseTableNames() ? new TreeMap(String.CASE_INSENSITIVE_ORDER) : new TreeMap();
      databasesUsedToTablesUsed.put(databaseName, tablesUsedToColumnsMap);
    }
    Map<String, Integer> nameToIndex = (Map)tablesUsedToColumnsMap.get(tableName);
    if (nameToIndex == null)
    {
      nameToIndex = new HashMap();
      tablesUsedToColumnsMap.put(tableName, nameToIndex);
    }
    return nameToIndex;
  }
  
  public int getConcurrency()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        return isUpdatable ? 1008 : 1007;
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private String getQuotedIdChar()
    throws SQLException
  {
    if (quotedIdChar == null) {
      quotedIdChar = session.getIdentifierQuoteString();
    }
    return quotedIdChar;
  }
  
  public void insertRow()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.7"), getExceptionInterceptor());
        }
        inserter.executeUpdate();
        
        long autoIncrementId = inserter.getLastInsertID();
        Field[] fields = getMetadata().getFields();
        byte[][] newRow = new byte[fields.length][];
        for (int i = 0; i < fields.length; i++)
        {
          newRow[i] = (inserter.isNull(i + 1) ? null : inserter.getBytesRepresentation(i + 1));
          if ((fields[i].isAutoIncrement()) && (autoIncrementId > 0L))
          {
            newRow[i] = StringUtils.getBytes(String.valueOf(autoIncrementId));
            inserter.setBytesNoEscapeNoQuotes(i + 1, newRow[i]);
          }
        }
        Row resultSetRow = new ByteArrayRow(newRow, getExceptionInterceptor());
        
        refreshRow(inserter, resultSetRow);
        
        rowData.addRow(resultSetRow);
        resetInserter();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isAfterLast()
    throws SQLException
  {
    try
    {
      return super.isAfterLast();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isBeforeFirst()
    throws SQLException
  {
    try
    {
      return super.isBeforeFirst();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isFirst()
    throws SQLException
  {
    try
    {
      return super.isFirst();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isLast()
    throws SQLException
  {
    try
    {
      return super.isLast();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  boolean isUpdatable()
  {
    return isUpdatable;
  }
  
  public boolean last()
    throws SQLException
  {
    try
    {
      if (onInsertRow) {
        onInsertRow = false;
      }
      if (doingUpdates) {
        doingUpdates = false;
      }
      return super.last();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void moveToCurrentRow()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!isUpdatable) {
          throw new NotUpdatable(notUpdatableReason);
        }
        if (onInsertRow)
        {
          onInsertRow = false;
          thisRow = savedCurrentRow;
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void moveToInsertRow()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!isUpdatable) {
          throw new NotUpdatable(notUpdatableReason);
        }
        if (inserter == null)
        {
          if (insertSQL == null) {
            generateStatements();
          }
          inserter = ((ClientPreparedStatement)getConnection().clientPrepareStatement(insertSQL));
          inserter.getQueryBindings().setColumnDefinition(getMetadata());
          if (populateInserterWithDefaultValues) {
            extractDefaultValues();
          }
        }
        resetInserter();
        
        Field[] fields = getMetadata().getFields();
        int numFields = fields.length;
        
        onInsertRow = true;
        doingUpdates = false;
        savedCurrentRow = thisRow;
        byte[][] newRowData = new byte[numFields][];
        thisRow = new ByteArrayRow(newRowData, getExceptionInterceptor());
        thisRow.setMetadata(getMetadata());
        for (int i = 0; i < numFields; i++) {
          if (!populateInserterWithDefaultValues)
          {
            inserter.setBytesNoEscapeNoQuotes(i + 1, StringUtils.getBytes("DEFAULT"));
            newRowData = (byte[][])null;
          }
          else if (defaultColumnValue[i] != null)
          {
            Field f = fields[i];
            switch (f.getMysqlTypeId())
            {
            case 7: 
            case 10: 
            case 11: 
            case 12: 
              if ((defaultColumnValue[i].length > 7) && (defaultColumnValue[i][0] == 67) && (defaultColumnValue[i][1] == 85) && (defaultColumnValue[i][2] == 82) && (defaultColumnValue[i][3] == 82) && (defaultColumnValue[i][4] == 69) && (defaultColumnValue[i][5] == 78) && (defaultColumnValue[i][6] == 84) && (defaultColumnValue[i][7] == 95)) {
                inserter.setBytesNoEscapeNoQuotes(i + 1, defaultColumnValue[i]);
              } else {
                inserter.setBytes(i + 1, defaultColumnValue[i], false, false);
              }
              break;
            case 8: 
            case 9: 
            default: 
              inserter.setBytes(i + 1, defaultColumnValue[i], false, false);
            }
            byte[] defaultValueCopy = new byte[defaultColumnValue[i].length];
            System.arraycopy(defaultColumnValue[i], 0, defaultValueCopy, 0, defaultValueCopy.length);
            newRowData[i] = defaultValueCopy;
          }
          else
          {
            inserter.setNull(i + 1, MysqlType.NULL);
            newRowData[i] = null;
          }
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean next()
    throws SQLException
  {
    try
    {
      if (onInsertRow) {
        onInsertRow = false;
      }
      if (doingUpdates) {
        doingUpdates = false;
      }
      return super.next();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean prev()
    throws SQLException
  {
    return super.prev();
  }
  
  public boolean previous()
    throws SQLException
  {
    try
    {
      if (onInsertRow) {
        onInsertRow = false;
      }
      if (doingUpdates) {
        doingUpdates = false;
      }
      return super.previous();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void realClose(boolean calledExplicitly)
    throws SQLException
  {
    try
    {
      if (isClosed) {
        return;
      }
      synchronized (checkClosed().getConnectionMutex())
      {
        SQLException sqlEx = null;
        if ((useUsageAdvisor) && 
          (deleter == null) && (inserter == null) && (refresher == null) && (updater == null)) {
          eventSink.processEvent((byte)0, session, getOwningStatement(), this, 0L, new Throwable(), 
            Messages.getString("UpdatableResultSet.34"));
        }
        try
        {
          if (deleter != null) {
            deleter.close();
          }
        }
        catch (SQLException ex)
        {
          sqlEx = ex;
        }
        try
        {
          if (inserter != null) {
            inserter.close();
          }
        }
        catch (SQLException ex)
        {
          sqlEx = ex;
        }
        try
        {
          if (refresher != null) {
            refresher.close();
          }
        }
        catch (SQLException ex)
        {
          sqlEx = ex;
        }
        try
        {
          if (updater != null) {
            updater.close();
          }
        }
        catch (SQLException ex)
        {
          sqlEx = ex;
        }
        super.realClose(calledExplicitly);
        if (sqlEx != null) {
          throw sqlEx;
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void refreshRow()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!isUpdatable) {
          throw new NotUpdatable(Messages.getString("NotUpdatable.0"));
        }
        if (onInsertRow) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.8"), getExceptionInterceptor());
        }
        if (rowData.size() == 0) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.9"), getExceptionInterceptor());
        }
        if (isBeforeFirst()) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.10"), getExceptionInterceptor());
        }
        if (isAfterLast()) {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.11"), getExceptionInterceptor());
        }
        refreshRow(updater, thisRow);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void refreshRow(ClientPreparedStatement updateInsertStmt, Row rowToRefresh)
    throws SQLException
  {
    if (refresher == null)
    {
      if (refreshSQL == null) {
        generateStatements();
      }
      refresher = (((ResultsetRow)thisRow).isBinaryEncoded() ? (ClientPreparedStatement)getConnection().serverPrepareStatement(refreshSQL) : (ClientPreparedStatement)getConnection().clientPrepareStatement(refreshSQL));
      
      refresher.getQueryBindings().setColumnDefinition(getMetadata());
    }
    refresher.clearParameters();
    
    int numKeys = primaryKeyIndicies.size();
    for (int i = 0; i < numKeys; i++)
    {
      byte[] dataFrom = null;
      int index = ((Integer)primaryKeyIndicies.get(i)).intValue();
      if ((!doingUpdates) && (!onInsertRow))
      {
        setParamValue(refresher, i + 1, thisRow, index, getMetadata().getFields()[index]);
      }
      else
      {
        dataFrom = updateInsertStmt.getBytesRepresentation(index + 1);
        if ((updateInsertStmt.isNull(index + 1)) || (dataFrom.length == 0))
        {
          setParamValue(refresher, i + 1, thisRow, index, getMetadata().getFields()[index]);
        }
        else
        {
          dataFrom = stripBinaryPrefix(dataFrom);
          refresher.setBytesNoEscape(i + 1, dataFrom);
        }
      }
    }
    ResultSet rs = null;
    try
    {
      rs = refresher.executeQuery();
      
      int numCols = rs.getMetaData().getColumnCount();
      if (rs.next()) {
        for (int i = 0; i < numCols; i++)
        {
          byte[] val = rs.getBytes(i + 1);
          rowToRefresh.setBytes(i, (val == null) || (rs.wasNull()) ? null : val);
        }
      } else {
        throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.12"), "S1000", 
          getExceptionInterceptor());
      }
      return;
    }
    finally
    {
      if (rs != null) {
        try
        {
          rs.close();
        }
        catch (SQLException localSQLException1) {}
      }
    }
  }
  
  public boolean relative(int rows)
    throws SQLException
  {
    try
    {
      return super.relative(rows);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private void resetInserter()
    throws SQLException
  {
    inserter.clearParameters();
    for (int i = 0; i < getMetadata().getFields().length; i++) {
      inserter.setNull(i + 1, 0);
    }
  }
  
  public boolean rowDeleted()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean rowInserted()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean rowUpdated()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void setResultSetConcurrency(int concurrencyFlag)
  {
    super.setResultSetConcurrency(concurrencyFlag);
  }
  
  private byte[] stripBinaryPrefix(byte[] dataFrom)
  {
    return StringUtils.stripEnclosure(dataFrom, "_binary'", "'");
  }
  
  protected void syncUpdate()
    throws SQLException
  {
    if (updater == null)
    {
      if (updateSQL == null) {
        generateStatements();
      }
      updater = ((ClientPreparedStatement)getConnection().clientPrepareStatement(updateSQL));
      updater.getQueryBindings().setColumnDefinition(getMetadata());
    }
    Field[] fields = getMetadata().getFields();
    int numFields = fields.length;
    updater.clearParameters();
    for (int i = 0; i < numFields; i++) {
      if (thisRow.getBytes(i) != null) {
        switch (fields[i].getMysqlType())
        {
        case DATE: 
        case TIMESTAMP: 
        case DATETIME: 
        case TIME: 
          updater.setString(i + 1, getString(i + 1));
          break;
        default: 
          updater.setObject(i + 1, getObject(i + 1), fields[i].getMysqlType());
          break;
        }
      } else {
        updater.setNull(i + 1, 0);
      }
    }
    int numKeys = primaryKeyIndicies.size();
    for (int i = 0; i < numKeys; i++)
    {
      int idx = ((Integer)primaryKeyIndicies.get(i)).intValue();
      setParamValue(updater, numFields + i + 1, thisRow, idx, fields[idx]);
    }
  }
  
  public void updateRow()
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!isUpdatable) {
          throw new NotUpdatable(notUpdatableReason);
        }
        if (doingUpdates)
        {
          updater.executeUpdate();
          refreshRow();
          doingUpdates = false;
        }
        else if (onInsertRow)
        {
          throw SQLError.createSQLException(Messages.getString("UpdatableResultSet.44"), getExceptionInterceptor());
        }
        syncUpdate();
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public int getHoldability()
    throws SQLException
  {
    try
    {
      throw SQLError.createSQLFeatureNotSupportedException();
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(String columnLabel, InputStream x, int length)
    throws SQLException
  {
    try
    {
      updateAsciiStream(findColumn(columnLabel), x, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(int columnIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setAsciiStream(columnIndex, x, length);
        }
        else
        {
          inserter.setAsciiStream(columnIndex, x, length);
          thisRow.setBytes(columnIndex - 1, STREAM_DATA_MARKER);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBigDecimal(String columnLabel, BigDecimal x)
    throws SQLException
  {
    try
    {
      updateBigDecimal(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBigDecimal(int columnIndex, BigDecimal x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setBigDecimal(columnIndex, x);
        }
        else
        {
          inserter.setBigDecimal(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, x == null ? null : StringUtils.getBytes(x.toString()));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(String columnLabel, InputStream x, int length)
    throws SQLException
  {
    try
    {
      updateBinaryStream(findColumn(columnLabel), x, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(int columnIndex, InputStream x, int length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setBinaryStream(columnIndex, x, length);
        }
        else
        {
          inserter.setBinaryStream(columnIndex, x, length);
          thisRow.setBytes(columnIndex - 1, x == null ? null : STREAM_DATA_MARKER);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(String columnLabel, Blob blob)
    throws SQLException
  {
    try
    {
      updateBlob(findColumn(columnLabel), blob);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(int columnIndex, Blob blob)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setBlob(columnIndex, blob);
        }
        else
        {
          inserter.setBlob(columnIndex, blob);
          thisRow.setBytes(columnIndex - 1, blob == null ? null : STREAM_DATA_MARKER);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBoolean(String columnLabel, boolean x)
    throws SQLException
  {
    try
    {
      updateBoolean(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBoolean(int columnIndex, boolean x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setBoolean(columnIndex, x);
        }
        else
        {
          inserter.setBoolean(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateByte(String columnLabel, byte x)
    throws SQLException
  {
    try
    {
      updateByte(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateByte(int columnIndex, byte x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setByte(columnIndex, x);
        }
        else
        {
          inserter.setByte(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBytes(String columnLabel, byte[] x)
    throws SQLException
  {
    try
    {
      updateBytes(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBytes(int columnIndex, byte[] x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setBytes(columnIndex, x);
        }
        else
        {
          inserter.setBytes(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, x);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(String columnLabel, Reader reader, int length)
    throws SQLException
  {
    try
    {
      updateCharacterStream(findColumn(columnLabel), reader, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(int columnIndex, Reader x, int length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setCharacterStream(columnIndex, x, length);
        }
        else
        {
          inserter.setCharacterStream(columnIndex, x, length);
          thisRow.setBytes(columnIndex - 1, x == null ? null : STREAM_DATA_MARKER);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(String columnLabel, Clob clob)
    throws SQLException
  {
    try
    {
      updateClob(findColumn(columnLabel), clob);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(int columnIndex, Clob clob)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (clob == null) {
          updateNull(columnIndex);
        } else {
          updateCharacterStream(columnIndex, clob.getCharacterStream(), (int)clob.length());
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateDate(String columnLabel, Date x)
    throws SQLException
  {
    try
    {
      updateDate(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateDate(int columnIndex, Date x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setDate(columnIndex, x);
        }
        else
        {
          inserter.setDate(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateDouble(String columnLabel, double x)
    throws SQLException
  {
    try
    {
      updateDouble(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateDouble(int columnIndex, double x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setDouble(columnIndex, x);
        }
        else
        {
          inserter.setDouble(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateFloat(String columnLabel, float x)
    throws SQLException
  {
    try
    {
      updateFloat(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateFloat(int columnIndex, float x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setFloat(columnIndex, x);
        }
        else
        {
          inserter.setFloat(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateInt(String columnLabel, int x)
    throws SQLException
  {
    try
    {
      updateInt(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateInt(int columnIndex, int x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setInt(columnIndex, x);
        }
        else
        {
          inserter.setInt(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateLong(String columnLabel, long x)
    throws SQLException
  {
    try
    {
      updateLong(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateLong(int columnIndex, long x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setLong(columnIndex, x);
        }
        else
        {
          inserter.setLong(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNull(String columnLabel)
    throws SQLException
  {
    try
    {
      updateNull(findColumn(columnLabel));
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNull(int columnIndex)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setNull(columnIndex, 0);
        }
        else
        {
          inserter.setNull(columnIndex, 0);
          thisRow.setBytes(columnIndex - 1, null);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(String columnLabel, Object x)
    throws SQLException
  {
    try
    {
      updateObject(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(int columnIndex, Object x)
    throws SQLException
  {
    try
    {
      updateObjectInternal(columnIndex, x, (Integer)null, 0);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(String columnLabel, Object x, int scale)
    throws SQLException
  {
    try
    {
      updateObject(findColumn(columnLabel), x, scale);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(int columnIndex, Object x, int scale)
    throws SQLException
  {
    try
    {
      updateObjectInternal(columnIndex, x, (Integer)null, scale);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  protected void updateObjectInternal(int columnIndex, Object x, Integer targetType, int scaleOrLength)
    throws SQLException
  {
    try
    {
      MysqlType targetMysqlType = targetType == null ? null : MysqlType.getByJdbcType(targetType.intValue());
      updateObjectInternal(columnIndex, x, targetMysqlType, scaleOrLength);
    }
    catch (FeatureNotAvailableException nae)
    {
      throw SQLError.createSQLFeatureNotSupportedException(Messages.getString("Statement.UnsupportedSQLType") + JDBCType.valueOf(targetType.intValue()), "S1C00", 
        getExceptionInterceptor());
    }
  }
  
  protected void updateObjectInternal(int columnIndex, Object x, SQLType targetType, int scaleOrLength)
    throws SQLException
  {
    synchronized (checkClosed().getConnectionMutex())
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        if (targetType == null) {
          updater.setObject(columnIndex, x);
        } else {
          updater.setObject(columnIndex, x, targetType);
        }
      }
      else
      {
        if (targetType == null) {
          inserter.setObject(columnIndex, x);
        } else {
          inserter.setObject(columnIndex, x, targetType);
        }
        thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
      }
    }
  }
  
  public void updateObject(String columnLabel, Object x, SQLType targetSqlType)
    throws SQLException
  {
    try
    {
      updateObject(findColumn(columnLabel), x, targetSqlType);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(int columnIndex, Object x, SQLType targetSqlType)
    throws SQLException
  {
    try
    {
      updateObjectInternal(columnIndex, x, targetSqlType, 0);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(String columnLabel, Object x, SQLType targetSqlType, int scaleOrLength)
    throws SQLException
  {
    try
    {
      updateObject(findColumn(columnLabel), x, targetSqlType, scaleOrLength);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateObject(int columnIndex, Object x, SQLType targetSqlType, int scaleOrLength)
    throws SQLException
  {
    try
    {
      updateObjectInternal(columnIndex, x, targetSqlType, scaleOrLength);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateShort(String columnLabel, short x)
    throws SQLException
  {
    try
    {
      updateShort(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateShort(int columnIndex, short x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setShort(columnIndex, x);
        }
        else
        {
          inserter.setShort(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateString(String columnLabel, String x)
    throws SQLException
  {
    try
    {
      updateString(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateString(int columnIndex, String x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setString(columnIndex, x);
        }
        else
        {
          inserter.setString(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, x == null ? null : StringUtils.getBytes(x, charEncoding));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateTime(String columnLabel, Time x)
    throws SQLException
  {
    try
    {
      updateTime(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateTime(int columnIndex, Time x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setTime(columnIndex, x);
        }
        else
        {
          inserter.setTime(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateTimestamp(String columnLabel, Timestamp x)
    throws SQLException
  {
    try
    {
      updateTimestamp(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateTimestamp(int columnIndex, Timestamp x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setTimestamp(columnIndex, x);
        }
        else
        {
          inserter.setTimestamp(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, inserter.getBytesRepresentation(columnIndex));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(String columnLabel, InputStream x)
    throws SQLException
  {
    try
    {
      updateAsciiStream(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(int columnIndex, InputStream x)
    throws SQLException
  {
    try
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setAsciiStream(columnIndex, x);
      }
      else
      {
        inserter.setAsciiStream(columnIndex, x);
        thisRow.setBytes(columnIndex - 1, STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(String columnLabel, InputStream x, long length)
    throws SQLException
  {
    try
    {
      updateAsciiStream(findColumn(columnLabel), x, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateAsciiStream(int columnIndex, InputStream x, long length)
    throws SQLException
  {
    try
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setAsciiStream(columnIndex, x, length);
      }
      else
      {
        inserter.setAsciiStream(columnIndex, x, length);
        thisRow.setBytes(columnIndex - 1, STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(String columnLabel, InputStream x)
    throws SQLException
  {
    try
    {
      updateBinaryStream(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(int columnIndex, InputStream x)
    throws SQLException
  {
    try
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setBinaryStream(columnIndex, x);
      }
      else
      {
        inserter.setBinaryStream(columnIndex, x);
        thisRow.setBytes(columnIndex - 1, x == null ? null : STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(String columnLabel, InputStream x, long length)
    throws SQLException
  {
    try
    {
      updateBinaryStream(findColumn(columnLabel), x, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBinaryStream(int columnIndex, InputStream x, long length)
    throws SQLException
  {
    try
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setBinaryStream(columnIndex, x, length);
      }
      else
      {
        inserter.setBinaryStream(columnIndex, x, length);
        thisRow.setBytes(columnIndex - 1, x == null ? null : STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(String columnLabel, InputStream inputStream)
    throws SQLException
  {
    try
    {
      updateBlob(findColumn(columnLabel), inputStream);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(int columnIndex, InputStream inputStream)
    throws SQLException
  {
    try
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setBlob(columnIndex, inputStream);
      }
      else
      {
        inserter.setBlob(columnIndex, inputStream);
        thisRow.setBytes(columnIndex - 1, inputStream == null ? null : STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(String columnLabel, InputStream inputStream, long length)
    throws SQLException
  {
    try
    {
      updateBlob(findColumn(columnLabel), inputStream, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateBlob(int columnIndex, InputStream inputStream, long length)
    throws SQLException
  {
    try
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setBlob(columnIndex, inputStream, length);
      }
      else
      {
        inserter.setBlob(columnIndex, inputStream, length);
        thisRow.setBytes(columnIndex - 1, inputStream == null ? null : STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(String columnLabel, Reader reader)
    throws SQLException
  {
    try
    {
      updateCharacterStream(findColumn(columnLabel), reader);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(int columnIndex, Reader x)
    throws SQLException
  {
    try
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setCharacterStream(columnIndex, x);
      }
      else
      {
        inserter.setCharacterStream(columnIndex, x);
        thisRow.setBytes(columnIndex - 1, x == null ? null : STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(String columnLabel, Reader reader, long length)
    throws SQLException
  {
    try
    {
      updateCharacterStream(findColumn(columnLabel), reader, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateCharacterStream(int columnIndex, Reader x, long length)
    throws SQLException
  {
    try
    {
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setCharacterStream(columnIndex, x, length);
      }
      else
      {
        inserter.setCharacterStream(columnIndex, x, length);
        thisRow.setBytes(columnIndex - 1, x == null ? null : STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(String columnLabel, Reader reader)
    throws SQLException
  {
    try
    {
      updateClob(findColumn(columnLabel), reader);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(int columnIndex, Reader reader)
    throws SQLException
  {
    try
    {
      updateCharacterStream(columnIndex, reader);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(String columnLabel, Reader reader, long length)
    throws SQLException
  {
    try
    {
      updateClob(findColumn(columnLabel), reader, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateClob(int columnIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      updateCharacterStream(columnIndex, reader, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNCharacterStream(String columnLabel, Reader reader)
    throws SQLException
  {
    try
    {
      updateNCharacterStream(findColumn(columnLabel), reader);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNCharacterStream(int columnIndex, Reader x)
    throws SQLException
  {
    try
    {
      String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException(Messages.getString("ResultSet.16"));
      }
      if (!onInsertRow)
      {
        if (!doingUpdates)
        {
          doingUpdates = true;
          syncUpdate();
        }
        updater.setNCharacterStream(columnIndex, x);
      }
      else
      {
        inserter.setNCharacterStream(columnIndex, x);
        thisRow.setBytes(columnIndex - 1, x == null ? null : STREAM_DATA_MARKER);
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNCharacterStream(String columnLabel, Reader reader, long length)
    throws SQLException
  {
    try
    {
      updateNCharacterStream(findColumn(columnLabel), reader, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNCharacterStream(int columnIndex, Reader x, long length)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
        if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
          throw new SQLException(Messages.getString("ResultSet.16"));
        }
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setNCharacterStream(columnIndex, x, length);
        }
        else
        {
          inserter.setNCharacterStream(columnIndex, x, length);
          thisRow.setBytes(columnIndex - 1, x == null ? null : STREAM_DATA_MARKER);
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(String columnLabel, Reader reader)
    throws SQLException
  {
    try
    {
      updateNClob(findColumn(columnLabel), reader);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(int columnIndex, Reader reader)
    throws SQLException
  {
    try
    {
      String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException(Messages.getString("ResultSet.17"));
      }
      updateCharacterStream(columnIndex, reader);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(String columnLabel, Reader reader, long length)
    throws SQLException
  {
    try
    {
      updateNClob(findColumn(columnLabel), reader, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(int columnIndex, Reader reader, long length)
    throws SQLException
  {
    try
    {
      String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException(Messages.getString("ResultSet.17"));
      }
      updateCharacterStream(columnIndex, reader, length);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(String columnLabel, java.sql.NClob nClob)
    throws SQLException
  {
    try
    {
      updateNClob(findColumn(columnLabel), nClob);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNClob(int columnIndex, java.sql.NClob nClob)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
        if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
          throw new SQLException(Messages.getString("ResultSet.17"));
        }
        if (nClob == null) {
          updateNull(columnIndex);
        } else {
          updateNCharacterStream(columnIndex, nClob.getCharacterStream(), (int)nClob.length());
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateSQLXML(String columnLabel, SQLXML xmlObject)
    throws SQLException
  {
    try
    {
      updateSQLXML(findColumn(columnLabel), xmlObject);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateSQLXML(int columnIndex, SQLXML xmlObject)
    throws SQLException
  {
    try
    {
      updateString(columnIndex, ((MysqlSQLXML)xmlObject).getString());
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNString(String columnLabel, String x)
    throws SQLException
  {
    try
    {
      updateNString(findColumn(columnLabel), x);
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public void updateNString(int columnIndex, String x)
    throws SQLException
  {
    try
    {
      synchronized (checkClosed().getConnectionMutex())
      {
        String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
        if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
          throw new SQLException(Messages.getString("ResultSet.18"));
        }
        if (!onInsertRow)
        {
          if (!doingUpdates)
          {
            doingUpdates = true;
            syncUpdate();
          }
          updater.setNString(columnIndex, x);
        }
        else
        {
          inserter.setNString(columnIndex, x);
          thisRow.setBytes(columnIndex - 1, x == null ? null : StringUtils.getBytes(x, fieldEncoding));
        }
      }
      return;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getNCharacterStream(String columnLabel)
    throws SQLException
  {
    try
    {
      return getNCharacterStream(findColumn(columnLabel));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public Reader getNCharacterStream(int columnIndex)
    throws SQLException
  {
    try
    {
      String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException(Messages.getString("ResultSet.11"));
      }
      return getCharacterStream(columnIndex);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.NClob getNClob(String columnLabel)
    throws SQLException
  {
    try
    {
      return getNClob(findColumn(columnLabel));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public java.sql.NClob getNClob(int columnIndex)
    throws SQLException
  {
    try
    {
      String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException("Can not call getNClob() when field's charset isn't UTF-8");
      }
      String asString = getStringForNClob(columnIndex);
      if (asString == null) {
        return null;
      }
      return new com.mysql.cj.jdbc.NClob(asString, getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getNString(String columnLabel)
    throws SQLException
  {
    try
    {
      return getNString(findColumn(columnLabel));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public String getNString(int columnIndex)
    throws SQLException
  {
    try
    {
      String fieldEncoding = getMetadata().getFields()[(columnIndex - 1)].getEncoding();
      if ((fieldEncoding == null) || (!fieldEncoding.equals("UTF-8"))) {
        throw new SQLException("Can not call getNString() when field's charset isn't UTF-8");
      }
      return getString(columnIndex);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public SQLXML getSQLXML(String columnLabel)
    throws SQLException
  {
    try
    {
      return getSQLXML(findColumn(columnLabel));
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public SQLXML getSQLXML(int columnIndex)
    throws SQLException
  {
    try
    {
      return new MysqlSQLXML(this, columnIndex, getExceptionInterceptor());
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  private String getStringForNClob(int columnIndex)
    throws SQLException
  {
    String asString = null;
    
    String forcedEncoding = "UTF-8";
    try
    {
      byte[] asBytes = null;
      
      asBytes = getBytes(columnIndex);
      if (asBytes != null) {
        asString = new String(asBytes, forcedEncoding);
      }
    }
    catch (UnsupportedEncodingException uee)
    {
      throw SQLError.createSQLException("Unsupported character encoding " + forcedEncoding, "S1009", 
        getExceptionInterceptor());
    }
    return asString;
  }
  
  public boolean isClosed()
    throws SQLException
  {
    try
    {
      return isClosed;
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public boolean isWrapperFor(Class<?> iface)
    throws SQLException
  {
    try
    {
      checkClosed();
      
      return iface.isInstance(this);
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
  
  public <T> T unwrap(Class<T> iface)
    throws SQLException
  {
    try
    {
      try
      {
        return (T)iface.cast(this);
      }
      catch (ClassCastException cce)
      {
        throw SQLError.createSQLException("Unable to unwrap to " + iface.toString(), "S1009", 
          getExceptionInterceptor());
      }
    }
    catch (CJException localCJException)
    {
      throw SQLExceptionsMapping.translateException(localCJException, getExceptionInterceptor());
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.result.UpdatableResultSet
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */