package com.mysql.cj.jdbc.result;

import com.mysql.cj.protocol.ColumnDefinition;
import java.sql.ResultSetMetaData;

public abstract interface CachedResultSetMetaData
  extends ColumnDefinition
{
  public abstract ResultSetMetaData getMetadata();
  
  public abstract void setMetadata(ResultSetMetaData paramResultSetMetaData);
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.result.CachedResultSetMetaData
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */