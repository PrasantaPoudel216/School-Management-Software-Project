package com.mysql.cj.jdbc.result;

import com.mysql.cj.jdbc.JdbcPreparedStatement;
import com.mysql.cj.jdbc.JdbcStatement;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.ResultsetRowsOwner;
import java.math.BigInteger;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Map;

public abstract interface ResultSetInternalMethods
  extends ResultSet, ResultsetRowsOwner, Resultset
{
  public abstract Object getObjectStoredProc(int paramInt1, int paramInt2)
    throws SQLException;
  
  public abstract Object getObjectStoredProc(int paramInt1, Map<Object, Object> paramMap, int paramInt2)
    throws SQLException;
  
  public abstract Object getObjectStoredProc(String paramString, int paramInt)
    throws SQLException;
  
  public abstract Object getObjectStoredProc(String paramString, Map<Object, Object> paramMap, int paramInt)
    throws SQLException;
  
  public abstract void realClose(boolean paramBoolean)
    throws SQLException;
  
  public abstract void setFirstCharOfQuery(char paramChar);
  
  public abstract void setOwningStatement(JdbcStatement paramJdbcStatement);
  
  public abstract char getFirstCharOfQuery();
  
  public abstract void setStatementUsedForFetchingRows(JdbcPreparedStatement paramJdbcPreparedStatement);
  
  public abstract void setWrapperStatement(Statement paramStatement);
  
  public abstract void initializeWithMetadata()
    throws SQLException;
  
  public abstract void populateCachedMetaData(CachedResultSetMetaData paramCachedResultSetMetaData)
    throws SQLException;
  
  public abstract BigInteger getBigInteger(int paramInt)
    throws SQLException;
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.result.ResultSetInternalMethods
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */