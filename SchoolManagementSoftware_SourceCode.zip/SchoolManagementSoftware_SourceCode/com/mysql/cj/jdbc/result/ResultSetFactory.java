package com.mysql.cj.jdbc.result;

import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.jdbc.JdbcConnection;
import com.mysql.cj.jdbc.StatementImpl;
import com.mysql.cj.protocol.ProtocolEntity;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.Resultset.Concurrency;
import com.mysql.cj.protocol.Resultset.Type;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.protocol.a.result.OkPacket;
import com.mysql.cj.protocol.a.result.ResultsetRowsCursor;
import java.sql.SQLException;

public class ResultSetFactory
  implements ProtocolEntityFactory<ResultSetImpl, NativePacketPayload>
{
  private JdbcConnection conn;
  private StatementImpl stmt;
  private Resultset.Type type = Resultset.Type.FORWARD_ONLY;
  private Resultset.Concurrency concurrency = Resultset.Concurrency.READ_ONLY;
  
  public ResultSetFactory(JdbcConnection connection, StatementImpl creatorStmt)
    throws SQLException
  {
    conn = connection;
    stmt = creatorStmt;
    if (creatorStmt != null)
    {
      type = Resultset.Type.fromValue(creatorStmt.getResultSetType(), Resultset.Type.FORWARD_ONLY);
      concurrency = Resultset.Concurrency.fromValue(creatorStmt.getResultSetConcurrency(), Resultset.Concurrency.READ_ONLY);
    }
  }
  
  public Resultset.Type getResultSetType()
  {
    return type;
  }
  
  public Resultset.Concurrency getResultSetConcurrency()
  {
    return concurrency;
  }
  
  public int getFetchSize()
  {
    try
    {
      return stmt.getFetchSize();
    }
    catch (SQLException ex)
    {
      throw ExceptionFactory.createException(ex.getMessage(), ex);
    }
  }
  
  public ResultSetImpl createFromProtocolEntity(ProtocolEntity protocolEntity)
  {
    try
    {
      if ((protocolEntity instanceof OkPacket)) {
        return new ResultSetImpl((OkPacket)protocolEntity, conn, stmt);
      }
      if ((protocolEntity instanceof ResultsetRows))
      {
        int resultSetConcurrency = getResultSetConcurrency().getIntValue();
        int resultSetType = getResultSetType().getIntValue();
        
        return createFromResultsetRows(resultSetConcurrency, resultSetType, (ResultsetRows)protocolEntity);
      }
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Unknown ProtocolEntity class " + protocolEntity));
    }
    catch (SQLException ex)
    {
      throw ExceptionFactory.createException(ex.getMessage(), ex);
    }
  }
  
  public ResultSetImpl createFromResultsetRows(int resultSetConcurrency, int resultSetType, ResultsetRows rows)
    throws SQLException
  {
    StatementImpl st = stmt;
    if (rows.getOwner() != null) {
      st = ((ResultSetImpl)rows.getOwner()).getOwningStatement();
    }
    ResultSetImpl rs;
    ResultSetImpl rs;
    switch (resultSetConcurrency)
    {
    case 1008: 
      rs = new UpdatableResultSet(rows, conn, st);
      break;
    default: 
      rs = new ResultSetImpl(rows, conn, st);
    }
    rs.setResultSetType(resultSetType);
    rs.setResultSetConcurrency(resultSetConcurrency);
    if (((rows instanceof ResultsetRowsCursor)) && (st != null)) {
      rs.setFetchSize(st.getFetchSize());
    }
    return rs;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.result.ResultSetFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */