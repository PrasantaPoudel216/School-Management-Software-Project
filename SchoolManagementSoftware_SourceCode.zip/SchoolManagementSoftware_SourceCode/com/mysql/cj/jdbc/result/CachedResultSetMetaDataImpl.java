package com.mysql.cj.jdbc.result;

import com.mysql.cj.result.DefaultColumnDefinition;
import java.sql.ResultSetMetaData;

public class CachedResultSetMetaDataImpl
  extends DefaultColumnDefinition
  implements CachedResultSetMetaData
{
  ResultSetMetaData metadata;
  
  public ResultSetMetaData getMetadata()
  {
    return metadata;
  }
  
  public void setMetadata(ResultSetMetaData metadata)
  {
    this.metadata = metadata;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.result.CachedResultSetMetaDataImpl
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */