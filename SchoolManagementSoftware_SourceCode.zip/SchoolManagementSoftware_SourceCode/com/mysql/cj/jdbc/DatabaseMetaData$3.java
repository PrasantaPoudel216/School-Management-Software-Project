package com.mysql.cj.jdbc;

import com.mysql.cj.exceptions.AssertionFailedException;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.util.StringUtils;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.StringTokenizer;

class DatabaseMetaData$3
  extends IterateBlock<String>
{
  DatabaseMetaData$3(DatabaseMetaData this$0, DatabaseMetaData.IteratorWithCleanup i, String paramString1, String paramString2, boolean paramBoolean, ArrayList paramArrayList)
  {
    super(i);
  }
  
  void forEach(String dbStr)
    throws SQLException
  {
    ResultSet fkresults = null;
    try
    {
      fkresults = this$0.extractForeignKeyFromCreateTable(dbStr, null);
      
      String foreignTableWithCase = this$0.getTableNameWithCase(val$foreignTable);
      String primaryTableWithCase = this$0.getTableNameWithCase(val$primaryTable);
      while (fkresults.next())
      {
        String tableType = fkresults.getString("Type");
        if ((tableType != null) && ((tableType.equalsIgnoreCase("innodb")) || (tableType.equalsIgnoreCase("SUPPORTS_FK"))))
        {
          String comment = fkresults.getString("Comment").trim();
          if (comment != null)
          {
            StringTokenizer commentTokens = new StringTokenizer(comment, ";", false);
            if (commentTokens.hasMoreTokens()) {
              String str1 = commentTokens.nextToken();
            }
            while (commentTokens.hasMoreTokens())
            {
              String keys = commentTokens.nextToken();
              DatabaseMetaData.LocalAndReferencedColumns parsedInfo = this$0.parseTableStatusIntoLocalAndReferencedColumns(keys);
              
              int keySeq = 1;
              
              Iterator<String> referencingColumns = localColumnsList.iterator();
              Iterator<String> referencedColumns = referencedColumnsList.iterator();
              while (referencingColumns.hasNext())
              {
                String referencingColumn = StringUtils.unQuoteIdentifier((String)referencingColumns.next(), this$0.quotedId);
                
                String dummy = fkresults.getString("Name");
                if ((dummy.compareTo(foreignTableWithCase) == 0) && 
                
                  (referencedTable.compareTo(primaryTableWithCase) == 0))
                {
                  byte[][] tuple = new byte[14][];
                  tuple[0] = (val$dbMapsToSchema ? this$0.s2b("def") : this$0.s2b(referencedDatabase));
                  tuple[1] = (val$dbMapsToSchema ? this$0.s2b(referencedDatabase) : null);
                  tuple[2] = this$0.s2b(referencedTable);
                  tuple[3] = this$0.s2b(StringUtils.unQuoteIdentifier((String)referencedColumns.next(), this$0.quotedId));
                  tuple[4] = (val$dbMapsToSchema ? this$0.s2b("def") : this$0.s2b(dbStr));
                  tuple[5] = (val$dbMapsToSchema ? this$0.s2b(dbStr) : null);
                  tuple[6] = this$0.s2b(dummy);
                  tuple[7] = this$0.s2b(referencingColumn);
                  tuple[8] = Integer.toString(keySeq).getBytes();
                  
                  int[] actions = this$0.getForeignKeyActions(keys);
                  tuple[9] = Integer.toString(actions[1]).getBytes();
                  tuple[10] = Integer.toString(actions[0]).getBytes();
                  
                  tuple[11] = this$0.s2b(constraintName);
                  tuple[12] = null;
                  tuple[13] = Integer.toString(7).getBytes();
                  val$tuples.add(new ByteArrayRow(tuple, this$0.getExceptionInterceptor()));
                  keySeq++;
                }
              }
            }
          }
        }
      }
    }
    finally
    {
      if (fkresults != null)
      {
        try
        {
          fkresults.close();
        }
        catch (Exception sqlEx)
        {
          AssertionFailedException.shouldNotHappen(sqlEx);
        }
        fkresults = null;
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.jdbc.DatabaseMetaData.3
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */