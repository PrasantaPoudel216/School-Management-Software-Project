package com.mysql.cj;

import com.mysql.cj.conf.HostInfo;
import com.mysql.cj.exceptions.OperationCancelledException;
import com.mysql.cj.protocol.a.NativeMessageBuilder;
import com.mysql.cj.util.StringUtils;

class CancelQueryTaskImpl$1
  extends Thread
{
  CancelQueryTaskImpl$1(CancelQueryTaskImpl this$0) {}
  
  public void run()
  {
    Query localQueryToCancel = this$0.queryToCancel;
    if (localQueryToCancel == null) {
      return;
    }
    NativeSession session = (NativeSession)localQueryToCancel.getSession();
    if (session == null) {
      return;
    }
    try
    {
      if (this$0.queryTimeoutKillsConnection)
      {
        localQueryToCancel.setCancelStatus(Query.CancelStatus.CANCELED_BY_TIMEOUT);
        session.invokeCleanupListeners(new OperationCancelledException(Messages.getString("Statement.ConnectionKilledDueToTimeout")));
      }
      else
      {
        synchronized (localQueryToCancel.getCancelTimeoutMutex())
        {
          long origConnId = session.getThreadId();
          HostInfo hostInfo = session.getHostInfo();
          String database = hostInfo.getDatabase();
          String user = StringUtils.isNullOrEmpty(hostInfo.getUser()) ? "" : hostInfo.getUser();
          String password = StringUtils.isNullOrEmpty(hostInfo.getPassword()) ? "" : hostInfo.getPassword();
          
          NativeSession newSession = new NativeSession(hostInfo, session.getPropertySet());
          newSession.connect(hostInfo, user, password, database, 30000, new TransactionEventHandler()
          {
            public void transactionCompleted() {}
            
            public void transactionBegun() {}
          });
          newSession.sendCommand(new NativeMessageBuilder().buildComQuery(newSession.getSharedSendPacket(), "KILL QUERY " + origConnId), false, 0);
          
          localQueryToCancel.setCancelStatus(Query.CancelStatus.CANCELED_BY_TIMEOUT);
        }
      }
    }
    catch (Throwable t)
    {
      this$0.caughtWhileCancelling = t;
    }
    finally
    {
      this$0.setQueryToCancel(null);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.CancelQueryTaskImpl.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */