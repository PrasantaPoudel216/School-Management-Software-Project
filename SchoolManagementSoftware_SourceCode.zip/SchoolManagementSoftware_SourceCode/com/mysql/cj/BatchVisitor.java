package com.mysql.cj;

public abstract interface BatchVisitor
{
  public abstract BatchVisitor increment();
  
  public abstract BatchVisitor decrement();
  
  public abstract BatchVisitor append(byte[] paramArrayOfByte);
  
  public abstract BatchVisitor merge(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2);
  
  public abstract BatchVisitor mergeWithLast(byte[] paramArrayOfByte);
}

/* Location:
 * Qualified Name:     com.mysql.cj.BatchVisitor
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */