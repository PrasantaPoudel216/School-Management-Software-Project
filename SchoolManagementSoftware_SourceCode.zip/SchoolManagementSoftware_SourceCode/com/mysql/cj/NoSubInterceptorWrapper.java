package com.mysql.cj;

import com.mysql.cj.interceptors.QueryInterceptor;
import com.mysql.cj.log.Log;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.ServerSession;
import java.util.Properties;
import java.util.function.Supplier;

public class NoSubInterceptorWrapper
  implements QueryInterceptor
{
  private final QueryInterceptor underlyingInterceptor;
  
  public NoSubInterceptorWrapper(QueryInterceptor underlyingInterceptor)
  {
    if (underlyingInterceptor == null) {
      throw new RuntimeException(Messages.getString("NoSubInterceptorWrapper.0"));
    }
    this.underlyingInterceptor = underlyingInterceptor;
  }
  
  public void destroy()
  {
    underlyingInterceptor.destroy();
  }
  
  public boolean executeTopLevelOnly()
  {
    return underlyingInterceptor.executeTopLevelOnly();
  }
  
  public QueryInterceptor init(MysqlConnection conn, Properties props, Log log)
  {
    underlyingInterceptor.init(conn, props, log);
    return this;
  }
  
  public <T extends Resultset> T postProcess(Supplier<String> sql, Query interceptedQuery, T originalResultSet, ServerSession serverSession)
  {
    underlyingInterceptor.postProcess(sql, interceptedQuery, originalResultSet, serverSession);
    
    return null;
  }
  
  public <T extends Resultset> T preProcess(Supplier<String> sql, Query interceptedQuery)
  {
    underlyingInterceptor.preProcess(sql, interceptedQuery);
    
    return null;
  }
  
  public <M extends Message> M preProcess(M queryPacket)
  {
    underlyingInterceptor.preProcess(queryPacket);
    
    return null;
  }
  
  public <M extends Message> M postProcess(M queryPacket, M originalResponsePacket)
  {
    underlyingInterceptor.postProcess(queryPacket, originalResponsePacket);
    
    return null;
  }
  
  public QueryInterceptor getUnderlyingInterceptor()
  {
    return underlyingInterceptor;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.NoSubInterceptorWrapper
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */