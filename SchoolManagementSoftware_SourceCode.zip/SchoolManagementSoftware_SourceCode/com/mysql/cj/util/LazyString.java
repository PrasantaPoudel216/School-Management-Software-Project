package com.mysql.cj.util;

import java.util.function.Supplier;

public class LazyString
  implements Supplier<String>
{
  private String string;
  private byte[] buffer;
  private int offset;
  private int length;
  private String encoding;
  
  public LazyString(String string)
  {
    this.string = string;
  }
  
  public LazyString(byte[] buffer, int offset, int length, String encoding)
  {
    this.buffer = buffer;
    this.offset = offset;
    this.length = length;
    this.encoding = encoding;
  }
  
  public LazyString(byte[] buffer, int offset, int length)
  {
    this.buffer = buffer;
    this.offset = offset;
    this.length = length;
  }
  
  private String createAndCacheString()
  {
    if (length > 0) {
      string = (encoding == null ? StringUtils.toString(buffer, offset, length) : StringUtils.toString(buffer, offset, length, encoding));
    }
    return string;
  }
  
  public String toString()
  {
    if (string != null) {
      return string;
    }
    return createAndCacheString();
  }
  
  public int length()
  {
    if (string != null) {
      return string.length();
    }
    return length;
  }
  
  public String get()
  {
    return toString();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.util.LazyString
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */