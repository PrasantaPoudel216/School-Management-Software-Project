package com.mysql.cj.util;

import java.io.PrintStream;

public class TestUtils
{
  public static void dumpTestcaseQuery(String query)
  {
    System.err.println(query);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.util.TestUtils
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */