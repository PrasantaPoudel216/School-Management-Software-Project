package com.mysql.cj.util;

import java.util.LinkedHashMap;
import java.util.Map.Entry;

public class LRUCache<K, V>
  extends LinkedHashMap<K, V>
{
  private static final long serialVersionUID = 1L;
  protected int maxElements;
  
  public LRUCache(int maxSize)
  {
    super(maxSize, 0.75F, true);
    maxElements = maxSize;
  }
  
  protected boolean removeEldestEntry(Map.Entry<K, V> eldest)
  {
    return size() > maxElements;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.util.LRUCache
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */