package com.mysql.cj.util;

import com.mysql.cj.CacheAdapter;
import com.mysql.cj.CacheAdapterFactory;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class PerVmServerConfigCacheFactory
  implements CacheAdapterFactory<String, Map<String, String>>
{
  static final ConcurrentHashMap<String, Map<String, String>> serverConfigByUrl = new ConcurrentHashMap();
  private static final CacheAdapter<String, Map<String, String>> serverConfigCache = new CacheAdapter()
  {
    public Map<String, String> get(String key)
    {
      return (Map)PerVmServerConfigCacheFactory.serverConfigByUrl.get(key);
    }
    
    public void put(String key, Map<String, String> value)
    {
      PerVmServerConfigCacheFactory.serverConfigByUrl.putIfAbsent(key, value);
    }
    
    public void invalidate(String key)
    {
      PerVmServerConfigCacheFactory.serverConfigByUrl.remove(key);
    }
    
    public void invalidateAll(Set<String> keys)
    {
      for (String key : keys) {
        PerVmServerConfigCacheFactory.serverConfigByUrl.remove(key);
      }
    }
    
    public void invalidateAll()
    {
      PerVmServerConfigCacheFactory.serverConfigByUrl.clear();
    }
  };
  
  public CacheAdapter<String, Map<String, String>> getInstance(Object syncMutex, String url, int cacheMaxSize, int maxKeySize)
  {
    return serverConfigCache;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.util.PerVmServerConfigCacheFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */