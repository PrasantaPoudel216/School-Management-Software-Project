package com.mysql.cj.util;

public class Base64Decoder$IntWrapper
{
  public int value;
  
  public Base64Decoder$IntWrapper(int value)
  {
    this.value = value;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.util.Base64Decoder.IntWrapper
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */