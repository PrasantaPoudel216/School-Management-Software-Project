package com.mysql.cj.util;

public enum StringUtils$SearchMode
{
  ALLOW_BACKSLASH_ESCAPE,  SKIP_BETWEEN_MARKERS,  SKIP_BLOCK_COMMENTS,  SKIP_LINE_COMMENTS,  SKIP_WHITE_SPACE;
  
  private StringUtils$SearchMode() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.util.StringUtils.SearchMode
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */