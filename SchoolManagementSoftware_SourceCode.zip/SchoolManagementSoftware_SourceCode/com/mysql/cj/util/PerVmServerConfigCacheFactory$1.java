package com.mysql.cj.util;

import com.mysql.cj.CacheAdapter;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

final class PerVmServerConfigCacheFactory$1
  implements CacheAdapter<String, Map<String, String>>
{
  public Map<String, String> get(String key)
  {
    return (Map)PerVmServerConfigCacheFactory.serverConfigByUrl.get(key);
  }
  
  public void put(String key, Map<String, String> value)
  {
    PerVmServerConfigCacheFactory.serverConfigByUrl.putIfAbsent(key, value);
  }
  
  public void invalidate(String key)
  {
    PerVmServerConfigCacheFactory.serverConfigByUrl.remove(key);
  }
  
  public void invalidateAll(Set<String> keys)
  {
    for (String key : keys) {
      PerVmServerConfigCacheFactory.serverConfigByUrl.remove(key);
    }
  }
  
  public void invalidateAll()
  {
    PerVmServerConfigCacheFactory.serverConfigByUrl.clear();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.util.PerVmServerConfigCacheFactory.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */