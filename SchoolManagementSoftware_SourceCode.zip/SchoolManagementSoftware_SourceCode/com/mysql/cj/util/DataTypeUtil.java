package com.mysql.cj.util;

public class DataTypeUtil
{
  public static long bitToLong(byte[] bytes, int offset, int length)
  {
    long valueAsLong = 0L;
    for (int i = 0; i < length; i++) {
      valueAsLong = valueAsLong << 8 | bytes[(offset + i)] & 0xFF;
    }
    return valueAsLong;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.util.DataTypeUtil
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */