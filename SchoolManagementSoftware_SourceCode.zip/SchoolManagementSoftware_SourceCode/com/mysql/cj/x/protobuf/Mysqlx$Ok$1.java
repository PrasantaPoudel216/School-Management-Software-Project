package com.mysql.cj.x.protobuf;

import com.google.protobuf.AbstractParser;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.InvalidProtocolBufferException;

final class Mysqlx$Ok$1
  extends AbstractParser<Mysqlx.Ok>
{
  public Mysqlx.Ok parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return new Mysqlx.Ok(input, extensionRegistry, null);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.Ok.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */