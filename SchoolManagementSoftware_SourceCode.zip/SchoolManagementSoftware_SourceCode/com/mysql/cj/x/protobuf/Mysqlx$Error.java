package com.mysql.cj.x.protobuf;

import com.google.protobuf.AbstractParser;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.EnumDescriptor;
import com.google.protobuf.Descriptors.EnumValueDescriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.GeneratedMessageV3.Builder;
import com.google.protobuf.GeneratedMessageV3.BuilderParent;
import com.google.protobuf.GeneratedMessageV3.FieldAccessorTable;
import com.google.protobuf.Internal.EnumLiteMap;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.google.protobuf.ProtocolMessageEnum;
import com.google.protobuf.UnknownFieldSet;
import com.google.protobuf.UnknownFieldSet.Builder;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

public final class Mysqlx$Error
  extends GeneratedMessageV3
  implements Mysqlx.ErrorOrBuilder
{
  private static final long serialVersionUID = 0L;
  private int bitField0_;
  public static final int SEVERITY_FIELD_NUMBER = 1;
  private int severity_;
  public static final int CODE_FIELD_NUMBER = 2;
  private int code_;
  public static final int SQL_STATE_FIELD_NUMBER = 4;
  private volatile Object sqlState_;
  public static final int MSG_FIELD_NUMBER = 3;
  private volatile Object msg_;
  
  private Mysqlx$Error(GeneratedMessageV3.Builder<?> builder)
  {
    super(builder);
  }
  
  private Mysqlx$Error()
  {
    severity_ = 0;
    code_ = 0;
    sqlState_ = "";
    msg_ = "";
  }
  
  public final UnknownFieldSet getUnknownFields()
  {
    return unknownFields;
  }
  
  private Mysqlx$Error(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    this();
    if (extensionRegistry == null) {
      throw new NullPointerException();
    }
    int mutable_bitField0_ = 0;
    
    UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
    try
    {
      boolean done = false;
      while (!done)
      {
        int tag = input.readTag();
        switch (tag)
        {
        case 0: 
          done = true;
          break;
        case 8: 
          int rawValue = input.readEnum();
          
          Severity value = Severity.valueOf(rawValue);
          if (value == null)
          {
            unknownFields.mergeVarintField(1, rawValue);
          }
          else
          {
            bitField0_ |= 0x1;
            severity_ = rawValue;
          }
          break;
        case 16: 
          bitField0_ |= 0x2;
          code_ = input.readUInt32();
          break;
        case 26: 
          ByteString bs = input.readBytes();
          bitField0_ |= 0x8;
          msg_ = bs;
          break;
        case 34: 
          ByteString bs = input.readBytes();
          bitField0_ |= 0x4;
          sqlState_ = bs;
          break;
        default: 
          if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
            done = true;
          }
          break;
        }
      }
    }
    catch (InvalidProtocolBufferException e)
    {
      throw e.setUnfinishedMessage(this);
    }
    catch (IOException e)
    {
      throw new InvalidProtocolBufferException(e).setUnfinishedMessage(this);
    }
    finally
    {
      this.unknownFields = unknownFields.build();
      makeExtensionsImmutable();
    }
  }
  
  public static final Descriptors.Descriptor getDescriptor()
  {
    return Mysqlx.access$2600();
  }
  
  protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
  {
    return 
      Mysqlx.access$2700().ensureFieldAccessorsInitialized(Error.class, Builder.class);
  }
  
  public static enum Severity
    implements ProtocolMessageEnum
  {
    ERROR(0),  FATAL(1);
    
    public static final int ERROR_VALUE = 0;
    public static final int FATAL_VALUE = 1;
    
    public final int getNumber()
    {
      return value;
    }
    
    @Deprecated
    public static Severity valueOf(int value)
    {
      return forNumber(value);
    }
    
    public static Severity forNumber(int value)
    {
      switch (value)
      {
      case 0: 
        return ERROR;
      case 1: 
        return FATAL;
      }
      return null;
    }
    
    public static Internal.EnumLiteMap<Severity> internalGetValueMap()
    {
      return internalValueMap;
    }
    
    private static final Internal.EnumLiteMap<Severity> internalValueMap = new Internal.EnumLiteMap()
    {
      public Mysqlx.Error.Severity findValueByNumber(int number)
      {
        return Mysqlx.Error.Severity.forNumber(number);
      }
    };
    
    public final Descriptors.EnumValueDescriptor getValueDescriptor()
    {
      return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(ordinal());
    }
    
    public final Descriptors.EnumDescriptor getDescriptorForType()
    {
      return getDescriptor();
    }
    
    public static final Descriptors.EnumDescriptor getDescriptor()
    {
      return (Descriptors.EnumDescriptor)Mysqlx.Error.getDescriptor().getEnumTypes().get(0);
    }
    
    private static final Severity[] VALUES = values();
    private final int value;
    
    public static Severity valueOf(Descriptors.EnumValueDescriptor desc)
    {
      if (desc.getType() != getDescriptor()) {
        throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
      }
      return VALUES[desc.getIndex()];
    }
    
    private Severity(int value)
    {
      this.value = value;
    }
  }
  
  public boolean hasSeverity()
  {
    return (bitField0_ & 0x1) == 1;
  }
  
  public Severity getSeverity()
  {
    Severity result = Severity.valueOf(severity_);
    return result == null ? Severity.ERROR : result;
  }
  
  public boolean hasCode()
  {
    return (bitField0_ & 0x2) == 2;
  }
  
  public int getCode()
  {
    return code_;
  }
  
  public boolean hasSqlState()
  {
    return (bitField0_ & 0x4) == 4;
  }
  
  public String getSqlState()
  {
    Object ref = sqlState_;
    if ((ref instanceof String)) {
      return (String)ref;
    }
    ByteString bs = (ByteString)ref;
    
    String s = bs.toStringUtf8();
    if (bs.isValidUtf8()) {
      sqlState_ = s;
    }
    return s;
  }
  
  public ByteString getSqlStateBytes()
  {
    Object ref = sqlState_;
    if ((ref instanceof String))
    {
      ByteString b = ByteString.copyFromUtf8((String)ref);
      
      sqlState_ = b;
      return b;
    }
    return (ByteString)ref;
  }
  
  public boolean hasMsg()
  {
    return (bitField0_ & 0x8) == 8;
  }
  
  public String getMsg()
  {
    Object ref = msg_;
    if ((ref instanceof String)) {
      return (String)ref;
    }
    ByteString bs = (ByteString)ref;
    
    String s = bs.toStringUtf8();
    if (bs.isValidUtf8()) {
      msg_ = s;
    }
    return s;
  }
  
  public ByteString getMsgBytes()
  {
    Object ref = msg_;
    if ((ref instanceof String))
    {
      ByteString b = ByteString.copyFromUtf8((String)ref);
      
      msg_ = b;
      return b;
    }
    return (ByteString)ref;
  }
  
  private byte memoizedIsInitialized = -1;
  
  public final boolean isInitialized()
  {
    byte isInitialized = memoizedIsInitialized;
    if (isInitialized == 1) {
      return true;
    }
    if (isInitialized == 0) {
      return false;
    }
    if (!hasCode())
    {
      memoizedIsInitialized = 0;
      return false;
    }
    if (!hasSqlState())
    {
      memoizedIsInitialized = 0;
      return false;
    }
    if (!hasMsg())
    {
      memoizedIsInitialized = 0;
      return false;
    }
    memoizedIsInitialized = 1;
    return true;
  }
  
  public void writeTo(CodedOutputStream output)
    throws IOException
  {
    if ((bitField0_ & 0x1) == 1) {
      output.writeEnum(1, severity_);
    }
    if ((bitField0_ & 0x2) == 2) {
      output.writeUInt32(2, code_);
    }
    if ((bitField0_ & 0x8) == 8) {
      GeneratedMessageV3.writeString(output, 3, msg_);
    }
    if ((bitField0_ & 0x4) == 4) {
      GeneratedMessageV3.writeString(output, 4, sqlState_);
    }
    unknownFields.writeTo(output);
  }
  
  public int getSerializedSize()
  {
    int size = memoizedSize;
    if (size != -1) {
      return size;
    }
    size = 0;
    if ((bitField0_ & 0x1) == 1) {
      size = size + CodedOutputStream.computeEnumSize(1, severity_);
    }
    if ((bitField0_ & 0x2) == 2) {
      size = size + CodedOutputStream.computeUInt32Size(2, code_);
    }
    if ((bitField0_ & 0x8) == 8) {
      size += GeneratedMessageV3.computeStringSize(3, msg_);
    }
    if ((bitField0_ & 0x4) == 4) {
      size += GeneratedMessageV3.computeStringSize(4, sqlState_);
    }
    size += unknownFields.getSerializedSize();
    memoizedSize = size;
    return size;
  }
  
  public boolean equals(Object obj)
  {
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof Error)) {
      return super.equals(obj);
    }
    Error other = (Error)obj;
    
    boolean result = true;
    result = (result) && (hasSeverity() == other.hasSeverity());
    if (hasSeverity()) {
      result = (result) && (severity_ == severity_);
    }
    result = (result) && (hasCode() == other.hasCode());
    if (hasCode()) {
      result = (result) && (getCode() == other.getCode());
    }
    result = (result) && (hasSqlState() == other.hasSqlState());
    if (hasSqlState()) {
      result = (result) && (getSqlState().equals(other.getSqlState()));
    }
    result = (result) && (hasMsg() == other.hasMsg());
    if (hasMsg()) {
      result = (result) && (getMsg().equals(other.getMsg()));
    }
    result = (result) && (unknownFields.equals(unknownFields));
    return result;
  }
  
  public int hashCode()
  {
    if (memoizedHashCode != 0) {
      return memoizedHashCode;
    }
    int hash = 41;
    hash = 19 * hash + getDescriptor().hashCode();
    if (hasSeverity())
    {
      hash = 37 * hash + 1;
      hash = 53 * hash + severity_;
    }
    if (hasCode())
    {
      hash = 37 * hash + 2;
      hash = 53 * hash + getCode();
    }
    if (hasSqlState())
    {
      hash = 37 * hash + 4;
      hash = 53 * hash + getSqlState().hashCode();
    }
    if (hasMsg())
    {
      hash = 37 * hash + 3;
      hash = 53 * hash + getMsg().hashCode();
    }
    hash = 29 * hash + unknownFields.hashCode();
    memoizedHashCode = hash;
    return hash;
  }
  
  public static Error parseFrom(ByteBuffer data)
    throws InvalidProtocolBufferException
  {
    return (Error)PARSER.parseFrom(data);
  }
  
  public static Error parseFrom(ByteBuffer data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (Error)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static Error parseFrom(ByteString data)
    throws InvalidProtocolBufferException
  {
    return (Error)PARSER.parseFrom(data);
  }
  
  public static Error parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (Error)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static Error parseFrom(byte[] data)
    throws InvalidProtocolBufferException
  {
    return (Error)PARSER.parseFrom(data);
  }
  
  public static Error parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (Error)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static Error parseFrom(InputStream input)
    throws IOException
  {
    return 
      (Error)GeneratedMessageV3.parseWithIOException(PARSER, input);
  }
  
  public static Error parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (Error)GeneratedMessageV3.parseWithIOException(PARSER, input, extensionRegistry);
  }
  
  public static Error parseDelimitedFrom(InputStream input)
    throws IOException
  {
    return 
      (Error)GeneratedMessageV3.parseDelimitedWithIOException(PARSER, input);
  }
  
  public static Error parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (Error)GeneratedMessageV3.parseDelimitedWithIOException(PARSER, input, extensionRegistry);
  }
  
  public static Error parseFrom(CodedInputStream input)
    throws IOException
  {
    return 
      (Error)GeneratedMessageV3.parseWithIOException(PARSER, input);
  }
  
  public static Error parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (Error)GeneratedMessageV3.parseWithIOException(PARSER, input, extensionRegistry);
  }
  
  public Builder newBuilderForType()
  {
    return newBuilder();
  }
  
  public static Builder newBuilder()
  {
    return DEFAULT_INSTANCE.toBuilder();
  }
  
  public static Builder newBuilder(Error prototype)
  {
    return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
  }
  
  public Builder toBuilder()
  {
    return this == DEFAULT_INSTANCE ? new Builder(null) : new Builder(null)
      .mergeFrom(this);
  }
  
  protected Builder newBuilderForType(GeneratedMessageV3.BuilderParent parent)
  {
    Builder builder = new Builder(parent, null);
    return builder;
  }
  
  public static final class Builder
    extends GeneratedMessageV3.Builder<Builder>
    implements Mysqlx.ErrorOrBuilder
  {
    private int bitField0_;
    
    public static final Descriptors.Descriptor getDescriptor()
    {
      return Mysqlx.access$2600();
    }
    
    protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return 
        Mysqlx.access$2700().ensureFieldAccessorsInitialized(Mysqlx.Error.class, Builder.class);
    }
    
    private Builder()
    {
      maybeForceBuilderInitialization();
    }
    
    private Builder(GeneratedMessageV3.BuilderParent parent)
    {
      super();
      maybeForceBuilderInitialization();
    }
    
    private void maybeForceBuilderInitialization()
    {
      if (Mysqlx.Error.alwaysUseFieldBuilders) {}
    }
    
    public Builder clear()
    {
      super.clear();
      severity_ = 0;
      bitField0_ &= 0xFFFFFFFE;
      code_ = 0;
      bitField0_ &= 0xFFFFFFFD;
      sqlState_ = "";
      bitField0_ &= 0xFFFFFFFB;
      msg_ = "";
      bitField0_ &= 0xFFFFFFF7;
      return this;
    }
    
    public Descriptors.Descriptor getDescriptorForType()
    {
      return Mysqlx.access$2600();
    }
    
    public Mysqlx.Error getDefaultInstanceForType()
    {
      return Mysqlx.Error.getDefaultInstance();
    }
    
    public Mysqlx.Error build()
    {
      Mysqlx.Error result = buildPartial();
      if (!result.isInitialized()) {
        throw newUninitializedMessageException(result);
      }
      return result;
    }
    
    public Mysqlx.Error buildPartial()
    {
      Mysqlx.Error result = new Mysqlx.Error(this, null);
      int from_bitField0_ = bitField0_;
      int to_bitField0_ = 0;
      if ((from_bitField0_ & 0x1) == 1) {
        to_bitField0_ |= 0x1;
      }
      severity_ = severity_;
      if ((from_bitField0_ & 0x2) == 2) {
        to_bitField0_ |= 0x2;
      }
      code_ = code_;
      if ((from_bitField0_ & 0x4) == 4) {
        to_bitField0_ |= 0x4;
      }
      sqlState_ = sqlState_;
      if ((from_bitField0_ & 0x8) == 8) {
        to_bitField0_ |= 0x8;
      }
      msg_ = msg_;
      bitField0_ = to_bitField0_;
      onBuilt();
      return result;
    }
    
    public Builder clone()
    {
      return (Builder)super.clone();
    }
    
    public Builder setField(Descriptors.FieldDescriptor field, Object value)
    {
      return (Builder)super.setField(field, value);
    }
    
    public Builder clearField(Descriptors.FieldDescriptor field)
    {
      return (Builder)super.clearField(field);
    }
    
    public Builder clearOneof(Descriptors.OneofDescriptor oneof)
    {
      return (Builder)super.clearOneof(oneof);
    }
    
    public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
    {
      return (Builder)super.setRepeatedField(field, index, value);
    }
    
    public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value)
    {
      return (Builder)super.addRepeatedField(field, value);
    }
    
    public Builder mergeFrom(Message other)
    {
      if ((other instanceof Mysqlx.Error)) {
        return mergeFrom((Mysqlx.Error)other);
      }
      super.mergeFrom(other);
      return this;
    }
    
    public Builder mergeFrom(Mysqlx.Error other)
    {
      if (other == Mysqlx.Error.getDefaultInstance()) {
        return this;
      }
      if (other.hasSeverity()) {
        setSeverity(other.getSeverity());
      }
      if (other.hasCode()) {
        setCode(other.getCode());
      }
      if (other.hasSqlState())
      {
        bitField0_ |= 0x4;
        sqlState_ = sqlState_;
        onChanged();
      }
      if (other.hasMsg())
      {
        bitField0_ |= 0x8;
        msg_ = msg_;
        onChanged();
      }
      mergeUnknownFields(unknownFields);
      onChanged();
      return this;
    }
    
    public final boolean isInitialized()
    {
      if (!hasCode()) {
        return false;
      }
      if (!hasSqlState()) {
        return false;
      }
      if (!hasMsg()) {
        return false;
      }
      return true;
    }
    
    public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      Mysqlx.Error parsedMessage = null;
      try
      {
        parsedMessage = (Mysqlx.Error)Mysqlx.Error.PARSER.parsePartialFrom(input, extensionRegistry);
      }
      catch (InvalidProtocolBufferException e)
      {
        parsedMessage = (Mysqlx.Error)e.getUnfinishedMessage();
        throw e.unwrapIOException();
      }
      finally
      {
        if (parsedMessage != null) {
          mergeFrom(parsedMessage);
        }
      }
      return this;
    }
    
    private int severity_ = 0;
    private int code_;
    
    public boolean hasSeverity()
    {
      return (bitField0_ & 0x1) == 1;
    }
    
    public Mysqlx.Error.Severity getSeverity()
    {
      Mysqlx.Error.Severity result = Mysqlx.Error.Severity.valueOf(severity_);
      return result == null ? Mysqlx.Error.Severity.ERROR : result;
    }
    
    public Builder setSeverity(Mysqlx.Error.Severity value)
    {
      if (value == null) {
        throw new NullPointerException();
      }
      bitField0_ |= 0x1;
      severity_ = value.getNumber();
      onChanged();
      return this;
    }
    
    public Builder clearSeverity()
    {
      bitField0_ &= 0xFFFFFFFE;
      severity_ = 0;
      onChanged();
      return this;
    }
    
    public boolean hasCode()
    {
      return (bitField0_ & 0x2) == 2;
    }
    
    public int getCode()
    {
      return code_;
    }
    
    public Builder setCode(int value)
    {
      bitField0_ |= 0x2;
      code_ = value;
      onChanged();
      return this;
    }
    
    public Builder clearCode()
    {
      bitField0_ &= 0xFFFFFFFD;
      code_ = 0;
      onChanged();
      return this;
    }
    
    private Object sqlState_ = "";
    
    public boolean hasSqlState()
    {
      return (bitField0_ & 0x4) == 4;
    }
    
    public String getSqlState()
    {
      Object ref = sqlState_;
      if (!(ref instanceof String))
      {
        ByteString bs = (ByteString)ref;
        
        String s = bs.toStringUtf8();
        if (bs.isValidUtf8()) {
          sqlState_ = s;
        }
        return s;
      }
      return (String)ref;
    }
    
    public ByteString getSqlStateBytes()
    {
      Object ref = sqlState_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        sqlState_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public Builder setSqlState(String value)
    {
      if (value == null) {
        throw new NullPointerException();
      }
      bitField0_ |= 0x4;
      sqlState_ = value;
      onChanged();
      return this;
    }
    
    public Builder clearSqlState()
    {
      bitField0_ &= 0xFFFFFFFB;
      sqlState_ = Mysqlx.Error.getDefaultInstance().getSqlState();
      onChanged();
      return this;
    }
    
    public Builder setSqlStateBytes(ByteString value)
    {
      if (value == null) {
        throw new NullPointerException();
      }
      bitField0_ |= 0x4;
      sqlState_ = value;
      onChanged();
      return this;
    }
    
    private Object msg_ = "";
    
    public boolean hasMsg()
    {
      return (bitField0_ & 0x8) == 8;
    }
    
    public String getMsg()
    {
      Object ref = msg_;
      if (!(ref instanceof String))
      {
        ByteString bs = (ByteString)ref;
        
        String s = bs.toStringUtf8();
        if (bs.isValidUtf8()) {
          msg_ = s;
        }
        return s;
      }
      return (String)ref;
    }
    
    public ByteString getMsgBytes()
    {
      Object ref = msg_;
      if ((ref instanceof String))
      {
        ByteString b = ByteString.copyFromUtf8((String)ref);
        
        msg_ = b;
        return b;
      }
      return (ByteString)ref;
    }
    
    public Builder setMsg(String value)
    {
      if (value == null) {
        throw new NullPointerException();
      }
      bitField0_ |= 0x8;
      msg_ = value;
      onChanged();
      return this;
    }
    
    public Builder clearMsg()
    {
      bitField0_ &= 0xFFFFFFF7;
      msg_ = Mysqlx.Error.getDefaultInstance().getMsg();
      onChanged();
      return this;
    }
    
    public Builder setMsgBytes(ByteString value)
    {
      if (value == null) {
        throw new NullPointerException();
      }
      bitField0_ |= 0x8;
      msg_ = value;
      onChanged();
      return this;
    }
    
    public final Builder setUnknownFields(UnknownFieldSet unknownFields)
    {
      return (Builder)super.setUnknownFields(unknownFields);
    }
    
    public final Builder mergeUnknownFields(UnknownFieldSet unknownFields)
    {
      return (Builder)super.mergeUnknownFields(unknownFields);
    }
  }
  
  private static final Error DEFAULT_INSTANCE = new Error();
  
  public static Error getDefaultInstance()
  {
    return DEFAULT_INSTANCE;
  }
  
  @Deprecated
  public static final Parser<Error> PARSER = new AbstractParser()
  {
    public Mysqlx.Error parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return new Mysqlx.Error(input, extensionRegistry, null);
    }
  };
  
  public static Parser<Error> parser()
  {
    return PARSER;
  }
  
  public Parser<Error> getParserForType()
  {
    return PARSER;
  }
  
  public Error getDefaultInstanceForType()
  {
    return DEFAULT_INSTANCE;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.Error
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */