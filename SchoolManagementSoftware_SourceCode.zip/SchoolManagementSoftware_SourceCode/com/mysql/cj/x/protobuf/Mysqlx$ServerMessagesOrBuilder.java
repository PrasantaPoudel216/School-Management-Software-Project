package com.mysql.cj.x.protobuf;

import com.google.protobuf.MessageOrBuilder;

public abstract interface Mysqlx$ServerMessagesOrBuilder
  extends MessageOrBuilder
{}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.ServerMessagesOrBuilder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */