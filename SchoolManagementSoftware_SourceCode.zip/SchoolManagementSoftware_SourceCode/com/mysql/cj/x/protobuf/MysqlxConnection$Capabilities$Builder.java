package com.mysql.cj.x.protobuf;

import com.google.protobuf.AbstractMessageLite.Builder;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3.Builder;
import com.google.protobuf.GeneratedMessageV3.BuilderParent;
import com.google.protobuf.GeneratedMessageV3.FieldAccessorTable;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.google.protobuf.RepeatedFieldBuilderV3;
import com.google.protobuf.UnknownFieldSet;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public final class MysqlxConnection$Capabilities$Builder
  extends GeneratedMessageV3.Builder<Builder>
  implements MysqlxConnection.CapabilitiesOrBuilder
{
  private int bitField0_;
  
  public static final Descriptors.Descriptor getDescriptor()
  {
    return MysqlxConnection.access$1100();
  }
  
  protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
  {
    return 
      MysqlxConnection.access$1200().ensureFieldAccessorsInitialized(MysqlxConnection.Capabilities.class, Builder.class);
  }
  
  private MysqlxConnection$Capabilities$Builder()
  {
    maybeForceBuilderInitialization();
  }
  
  private MysqlxConnection$Capabilities$Builder(GeneratedMessageV3.BuilderParent parent)
  {
    super(parent);
    maybeForceBuilderInitialization();
  }
  
  private void maybeForceBuilderInitialization()
  {
    if (MysqlxConnection.Capabilities.access$1500()) {
      getCapabilitiesFieldBuilder();
    }
  }
  
  public Builder clear()
  {
    super.clear();
    if (capabilitiesBuilder_ == null)
    {
      capabilities_ = Collections.emptyList();
      bitField0_ &= 0xFFFFFFFE;
    }
    else
    {
      capabilitiesBuilder_.clear();
    }
    return this;
  }
  
  public Descriptors.Descriptor getDescriptorForType()
  {
    return MysqlxConnection.access$1100();
  }
  
  public MysqlxConnection.Capabilities getDefaultInstanceForType()
  {
    return MysqlxConnection.Capabilities.getDefaultInstance();
  }
  
  public MysqlxConnection.Capabilities build()
  {
    MysqlxConnection.Capabilities result = buildPartial();
    if (!result.isInitialized()) {
      throw newUninitializedMessageException(result);
    }
    return result;
  }
  
  public MysqlxConnection.Capabilities buildPartial()
  {
    MysqlxConnection.Capabilities result = new MysqlxConnection.Capabilities(this, null);
    int from_bitField0_ = bitField0_;
    if (capabilitiesBuilder_ == null)
    {
      if ((bitField0_ & 0x1) == 1)
      {
        capabilities_ = Collections.unmodifiableList(capabilities_);
        bitField0_ &= 0xFFFFFFFE;
      }
      MysqlxConnection.Capabilities.access$1702(result, capabilities_);
    }
    else
    {
      MysqlxConnection.Capabilities.access$1702(result, capabilitiesBuilder_.build());
    }
    onBuilt();
    return result;
  }
  
  public Builder clone()
  {
    return (Builder)super.clone();
  }
  
  public Builder setField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.setField(field, value);
  }
  
  public Builder clearField(Descriptors.FieldDescriptor field)
  {
    return (Builder)super.clearField(field);
  }
  
  public Builder clearOneof(Descriptors.OneofDescriptor oneof)
  {
    return (Builder)super.clearOneof(oneof);
  }
  
  public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
  {
    return (Builder)super.setRepeatedField(field, index, value);
  }
  
  public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.addRepeatedField(field, value);
  }
  
  public Builder mergeFrom(Message other)
  {
    if ((other instanceof MysqlxConnection.Capabilities)) {
      return mergeFrom((MysqlxConnection.Capabilities)other);
    }
    super.mergeFrom(other);
    return this;
  }
  
  public Builder mergeFrom(MysqlxConnection.Capabilities other)
  {
    if (other == MysqlxConnection.Capabilities.getDefaultInstance()) {
      return this;
    }
    if (capabilitiesBuilder_ == null)
    {
      if (!MysqlxConnection.Capabilities.access$1700(other).isEmpty())
      {
        if (capabilities_.isEmpty())
        {
          capabilities_ = MysqlxConnection.Capabilities.access$1700(other);
          bitField0_ &= 0xFFFFFFFE;
        }
        else
        {
          ensureCapabilitiesIsMutable();
          capabilities_.addAll(MysqlxConnection.Capabilities.access$1700(other));
        }
        onChanged();
      }
    }
    else if (!MysqlxConnection.Capabilities.access$1700(other).isEmpty()) {
      if (capabilitiesBuilder_.isEmpty())
      {
        capabilitiesBuilder_.dispose();
        capabilitiesBuilder_ = null;
        capabilities_ = MysqlxConnection.Capabilities.access$1700(other);
        bitField0_ &= 0xFFFFFFFE;
        
        capabilitiesBuilder_ = (MysqlxConnection.Capabilities.access$1800() ? getCapabilitiesFieldBuilder() : null);
      }
      else
      {
        capabilitiesBuilder_.addAllMessages(MysqlxConnection.Capabilities.access$1700(other));
      }
    }
    mergeUnknownFields(MysqlxConnection.Capabilities.access$1900(other));
    onChanged();
    return this;
  }
  
  public final boolean isInitialized()
  {
    for (int i = 0; i < getCapabilitiesCount(); i++) {
      if (!getCapabilities(i).isInitialized()) {
        return false;
      }
    }
    return true;
  }
  
  public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    MysqlxConnection.Capabilities parsedMessage = null;
    try
    {
      parsedMessage = (MysqlxConnection.Capabilities)MysqlxConnection.Capabilities.PARSER.parsePartialFrom(input, extensionRegistry);
    }
    catch (InvalidProtocolBufferException e)
    {
      parsedMessage = (MysqlxConnection.Capabilities)e.getUnfinishedMessage();
      throw e.unwrapIOException();
    }
    finally
    {
      if (parsedMessage != null) {
        mergeFrom(parsedMessage);
      }
    }
    return this;
  }
  
  private List<MysqlxConnection.Capability> capabilities_ = Collections.emptyList();
  private RepeatedFieldBuilderV3<MysqlxConnection.Capability, MysqlxConnection.Capability.Builder, MysqlxConnection.CapabilityOrBuilder> capabilitiesBuilder_;
  
  private void ensureCapabilitiesIsMutable()
  {
    if ((bitField0_ & 0x1) != 1)
    {
      capabilities_ = new ArrayList(capabilities_);
      bitField0_ |= 0x1;
    }
  }
  
  public List<MysqlxConnection.Capability> getCapabilitiesList()
  {
    if (capabilitiesBuilder_ == null) {
      return Collections.unmodifiableList(capabilities_);
    }
    return capabilitiesBuilder_.getMessageList();
  }
  
  public int getCapabilitiesCount()
  {
    if (capabilitiesBuilder_ == null) {
      return capabilities_.size();
    }
    return capabilitiesBuilder_.getCount();
  }
  
  public MysqlxConnection.Capability getCapabilities(int index)
  {
    if (capabilitiesBuilder_ == null) {
      return (MysqlxConnection.Capability)capabilities_.get(index);
    }
    return (MysqlxConnection.Capability)capabilitiesBuilder_.getMessage(index);
  }
  
  public Builder setCapabilities(int index, MysqlxConnection.Capability value)
  {
    if (capabilitiesBuilder_ == null)
    {
      if (value == null) {
        throw new NullPointerException();
      }
      ensureCapabilitiesIsMutable();
      capabilities_.set(index, value);
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.setMessage(index, value);
    }
    return this;
  }
  
  public Builder setCapabilities(int index, MysqlxConnection.Capability.Builder builderForValue)
  {
    if (capabilitiesBuilder_ == null)
    {
      ensureCapabilitiesIsMutable();
      capabilities_.set(index, builderForValue.build());
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.setMessage(index, builderForValue.build());
    }
    return this;
  }
  
  public Builder addCapabilities(MysqlxConnection.Capability value)
  {
    if (capabilitiesBuilder_ == null)
    {
      if (value == null) {
        throw new NullPointerException();
      }
      ensureCapabilitiesIsMutable();
      capabilities_.add(value);
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.addMessage(value);
    }
    return this;
  }
  
  public Builder addCapabilities(int index, MysqlxConnection.Capability value)
  {
    if (capabilitiesBuilder_ == null)
    {
      if (value == null) {
        throw new NullPointerException();
      }
      ensureCapabilitiesIsMutable();
      capabilities_.add(index, value);
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.addMessage(index, value);
    }
    return this;
  }
  
  public Builder addCapabilities(MysqlxConnection.Capability.Builder builderForValue)
  {
    if (capabilitiesBuilder_ == null)
    {
      ensureCapabilitiesIsMutable();
      capabilities_.add(builderForValue.build());
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.addMessage(builderForValue.build());
    }
    return this;
  }
  
  public Builder addCapabilities(int index, MysqlxConnection.Capability.Builder builderForValue)
  {
    if (capabilitiesBuilder_ == null)
    {
      ensureCapabilitiesIsMutable();
      capabilities_.add(index, builderForValue.build());
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.addMessage(index, builderForValue.build());
    }
    return this;
  }
  
  public Builder addAllCapabilities(Iterable<? extends MysqlxConnection.Capability> values)
  {
    if (capabilitiesBuilder_ == null)
    {
      ensureCapabilitiesIsMutable();
      AbstractMessageLite.Builder.addAll(values, capabilities_);
      
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.addAllMessages(values);
    }
    return this;
  }
  
  public Builder clearCapabilities()
  {
    if (capabilitiesBuilder_ == null)
    {
      capabilities_ = Collections.emptyList();
      bitField0_ &= 0xFFFFFFFE;
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.clear();
    }
    return this;
  }
  
  public Builder removeCapabilities(int index)
  {
    if (capabilitiesBuilder_ == null)
    {
      ensureCapabilitiesIsMutable();
      capabilities_.remove(index);
      onChanged();
    }
    else
    {
      capabilitiesBuilder_.remove(index);
    }
    return this;
  }
  
  public MysqlxConnection.Capability.Builder getCapabilitiesBuilder(int index)
  {
    return (MysqlxConnection.Capability.Builder)getCapabilitiesFieldBuilder().getBuilder(index);
  }
  
  public MysqlxConnection.CapabilityOrBuilder getCapabilitiesOrBuilder(int index)
  {
    if (capabilitiesBuilder_ == null) {
      return (MysqlxConnection.CapabilityOrBuilder)capabilities_.get(index);
    }
    return (MysqlxConnection.CapabilityOrBuilder)capabilitiesBuilder_.getMessageOrBuilder(index);
  }
  
  public List<? extends MysqlxConnection.CapabilityOrBuilder> getCapabilitiesOrBuilderList()
  {
    if (capabilitiesBuilder_ != null) {
      return capabilitiesBuilder_.getMessageOrBuilderList();
    }
    return Collections.unmodifiableList(capabilities_);
  }
  
  public MysqlxConnection.Capability.Builder addCapabilitiesBuilder()
  {
    return (MysqlxConnection.Capability.Builder)getCapabilitiesFieldBuilder().addBuilder(
      MysqlxConnection.Capability.getDefaultInstance());
  }
  
  public MysqlxConnection.Capability.Builder addCapabilitiesBuilder(int index)
  {
    return (MysqlxConnection.Capability.Builder)getCapabilitiesFieldBuilder().addBuilder(index, 
      MysqlxConnection.Capability.getDefaultInstance());
  }
  
  public List<MysqlxConnection.Capability.Builder> getCapabilitiesBuilderList()
  {
    return getCapabilitiesFieldBuilder().getBuilderList();
  }
  
  private RepeatedFieldBuilderV3<MysqlxConnection.Capability, MysqlxConnection.Capability.Builder, MysqlxConnection.CapabilityOrBuilder> getCapabilitiesFieldBuilder()
  {
    if (capabilitiesBuilder_ == null)
    {
      capabilitiesBuilder_ = new RepeatedFieldBuilderV3(capabilities_, (bitField0_ & 0x1) == 1, getParentForChildren(), isClean());
      capabilities_ = null;
    }
    return capabilitiesBuilder_;
  }
  
  public final Builder setUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.setUnknownFields(unknownFields);
  }
  
  public final Builder mergeUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.mergeUnknownFields(unknownFields);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.MysqlxConnection.Capabilities.Builder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */