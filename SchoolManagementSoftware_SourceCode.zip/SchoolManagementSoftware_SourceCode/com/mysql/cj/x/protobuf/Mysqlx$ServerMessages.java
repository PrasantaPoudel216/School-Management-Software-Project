package com.mysql.cj.x.protobuf;

import com.google.protobuf.AbstractParser;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.EnumDescriptor;
import com.google.protobuf.Descriptors.EnumValueDescriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.GeneratedMessageV3.Builder;
import com.google.protobuf.GeneratedMessageV3.BuilderParent;
import com.google.protobuf.GeneratedMessageV3.FieldAccessorTable;
import com.google.protobuf.Internal.EnumLiteMap;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.google.protobuf.ProtocolMessageEnum;
import com.google.protobuf.UnknownFieldSet;
import com.google.protobuf.UnknownFieldSet.Builder;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

public final class Mysqlx$ServerMessages
  extends GeneratedMessageV3
  implements Mysqlx.ServerMessagesOrBuilder
{
  private static final long serialVersionUID = 0L;
  
  private Mysqlx$ServerMessages(GeneratedMessageV3.Builder<?> builder)
  {
    super(builder);
  }
  
  private Mysqlx$ServerMessages() {}
  
  public final UnknownFieldSet getUnknownFields()
  {
    return unknownFields;
  }
  
  private Mysqlx$ServerMessages(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    this();
    if (extensionRegistry == null) {
      throw new NullPointerException();
    }
    UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
    try
    {
      boolean done = false;
      while (!done)
      {
        int tag = input.readTag();
        switch (tag)
        {
        case 0: 
          done = true;
          break;
        default: 
          if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
            done = true;
          }
          break;
        }
      }
    }
    catch (InvalidProtocolBufferException e)
    {
      throw e.setUnfinishedMessage(this);
    }
    catch (IOException e)
    {
      throw new InvalidProtocolBufferException(e).setUnfinishedMessage(this);
    }
    finally
    {
      this.unknownFields = unknownFields.build();
      makeExtensionsImmutable();
    }
  }
  
  public static final Descriptors.Descriptor getDescriptor()
  {
    return Mysqlx.access$800();
  }
  
  protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
  {
    return 
      Mysqlx.access$900().ensureFieldAccessorsInitialized(ServerMessages.class, Builder.class);
  }
  
  public static enum Type
    implements ProtocolMessageEnum
  {
    OK(0),  ERROR(1),  CONN_CAPABILITIES(2),  SESS_AUTHENTICATE_CONTINUE(3),  SESS_AUTHENTICATE_OK(4),  NOTICE(11),  RESULTSET_COLUMN_META_DATA(12),  RESULTSET_ROW(13),  RESULTSET_FETCH_DONE(14),  RESULTSET_FETCH_SUSPENDED(15),  RESULTSET_FETCH_DONE_MORE_RESULTSETS(16),  SQL_STMT_EXECUTE_OK(17),  RESULTSET_FETCH_DONE_MORE_OUT_PARAMS(18);
    
    public static final int OK_VALUE = 0;
    public static final int ERROR_VALUE = 1;
    public static final int CONN_CAPABILITIES_VALUE = 2;
    public static final int SESS_AUTHENTICATE_CONTINUE_VALUE = 3;
    public static final int SESS_AUTHENTICATE_OK_VALUE = 4;
    public static final int NOTICE_VALUE = 11;
    public static final int RESULTSET_COLUMN_META_DATA_VALUE = 12;
    public static final int RESULTSET_ROW_VALUE = 13;
    public static final int RESULTSET_FETCH_DONE_VALUE = 14;
    public static final int RESULTSET_FETCH_SUSPENDED_VALUE = 15;
    public static final int RESULTSET_FETCH_DONE_MORE_RESULTSETS_VALUE = 16;
    public static final int SQL_STMT_EXECUTE_OK_VALUE = 17;
    public static final int RESULTSET_FETCH_DONE_MORE_OUT_PARAMS_VALUE = 18;
    
    public final int getNumber()
    {
      return value;
    }
    
    @Deprecated
    public static Type valueOf(int value)
    {
      return forNumber(value);
    }
    
    public static Type forNumber(int value)
    {
      switch (value)
      {
      case 0: 
        return OK;
      case 1: 
        return ERROR;
      case 2: 
        return CONN_CAPABILITIES;
      case 3: 
        return SESS_AUTHENTICATE_CONTINUE;
      case 4: 
        return SESS_AUTHENTICATE_OK;
      case 11: 
        return NOTICE;
      case 12: 
        return RESULTSET_COLUMN_META_DATA;
      case 13: 
        return RESULTSET_ROW;
      case 14: 
        return RESULTSET_FETCH_DONE;
      case 15: 
        return RESULTSET_FETCH_SUSPENDED;
      case 16: 
        return RESULTSET_FETCH_DONE_MORE_RESULTSETS;
      case 17: 
        return SQL_STMT_EXECUTE_OK;
      case 18: 
        return RESULTSET_FETCH_DONE_MORE_OUT_PARAMS;
      }
      return null;
    }
    
    public static Internal.EnumLiteMap<Type> internalGetValueMap()
    {
      return internalValueMap;
    }
    
    private static final Internal.EnumLiteMap<Type> internalValueMap = new Internal.EnumLiteMap()
    {
      public Mysqlx.ServerMessages.Type findValueByNumber(int number)
      {
        return Mysqlx.ServerMessages.Type.forNumber(number);
      }
    };
    
    public final Descriptors.EnumValueDescriptor getValueDescriptor()
    {
      return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(ordinal());
    }
    
    public final Descriptors.EnumDescriptor getDescriptorForType()
    {
      return getDescriptor();
    }
    
    public static final Descriptors.EnumDescriptor getDescriptor()
    {
      return (Descriptors.EnumDescriptor)Mysqlx.ServerMessages.getDescriptor().getEnumTypes().get(0);
    }
    
    private static final Type[] VALUES = values();
    private final int value;
    
    public static Type valueOf(Descriptors.EnumValueDescriptor desc)
    {
      if (desc.getType() != getDescriptor()) {
        throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
      }
      return VALUES[desc.getIndex()];
    }
    
    private Type(int value)
    {
      this.value = value;
    }
  }
  
  private byte memoizedIsInitialized = -1;
  
  public final boolean isInitialized()
  {
    byte isInitialized = memoizedIsInitialized;
    if (isInitialized == 1) {
      return true;
    }
    if (isInitialized == 0) {
      return false;
    }
    memoizedIsInitialized = 1;
    return true;
  }
  
  public void writeTo(CodedOutputStream output)
    throws IOException
  {
    unknownFields.writeTo(output);
  }
  
  public int getSerializedSize()
  {
    int size = memoizedSize;
    if (size != -1) {
      return size;
    }
    size = 0;
    size += unknownFields.getSerializedSize();
    memoizedSize = size;
    return size;
  }
  
  public boolean equals(Object obj)
  {
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof ServerMessages)) {
      return super.equals(obj);
    }
    ServerMessages other = (ServerMessages)obj;
    
    boolean result = true;
    result = (result) && (unknownFields.equals(unknownFields));
    return result;
  }
  
  public int hashCode()
  {
    if (memoizedHashCode != 0) {
      return memoizedHashCode;
    }
    int hash = 41;
    hash = 19 * hash + getDescriptor().hashCode();
    hash = 29 * hash + unknownFields.hashCode();
    memoizedHashCode = hash;
    return hash;
  }
  
  public static ServerMessages parseFrom(ByteBuffer data)
    throws InvalidProtocolBufferException
  {
    return (ServerMessages)PARSER.parseFrom(data);
  }
  
  public static ServerMessages parseFrom(ByteBuffer data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (ServerMessages)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static ServerMessages parseFrom(ByteString data)
    throws InvalidProtocolBufferException
  {
    return (ServerMessages)PARSER.parseFrom(data);
  }
  
  public static ServerMessages parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (ServerMessages)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static ServerMessages parseFrom(byte[] data)
    throws InvalidProtocolBufferException
  {
    return (ServerMessages)PARSER.parseFrom(data);
  }
  
  public static ServerMessages parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (ServerMessages)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static ServerMessages parseFrom(InputStream input)
    throws IOException
  {
    return 
      (ServerMessages)GeneratedMessageV3.parseWithIOException(PARSER, input);
  }
  
  public static ServerMessages parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (ServerMessages)GeneratedMessageV3.parseWithIOException(PARSER, input, extensionRegistry);
  }
  
  public static ServerMessages parseDelimitedFrom(InputStream input)
    throws IOException
  {
    return 
      (ServerMessages)GeneratedMessageV3.parseDelimitedWithIOException(PARSER, input);
  }
  
  public static ServerMessages parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (ServerMessages)GeneratedMessageV3.parseDelimitedWithIOException(PARSER, input, extensionRegistry);
  }
  
  public static ServerMessages parseFrom(CodedInputStream input)
    throws IOException
  {
    return 
      (ServerMessages)GeneratedMessageV3.parseWithIOException(PARSER, input);
  }
  
  public static ServerMessages parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (ServerMessages)GeneratedMessageV3.parseWithIOException(PARSER, input, extensionRegistry);
  }
  
  public Builder newBuilderForType()
  {
    return newBuilder();
  }
  
  public static Builder newBuilder()
  {
    return DEFAULT_INSTANCE.toBuilder();
  }
  
  public static Builder newBuilder(ServerMessages prototype)
  {
    return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
  }
  
  public Builder toBuilder()
  {
    return this == DEFAULT_INSTANCE ? new Builder(null) : new Builder(null)
      .mergeFrom(this);
  }
  
  protected Builder newBuilderForType(GeneratedMessageV3.BuilderParent parent)
  {
    Builder builder = new Builder(parent, null);
    return builder;
  }
  
  public static final class Builder
    extends GeneratedMessageV3.Builder<Builder>
    implements Mysqlx.ServerMessagesOrBuilder
  {
    public static final Descriptors.Descriptor getDescriptor()
    {
      return Mysqlx.access$800();
    }
    
    protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return 
        Mysqlx.access$900().ensureFieldAccessorsInitialized(Mysqlx.ServerMessages.class, Builder.class);
    }
    
    private Builder()
    {
      maybeForceBuilderInitialization();
    }
    
    private Builder(GeneratedMessageV3.BuilderParent parent)
    {
      super();
      maybeForceBuilderInitialization();
    }
    
    private void maybeForceBuilderInitialization()
    {
      if (Mysqlx.ServerMessages.alwaysUseFieldBuilders) {}
    }
    
    public Builder clear()
    {
      super.clear();
      return this;
    }
    
    public Descriptors.Descriptor getDescriptorForType()
    {
      return Mysqlx.access$800();
    }
    
    public Mysqlx.ServerMessages getDefaultInstanceForType()
    {
      return Mysqlx.ServerMessages.getDefaultInstance();
    }
    
    public Mysqlx.ServerMessages build()
    {
      Mysqlx.ServerMessages result = buildPartial();
      if (!result.isInitialized()) {
        throw newUninitializedMessageException(result);
      }
      return result;
    }
    
    public Mysqlx.ServerMessages buildPartial()
    {
      Mysqlx.ServerMessages result = new Mysqlx.ServerMessages(this, null);
      onBuilt();
      return result;
    }
    
    public Builder clone()
    {
      return (Builder)super.clone();
    }
    
    public Builder setField(Descriptors.FieldDescriptor field, Object value)
    {
      return (Builder)super.setField(field, value);
    }
    
    public Builder clearField(Descriptors.FieldDescriptor field)
    {
      return (Builder)super.clearField(field);
    }
    
    public Builder clearOneof(Descriptors.OneofDescriptor oneof)
    {
      return (Builder)super.clearOneof(oneof);
    }
    
    public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
    {
      return (Builder)super.setRepeatedField(field, index, value);
    }
    
    public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value)
    {
      return (Builder)super.addRepeatedField(field, value);
    }
    
    public Builder mergeFrom(Message other)
    {
      if ((other instanceof Mysqlx.ServerMessages)) {
        return mergeFrom((Mysqlx.ServerMessages)other);
      }
      super.mergeFrom(other);
      return this;
    }
    
    public Builder mergeFrom(Mysqlx.ServerMessages other)
    {
      if (other == Mysqlx.ServerMessages.getDefaultInstance()) {
        return this;
      }
      mergeUnknownFields(unknownFields);
      onChanged();
      return this;
    }
    
    public final boolean isInitialized()
    {
      return true;
    }
    
    public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      Mysqlx.ServerMessages parsedMessage = null;
      try
      {
        parsedMessage = (Mysqlx.ServerMessages)Mysqlx.ServerMessages.PARSER.parsePartialFrom(input, extensionRegistry);
      }
      catch (InvalidProtocolBufferException e)
      {
        parsedMessage = (Mysqlx.ServerMessages)e.getUnfinishedMessage();
        throw e.unwrapIOException();
      }
      finally
      {
        if (parsedMessage != null) {
          mergeFrom(parsedMessage);
        }
      }
      return this;
    }
    
    public final Builder setUnknownFields(UnknownFieldSet unknownFields)
    {
      return (Builder)super.setUnknownFields(unknownFields);
    }
    
    public final Builder mergeUnknownFields(UnknownFieldSet unknownFields)
    {
      return (Builder)super.mergeUnknownFields(unknownFields);
    }
  }
  
  private static final ServerMessages DEFAULT_INSTANCE = new ServerMessages();
  
  public static ServerMessages getDefaultInstance()
  {
    return DEFAULT_INSTANCE;
  }
  
  @Deprecated
  public static final Parser<ServerMessages> PARSER = new AbstractParser()
  {
    public Mysqlx.ServerMessages parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return new Mysqlx.ServerMessages(input, extensionRegistry, null);
    }
  };
  
  public static Parser<ServerMessages> parser()
  {
    return PARSER;
  }
  
  public Parser<ServerMessages> getParserForType()
  {
    return PARSER;
  }
  
  public ServerMessages getDefaultInstanceForType()
  {
    return DEFAULT_INSTANCE;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.ServerMessages
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */