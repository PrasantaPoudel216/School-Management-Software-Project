package com.mysql.cj.x.protobuf;

import com.google.protobuf.CodedInputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3.Builder;
import com.google.protobuf.GeneratedMessageV3.BuilderParent;
import com.google.protobuf.GeneratedMessageV3.FieldAccessorTable;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.google.protobuf.UnknownFieldSet;
import java.io.IOException;

public final class Mysqlx$ServerMessages$Builder
  extends GeneratedMessageV3.Builder<Builder>
  implements Mysqlx.ServerMessagesOrBuilder
{
  public static final Descriptors.Descriptor getDescriptor()
  {
    return Mysqlx.access$800();
  }
  
  protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
  {
    return 
      Mysqlx.access$900().ensureFieldAccessorsInitialized(Mysqlx.ServerMessages.class, Builder.class);
  }
  
  private Mysqlx$ServerMessages$Builder()
  {
    maybeForceBuilderInitialization();
  }
  
  private Mysqlx$ServerMessages$Builder(GeneratedMessageV3.BuilderParent parent)
  {
    super(parent);
    maybeForceBuilderInitialization();
  }
  
  private void maybeForceBuilderInitialization()
  {
    if (Mysqlx.ServerMessages.access$1200()) {}
  }
  
  public Builder clear()
  {
    super.clear();
    return this;
  }
  
  public Descriptors.Descriptor getDescriptorForType()
  {
    return Mysqlx.access$800();
  }
  
  public Mysqlx.ServerMessages getDefaultInstanceForType()
  {
    return Mysqlx.ServerMessages.getDefaultInstance();
  }
  
  public Mysqlx.ServerMessages build()
  {
    Mysqlx.ServerMessages result = buildPartial();
    if (!result.isInitialized()) {
      throw newUninitializedMessageException(result);
    }
    return result;
  }
  
  public Mysqlx.ServerMessages buildPartial()
  {
    Mysqlx.ServerMessages result = new Mysqlx.ServerMessages(this, null);
    onBuilt();
    return result;
  }
  
  public Builder clone()
  {
    return (Builder)super.clone();
  }
  
  public Builder setField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.setField(field, value);
  }
  
  public Builder clearField(Descriptors.FieldDescriptor field)
  {
    return (Builder)super.clearField(field);
  }
  
  public Builder clearOneof(Descriptors.OneofDescriptor oneof)
  {
    return (Builder)super.clearOneof(oneof);
  }
  
  public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
  {
    return (Builder)super.setRepeatedField(field, index, value);
  }
  
  public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.addRepeatedField(field, value);
  }
  
  public Builder mergeFrom(Message other)
  {
    if ((other instanceof Mysqlx.ServerMessages)) {
      return mergeFrom((Mysqlx.ServerMessages)other);
    }
    super.mergeFrom(other);
    return this;
  }
  
  public Builder mergeFrom(Mysqlx.ServerMessages other)
  {
    if (other == Mysqlx.ServerMessages.getDefaultInstance()) {
      return this;
    }
    mergeUnknownFields(Mysqlx.ServerMessages.access$1400(other));
    onChanged();
    return this;
  }
  
  public final boolean isInitialized()
  {
    return true;
  }
  
  public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    Mysqlx.ServerMessages parsedMessage = null;
    try
    {
      parsedMessage = (Mysqlx.ServerMessages)Mysqlx.ServerMessages.PARSER.parsePartialFrom(input, extensionRegistry);
    }
    catch (InvalidProtocolBufferException e)
    {
      parsedMessage = (Mysqlx.ServerMessages)e.getUnfinishedMessage();
      throw e.unwrapIOException();
    }
    finally
    {
      if (parsedMessage != null) {
        mergeFrom(parsedMessage);
      }
    }
    return this;
  }
  
  public final Builder setUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.setUnknownFields(unknownFields);
  }
  
  public final Builder mergeUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.mergeUnknownFields(unknownFields);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.ServerMessages.Builder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */