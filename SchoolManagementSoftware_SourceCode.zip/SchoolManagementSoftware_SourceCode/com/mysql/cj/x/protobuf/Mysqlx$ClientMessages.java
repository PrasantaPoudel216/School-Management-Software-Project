package com.mysql.cj.x.protobuf;

import com.google.protobuf.AbstractParser;
import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.EnumDescriptor;
import com.google.protobuf.Descriptors.EnumValueDescriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.GeneratedMessageV3.Builder;
import com.google.protobuf.GeneratedMessageV3.BuilderParent;
import com.google.protobuf.GeneratedMessageV3.FieldAccessorTable;
import com.google.protobuf.Internal.EnumLiteMap;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.google.protobuf.ProtocolMessageEnum;
import com.google.protobuf.UnknownFieldSet;
import com.google.protobuf.UnknownFieldSet.Builder;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.List;

public final class Mysqlx$ClientMessages
  extends GeneratedMessageV3
  implements Mysqlx.ClientMessagesOrBuilder
{
  private static final long serialVersionUID = 0L;
  
  private Mysqlx$ClientMessages(GeneratedMessageV3.Builder<?> builder)
  {
    super(builder);
  }
  
  private Mysqlx$ClientMessages() {}
  
  public final UnknownFieldSet getUnknownFields()
  {
    return unknownFields;
  }
  
  private Mysqlx$ClientMessages(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    this();
    if (extensionRegistry == null) {
      throw new NullPointerException();
    }
    UnknownFieldSet.Builder unknownFields = UnknownFieldSet.newBuilder();
    try
    {
      boolean done = false;
      while (!done)
      {
        int tag = input.readTag();
        switch (tag)
        {
        case 0: 
          done = true;
          break;
        default: 
          if (!parseUnknownField(input, unknownFields, extensionRegistry, tag)) {
            done = true;
          }
          break;
        }
      }
    }
    catch (InvalidProtocolBufferException e)
    {
      throw e.setUnfinishedMessage(this);
    }
    catch (IOException e)
    {
      throw new InvalidProtocolBufferException(e).setUnfinishedMessage(this);
    }
    finally
    {
      this.unknownFields = unknownFields.build();
      makeExtensionsImmutable();
    }
  }
  
  public static final Descriptors.Descriptor getDescriptor()
  {
    return Mysqlx.access$000();
  }
  
  protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
  {
    return 
      Mysqlx.access$100().ensureFieldAccessorsInitialized(ClientMessages.class, Builder.class);
  }
  
  public static enum Type
    implements ProtocolMessageEnum
  {
    CON_CAPABILITIES_GET(1),  CON_CAPABILITIES_SET(2),  CON_CLOSE(3),  SESS_AUTHENTICATE_START(4),  SESS_AUTHENTICATE_CONTINUE(5),  SESS_RESET(6),  SESS_CLOSE(7),  SQL_STMT_EXECUTE(12),  CRUD_FIND(17),  CRUD_INSERT(18),  CRUD_UPDATE(19),  CRUD_DELETE(20),  EXPECT_OPEN(24),  EXPECT_CLOSE(25),  CRUD_CREATE_VIEW(30),  CRUD_MODIFY_VIEW(31),  CRUD_DROP_VIEW(32),  PREPARE_PREPARE(40),  PREPARE_EXECUTE(41),  PREPARE_DEALLOCATE(42),  CURSOR_OPEN(43),  CURSOR_CLOSE(44),  CURSOR_FETCH(45);
    
    public static final int CON_CAPABILITIES_GET_VALUE = 1;
    public static final int CON_CAPABILITIES_SET_VALUE = 2;
    public static final int CON_CLOSE_VALUE = 3;
    public static final int SESS_AUTHENTICATE_START_VALUE = 4;
    public static final int SESS_AUTHENTICATE_CONTINUE_VALUE = 5;
    public static final int SESS_RESET_VALUE = 6;
    public static final int SESS_CLOSE_VALUE = 7;
    public static final int SQL_STMT_EXECUTE_VALUE = 12;
    public static final int CRUD_FIND_VALUE = 17;
    public static final int CRUD_INSERT_VALUE = 18;
    public static final int CRUD_UPDATE_VALUE = 19;
    public static final int CRUD_DELETE_VALUE = 20;
    public static final int EXPECT_OPEN_VALUE = 24;
    public static final int EXPECT_CLOSE_VALUE = 25;
    public static final int CRUD_CREATE_VIEW_VALUE = 30;
    public static final int CRUD_MODIFY_VIEW_VALUE = 31;
    public static final int CRUD_DROP_VIEW_VALUE = 32;
    public static final int PREPARE_PREPARE_VALUE = 40;
    public static final int PREPARE_EXECUTE_VALUE = 41;
    public static final int PREPARE_DEALLOCATE_VALUE = 42;
    public static final int CURSOR_OPEN_VALUE = 43;
    public static final int CURSOR_CLOSE_VALUE = 44;
    public static final int CURSOR_FETCH_VALUE = 45;
    
    public final int getNumber()
    {
      return value;
    }
    
    @Deprecated
    public static Type valueOf(int value)
    {
      return forNumber(value);
    }
    
    public static Type forNumber(int value)
    {
      switch (value)
      {
      case 1: 
        return CON_CAPABILITIES_GET;
      case 2: 
        return CON_CAPABILITIES_SET;
      case 3: 
        return CON_CLOSE;
      case 4: 
        return SESS_AUTHENTICATE_START;
      case 5: 
        return SESS_AUTHENTICATE_CONTINUE;
      case 6: 
        return SESS_RESET;
      case 7: 
        return SESS_CLOSE;
      case 12: 
        return SQL_STMT_EXECUTE;
      case 17: 
        return CRUD_FIND;
      case 18: 
        return CRUD_INSERT;
      case 19: 
        return CRUD_UPDATE;
      case 20: 
        return CRUD_DELETE;
      case 24: 
        return EXPECT_OPEN;
      case 25: 
        return EXPECT_CLOSE;
      case 30: 
        return CRUD_CREATE_VIEW;
      case 31: 
        return CRUD_MODIFY_VIEW;
      case 32: 
        return CRUD_DROP_VIEW;
      case 40: 
        return PREPARE_PREPARE;
      case 41: 
        return PREPARE_EXECUTE;
      case 42: 
        return PREPARE_DEALLOCATE;
      case 43: 
        return CURSOR_OPEN;
      case 44: 
        return CURSOR_CLOSE;
      case 45: 
        return CURSOR_FETCH;
      }
      return null;
    }
    
    public static Internal.EnumLiteMap<Type> internalGetValueMap()
    {
      return internalValueMap;
    }
    
    private static final Internal.EnumLiteMap<Type> internalValueMap = new Internal.EnumLiteMap()
    {
      public Mysqlx.ClientMessages.Type findValueByNumber(int number)
      {
        return Mysqlx.ClientMessages.Type.forNumber(number);
      }
    };
    
    public final Descriptors.EnumValueDescriptor getValueDescriptor()
    {
      return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(ordinal());
    }
    
    public final Descriptors.EnumDescriptor getDescriptorForType()
    {
      return getDescriptor();
    }
    
    public static final Descriptors.EnumDescriptor getDescriptor()
    {
      return (Descriptors.EnumDescriptor)Mysqlx.ClientMessages.getDescriptor().getEnumTypes().get(0);
    }
    
    private static final Type[] VALUES = values();
    private final int value;
    
    public static Type valueOf(Descriptors.EnumValueDescriptor desc)
    {
      if (desc.getType() != getDescriptor()) {
        throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
      }
      return VALUES[desc.getIndex()];
    }
    
    private Type(int value)
    {
      this.value = value;
    }
  }
  
  private byte memoizedIsInitialized = -1;
  
  public final boolean isInitialized()
  {
    byte isInitialized = memoizedIsInitialized;
    if (isInitialized == 1) {
      return true;
    }
    if (isInitialized == 0) {
      return false;
    }
    memoizedIsInitialized = 1;
    return true;
  }
  
  public void writeTo(CodedOutputStream output)
    throws IOException
  {
    unknownFields.writeTo(output);
  }
  
  public int getSerializedSize()
  {
    int size = memoizedSize;
    if (size != -1) {
      return size;
    }
    size = 0;
    size += unknownFields.getSerializedSize();
    memoizedSize = size;
    return size;
  }
  
  public boolean equals(Object obj)
  {
    if (obj == this) {
      return true;
    }
    if (!(obj instanceof ClientMessages)) {
      return super.equals(obj);
    }
    ClientMessages other = (ClientMessages)obj;
    
    boolean result = true;
    result = (result) && (unknownFields.equals(unknownFields));
    return result;
  }
  
  public int hashCode()
  {
    if (memoizedHashCode != 0) {
      return memoizedHashCode;
    }
    int hash = 41;
    hash = 19 * hash + getDescriptor().hashCode();
    hash = 29 * hash + unknownFields.hashCode();
    memoizedHashCode = hash;
    return hash;
  }
  
  public static ClientMessages parseFrom(ByteBuffer data)
    throws InvalidProtocolBufferException
  {
    return (ClientMessages)PARSER.parseFrom(data);
  }
  
  public static ClientMessages parseFrom(ByteBuffer data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (ClientMessages)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static ClientMessages parseFrom(ByteString data)
    throws InvalidProtocolBufferException
  {
    return (ClientMessages)PARSER.parseFrom(data);
  }
  
  public static ClientMessages parseFrom(ByteString data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (ClientMessages)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static ClientMessages parseFrom(byte[] data)
    throws InvalidProtocolBufferException
  {
    return (ClientMessages)PARSER.parseFrom(data);
  }
  
  public static ClientMessages parseFrom(byte[] data, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return (ClientMessages)PARSER.parseFrom(data, extensionRegistry);
  }
  
  public static ClientMessages parseFrom(InputStream input)
    throws IOException
  {
    return 
      (ClientMessages)GeneratedMessageV3.parseWithIOException(PARSER, input);
  }
  
  public static ClientMessages parseFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (ClientMessages)GeneratedMessageV3.parseWithIOException(PARSER, input, extensionRegistry);
  }
  
  public static ClientMessages parseDelimitedFrom(InputStream input)
    throws IOException
  {
    return 
      (ClientMessages)GeneratedMessageV3.parseDelimitedWithIOException(PARSER, input);
  }
  
  public static ClientMessages parseDelimitedFrom(InputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (ClientMessages)GeneratedMessageV3.parseDelimitedWithIOException(PARSER, input, extensionRegistry);
  }
  
  public static ClientMessages parseFrom(CodedInputStream input)
    throws IOException
  {
    return 
      (ClientMessages)GeneratedMessageV3.parseWithIOException(PARSER, input);
  }
  
  public static ClientMessages parseFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    return 
      (ClientMessages)GeneratedMessageV3.parseWithIOException(PARSER, input, extensionRegistry);
  }
  
  public Builder newBuilderForType()
  {
    return newBuilder();
  }
  
  public static Builder newBuilder()
  {
    return DEFAULT_INSTANCE.toBuilder();
  }
  
  public static Builder newBuilder(ClientMessages prototype)
  {
    return DEFAULT_INSTANCE.toBuilder().mergeFrom(prototype);
  }
  
  public Builder toBuilder()
  {
    return this == DEFAULT_INSTANCE ? new Builder(null) : new Builder(null)
      .mergeFrom(this);
  }
  
  protected Builder newBuilderForType(GeneratedMessageV3.BuilderParent parent)
  {
    Builder builder = new Builder(parent, null);
    return builder;
  }
  
  public static final class Builder
    extends GeneratedMessageV3.Builder<Builder>
    implements Mysqlx.ClientMessagesOrBuilder
  {
    public static final Descriptors.Descriptor getDescriptor()
    {
      return Mysqlx.access$000();
    }
    
    protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
    {
      return 
        Mysqlx.access$100().ensureFieldAccessorsInitialized(Mysqlx.ClientMessages.class, Builder.class);
    }
    
    private Builder()
    {
      maybeForceBuilderInitialization();
    }
    
    private Builder(GeneratedMessageV3.BuilderParent parent)
    {
      super();
      maybeForceBuilderInitialization();
    }
    
    private void maybeForceBuilderInitialization()
    {
      if (Mysqlx.ClientMessages.alwaysUseFieldBuilders) {}
    }
    
    public Builder clear()
    {
      super.clear();
      return this;
    }
    
    public Descriptors.Descriptor getDescriptorForType()
    {
      return Mysqlx.access$000();
    }
    
    public Mysqlx.ClientMessages getDefaultInstanceForType()
    {
      return Mysqlx.ClientMessages.getDefaultInstance();
    }
    
    public Mysqlx.ClientMessages build()
    {
      Mysqlx.ClientMessages result = buildPartial();
      if (!result.isInitialized()) {
        throw newUninitializedMessageException(result);
      }
      return result;
    }
    
    public Mysqlx.ClientMessages buildPartial()
    {
      Mysqlx.ClientMessages result = new Mysqlx.ClientMessages(this, null);
      onBuilt();
      return result;
    }
    
    public Builder clone()
    {
      return (Builder)super.clone();
    }
    
    public Builder setField(Descriptors.FieldDescriptor field, Object value)
    {
      return (Builder)super.setField(field, value);
    }
    
    public Builder clearField(Descriptors.FieldDescriptor field)
    {
      return (Builder)super.clearField(field);
    }
    
    public Builder clearOneof(Descriptors.OneofDescriptor oneof)
    {
      return (Builder)super.clearOneof(oneof);
    }
    
    public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
    {
      return (Builder)super.setRepeatedField(field, index, value);
    }
    
    public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value)
    {
      return (Builder)super.addRepeatedField(field, value);
    }
    
    public Builder mergeFrom(Message other)
    {
      if ((other instanceof Mysqlx.ClientMessages)) {
        return mergeFrom((Mysqlx.ClientMessages)other);
      }
      super.mergeFrom(other);
      return this;
    }
    
    public Builder mergeFrom(Mysqlx.ClientMessages other)
    {
      if (other == Mysqlx.ClientMessages.getDefaultInstance()) {
        return this;
      }
      mergeUnknownFields(unknownFields);
      onChanged();
      return this;
    }
    
    public final boolean isInitialized()
    {
      return true;
    }
    
    public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws IOException
    {
      Mysqlx.ClientMessages parsedMessage = null;
      try
      {
        parsedMessage = (Mysqlx.ClientMessages)Mysqlx.ClientMessages.PARSER.parsePartialFrom(input, extensionRegistry);
      }
      catch (InvalidProtocolBufferException e)
      {
        parsedMessage = (Mysqlx.ClientMessages)e.getUnfinishedMessage();
        throw e.unwrapIOException();
      }
      finally
      {
        if (parsedMessage != null) {
          mergeFrom(parsedMessage);
        }
      }
      return this;
    }
    
    public final Builder setUnknownFields(UnknownFieldSet unknownFields)
    {
      return (Builder)super.setUnknownFields(unknownFields);
    }
    
    public final Builder mergeUnknownFields(UnknownFieldSet unknownFields)
    {
      return (Builder)super.mergeUnknownFields(unknownFields);
    }
  }
  
  private static final ClientMessages DEFAULT_INSTANCE = new ClientMessages();
  
  public static ClientMessages getDefaultInstance()
  {
    return DEFAULT_INSTANCE;
  }
  
  @Deprecated
  public static final Parser<ClientMessages> PARSER = new AbstractParser()
  {
    public Mysqlx.ClientMessages parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
      throws InvalidProtocolBufferException
    {
      return new Mysqlx.ClientMessages(input, extensionRegistry, null);
    }
  };
  
  public static Parser<ClientMessages> parser()
  {
    return PARSER;
  }
  
  public Parser<ClientMessages> getParserForType()
  {
    return PARSER;
  }
  
  public ClientMessages getDefaultInstanceForType()
  {
    return DEFAULT_INSTANCE;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.ClientMessages
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */