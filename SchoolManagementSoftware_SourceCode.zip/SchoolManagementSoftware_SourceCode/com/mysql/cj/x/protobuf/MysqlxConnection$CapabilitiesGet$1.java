package com.mysql.cj.x.protobuf;

import com.google.protobuf.AbstractParser;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.InvalidProtocolBufferException;

final class MysqlxConnection$CapabilitiesGet$1
  extends AbstractParser<MysqlxConnection.CapabilitiesGet>
{
  public MysqlxConnection.CapabilitiesGet parsePartialFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws InvalidProtocolBufferException
  {
    return new MysqlxConnection.CapabilitiesGet(input, extensionRegistry, null);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.MysqlxConnection.CapabilitiesGet.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */