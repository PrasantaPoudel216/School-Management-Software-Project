package com.mysql.cj.x.protobuf;

import com.google.protobuf.ByteString;
import com.google.protobuf.MessageOrBuilder;

public abstract interface Mysqlx$ErrorOrBuilder
  extends MessageOrBuilder
{
  public abstract boolean hasSeverity();
  
  public abstract Mysqlx.Error.Severity getSeverity();
  
  public abstract boolean hasCode();
  
  public abstract int getCode();
  
  public abstract boolean hasSqlState();
  
  public abstract String getSqlState();
  
  public abstract ByteString getSqlStateBytes();
  
  public abstract boolean hasMsg();
  
  public abstract String getMsg();
  
  public abstract ByteString getMsgBytes();
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.ErrorOrBuilder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */