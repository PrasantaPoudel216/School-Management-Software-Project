package com.mysql.cj.x.protobuf;

import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.EnumDescriptor;
import com.google.protobuf.Descriptors.EnumValueDescriptor;
import com.google.protobuf.Internal.EnumLiteMap;
import com.google.protobuf.ProtocolMessageEnum;
import java.util.List;

public enum Mysqlx$Error$Severity
  implements ProtocolMessageEnum
{
  ERROR(0),  FATAL(1);
  
  public static final int ERROR_VALUE = 0;
  public static final int FATAL_VALUE = 1;
  
  public final int getNumber()
  {
    return value;
  }
  
  @Deprecated
  public static Severity valueOf(int value)
  {
    return forNumber(value);
  }
  
  public static Severity forNumber(int value)
  {
    switch (value)
    {
    case 0: 
      return ERROR;
    case 1: 
      return FATAL;
    }
    return null;
  }
  
  public static Internal.EnumLiteMap<Severity> internalGetValueMap()
  {
    return internalValueMap;
  }
  
  private static final Internal.EnumLiteMap<Severity> internalValueMap = new Internal.EnumLiteMap()
  {
    public Mysqlx.Error.Severity findValueByNumber(int number)
    {
      return Mysqlx.Error.Severity.forNumber(number);
    }
  };
  
  public final Descriptors.EnumValueDescriptor getValueDescriptor()
  {
    return (Descriptors.EnumValueDescriptor)getDescriptor().getValues().get(ordinal());
  }
  
  public final Descriptors.EnumDescriptor getDescriptorForType()
  {
    return getDescriptor();
  }
  
  public static final Descriptors.EnumDescriptor getDescriptor()
  {
    return (Descriptors.EnumDescriptor)Mysqlx.Error.getDescriptor().getEnumTypes().get(0);
  }
  
  private static final Severity[] VALUES = values();
  private final int value;
  
  public static Severity valueOf(Descriptors.EnumValueDescriptor desc)
  {
    if (desc.getType() != getDescriptor()) {
      throw new IllegalArgumentException("EnumValueDescriptor is not for this type.");
    }
    return VALUES[desc.getIndex()];
  }
  
  private Mysqlx$Error$Severity(int value)
  {
    this.value = value;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.Error.Severity
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */