package com.mysql.cj.x.protobuf;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3.Builder;
import com.google.protobuf.GeneratedMessageV3.BuilderParent;
import com.google.protobuf.GeneratedMessageV3.FieldAccessorTable;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.google.protobuf.UnknownFieldSet;
import java.io.IOException;

public final class Mysqlx$Error$Builder
  extends GeneratedMessageV3.Builder<Builder>
  implements Mysqlx.ErrorOrBuilder
{
  private int bitField0_;
  
  public static final Descriptors.Descriptor getDescriptor()
  {
    return Mysqlx.access$2600();
  }
  
  protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
  {
    return 
      Mysqlx.access$2700().ensureFieldAccessorsInitialized(Mysqlx.Error.class, Builder.class);
  }
  
  private Mysqlx$Error$Builder()
  {
    maybeForceBuilderInitialization();
  }
  
  private Mysqlx$Error$Builder(GeneratedMessageV3.BuilderParent parent)
  {
    super(parent);
    maybeForceBuilderInitialization();
  }
  
  private void maybeForceBuilderInitialization()
  {
    if (Mysqlx.Error.access$3000()) {}
  }
  
  public Builder clear()
  {
    super.clear();
    severity_ = 0;
    bitField0_ &= 0xFFFFFFFE;
    code_ = 0;
    bitField0_ &= 0xFFFFFFFD;
    sqlState_ = "";
    bitField0_ &= 0xFFFFFFFB;
    msg_ = "";
    bitField0_ &= 0xFFFFFFF7;
    return this;
  }
  
  public Descriptors.Descriptor getDescriptorForType()
  {
    return Mysqlx.access$2600();
  }
  
  public Mysqlx.Error getDefaultInstanceForType()
  {
    return Mysqlx.Error.getDefaultInstance();
  }
  
  public Mysqlx.Error build()
  {
    Mysqlx.Error result = buildPartial();
    if (!result.isInitialized()) {
      throw newUninitializedMessageException(result);
    }
    return result;
  }
  
  public Mysqlx.Error buildPartial()
  {
    Mysqlx.Error result = new Mysqlx.Error(this, null);
    int from_bitField0_ = bitField0_;
    int to_bitField0_ = 0;
    if ((from_bitField0_ & 0x1) == 1) {
      to_bitField0_ |= 0x1;
    }
    Mysqlx.Error.access$3202(result, severity_);
    if ((from_bitField0_ & 0x2) == 2) {
      to_bitField0_ |= 0x2;
    }
    Mysqlx.Error.access$3302(result, code_);
    if ((from_bitField0_ & 0x4) == 4) {
      to_bitField0_ |= 0x4;
    }
    Mysqlx.Error.access$3402(result, sqlState_);
    if ((from_bitField0_ & 0x8) == 8) {
      to_bitField0_ |= 0x8;
    }
    Mysqlx.Error.access$3502(result, msg_);
    Mysqlx.Error.access$3602(result, to_bitField0_);
    onBuilt();
    return result;
  }
  
  public Builder clone()
  {
    return (Builder)super.clone();
  }
  
  public Builder setField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.setField(field, value);
  }
  
  public Builder clearField(Descriptors.FieldDescriptor field)
  {
    return (Builder)super.clearField(field);
  }
  
  public Builder clearOneof(Descriptors.OneofDescriptor oneof)
  {
    return (Builder)super.clearOneof(oneof);
  }
  
  public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
  {
    return (Builder)super.setRepeatedField(field, index, value);
  }
  
  public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.addRepeatedField(field, value);
  }
  
  public Builder mergeFrom(Message other)
  {
    if ((other instanceof Mysqlx.Error)) {
      return mergeFrom((Mysqlx.Error)other);
    }
    super.mergeFrom(other);
    return this;
  }
  
  public Builder mergeFrom(Mysqlx.Error other)
  {
    if (other == Mysqlx.Error.getDefaultInstance()) {
      return this;
    }
    if (other.hasSeverity()) {
      setSeverity(other.getSeverity());
    }
    if (other.hasCode()) {
      setCode(other.getCode());
    }
    if (other.hasSqlState())
    {
      bitField0_ |= 0x4;
      sqlState_ = Mysqlx.Error.access$3400(other);
      onChanged();
    }
    if (other.hasMsg())
    {
      bitField0_ |= 0x8;
      msg_ = Mysqlx.Error.access$3500(other);
      onChanged();
    }
    mergeUnknownFields(Mysqlx.Error.access$3700(other));
    onChanged();
    return this;
  }
  
  public final boolean isInitialized()
  {
    if (!hasCode()) {
      return false;
    }
    if (!hasSqlState()) {
      return false;
    }
    if (!hasMsg()) {
      return false;
    }
    return true;
  }
  
  public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    Mysqlx.Error parsedMessage = null;
    try
    {
      parsedMessage = (Mysqlx.Error)Mysqlx.Error.PARSER.parsePartialFrom(input, extensionRegistry);
    }
    catch (InvalidProtocolBufferException e)
    {
      parsedMessage = (Mysqlx.Error)e.getUnfinishedMessage();
      throw e.unwrapIOException();
    }
    finally
    {
      if (parsedMessage != null) {
        mergeFrom(parsedMessage);
      }
    }
    return this;
  }
  
  private int severity_ = 0;
  private int code_;
  
  public boolean hasSeverity()
  {
    return (bitField0_ & 0x1) == 1;
  }
  
  public Mysqlx.Error.Severity getSeverity()
  {
    Mysqlx.Error.Severity result = Mysqlx.Error.Severity.valueOf(severity_);
    return result == null ? Mysqlx.Error.Severity.ERROR : result;
  }
  
  public Builder setSeverity(Mysqlx.Error.Severity value)
  {
    if (value == null) {
      throw new NullPointerException();
    }
    bitField0_ |= 0x1;
    severity_ = value.getNumber();
    onChanged();
    return this;
  }
  
  public Builder clearSeverity()
  {
    bitField0_ &= 0xFFFFFFFE;
    severity_ = 0;
    onChanged();
    return this;
  }
  
  public boolean hasCode()
  {
    return (bitField0_ & 0x2) == 2;
  }
  
  public int getCode()
  {
    return code_;
  }
  
  public Builder setCode(int value)
  {
    bitField0_ |= 0x2;
    code_ = value;
    onChanged();
    return this;
  }
  
  public Builder clearCode()
  {
    bitField0_ &= 0xFFFFFFFD;
    code_ = 0;
    onChanged();
    return this;
  }
  
  private Object sqlState_ = "";
  
  public boolean hasSqlState()
  {
    return (bitField0_ & 0x4) == 4;
  }
  
  public String getSqlState()
  {
    Object ref = sqlState_;
    if (!(ref instanceof String))
    {
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        sqlState_ = s;
      }
      return s;
    }
    return (String)ref;
  }
  
  public ByteString getSqlStateBytes()
  {
    Object ref = sqlState_;
    if ((ref instanceof String))
    {
      ByteString b = ByteString.copyFromUtf8((String)ref);
      
      sqlState_ = b;
      return b;
    }
    return (ByteString)ref;
  }
  
  public Builder setSqlState(String value)
  {
    if (value == null) {
      throw new NullPointerException();
    }
    bitField0_ |= 0x4;
    sqlState_ = value;
    onChanged();
    return this;
  }
  
  public Builder clearSqlState()
  {
    bitField0_ &= 0xFFFFFFFB;
    sqlState_ = Mysqlx.Error.getDefaultInstance().getSqlState();
    onChanged();
    return this;
  }
  
  public Builder setSqlStateBytes(ByteString value)
  {
    if (value == null) {
      throw new NullPointerException();
    }
    bitField0_ |= 0x4;
    sqlState_ = value;
    onChanged();
    return this;
  }
  
  private Object msg_ = "";
  
  public boolean hasMsg()
  {
    return (bitField0_ & 0x8) == 8;
  }
  
  public String getMsg()
  {
    Object ref = msg_;
    if (!(ref instanceof String))
    {
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        msg_ = s;
      }
      return s;
    }
    return (String)ref;
  }
  
  public ByteString getMsgBytes()
  {
    Object ref = msg_;
    if ((ref instanceof String))
    {
      ByteString b = ByteString.copyFromUtf8((String)ref);
      
      msg_ = b;
      return b;
    }
    return (ByteString)ref;
  }
  
  public Builder setMsg(String value)
  {
    if (value == null) {
      throw new NullPointerException();
    }
    bitField0_ |= 0x8;
    msg_ = value;
    onChanged();
    return this;
  }
  
  public Builder clearMsg()
  {
    bitField0_ &= 0xFFFFFFF7;
    msg_ = Mysqlx.Error.getDefaultInstance().getMsg();
    onChanged();
    return this;
  }
  
  public Builder setMsgBytes(ByteString value)
  {
    if (value == null) {
      throw new NullPointerException();
    }
    bitField0_ |= 0x8;
    msg_ = value;
    onChanged();
    return this;
  }
  
  public final Builder setUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.setUnknownFields(unknownFields);
  }
  
  public final Builder mergeUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.mergeUnknownFields(unknownFields);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.Error.Builder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */