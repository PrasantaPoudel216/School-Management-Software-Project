package com.mysql.cj.x.protobuf;

import com.google.protobuf.ByteString;
import com.google.protobuf.MessageOrBuilder;

public abstract interface Mysqlx$OkOrBuilder
  extends MessageOrBuilder
{
  public abstract boolean hasMsg();
  
  public abstract String getMsg();
  
  public abstract ByteString getMsgBytes();
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.OkOrBuilder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */