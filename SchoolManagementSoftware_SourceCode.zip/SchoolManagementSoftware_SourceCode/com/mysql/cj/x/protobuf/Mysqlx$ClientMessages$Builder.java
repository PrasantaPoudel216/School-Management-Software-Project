package com.mysql.cj.x.protobuf;

import com.google.protobuf.CodedInputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3.Builder;
import com.google.protobuf.GeneratedMessageV3.BuilderParent;
import com.google.protobuf.GeneratedMessageV3.FieldAccessorTable;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.google.protobuf.UnknownFieldSet;
import java.io.IOException;

public final class Mysqlx$ClientMessages$Builder
  extends GeneratedMessageV3.Builder<Builder>
  implements Mysqlx.ClientMessagesOrBuilder
{
  public static final Descriptors.Descriptor getDescriptor()
  {
    return Mysqlx.access$000();
  }
  
  protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
  {
    return 
      Mysqlx.access$100().ensureFieldAccessorsInitialized(Mysqlx.ClientMessages.class, Builder.class);
  }
  
  private Mysqlx$ClientMessages$Builder()
  {
    maybeForceBuilderInitialization();
  }
  
  private Mysqlx$ClientMessages$Builder(GeneratedMessageV3.BuilderParent parent)
  {
    super(parent);
    maybeForceBuilderInitialization();
  }
  
  private void maybeForceBuilderInitialization()
  {
    if (Mysqlx.ClientMessages.access$400()) {}
  }
  
  public Builder clear()
  {
    super.clear();
    return this;
  }
  
  public Descriptors.Descriptor getDescriptorForType()
  {
    return Mysqlx.access$000();
  }
  
  public Mysqlx.ClientMessages getDefaultInstanceForType()
  {
    return Mysqlx.ClientMessages.getDefaultInstance();
  }
  
  public Mysqlx.ClientMessages build()
  {
    Mysqlx.ClientMessages result = buildPartial();
    if (!result.isInitialized()) {
      throw newUninitializedMessageException(result);
    }
    return result;
  }
  
  public Mysqlx.ClientMessages buildPartial()
  {
    Mysqlx.ClientMessages result = new Mysqlx.ClientMessages(this, null);
    onBuilt();
    return result;
  }
  
  public Builder clone()
  {
    return (Builder)super.clone();
  }
  
  public Builder setField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.setField(field, value);
  }
  
  public Builder clearField(Descriptors.FieldDescriptor field)
  {
    return (Builder)super.clearField(field);
  }
  
  public Builder clearOneof(Descriptors.OneofDescriptor oneof)
  {
    return (Builder)super.clearOneof(oneof);
  }
  
  public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
  {
    return (Builder)super.setRepeatedField(field, index, value);
  }
  
  public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.addRepeatedField(field, value);
  }
  
  public Builder mergeFrom(Message other)
  {
    if ((other instanceof Mysqlx.ClientMessages)) {
      return mergeFrom((Mysqlx.ClientMessages)other);
    }
    super.mergeFrom(other);
    return this;
  }
  
  public Builder mergeFrom(Mysqlx.ClientMessages other)
  {
    if (other == Mysqlx.ClientMessages.getDefaultInstance()) {
      return this;
    }
    mergeUnknownFields(Mysqlx.ClientMessages.access$600(other));
    onChanged();
    return this;
  }
  
  public final boolean isInitialized()
  {
    return true;
  }
  
  public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    Mysqlx.ClientMessages parsedMessage = null;
    try
    {
      parsedMessage = (Mysqlx.ClientMessages)Mysqlx.ClientMessages.PARSER.parsePartialFrom(input, extensionRegistry);
    }
    catch (InvalidProtocolBufferException e)
    {
      parsedMessage = (Mysqlx.ClientMessages)e.getUnfinishedMessage();
      throw e.unwrapIOException();
    }
    finally
    {
      if (parsedMessage != null) {
        mergeFrom(parsedMessage);
      }
    }
    return this;
  }
  
  public final Builder setUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.setUnknownFields(unknownFields);
  }
  
  public final Builder mergeUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.mergeUnknownFields(unknownFields);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.ClientMessages.Builder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */