package com.mysql.cj.x.protobuf;

import com.google.protobuf.Internal.EnumLiteMap;

final class Mysqlx$ServerMessages$Type$1
  implements Internal.EnumLiteMap<Mysqlx.ServerMessages.Type>
{
  public Mysqlx.ServerMessages.Type findValueByNumber(int number)
  {
    return Mysqlx.ServerMessages.Type.forNumber(number);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.ServerMessages.Type.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */