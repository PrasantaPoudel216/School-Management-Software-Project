package com.mysql.cj.x.protobuf;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedInputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.ExtensionRegistryLite;
import com.google.protobuf.GeneratedMessageV3.Builder;
import com.google.protobuf.GeneratedMessageV3.BuilderParent;
import com.google.protobuf.GeneratedMessageV3.FieldAccessorTable;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Message;
import com.google.protobuf.Parser;
import com.google.protobuf.UnknownFieldSet;
import java.io.IOException;

public final class Mysqlx$Ok$Builder
  extends GeneratedMessageV3.Builder<Builder>
  implements Mysqlx.OkOrBuilder
{
  private int bitField0_;
  
  public static final Descriptors.Descriptor getDescriptor()
  {
    return Mysqlx.access$1600();
  }
  
  protected GeneratedMessageV3.FieldAccessorTable internalGetFieldAccessorTable()
  {
    return 
      Mysqlx.access$1700().ensureFieldAccessorsInitialized(Mysqlx.Ok.class, Builder.class);
  }
  
  private Mysqlx$Ok$Builder()
  {
    maybeForceBuilderInitialization();
  }
  
  private Mysqlx$Ok$Builder(GeneratedMessageV3.BuilderParent parent)
  {
    super(parent);
    maybeForceBuilderInitialization();
  }
  
  private void maybeForceBuilderInitialization()
  {
    if (Mysqlx.Ok.access$2000()) {}
  }
  
  public Builder clear()
  {
    super.clear();
    msg_ = "";
    bitField0_ &= 0xFFFFFFFE;
    return this;
  }
  
  public Descriptors.Descriptor getDescriptorForType()
  {
    return Mysqlx.access$1600();
  }
  
  public Mysqlx.Ok getDefaultInstanceForType()
  {
    return Mysqlx.Ok.getDefaultInstance();
  }
  
  public Mysqlx.Ok build()
  {
    Mysqlx.Ok result = buildPartial();
    if (!result.isInitialized()) {
      throw newUninitializedMessageException(result);
    }
    return result;
  }
  
  public Mysqlx.Ok buildPartial()
  {
    Mysqlx.Ok result = new Mysqlx.Ok(this, null);
    int from_bitField0_ = bitField0_;
    int to_bitField0_ = 0;
    if ((from_bitField0_ & 0x1) == 1) {
      to_bitField0_ |= 0x1;
    }
    Mysqlx.Ok.access$2202(result, msg_);
    Mysqlx.Ok.access$2302(result, to_bitField0_);
    onBuilt();
    return result;
  }
  
  public Builder clone()
  {
    return (Builder)super.clone();
  }
  
  public Builder setField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.setField(field, value);
  }
  
  public Builder clearField(Descriptors.FieldDescriptor field)
  {
    return (Builder)super.clearField(field);
  }
  
  public Builder clearOneof(Descriptors.OneofDescriptor oneof)
  {
    return (Builder)super.clearOneof(oneof);
  }
  
  public Builder setRepeatedField(Descriptors.FieldDescriptor field, int index, Object value)
  {
    return (Builder)super.setRepeatedField(field, index, value);
  }
  
  public Builder addRepeatedField(Descriptors.FieldDescriptor field, Object value)
  {
    return (Builder)super.addRepeatedField(field, value);
  }
  
  public Builder mergeFrom(Message other)
  {
    if ((other instanceof Mysqlx.Ok)) {
      return mergeFrom((Mysqlx.Ok)other);
    }
    super.mergeFrom(other);
    return this;
  }
  
  public Builder mergeFrom(Mysqlx.Ok other)
  {
    if (other == Mysqlx.Ok.getDefaultInstance()) {
      return this;
    }
    if (other.hasMsg())
    {
      bitField0_ |= 0x1;
      msg_ = Mysqlx.Ok.access$2200(other);
      onChanged();
    }
    mergeUnknownFields(Mysqlx.Ok.access$2400(other));
    onChanged();
    return this;
  }
  
  public final boolean isInitialized()
  {
    return true;
  }
  
  public Builder mergeFrom(CodedInputStream input, ExtensionRegistryLite extensionRegistry)
    throws IOException
  {
    Mysqlx.Ok parsedMessage = null;
    try
    {
      parsedMessage = (Mysqlx.Ok)Mysqlx.Ok.PARSER.parsePartialFrom(input, extensionRegistry);
    }
    catch (InvalidProtocolBufferException e)
    {
      parsedMessage = (Mysqlx.Ok)e.getUnfinishedMessage();
      throw e.unwrapIOException();
    }
    finally
    {
      if (parsedMessage != null) {
        mergeFrom(parsedMessage);
      }
    }
    return this;
  }
  
  private Object msg_ = "";
  
  public boolean hasMsg()
  {
    return (bitField0_ & 0x1) == 1;
  }
  
  public String getMsg()
  {
    Object ref = msg_;
    if (!(ref instanceof String))
    {
      ByteString bs = (ByteString)ref;
      
      String s = bs.toStringUtf8();
      if (bs.isValidUtf8()) {
        msg_ = s;
      }
      return s;
    }
    return (String)ref;
  }
  
  public ByteString getMsgBytes()
  {
    Object ref = msg_;
    if ((ref instanceof String))
    {
      ByteString b = ByteString.copyFromUtf8((String)ref);
      
      msg_ = b;
      return b;
    }
    return (ByteString)ref;
  }
  
  public Builder setMsg(String value)
  {
    if (value == null) {
      throw new NullPointerException();
    }
    bitField0_ |= 0x1;
    msg_ = value;
    onChanged();
    return this;
  }
  
  public Builder clearMsg()
  {
    bitField0_ &= 0xFFFFFFFE;
    msg_ = Mysqlx.Ok.getDefaultInstance().getMsg();
    onChanged();
    return this;
  }
  
  public Builder setMsgBytes(ByteString value)
  {
    if (value == null) {
      throw new NullPointerException();
    }
    bitField0_ |= 0x1;
    msg_ = value;
    onChanged();
    return this;
  }
  
  public final Builder setUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.setUnknownFields(unknownFields);
  }
  
  public final Builder mergeUnknownFields(UnknownFieldSet unknownFields)
  {
    return (Builder)super.mergeUnknownFields(unknownFields);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.Ok.Builder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */