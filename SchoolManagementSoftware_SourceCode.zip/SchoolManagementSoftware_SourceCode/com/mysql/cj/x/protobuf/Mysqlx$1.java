package com.mysql.cj.x.protobuf;

import com.google.protobuf.Descriptors.FileDescriptor;
import com.google.protobuf.Descriptors.FileDescriptor.InternalDescriptorAssigner;
import com.google.protobuf.ExtensionRegistry;

final class Mysqlx$1
  implements Descriptors.FileDescriptor.InternalDescriptorAssigner
{
  public ExtensionRegistry assignDescriptors(Descriptors.FileDescriptor root)
  {
    Mysqlx.access$3902(root);
    return null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */