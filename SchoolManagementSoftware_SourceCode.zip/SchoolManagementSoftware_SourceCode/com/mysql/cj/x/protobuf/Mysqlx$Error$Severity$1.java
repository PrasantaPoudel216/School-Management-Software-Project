package com.mysql.cj.x.protobuf;

import com.google.protobuf.Internal.EnumLiteMap;

final class Mysqlx$Error$Severity$1
  implements Internal.EnumLiteMap<Mysqlx.Error.Severity>
{
  public Mysqlx.Error.Severity findValueByNumber(int number)
  {
    return Mysqlx.Error.Severity.forNumber(number);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.x.protobuf.Mysqlx.Error.Severity.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */