package com.mysql.cj;

import java.util.Map;

public class LicenseConfiguration
{
  public static void checkLicenseType(Map<String, String> serverVariables) {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.LicenseConfiguration
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */