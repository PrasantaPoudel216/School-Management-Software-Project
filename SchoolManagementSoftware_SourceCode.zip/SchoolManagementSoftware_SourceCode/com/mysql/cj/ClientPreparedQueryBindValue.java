package com.mysql.cj;

import java.io.InputStream;

public class ClientPreparedQueryBindValue
  implements BindValue
{
  protected boolean isNull;
  protected boolean isStream = false;
  protected MysqlType parameterType = MysqlType.NULL;
  public Object value;
  protected long streamLength;
  protected boolean isSet = false;
  
  public ClientPreparedQueryBindValue() {}
  
  public ClientPreparedQueryBindValue clone()
  {
    return new ClientPreparedQueryBindValue(this);
  }
  
  protected ClientPreparedQueryBindValue(ClientPreparedQueryBindValue copyMe)
  {
    isNull = isNull;
    isStream = isStream;
    parameterType = parameterType;
    if ((value != null) && ((value instanceof byte[])))
    {
      value = new byte[((byte[])value).length];
      System.arraycopy(value, 0, value, 0, ((byte[])value).length);
    }
    else
    {
      value = value;
    }
    streamLength = streamLength;
    isSet = isSet;
  }
  
  public void reset()
  {
    isNull = false;
    isStream = false;
    parameterType = MysqlType.NULL;
    value = null;
    streamLength = 0L;
    isSet = false;
  }
  
  public boolean isNull()
  {
    return isNull;
  }
  
  public void setNull(boolean isNull)
  {
    this.isNull = isNull;
    if (isNull) {
      parameterType = MysqlType.NULL;
    }
    isSet = true;
  }
  
  public boolean isStream()
  {
    return isStream;
  }
  
  public void setIsStream(boolean isStream)
  {
    this.isStream = isStream;
  }
  
  public MysqlType getMysqlType()
  {
    return parameterType;
  }
  
  public void setMysqlType(MysqlType type)
  {
    parameterType = type;
  }
  
  public byte[] getByteValue()
  {
    if ((value instanceof byte[])) {
      return (byte[])value;
    }
    return null;
  }
  
  public void setByteValue(byte[] parameterValue)
  {
    isNull = false;
    isStream = false;
    value = parameterValue;
    streamLength = 0L;
    isSet = true;
  }
  
  public InputStream getStreamValue()
  {
    if ((value instanceof InputStream)) {
      return (InputStream)value;
    }
    return null;
  }
  
  public void setStreamValue(InputStream parameterStream, long streamLength)
  {
    value = parameterStream;
    this.streamLength = streamLength;
    isSet = true;
  }
  
  public long getStreamLength()
  {
    return streamLength;
  }
  
  public void setStreamLength(long length)
  {
    streamLength = length;
  }
  
  public boolean isSet()
  {
    return isSet;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.ClientPreparedQueryBindValue
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */