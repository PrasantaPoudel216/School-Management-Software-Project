package com.mysql.cj;

public class SimpleQuery
  extends AbstractQuery
{
  public SimpleQuery(NativeSession sess)
  {
    super(sess);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.SimpleQuery
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */