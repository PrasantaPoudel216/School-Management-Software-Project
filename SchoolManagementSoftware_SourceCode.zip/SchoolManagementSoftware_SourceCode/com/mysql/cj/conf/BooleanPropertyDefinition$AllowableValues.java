package com.mysql.cj.conf;

public enum BooleanPropertyDefinition$AllowableValues
{
  TRUE(true),  FALSE(false),  YES(true),  NO(false);
  
  private boolean asBoolean;
  
  private BooleanPropertyDefinition$AllowableValues(boolean booleanValue)
  {
    asBoolean = booleanValue;
  }
  
  public boolean asBoolean()
  {
    return asBoolean;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.BooleanPropertyDefinition.AllowableValues
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */