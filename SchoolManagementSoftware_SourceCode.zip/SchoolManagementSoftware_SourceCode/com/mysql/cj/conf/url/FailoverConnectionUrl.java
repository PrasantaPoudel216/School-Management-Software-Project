package com.mysql.cj.conf.url;

import com.mysql.cj.conf.ConnectionUrl;
import com.mysql.cj.conf.ConnectionUrl.Type;
import com.mysql.cj.conf.ConnectionUrlParser;
import java.util.Properties;

public class FailoverConnectionUrl
  extends ConnectionUrl
{
  public FailoverConnectionUrl(ConnectionUrlParser connStrParser, Properties info)
  {
    super(connStrParser, info);
    type = ConnectionUrl.Type.FAILOVER_CONNECTION;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.url.FailoverConnectionUrl
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */