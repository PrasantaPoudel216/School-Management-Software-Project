package com.mysql.cj.conf;

public enum PropertyDefinitions$AuthMech
{
  PLAIN,  MYSQL41,  SHA256_MEMORY,  EXTERNAL;
  
  private PropertyDefinitions$AuthMech() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.PropertyDefinitions.AuthMech
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */