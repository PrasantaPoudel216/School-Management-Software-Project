package com.mysql.cj.conf;

public enum PropertyDefinitions$DatabaseTerm
{
  CATALOG,  SCHEMA;
  
  private PropertyDefinitions$DatabaseTerm() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.PropertyDefinitions.DatabaseTerm
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */