package com.mysql.cj.conf;

import java.util.Properties;

public abstract interface PropertySet
{
  public abstract void addProperty(RuntimeProperty<?> paramRuntimeProperty);
  
  public abstract void removeProperty(String paramString);
  
  public abstract void removeProperty(PropertyKey paramPropertyKey);
  
  public abstract <T> RuntimeProperty<T> getProperty(String paramString);
  
  public abstract <T> RuntimeProperty<T> getProperty(PropertyKey paramPropertyKey);
  
  public abstract RuntimeProperty<Boolean> getBooleanProperty(String paramString);
  
  public abstract RuntimeProperty<Boolean> getBooleanProperty(PropertyKey paramPropertyKey);
  
  public abstract RuntimeProperty<Integer> getIntegerProperty(String paramString);
  
  public abstract RuntimeProperty<Integer> getIntegerProperty(PropertyKey paramPropertyKey);
  
  public abstract RuntimeProperty<Long> getLongProperty(String paramString);
  
  public abstract RuntimeProperty<Long> getLongProperty(PropertyKey paramPropertyKey);
  
  public abstract RuntimeProperty<Integer> getMemorySizeProperty(String paramString);
  
  public abstract RuntimeProperty<Integer> getMemorySizeProperty(PropertyKey paramPropertyKey);
  
  public abstract RuntimeProperty<String> getStringProperty(String paramString);
  
  public abstract RuntimeProperty<String> getStringProperty(PropertyKey paramPropertyKey);
  
  public abstract <T extends Enum<T>> RuntimeProperty<T> getEnumProperty(String paramString);
  
  public abstract <T extends Enum<T>> RuntimeProperty<T> getEnumProperty(PropertyKey paramPropertyKey);
  
  public abstract void initializeProperties(Properties paramProperties);
  
  public abstract void postInitialization();
  
  public abstract Properties exposeAsProperties();
  
  public abstract void reset();
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.PropertySet
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */