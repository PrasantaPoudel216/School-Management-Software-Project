package com.mysql.cj.conf;

 enum ConnectionUrl$HostsCardinality$2
{
  ConnectionUrl$HostsCardinality$2()
  {
    super(paramString, paramInt, null);
  }
  
  public boolean assertSize(int n)
  {
    return n > 1;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.ConnectionUrl.HostsCardinality.2
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */