package com.mysql.cj.conf;

@FunctionalInterface
public abstract interface RuntimeProperty$RuntimePropertyListener
{
  public abstract void handlePropertyChange(RuntimeProperty<?> paramRuntimeProperty);
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.RuntimeProperty.RuntimePropertyListener
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */