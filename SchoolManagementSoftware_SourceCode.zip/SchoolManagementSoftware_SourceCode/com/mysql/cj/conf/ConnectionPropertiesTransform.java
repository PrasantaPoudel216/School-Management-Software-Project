package com.mysql.cj.conf;

import java.util.Properties;

public abstract interface ConnectionPropertiesTransform
{
  public abstract Properties transformProperties(Properties paramProperties);
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.ConnectionPropertiesTransform
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */