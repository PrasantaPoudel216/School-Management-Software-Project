package com.mysql.cj.conf;

public abstract interface DatabaseUrlContainer
{
  public abstract String getDatabaseUrl();
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.DatabaseUrlContainer
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */