package com.mysql.cj.conf;

public enum ConnectionUrl$HostsCardinality
{
  SINGLE,  MULTIPLE,  ONE_OR_MORE;
  
  private ConnectionUrl$HostsCardinality() {}
  
  public abstract boolean assertSize(int paramInt);
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.ConnectionUrl.HostsCardinality
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */