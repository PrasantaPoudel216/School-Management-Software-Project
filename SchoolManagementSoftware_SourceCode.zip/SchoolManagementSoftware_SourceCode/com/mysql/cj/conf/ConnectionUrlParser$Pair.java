package com.mysql.cj.conf;

public class ConnectionUrlParser$Pair<T, U>
{
  public final T left;
  public final U right;
  
  public ConnectionUrlParser$Pair(T left, U right)
  {
    this.left = left;
    this.right = right;
  }
  
  public String toString()
  {
    StringBuilder asStr = new StringBuilder(super.toString());
    asStr.append(String.format(" :: { left: %s, right: %s }", new Object[] { left, right }));
    return asStr.toString();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.ConnectionUrlParser.Pair
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */