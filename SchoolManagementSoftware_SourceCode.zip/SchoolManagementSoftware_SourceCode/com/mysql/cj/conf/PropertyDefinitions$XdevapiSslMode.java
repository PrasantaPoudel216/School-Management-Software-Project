package com.mysql.cj.conf;

public enum PropertyDefinitions$XdevapiSslMode
{
  REQUIRED,  VERIFY_CA,  VERIFY_IDENTITY,  DISABLED;
  
  private PropertyDefinitions$XdevapiSslMode() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.PropertyDefinitions.XdevapiSslMode
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */