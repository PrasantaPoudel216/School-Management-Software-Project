package com.mysql.cj.conf;

public enum PropertyDefinitions$ZeroDatetimeBehavior
{
  CONVERT_TO_NULL,  EXCEPTION,  ROUND;
  
  private PropertyDefinitions$ZeroDatetimeBehavior() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.PropertyDefinitions.ZeroDatetimeBehavior
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */