package com.mysql.cj.conf;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.UnsupportedConnectionStringException;

public enum ConnectionUrl$Type
{
  SINGLE_CONNECTION("jdbc:mysql:", ConnectionUrl.HostsCardinality.SINGLE),  FAILOVER_CONNECTION("jdbc:mysql:", ConnectionUrl.HostsCardinality.MULTIPLE),  LOADBALANCE_CONNECTION("jdbc:mysql:loadbalance:", ConnectionUrl.HostsCardinality.ONE_OR_MORE),  REPLICATION_CONNECTION("jdbc:mysql:replication:", ConnectionUrl.HostsCardinality.ONE_OR_MORE),  XDEVAPI_SESSION("mysqlx:", ConnectionUrl.HostsCardinality.ONE_OR_MORE);
  
  private String scheme;
  private ConnectionUrl.HostsCardinality cardinality;
  
  private ConnectionUrl$Type(String scheme, ConnectionUrl.HostsCardinality cardinality)
  {
    this.scheme = scheme;
    this.cardinality = cardinality;
  }
  
  public String getScheme()
  {
    return scheme;
  }
  
  public ConnectionUrl.HostsCardinality getCardinality()
  {
    return cardinality;
  }
  
  public static Type fromValue(String scheme, int n)
  {
    for (Type t : ) {
      if ((t.getScheme().equalsIgnoreCase(scheme)) && ((n < 0) || (t.getCardinality().assertSize(n)))) {
        return t;
      }
    }
    if (n < 0) {
      throw ((UnsupportedConnectionStringException)ExceptionFactory.createException(UnsupportedConnectionStringException.class, 
        Messages.getString("ConnectionString.5", new Object[] { scheme })));
    }
    throw ((UnsupportedConnectionStringException)ExceptionFactory.createException(UnsupportedConnectionStringException.class, 
      Messages.getString("ConnectionString.6", new Object[] { scheme, Integer.valueOf(n) })));
  }
  
  public static boolean isSupported(String scheme)
  {
    for (Type t : ) {
      if (t.getScheme().equalsIgnoreCase(scheme)) {
        return true;
      }
    }
    return false;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.ConnectionUrl.Type
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */