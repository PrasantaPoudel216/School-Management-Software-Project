package com.mysql.cj.conf;

import com.mysql.cj.exceptions.ExceptionInterceptor;
import java.util.Properties;
import javax.naming.Reference;

public class MemorySizeProperty
  extends IntegerProperty
{
  private static final long serialVersionUID = 4200558564320133284L;
  private String initialValueAsString;
  protected String valueAsString;
  
  protected MemorySizeProperty(PropertyDefinition<Integer> propertyDefinition)
  {
    super(propertyDefinition);
    valueAsString = ((Integer)propertyDefinition.getDefaultValue()).toString();
  }
  
  public void initializeFrom(Properties extractFrom, ExceptionInterceptor exceptionInterceptor)
  {
    super.initializeFrom(extractFrom, exceptionInterceptor);
    initialValueAsString = valueAsString;
  }
  
  public void initializeFrom(Reference ref, ExceptionInterceptor exceptionInterceptor)
  {
    super.initializeFrom(ref, exceptionInterceptor);
    initialValueAsString = valueAsString;
  }
  
  public String getStringValue()
  {
    return valueAsString;
  }
  
  public void setValueInternal(Integer value, String valueAsString, ExceptionInterceptor exceptionInterceptor)
  {
    super.setValueInternal(value, valueAsString, exceptionInterceptor);
    this.valueAsString = (valueAsString == null ? String.valueOf(value.intValue()) : valueAsString);
  }
  
  public void resetValue()
  {
    value = initialValue;
    valueAsString = initialValueAsString;
    invokeListeners();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.MemorySizeProperty
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */