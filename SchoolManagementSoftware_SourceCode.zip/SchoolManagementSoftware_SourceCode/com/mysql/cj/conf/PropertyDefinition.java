package com.mysql.cj.conf;

import com.mysql.cj.exceptions.ExceptionInterceptor;

public abstract interface PropertyDefinition<T>
{
  public abstract boolean hasValueConstraints();
  
  public abstract boolean isRangeBased();
  
  public abstract PropertyKey getPropertyKey();
  
  public abstract String getName();
  
  public abstract String getCcAlias();
  
  public abstract boolean hasCcAlias();
  
  public abstract T getDefaultValue();
  
  public abstract boolean isRuntimeModifiable();
  
  public abstract String getDescription();
  
  public abstract String getSinceVersion();
  
  public abstract String getCategory();
  
  public abstract int getOrder();
  
  public abstract String[] getAllowableValues();
  
  public abstract int getLowerBound();
  
  public abstract int getUpperBound();
  
  public abstract T parseObject(String paramString, ExceptionInterceptor paramExceptionInterceptor);
  
  public abstract RuntimeProperty<T> createRuntimeProperty();
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.PropertyDefinition
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */