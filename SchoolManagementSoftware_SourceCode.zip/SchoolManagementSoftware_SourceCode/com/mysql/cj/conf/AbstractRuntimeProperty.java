package com.mysql.cj.conf;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.PropertyNotModifiableException;
import java.io.Serializable;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import javax.naming.RefAddr;
import javax.naming.Reference;

public abstract class AbstractRuntimeProperty<T>
  implements RuntimeProperty<T>, Serializable
{
  private static final long serialVersionUID = -3424722534876438236L;
  private PropertyDefinition<T> propertyDefinition;
  protected T value;
  protected T initialValue;
  protected boolean wasExplicitlySet = false;
  private List<WeakReference<RuntimeProperty.RuntimePropertyListener>> listeners;
  
  public AbstractRuntimeProperty() {}
  
  protected AbstractRuntimeProperty(PropertyDefinition<T> propertyDefinition)
  {
    this.propertyDefinition = propertyDefinition;
    value = propertyDefinition.getDefaultValue();
    initialValue = propertyDefinition.getDefaultValue();
  }
  
  public PropertyDefinition<T> getPropertyDefinition()
  {
    return propertyDefinition;
  }
  
  public void initializeFrom(Properties extractFrom, ExceptionInterceptor exceptionInterceptor)
  {
    String name = getPropertyDefinition().getName();
    String alias = getPropertyDefinition().getCcAlias();
    if (extractFrom.containsKey(name))
    {
      String extractedValue = (String)extractFrom.remove(name);
      if (extractedValue != null)
      {
        setValueInternal(extractedValue, exceptionInterceptor);
        initialValue = value;
      }
    }
    else if ((alias != null) && (extractFrom.containsKey(alias)))
    {
      String extractedValue = (String)extractFrom.remove(alias);
      if (extractedValue != null)
      {
        setValueInternal(extractedValue, exceptionInterceptor);
        initialValue = value;
      }
    }
  }
  
  public void initializeFrom(Reference ref, ExceptionInterceptor exceptionInterceptor)
  {
    RefAddr refAddr = ref.get(getPropertyDefinition().getName());
    if (refAddr != null)
    {
      String refContentAsString = (String)refAddr.getContent();
      if (refContentAsString != null)
      {
        setValueInternal(refContentAsString, exceptionInterceptor);
        initialValue = value;
      }
    }
  }
  
  public void resetValue()
  {
    value = initialValue;
    invokeListeners();
  }
  
  public boolean isExplicitlySet()
  {
    return wasExplicitlySet;
  }
  
  public void addListener(RuntimeProperty.RuntimePropertyListener l)
  {
    if (listeners == null) {
      listeners = new ArrayList();
    }
    boolean found = false;
    for (WeakReference<RuntimeProperty.RuntimePropertyListener> weakReference : listeners) {
      if (l.equals(weakReference.get()))
      {
        found = true;
        break;
      }
    }
    if (!found) {
      listeners.add(new WeakReference(l));
    }
  }
  
  public void removeListener(RuntimeProperty.RuntimePropertyListener listener)
  {
    if (listeners != null) {
      for (WeakReference<RuntimeProperty.RuntimePropertyListener> wr : listeners)
      {
        RuntimeProperty.RuntimePropertyListener l = (RuntimeProperty.RuntimePropertyListener)wr.get();
        if (l.equals(listener))
        {
          listeners.remove(wr);
          break;
        }
      }
    }
  }
  
  protected void invokeListeners()
  {
    if (listeners != null) {
      for (WeakReference<RuntimeProperty.RuntimePropertyListener> wr : listeners)
      {
        RuntimeProperty.RuntimePropertyListener l = (RuntimeProperty.RuntimePropertyListener)wr.get();
        if (l != null) {
          l.handlePropertyChange(this);
        } else {
          listeners.remove(wr);
        }
      }
    }
  }
  
  public T getValue()
  {
    return (T)value;
  }
  
  public T getInitialValue()
  {
    return (T)initialValue;
  }
  
  public String getStringValue()
  {
    return value == null ? null : value.toString();
  }
  
  public void setValueInternal(String value, ExceptionInterceptor exceptionInterceptor)
  {
    setValueInternal(getPropertyDefinition().parseObject(value, exceptionInterceptor), value, exceptionInterceptor);
  }
  
  public void setValueInternal(T value, String valueAsString, ExceptionInterceptor exceptionInterceptor)
  {
    if (getPropertyDefinition().isRangeBased()) {
      checkRange(value, valueAsString, exceptionInterceptor);
    }
    this.value = value;
    wasExplicitlySet = true;
  }
  
  protected void checkRange(T val, String valueAsString, ExceptionInterceptor exceptionInterceptor) {}
  
  public void setValue(T value)
  {
    setValue(value, null);
  }
  
  public void setValue(T value, ExceptionInterceptor exceptionInterceptor)
  {
    if (getPropertyDefinition().isRuntimeModifiable())
    {
      setValueInternal(value, null, exceptionInterceptor);
      invokeListeners();
    }
    else
    {
      throw ((PropertyNotModifiableException)ExceptionFactory.createException(PropertyNotModifiableException.class, 
        Messages.getString("ConnectionProperties.dynamicChangeIsNotAllowed", new Object[] {"'" + getPropertyDefinition().getName() + "'" })));
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.AbstractRuntimeProperty
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */