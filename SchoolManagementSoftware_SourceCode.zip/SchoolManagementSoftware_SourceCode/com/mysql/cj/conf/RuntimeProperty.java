package com.mysql.cj.conf;

import com.mysql.cj.exceptions.ExceptionInterceptor;
import java.util.Properties;
import javax.naming.Reference;

public abstract interface RuntimeProperty<T>
{
  public abstract PropertyDefinition<T> getPropertyDefinition();
  
  public abstract void initializeFrom(Properties paramProperties, ExceptionInterceptor paramExceptionInterceptor);
  
  public abstract void initializeFrom(Reference paramReference, ExceptionInterceptor paramExceptionInterceptor);
  
  public abstract void resetValue();
  
  public abstract boolean isExplicitlySet();
  
  public abstract void addListener(RuntimePropertyListener paramRuntimePropertyListener);
  
  public abstract void removeListener(RuntimePropertyListener paramRuntimePropertyListener);
  
  public abstract T getValue();
  
  public abstract T getInitialValue();
  
  public abstract String getStringValue();
  
  public abstract void setValue(T paramT);
  
  public abstract void setValue(T paramT, ExceptionInterceptor paramExceptionInterceptor);
  
  @FunctionalInterface
  public static abstract interface RuntimePropertyListener
  {
    public abstract void handlePropertyChange(RuntimeProperty<?> paramRuntimeProperty);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.RuntimeProperty
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */