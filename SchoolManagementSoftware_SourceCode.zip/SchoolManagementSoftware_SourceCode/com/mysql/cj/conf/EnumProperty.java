package com.mysql.cj.conf;

public class EnumProperty<T extends Enum<T>>
  extends AbstractRuntimeProperty<T>
{
  private static final long serialVersionUID = -60853080911910124L;
  
  protected EnumProperty(PropertyDefinition<T> propertyDefinition)
  {
    super(propertyDefinition);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.conf.EnumProperty
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */