package com.mysql.cj;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.a.NativeConstants.IntegerDataType;
import com.mysql.cj.protocol.a.NativeConstants.StringLengthDataType;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.protocol.a.NativeProtocol;
import com.mysql.cj.util.StringUtils;
import com.mysql.cj.util.Util;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public abstract class AbstractPreparedQuery<T extends QueryBindings<?>>
  extends AbstractQuery
  implements PreparedQuery<T>
{
  protected ParseInfo parseInfo;
  protected T queryBindings = null;
  protected String originalSql = null;
  protected int parameterCount;
  protected RuntimeProperty<Boolean> autoClosePStmtStreams;
  protected int batchCommandIndex = -1;
  protected RuntimeProperty<Boolean> useStreamLengthsInPrepStmts;
  private byte[] streamConvertBuf = null;
  private boolean usingAnsiMode;
  
  public AbstractPreparedQuery(NativeSession sess)
  {
    super(sess);
    
    autoClosePStmtStreams = session.getPropertySet().getBooleanProperty(PropertyKey.autoClosePStmtStreams);
    useStreamLengthsInPrepStmts = session.getPropertySet().getBooleanProperty(PropertyKey.useStreamLengthsInPrepStmts);
    usingAnsiMode = (!session.getServerSession().useAnsiQuotedIdentifiers());
  }
  
  public void closeQuery()
  {
    streamConvertBuf = null;
    super.closeQuery();
  }
  
  public ParseInfo getParseInfo()
  {
    return parseInfo;
  }
  
  public void setParseInfo(ParseInfo parseInfo)
  {
    this.parseInfo = parseInfo;
  }
  
  public String getOriginalSql()
  {
    return originalSql;
  }
  
  public void setOriginalSql(String originalSql)
  {
    this.originalSql = originalSql;
  }
  
  public int getParameterCount()
  {
    return parameterCount;
  }
  
  public void setParameterCount(int parameterCount)
  {
    this.parameterCount = parameterCount;
  }
  
  public T getQueryBindings()
  {
    return queryBindings;
  }
  
  public void setQueryBindings(T queryBindings)
  {
    this.queryBindings = queryBindings;
  }
  
  public int getBatchCommandIndex()
  {
    return batchCommandIndex;
  }
  
  public void setBatchCommandIndex(int batchCommandIndex)
  {
    this.batchCommandIndex = batchCommandIndex;
  }
  
  public int computeBatchSize(int numBatchedArgs)
  {
    long[] combinedValues = computeMaxParameterSetSizeAndBatchSize(numBatchedArgs);
    
    long maxSizeOfParameterSet = combinedValues[0];
    long sizeOfEntireBatch = combinedValues[1];
    if (sizeOfEntireBatch < ((Integer)maxAllowedPacket.getValue()).intValue() - originalSql.length()) {
      return numBatchedArgs;
    }
    return (int)Math.max(1L, (((Integer)maxAllowedPacket.getValue()).intValue() - originalSql.length()) / maxSizeOfParameterSet);
  }
  
  public void checkNullOrEmptyQuery(String sql)
  {
    if (sql == null) {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("PreparedQuery.0"), session.getExceptionInterceptor()));
    }
    if (sql.length() == 0) {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("PreparedQuery.1"), session.getExceptionInterceptor()));
    }
  }
  
  public String asSql()
  {
    return asSql(false);
  }
  
  public String asSql(boolean quoteStreamsAndUnknowns)
  {
    StringBuilder buf = new StringBuilder();
    
    Object batchArg = null;
    if (batchCommandIndex != -1) {
      batchArg = batchedArgs.get(batchCommandIndex);
    }
    byte[][] staticSqlStrings = parseInfo.getStaticSql();
    for (int i = 0; i < parameterCount; i++)
    {
      buf.append(charEncoding != null ? StringUtils.toString(staticSqlStrings[i], charEncoding) : StringUtils.toString(staticSqlStrings[i]));
      
      byte[] val = null;
      if ((batchArg != null) && ((batchArg instanceof String)))
      {
        buf.append((String)batchArg);
      }
      else
      {
        val = batchCommandIndex == -1 ? queryBindings.getBindValues()[i].getByteValue() : queryBindings == null ? null : ((QueryBindings)batchArg).getBindValues()[i].getByteValue();
        
        boolean isStreamParam = batchCommandIndex == -1 ? queryBindings.getBindValues()[i].isStream() : queryBindings == null ? false : ((QueryBindings)batchArg).getBindValues()[i].isStream();
        if ((val == null) && (!isStreamParam)) {
          buf.append(quoteStreamsAndUnknowns ? "'** NOT SPECIFIED **'" : "** NOT SPECIFIED **");
        } else if (isStreamParam) {
          buf.append(quoteStreamsAndUnknowns ? "'** STREAM DATA **'" : "** STREAM DATA **");
        } else {
          buf.append(StringUtils.toString(val, charEncoding));
        }
      }
    }
    buf.append(charEncoding != null ? StringUtils.toString(staticSqlStrings[parameterCount], charEncoding) : 
      StringUtils.toAsciiString(staticSqlStrings[parameterCount]));
    
    return buf.toString();
  }
  
  protected abstract long[] computeMaxParameterSetSizeAndBatchSize(int paramInt);
  
  /* Error */
  public <M extends Message> M fillSendPacket()
  {
    // Byte code:
    //   0: aload_0
    //   1: dup
    //   2: astore_1
    //   3: monitorenter
    //   4: aload_0
    //   5: aload_0
    //   6: getfield 2	com/mysql/cj/AbstractPreparedQuery:queryBindings	Lcom/mysql/cj/QueryBindings;
    //   9: invokevirtual 53	com/mysql/cj/AbstractPreparedQuery:fillSendPacket	(Lcom/mysql/cj/QueryBindings;)Lcom/mysql/cj/protocol/Message;
    //   12: aload_1
    //   13: monitorexit
    //   14: areturn
    //   15: astore_2
    //   16: aload_1
    //   17: monitorexit
    //   18: aload_2
    //   19: athrow
    // Line number table:
    //   Java source line #219	-> byte code offset #0
    //   Java source line #220	-> byte code offset #4
    //   Java source line #221	-> byte code offset #15
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	20	0	this	AbstractPreparedQuery<T>
    //   2	15	1	Ljava/lang/Object;	Object
    //   15	4	2	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   4	14	15	finally
    //   15	18	15	finally
  }
  
  public <M extends Message> M fillSendPacket(QueryBindings<?> bindings)
  {
    synchronized (this)
    {
      BindValue[] bindValues = bindings.getBindValues();
      
      NativePacketPayload sendPacket = session.getSharedSendPacket();
      
      sendPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 3L);
      
      boolean useStreamLengths = ((Boolean)useStreamLengthsInPrepStmts.getValue()).booleanValue();
      
      int ensurePacketSize = 0;
      
      String statementComment = session.getProtocol().getQueryComment();
      
      byte[] commentAsBytes = null;
      if (statementComment != null)
      {
        commentAsBytes = StringUtils.getBytes(statementComment, charEncoding);
        
        ensurePacketSize += commentAsBytes.length;
        ensurePacketSize += 6;
      }
      for (int i = 0; i < bindValues.length; i++) {
        if ((bindValues[i].isStream()) && (useStreamLengths)) {
          ensurePacketSize = (int)(ensurePacketSize + bindValues[i].getStreamLength());
        }
      }
      if (ensurePacketSize != 0) {
        sendPacket.ensureCapacity(ensurePacketSize);
      }
      if (commentAsBytes != null)
      {
        sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, Constants.SLASH_STAR_SPACE_AS_BYTES);
        sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, commentAsBytes);
        sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
      }
      byte[][] staticSqlStrings = parseInfo.getStaticSql();
      for (int i = 0; i < bindValues.length; i++)
      {
        bindings.checkParameterSet(i);
        
        sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, staticSqlStrings[i]);
        if (bindValues[i].isStream()) {
          streamToBytes(sendPacket, bindValues[i].getStreamValue(), true, bindValues[i].getStreamLength(), useStreamLengths);
        } else {
          sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, bindValues[i].getByteValue());
        }
      }
      sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, staticSqlStrings[bindValues.length]);
      
      return sendPacket;
    }
  }
  
  private final void streamToBytes(NativePacketPayload packet, InputStream in, boolean escape, long streamLength, boolean useLength)
  {
    try
    {
      if (streamConvertBuf == null) {
        streamConvertBuf = new byte['?'];
      }
      boolean hexEscape = session.getServerSession().isNoBackslashEscapesSet();
      if (streamLength == -1L) {
        useLength = false;
      }
      int bc = useLength ? Util.readBlock(in, streamConvertBuf, (int)streamLength, session.getExceptionInterceptor()) : Util.readBlock(in, streamConvertBuf, session.getExceptionInterceptor());
      
      int lengthLeftToRead = (int)streamLength - bc;
      
      packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, StringUtils.getBytes(hexEscape ? "x" : "_binary"));
      if (escape) {
        packet.writeInteger(NativeConstants.IntegerDataType.INT1, 39L);
      }
      while (bc > 0)
      {
        if (hexEscape) {
          ((AbstractQueryBindings)queryBindings).hexEscapeBlock(streamConvertBuf, packet, bc);
        } else if (escape) {
          escapeblockFast(streamConvertBuf, packet, bc);
        } else {
          packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, streamConvertBuf, 0, bc);
        }
        if (useLength)
        {
          bc = Util.readBlock(in, streamConvertBuf, lengthLeftToRead, session.getExceptionInterceptor());
          if (bc > 0) {
            lengthLeftToRead -= bc;
          }
        }
        else
        {
          bc = Util.readBlock(in, streamConvertBuf, session.getExceptionInterceptor());
        }
      }
      if (escape) {
        packet.writeInteger(NativeConstants.IntegerDataType.INT1, 39L);
      }
    }
    finally
    {
      if (((Boolean)autoClosePStmtStreams.getValue()).booleanValue())
      {
        try
        {
          in.close();
        }
        catch (IOException localIOException1) {}
        in = null;
      }
    }
  }
  
  private final void escapeblockFast(byte[] buf, NativePacketPayload packet, int size)
  {
    int lastwritten = 0;
    for (int i = 0; i < size; i++)
    {
      byte b = buf[i];
      if (b == 0)
      {
        if (i > lastwritten) {
          packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, buf, lastwritten, i - lastwritten);
        }
        packet.writeInteger(NativeConstants.IntegerDataType.INT1, 92L);
        packet.writeInteger(NativeConstants.IntegerDataType.INT1, 48L);
        lastwritten = i + 1;
      }
      else if ((b == 92) || (b == 39) || ((!usingAnsiMode) && (b == 34)))
      {
        if (i > lastwritten) {
          packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, buf, lastwritten, i - lastwritten);
        }
        packet.writeInteger(NativeConstants.IntegerDataType.INT1, 92L);
        lastwritten = i;
      }
    }
    if (lastwritten < size) {
      packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, buf, lastwritten, size - lastwritten);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.AbstractPreparedQuery
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */