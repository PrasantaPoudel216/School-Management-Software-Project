package com.mysql.cj;

import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.Resultset.Type;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract interface Query
{
  public abstract int getId();
  
  public abstract void setCancelStatus(CancelStatus paramCancelStatus);
  
  public abstract void checkCancelTimeout();
  
  public abstract <T extends Resultset, M extends Message> ProtocolEntityFactory<T, M> getResultSetFactory();
  
  public abstract Session getSession();
  
  public abstract Object getCancelTimeoutMutex();
  
  public abstract void resetCancelledState();
  
  public abstract void closeQuery();
  
  public abstract void addBatch(Object paramObject);
  
  public abstract List<Object> getBatchedArgs();
  
  public abstract void clearBatchedArgs();
  
  public abstract int getResultFetchSize();
  
  public abstract void setResultFetchSize(int paramInt);
  
  public abstract Resultset.Type getResultType();
  
  public abstract void setResultType(Resultset.Type paramType);
  
  public abstract int getTimeoutInMillis();
  
  public abstract void setTimeoutInMillis(int paramInt);
  
  public abstract CancelQueryTask startQueryTimer(Query paramQuery, int paramInt);
  
  public abstract AtomicBoolean getStatementExecuting();
  
  public abstract String getCurrentDatabase();
  
  public abstract void setCurrentDatabase(String paramString);
  
  public abstract boolean isClearWarningsCalled();
  
  public abstract void setClearWarningsCalled(boolean paramBoolean);
  
  public abstract void statementBegins();
  
  public abstract void stopQueryTimer(CancelQueryTask paramCancelQueryTask, boolean paramBoolean1, boolean paramBoolean2);
  
  public static enum CancelStatus
  {
    NOT_CANCELED,  CANCELED_BY_USER,  CANCELED_BY_TIMEOUT;
    
    private CancelStatus() {}
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.Query
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */