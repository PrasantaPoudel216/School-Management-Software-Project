package com.mysql.cj;

import com.mysql.cj.protocol.Message;
import java.util.List;

public abstract interface MessageBuilder<M extends Message>
{
  public abstract M buildSqlStatement(String paramString);
  
  public abstract M buildSqlStatement(String paramString, List<Object> paramList);
  
  public abstract M buildClose();
}

/* Location:
 * Qualified Name:     com.mysql.cj.MessageBuilder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */