package com.mysql.cj;

import java.io.InputStream;

public abstract interface BindValue
{
  public abstract BindValue clone();
  
  public abstract void reset();
  
  public abstract boolean isNull();
  
  public abstract void setNull(boolean paramBoolean);
  
  public abstract boolean isStream();
  
  public abstract void setIsStream(boolean paramBoolean);
  
  public abstract MysqlType getMysqlType();
  
  public abstract void setMysqlType(MysqlType paramMysqlType);
  
  public abstract byte[] getByteValue();
  
  public abstract void setByteValue(byte[] paramArrayOfByte);
  
  public abstract InputStream getStreamValue();
  
  public abstract void setStreamValue(InputStream paramInputStream, long paramLong);
  
  public abstract long getStreamLength();
  
  public abstract void setStreamLength(long paramLong);
  
  public abstract boolean isSet();
}

/* Location:
 * Qualified Name:     com.mysql.cj.BindValue
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */