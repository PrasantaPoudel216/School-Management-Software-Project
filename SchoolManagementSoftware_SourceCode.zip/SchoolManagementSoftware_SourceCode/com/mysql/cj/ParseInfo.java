package com.mysql.cj;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.util.StringUtils;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

public class ParseInfo
{
  protected static final String[] ON_DUPLICATE_KEY_UPDATE_CLAUSE = { "ON", "DUPLICATE", "KEY", "UPDATE" };
  private char firstStmtChar = '\000';
  private boolean foundLoadData = false;
  long lastUsed = 0L;
  int statementLength = 0;
  int statementStartPos = 0;
  boolean canRewriteAsMultiValueInsert = false;
  byte[][] staticSql = (byte[][])null;
  boolean hasPlaceholders = false;
  public int numberOfQueries = 1;
  boolean isOnDuplicateKeyUpdate = false;
  int locationOfOnDuplicateKeyUpdate = -1;
  String valuesClause;
  boolean parametersInDuplicateKeyClause = false;
  String charEncoding;
  private ParseInfo batchHead;
  private ParseInfo batchValues;
  private ParseInfo batchODKUClause;
  
  private ParseInfo(byte[][] staticSql, char firstStmtChar, boolean foundLoadData, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementLength, int statementStartPos)
  {
    this.firstStmtChar = firstStmtChar;
    this.foundLoadData = foundLoadData;
    this.isOnDuplicateKeyUpdate = isOnDuplicateKeyUpdate;
    this.locationOfOnDuplicateKeyUpdate = locationOfOnDuplicateKeyUpdate;
    this.statementLength = statementLength;
    this.statementStartPos = statementStartPos;
    this.staticSql = staticSql;
  }
  
  public ParseInfo(String sql, Session session, String encoding)
  {
    this(sql, session, encoding, true);
  }
  
  public ParseInfo(String sql, Session session, String encoding, boolean buildRewriteInfo)
  {
    try
    {
      if (sql == null) {
        throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("PreparedStatement.61"), session
          .getExceptionInterceptor()));
      }
      charEncoding = encoding;
      lastUsed = System.currentTimeMillis();
      
      String quotedIdentifierString = session.getIdentifierQuoteString();
      
      char quotedIdentifierChar = '\000';
      if ((quotedIdentifierString != null) && (!quotedIdentifierString.equals(" ")) && (quotedIdentifierString.length() > 0)) {
        quotedIdentifierChar = quotedIdentifierString.charAt(0);
      }
      statementLength = sql.length();
      
      ArrayList<int[]> endpointList = new ArrayList();
      boolean inQuotes = false;
      char quoteChar = '\000';
      boolean inQuotedId = false;
      int lastParmEnd = 0;
      
      boolean noBackslashEscapes = session.getServerSession().isNoBackslashEscapesSet();
      
      statementStartPos = findStartOfStatement(sql);
      for (int i = statementStartPos; i < statementLength; i++)
      {
        char c = sql.charAt(i);
        if ((firstStmtChar == 0) && (Character.isLetter(c)))
        {
          firstStmtChar = Character.toUpperCase(c);
          if (firstStmtChar == 'I')
          {
            locationOfOnDuplicateKeyUpdate = getOnDuplicateKeyLocation(sql, 
              ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.dontCheckOnDuplicateKeyUpdateInSQL).getValue()).booleanValue(), 
              ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.rewriteBatchedStatements).getValue()).booleanValue(), session
              .getServerSession().isNoBackslashEscapesSet());
            isOnDuplicateKeyUpdate = (locationOfOnDuplicateKeyUpdate != -1);
          }
        }
        if ((!noBackslashEscapes) && (c == '\\') && (i < statementLength - 1))
        {
          i++;
        }
        else
        {
          if ((!inQuotes) && (quotedIdentifierChar != 0) && (c == quotedIdentifierChar)) {
            inQuotedId = !inQuotedId;
          } else if (!inQuotedId) {
            if (inQuotes)
            {
              if (((c == '\'') || (c == '"')) && (c == quoteChar))
              {
                if ((i < statementLength - 1) && (sql.charAt(i + 1) == quoteChar))
                {
                  i++;
                  continue;
                }
                inQuotes = !inQuotes;
                quoteChar = '\000';
              }
              else if (((c == '\'') || (c == '"')) && (c == quoteChar))
              {
                inQuotes = !inQuotes;
                quoteChar = '\000';
              }
            }
            else
            {
              if ((c == '#') || ((c == '-') && (i + 1 < statementLength) && (sql.charAt(i + 1) == '-')))
              {
                int endOfStmt = statementLength - 1;
                for (; i < endOfStmt; i++)
                {
                  c = sql.charAt(i);
                  if ((c == '\r') || (c == '\n')) {
                    break;
                  }
                }
              }
              if ((c == '/') && (i + 1 < statementLength))
              {
                char cNext = sql.charAt(i + 1);
                if (cNext == '*')
                {
                  i += 2;
                  for (int j = i; j < statementLength; j++)
                  {
                    i++;
                    cNext = sql.charAt(j);
                    if ((cNext == '*') && (j + 1 < statementLength) && 
                      (sql.charAt(j + 1) == '/'))
                    {
                      i++;
                      if (i >= statementLength) {
                        break;
                      }
                      c = sql.charAt(i); break;
                    }
                  }
                }
              }
              else if ((c == '\'') || (c == '"'))
              {
                inQuotes = true;
                quoteChar = c;
              }
            }
          }
          if ((!inQuotes) && (!inQuotedId)) {
            if (c == '?')
            {
              endpointList.add(new int[] { lastParmEnd, i });
              lastParmEnd = i + 1;
              if ((isOnDuplicateKeyUpdate) && (i > locationOfOnDuplicateKeyUpdate)) {
                parametersInDuplicateKeyClause = true;
              }
            }
            else if (c == ';')
            {
              int j = i + 1;
              if (j < statementLength)
              {
                for (; j < statementLength; j++) {
                  if (!Character.isWhitespace(sql.charAt(j))) {
                    break;
                  }
                }
                if (j < statementLength) {
                  numberOfQueries += 1;
                }
                i = j - 1;
              }
            }
          }
        }
      }
      if (firstStmtChar == 'L')
      {
        if (StringUtils.startsWithIgnoreCaseAndWs(sql, "LOAD DATA")) {
          foundLoadData = true;
        } else {
          foundLoadData = false;
        }
      }
      else {
        foundLoadData = false;
      }
      endpointList.add(new int[] { lastParmEnd, statementLength });
      staticSql = new byte[endpointList.size()][];
      hasPlaceholders = (staticSql.length > 1);
      for (i = 0; i < staticSql.length; i++)
      {
        int[] ep = (int[])endpointList.get(i);
        int end = ep[1];
        int begin = ep[0];
        int len = end - begin;
        if (foundLoadData)
        {
          staticSql[i] = StringUtils.getBytes(sql, begin, len);
        }
        else if (encoding == null)
        {
          byte[] buf = new byte[len];
          for (int j = 0; j < len; j++) {
            buf[j] = ((byte)sql.charAt(begin + j));
          }
          staticSql[i] = buf;
        }
        else
        {
          staticSql[i] = StringUtils.getBytes(sql, begin, len, encoding);
        }
      }
    }
    catch (StringIndexOutOfBoundsException oobEx)
    {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("PreparedStatement.62", new Object[] { sql }), oobEx, session
        .getExceptionInterceptor()));
    }
    if (buildRewriteInfo)
    {
      canRewriteAsMultiValueInsert = ((numberOfQueries == 1) && (!parametersInDuplicateKeyClause) && (canRewrite(sql, isOnDuplicateKeyUpdate, locationOfOnDuplicateKeyUpdate, statementStartPos)));
      if ((canRewriteAsMultiValueInsert) && (((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.rewriteBatchedStatements).getValue()).booleanValue())) {
        buildRewriteBatchedParams(sql, session, encoding);
      }
    }
  }
  
  public byte[][] getStaticSql()
  {
    return staticSql;
  }
  
  public String getValuesClause()
  {
    return valuesClause;
  }
  
  public int getLocationOfOnDuplicateKeyUpdate()
  {
    return locationOfOnDuplicateKeyUpdate;
  }
  
  public boolean canRewriteAsMultiValueInsertAtSqlLevel()
  {
    return canRewriteAsMultiValueInsert;
  }
  
  public boolean containsOnDuplicateKeyUpdateInSQL()
  {
    return isOnDuplicateKeyUpdate;
  }
  
  private void buildRewriteBatchedParams(String sql, Session session, String encoding)
  {
    valuesClause = extractValuesClause(sql, session.getIdentifierQuoteString());
    String odkuClause = isOnDuplicateKeyUpdate ? sql.substring(locationOfOnDuplicateKeyUpdate) : null;
    
    String headSql = null;
    if (isOnDuplicateKeyUpdate) {
      headSql = sql.substring(0, locationOfOnDuplicateKeyUpdate);
    } else {
      headSql = sql;
    }
    batchHead = new ParseInfo(headSql, session, encoding, false);
    batchValues = new ParseInfo("," + valuesClause, session, encoding, false);
    batchODKUClause = null;
    if ((odkuClause != null) && (odkuClause.length() > 0)) {
      batchODKUClause = new ParseInfo("," + valuesClause + " " + odkuClause, session, encoding, false);
    }
  }
  
  private String extractValuesClause(String sql, String quoteCharStr)
  {
    int indexOfValues = -1;
    int valuesSearchStart = statementStartPos;
    while (indexOfValues == -1)
    {
      if (quoteCharStr.length() > 0) {
        indexOfValues = StringUtils.indexOfIgnoreCase(valuesSearchStart, sql, "VALUES", quoteCharStr, quoteCharStr, StringUtils.SEARCH_MODE__MRK_COM_WS);
      } else {
        indexOfValues = StringUtils.indexOfIgnoreCase(valuesSearchStart, sql, "VALUES");
      }
      if (indexOfValues <= 0) {
        break;
      }
      char c = sql.charAt(indexOfValues - 1);
      if ((!Character.isWhitespace(c)) && (c != ')') && (c != '`'))
      {
        valuesSearchStart = indexOfValues + 6;
        indexOfValues = -1;
      }
      else
      {
        c = sql.charAt(indexOfValues + 6);
        if ((!Character.isWhitespace(c)) && (c != '('))
        {
          valuesSearchStart = indexOfValues + 6;
          indexOfValues = -1;
        }
      }
    }
    if (indexOfValues == -1) {
      return null;
    }
    int indexOfFirstParen = sql.indexOf('(', indexOfValues + 6);
    if (indexOfFirstParen == -1) {
      return null;
    }
    int endOfValuesClause = isOnDuplicateKeyUpdate ? locationOfOnDuplicateKeyUpdate : sql.length();
    
    return sql.substring(indexOfFirstParen, endOfValuesClause);
  }
  
  public synchronized ParseInfo getParseInfoForBatch(int numBatch)
  {
    AppendingBatchVisitor apv = new AppendingBatchVisitor();
    buildInfoForBatch(numBatch, apv);
    
    ParseInfo batchParseInfo = new ParseInfo(apv.getStaticSqlStrings(), firstStmtChar, foundLoadData, isOnDuplicateKeyUpdate, locationOfOnDuplicateKeyUpdate, statementLength, statementStartPos);
    
    return batchParseInfo;
  }
  
  public String getSqlForBatch(int numBatch)
    throws UnsupportedEncodingException
  {
    ParseInfo batchInfo = getParseInfoForBatch(numBatch);
    
    return batchInfo.getSqlForBatch();
  }
  
  public String getSqlForBatch()
    throws UnsupportedEncodingException
  {
    int size = 0;
    byte[][] sqlStrings = staticSql;
    int sqlStringsLength = sqlStrings.length;
    for (int i = 0; i < sqlStringsLength; i++)
    {
      size += sqlStrings[i].length;
      size++;
    }
    StringBuilder buf = new StringBuilder(size);
    for (int i = 0; i < sqlStringsLength - 1; i++)
    {
      buf.append(StringUtils.toString(sqlStrings[i], charEncoding));
      buf.append("?");
    }
    buf.append(StringUtils.toString(sqlStrings[(sqlStringsLength - 1)]));
    
    return buf.toString();
  }
  
  private void buildInfoForBatch(int numBatch, BatchVisitor visitor)
  {
    if (!hasPlaceholders)
    {
      if (numBatch == 1)
      {
        visitor.append(staticSql[0]);
        
        return;
      }
      byte[] headStaticSql = batchHead.staticSql[0];
      visitor.append(headStaticSql).increment();
      
      int numValueRepeats = numBatch - 1;
      if (batchODKUClause != null) {
        numValueRepeats--;
      }
      byte[] valuesStaticSql = batchValues.staticSql[0];
      for (int i = 0; i < numValueRepeats; i++) {
        visitor.mergeWithLast(valuesStaticSql).increment();
      }
      if (batchODKUClause != null)
      {
        byte[] batchOdkuStaticSql = batchODKUClause.staticSql[0];
        visitor.mergeWithLast(batchOdkuStaticSql).increment();
      }
      return;
    }
    byte[][] headStaticSql = batchHead.staticSql;
    int headStaticSqlLength = headStaticSql.length;
    byte[] endOfHead = headStaticSql[(headStaticSqlLength - 1)];
    for (int i = 0; i < headStaticSqlLength - 1; i++) {
      visitor.append(headStaticSql[i]).increment();
    }
    int numValueRepeats = numBatch - 1;
    if (batchODKUClause != null) {
      numValueRepeats--;
    }
    byte[][] valuesStaticSql = batchValues.staticSql;
    int valuesStaticSqlLength = valuesStaticSql.length;
    byte[] beginOfValues = valuesStaticSql[0];
    byte[] endOfValues = valuesStaticSql[(valuesStaticSqlLength - 1)];
    for (int i = 0; i < numValueRepeats; i++)
    {
      visitor.merge(endOfValues, beginOfValues).increment();
      for (int j = 1; j < valuesStaticSqlLength - 1; j++) {
        visitor.append(valuesStaticSql[j]).increment();
      }
    }
    if (batchODKUClause != null)
    {
      byte[][] batchOdkuStaticSql = batchODKUClause.staticSql;
      int batchOdkuStaticSqlLength = batchOdkuStaticSql.length;
      byte[] beginOfOdku = batchOdkuStaticSql[0];
      byte[] endOfOdku = batchOdkuStaticSql[(batchOdkuStaticSqlLength - 1)];
      if (numBatch > 1)
      {
        visitor.merge(numValueRepeats > 0 ? endOfValues : endOfHead, beginOfOdku).increment();
        for (int i = 1; i < batchOdkuStaticSqlLength; i++) {
          visitor.append(batchOdkuStaticSql[i]).increment();
        }
      }
      else
      {
        visitor.append(endOfOdku).increment();
      }
    }
    else
    {
      visitor.append(endOfHead);
    }
  }
  
  protected static int findStartOfStatement(String sql)
  {
    int statementStartPos = 0;
    if (StringUtils.startsWithIgnoreCaseAndWs(sql, "/*"))
    {
      statementStartPos = sql.indexOf("*/");
      if (statementStartPos == -1) {
        statementStartPos = 0;
      } else {
        statementStartPos += 2;
      }
    }
    else if ((StringUtils.startsWithIgnoreCaseAndWs(sql, "--")) || (StringUtils.startsWithIgnoreCaseAndWs(sql, "#")))
    {
      statementStartPos = sql.indexOf('\n');
      if (statementStartPos == -1)
      {
        statementStartPos = sql.indexOf('\r');
        if (statementStartPos == -1) {
          statementStartPos = 0;
        }
      }
    }
    return statementStartPos;
  }
  
  public static int getOnDuplicateKeyLocation(String sql, boolean dontCheckOnDuplicateKeyUpdateInSQL, boolean rewriteBatchedStatements, boolean noBackslashEscapes)
  {
    return (dontCheckOnDuplicateKeyUpdateInSQL) && (!rewriteBatchedStatements) ? -1 : StringUtils.indexOfIgnoreCase(0, sql, ON_DUPLICATE_KEY_UPDATE_CLAUSE, "\"'`", "\"'`", noBackslashEscapes ? StringUtils.SEARCH_MODE__MRK_COM_WS : StringUtils.SEARCH_MODE__ALL);
  }
  
  protected static boolean canRewrite(String sql, boolean isOnDuplicateKeyUpdate, int locationOfOnDuplicateKeyUpdate, int statementStartPos)
  {
    if (StringUtils.startsWithIgnoreCaseAndWs(sql, "INSERT", statementStartPos))
    {
      if (StringUtils.indexOfIgnoreCase(statementStartPos, sql, "SELECT", "\"'`", "\"'`", StringUtils.SEARCH_MODE__MRK_COM_WS) != -1) {
        return false;
      }
      if (isOnDuplicateKeyUpdate)
      {
        int updateClausePos = StringUtils.indexOfIgnoreCase(locationOfOnDuplicateKeyUpdate, sql, " UPDATE ");
        if (updateClausePos != -1) {
          return StringUtils.indexOfIgnoreCase(updateClausePos, sql, "LAST_INSERT_ID", "\"'`", "\"'`", StringUtils.SEARCH_MODE__MRK_COM_WS) == -1;
        }
      }
      return true;
    }
    return (StringUtils.startsWithIgnoreCaseAndWs(sql, "REPLACE", statementStartPos)) && 
      (StringUtils.indexOfIgnoreCase(statementStartPos, sql, "SELECT", "\"'`", "\"'`", StringUtils.SEARCH_MODE__MRK_COM_WS) == -1);
  }
  
  public boolean isFoundLoadData()
  {
    return foundLoadData;
  }
  
  public char getFirstStmtChar()
  {
    return firstStmtChar;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.ParseInfo
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */