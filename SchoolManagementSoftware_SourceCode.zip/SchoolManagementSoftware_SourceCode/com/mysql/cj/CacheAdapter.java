package com.mysql.cj;

import java.util.Set;

public abstract interface CacheAdapter<K, V>
{
  public abstract V get(K paramK);
  
  public abstract void put(K paramK, V paramV);
  
  public abstract void invalidate(K paramK);
  
  public abstract void invalidateAll(Set<K> paramSet);
  
  public abstract void invalidateAll();
}

/* Location:
 * Qualified Name:     com.mysql.cj.CacheAdapter
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */