package com.mysql.cj;

import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.protocol.a.NativeProtocol;
import com.mysql.cj.util.TestUtils;
import java.io.IOException;

public class ServerPreparedQueryTestcaseGenerator
  extends ServerPreparedQuery
{
  public ServerPreparedQueryTestcaseGenerator(NativeSession sess)
  {
    super(sess);
  }
  
  public void closeQuery()
  {
    dumpCloseForTestcase();
    super.closeQuery();
  }
  
  private void dumpCloseForTestcase()
  {
    StringBuilder buf = new StringBuilder();
    session.getProtocol().generateQueryCommentBlock(buf);
    buf.append("DEALLOCATE PREPARE debug_stmt_");
    buf.append(statementId);
    buf.append(";\n");
    
    TestUtils.dumpTestcaseQuery(buf.toString());
  }
  
  public void serverPrepare(String sql)
    throws IOException
  {
    dumpPrepareForTestcase();
    super.serverPrepare(sql);
  }
  
  private void dumpPrepareForTestcase()
  {
    StringBuilder buf = new StringBuilder(getOriginalSql().length() + 64);
    
    session.getProtocol().generateQueryCommentBlock(buf);
    
    buf.append("PREPARE debug_stmt_");
    buf.append(statementId);
    buf.append(" FROM \"");
    buf.append(getOriginalSql());
    buf.append("\";\n");
    
    TestUtils.dumpTestcaseQuery(buf.toString());
  }
  
  public <T extends Resultset> T serverExecute(int maxRowsToRetrieve, boolean createStreamingResultSet, ColumnDefinition metadata, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory)
  {
    dumpExecuteForTestcase();
    return super.serverExecute(maxRowsToRetrieve, createStreamingResultSet, metadata, resultSetFactory);
  }
  
  private void dumpExecuteForTestcase()
  {
    StringBuilder buf = new StringBuilder();
    for (int i = 0; i < getParameterCount(); i++)
    {
      session.getProtocol().generateQueryCommentBlock(buf);
      
      buf.append("SET @debug_stmt_param");
      buf.append(statementId);
      buf.append("_");
      buf.append(i);
      buf.append("=");
      
      ServerPreparedQueryBindValue bv = ((ServerPreparedQueryBindValue[])((ServerPreparedQueryBindings)queryBindings).getBindValues())[i];
      buf.append(bv.isNull() ? "NULL" : bv.toString(true));
      
      buf.append(";\n");
    }
    session.getProtocol().generateQueryCommentBlock(buf);
    
    buf.append("EXECUTE debug_stmt_");
    buf.append(statementId);
    if (getParameterCount() > 0)
    {
      buf.append(" USING ");
      for (int i = 0; i < getParameterCount(); i++)
      {
        if (i > 0) {
          buf.append(", ");
        }
        buf.append("@debug_stmt_param");
        buf.append(statementId);
        buf.append("_");
        buf.append(i);
      }
    }
    buf.append(";\n");
    
    TestUtils.dumpTestcaseQuery(buf.toString());
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.ServerPreparedQueryTestcaseGenerator
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */