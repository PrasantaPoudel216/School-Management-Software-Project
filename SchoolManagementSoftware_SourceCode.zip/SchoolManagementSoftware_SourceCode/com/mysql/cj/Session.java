package com.mysql.cj;

import com.mysql.cj.conf.HostInfo;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.log.Log;
import com.mysql.cj.log.ProfilerEventHandler;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.result.Row;
import java.net.SocketAddress;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collector;

public abstract interface Session
{
  public abstract PropertySet getPropertySet();
  
  public abstract <M extends Message> MessageBuilder<M> getMessageBuilder();
  
  public abstract void changeUser(String paramString1, String paramString2, String paramString3);
  
  public abstract ExceptionInterceptor getExceptionInterceptor();
  
  public abstract void setExceptionInterceptor(ExceptionInterceptor paramExceptionInterceptor);
  
  public abstract void quit();
  
  public abstract void forceClose();
  
  public abstract boolean versionMeetsMinimum(int paramInt1, int paramInt2, int paramInt3);
  
  public abstract long getThreadId();
  
  public abstract boolean isSetNeededForAutoCommitMode(boolean paramBoolean);
  
  public abstract Log getLog();
  
  public abstract ProfilerEventHandler getProfilerEventHandler();
  
  public abstract HostInfo getHostInfo();
  
  public abstract String getQueryTimingUnits();
  
  public abstract ServerSession getServerSession();
  
  public abstract boolean isSSLEstablished();
  
  public abstract SocketAddress getRemoteSocketAddress();
  
  public abstract String getProcessHost();
  
  public abstract void addListener(SessionEventListener paramSessionEventListener);
  
  public abstract void removeListener(SessionEventListener paramSessionEventListener);
  
  public abstract boolean isClosed();
  
  public abstract String getIdentifierQuoteString();
  
  public abstract DataStoreMetadata getDataStoreMetadata();
  
  public abstract <M extends Message, RES_T, R> RES_T query(M paramM, Predicate<Row> paramPredicate, Function<Row, R> paramFunction, Collector<R, ?, RES_T> paramCollector);
  
  public static abstract interface SessionEventListener
  {
    public abstract void handleNormalClose();
    
    public abstract void handleReconnect();
    
    public abstract void handleCleanup(Throwable paramThrowable);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.Session
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */