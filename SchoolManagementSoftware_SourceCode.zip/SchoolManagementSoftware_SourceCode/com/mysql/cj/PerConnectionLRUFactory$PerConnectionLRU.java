package com.mysql.cj;

import com.mysql.cj.util.LRUCache;
import java.util.Set;

class PerConnectionLRUFactory$PerConnectionLRU
  implements CacheAdapter<String, ParseInfo>
{
  private final int cacheSqlLimit;
  private final LRUCache<String, ParseInfo> cache;
  private final Object syncMutex;
  
  protected PerConnectionLRUFactory$PerConnectionLRU(PerConnectionLRUFactory this$0, Object syncMutex, int cacheMaxSize, int maxKeySize)
  {
    int cacheSize = cacheMaxSize;
    cacheSqlLimit = maxKeySize;
    cache = new LRUCache(cacheSize);
    this.syncMutex = syncMutex;
  }
  
  /* Error */
  public ParseInfo get(String key)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +14 -> 15
    //   4: aload_1
    //   5: invokevirtual 8	java/lang/String:length	()I
    //   8: aload_0
    //   9: getfield 3	com/mysql/cj/PerConnectionLRUFactory$PerConnectionLRU:cacheSqlLimit	I
    //   12: if_icmple +5 -> 17
    //   15: aconst_null
    //   16: areturn
    //   17: aload_0
    //   18: getfield 7	com/mysql/cj/PerConnectionLRUFactory$PerConnectionLRU:syncMutex	Ljava/lang/Object;
    //   21: dup
    //   22: astore_2
    //   23: monitorenter
    //   24: aload_0
    //   25: getfield 6	com/mysql/cj/PerConnectionLRUFactory$PerConnectionLRU:cache	Lcom/mysql/cj/util/LRUCache;
    //   28: aload_1
    //   29: invokevirtual 9	com/mysql/cj/util/LRUCache:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   32: checkcast 10	com/mysql/cj/ParseInfo
    //   35: aload_2
    //   36: monitorexit
    //   37: areturn
    //   38: astore_3
    //   39: aload_2
    //   40: monitorexit
    //   41: aload_3
    //   42: athrow
    // Line number table:
    //   Java source line #56	-> byte code offset #0
    //   Java source line #57	-> byte code offset #15
    //   Java source line #60	-> byte code offset #17
    //   Java source line #61	-> byte code offset #24
    //   Java source line #62	-> byte code offset #38
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	43	0	this	PerConnectionLRU
    //   0	43	1	key	String
    //   22	18	2	Ljava/lang/Object;	Object
    //   38	4	3	localObject1	Object
    // Exception table:
    //   from	to	target	type
    //   24	37	38	finally
    //   38	41	38	finally
  }
  
  public void put(String key, ParseInfo value)
  {
    if ((key == null) || (key.length() > cacheSqlLimit)) {
      return;
    }
    synchronized (syncMutex)
    {
      cache.put(key, value);
    }
  }
  
  public void invalidate(String key)
  {
    synchronized (syncMutex)
    {
      cache.remove(key);
    }
  }
  
  public void invalidateAll(Set<String> keys)
  {
    synchronized (syncMutex)
    {
      for (String key : keys) {
        cache.remove(key);
      }
    }
  }
  
  public void invalidateAll()
  {
    synchronized (syncMutex)
    {
      cache.clear();
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.PerConnectionLRUFactory.PerConnectionLRU
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */