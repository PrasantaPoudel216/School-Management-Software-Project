package com.mysql.cj;

import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import java.util.Properties;

public abstract interface MysqlConnection
{
  public abstract PropertySet getPropertySet();
  
  public abstract void createNewIO(boolean paramBoolean);
  
  public abstract long getId();
  
  public abstract Properties getProperties();
  
  public abstract Object getConnectionMutex();
  
  public abstract Session getSession();
  
  public abstract String getURL();
  
  public abstract String getUser();
  
  public abstract ExceptionInterceptor getExceptionInterceptor();
  
  public abstract void checkClosed();
  
  public abstract void normalClose();
  
  public abstract void cleanup(Throwable paramThrowable);
}

/* Location:
 * Qualified Name:     com.mysql.cj.MysqlConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */