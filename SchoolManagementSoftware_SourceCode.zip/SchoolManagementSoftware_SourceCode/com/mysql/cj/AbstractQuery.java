package com.mysql.cj;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.CJTimeoutException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.OperationCancelledException;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.Resultset.Type;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Timer;
import java.util.concurrent.atomic.AtomicBoolean;

public abstract class AbstractQuery
  implements Query
{
  static int statementCounter = 1;
  public NativeSession session = null;
  protected int statementId;
  protected RuntimeProperty<Integer> maxAllowedPacket;
  protected String charEncoding = null;
  protected Object cancelTimeoutMutex = new Object();
  private Query.CancelStatus cancelStatus = Query.CancelStatus.NOT_CANCELED;
  protected int timeoutInMillis = 0;
  protected List<Object> batchedArgs;
  protected Resultset.Type resultSetType = Resultset.Type.FORWARD_ONLY;
  protected int fetchSize = 0;
  protected final AtomicBoolean statementExecuting = new AtomicBoolean(false);
  protected String currentDb = null;
  protected boolean clearWarningsCalled = false;
  
  public AbstractQuery(NativeSession sess)
  {
    statementCounter += 1;
    session = sess;
    maxAllowedPacket = sess.getPropertySet().getIntegerProperty(PropertyKey.maxAllowedPacket);
    charEncoding = ((String)sess.getPropertySet().getStringProperty(PropertyKey.characterEncoding).getValue());
  }
  
  public int getId()
  {
    return statementId;
  }
  
  public void setCancelStatus(Query.CancelStatus cs)
  {
    cancelStatus = cs;
  }
  
  public void checkCancelTimeout()
  {
    synchronized (cancelTimeoutMutex)
    {
      if (cancelStatus != Query.CancelStatus.NOT_CANCELED)
      {
        CJException cause = cancelStatus == Query.CancelStatus.CANCELED_BY_TIMEOUT ? new CJTimeoutException() : new OperationCancelledException();
        resetCancelledState();
        throw cause;
      }
    }
  }
  
  public void resetCancelledState()
  {
    synchronized (cancelTimeoutMutex)
    {
      cancelStatus = Query.CancelStatus.NOT_CANCELED;
    }
  }
  
  public <T extends Resultset, M extends Message> ProtocolEntityFactory<T, M> getResultSetFactory()
  {
    return null;
  }
  
  public NativeSession getSession()
  {
    return session;
  }
  
  public Object getCancelTimeoutMutex()
  {
    return cancelTimeoutMutex;
  }
  
  public void closeQuery()
  {
    session = null;
  }
  
  public void addBatch(Object batch)
  {
    if (batchedArgs == null) {
      batchedArgs = new ArrayList();
    }
    batchedArgs.add(batch);
  }
  
  public List<Object> getBatchedArgs()
  {
    return batchedArgs == null ? null : Collections.unmodifiableList(batchedArgs);
  }
  
  public void clearBatchedArgs()
  {
    if (batchedArgs != null) {
      batchedArgs.clear();
    }
  }
  
  public int getResultFetchSize()
  {
    return fetchSize;
  }
  
  public void setResultFetchSize(int fetchSize)
  {
    this.fetchSize = fetchSize;
  }
  
  public Resultset.Type getResultType()
  {
    return resultSetType;
  }
  
  public void setResultType(Resultset.Type resultSetType)
  {
    this.resultSetType = resultSetType;
  }
  
  public int getTimeoutInMillis()
  {
    return timeoutInMillis;
  }
  
  public void setTimeoutInMillis(int timeoutInMillis)
  {
    this.timeoutInMillis = timeoutInMillis;
  }
  
  public CancelQueryTask startQueryTimer(Query stmtToCancel, int timeout)
  {
    if ((((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.enableQueryTimeouts).getValue()).booleanValue()) && (timeout != 0))
    {
      CancelQueryTaskImpl timeoutTask = new CancelQueryTaskImpl(stmtToCancel);
      session.getCancelTimer().schedule(timeoutTask, timeout);
      return timeoutTask;
    }
    return null;
  }
  
  public void stopQueryTimer(CancelQueryTask timeoutTask, boolean rethrowCancelReason, boolean checkCancelTimeout)
  {
    if (timeoutTask != null)
    {
      timeoutTask.cancel();
      if ((rethrowCancelReason) && (timeoutTask.getCaughtWhileCancelling() != null))
      {
        Throwable t = timeoutTask.getCaughtWhileCancelling();
        throw ExceptionFactory.createException(t.getMessage(), t);
      }
      session.getCancelTimer().purge();
      if (checkCancelTimeout) {
        checkCancelTimeout();
      }
    }
  }
  
  public AtomicBoolean getStatementExecuting()
  {
    return statementExecuting;
  }
  
  public String getCurrentDatabase()
  {
    return currentDb;
  }
  
  public void setCurrentDatabase(String currentDb)
  {
    this.currentDb = currentDb;
  }
  
  public boolean isClearWarningsCalled()
  {
    return clearWarningsCalled;
  }
  
  public void setClearWarningsCalled(boolean clearWarningsCalled)
  {
    this.clearWarningsCalled = clearWarningsCalled;
  }
  
  public void statementBegins()
  {
    clearWarningsCalled = false;
    statementExecuting.set(true);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.AbstractQuery
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */