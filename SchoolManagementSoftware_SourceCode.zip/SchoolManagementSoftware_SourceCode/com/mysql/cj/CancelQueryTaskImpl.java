package com.mysql.cj;

import com.mysql.cj.conf.HostInfo;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.OperationCancelledException;
import com.mysql.cj.protocol.a.NativeMessageBuilder;
import com.mysql.cj.util.StringUtils;
import java.util.TimerTask;

public class CancelQueryTaskImpl
  extends TimerTask
  implements CancelQueryTask
{
  Query queryToCancel;
  Throwable caughtWhileCancelling = null;
  boolean queryTimeoutKillsConnection = false;
  
  public CancelQueryTaskImpl(Query cancellee)
  {
    queryToCancel = cancellee;
    NativeSession session = (NativeSession)cancellee.getSession();
    queryTimeoutKillsConnection = ((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.queryTimeoutKillsConnection).getValue()).booleanValue();
  }
  
  public boolean cancel()
  {
    boolean res = super.cancel();
    queryToCancel = null;
    return res;
  }
  
  public void run()
  {
    Thread cancelThread = new Thread()
    {
      public void run()
      {
        Query localQueryToCancel = queryToCancel;
        if (localQueryToCancel == null) {
          return;
        }
        NativeSession session = (NativeSession)localQueryToCancel.getSession();
        if (session == null) {
          return;
        }
        try
        {
          if (queryTimeoutKillsConnection)
          {
            localQueryToCancel.setCancelStatus(Query.CancelStatus.CANCELED_BY_TIMEOUT);
            session.invokeCleanupListeners(new OperationCancelledException(Messages.getString("Statement.ConnectionKilledDueToTimeout")));
          }
          else
          {
            synchronized (localQueryToCancel.getCancelTimeoutMutex())
            {
              long origConnId = session.getThreadId();
              HostInfo hostInfo = session.getHostInfo();
              String database = hostInfo.getDatabase();
              String user = StringUtils.isNullOrEmpty(hostInfo.getUser()) ? "" : hostInfo.getUser();
              String password = StringUtils.isNullOrEmpty(hostInfo.getPassword()) ? "" : hostInfo.getPassword();
              
              NativeSession newSession = new NativeSession(hostInfo, session.getPropertySet());
              newSession.connect(hostInfo, user, password, database, 30000, new TransactionEventHandler()
              {
                public void transactionCompleted() {}
                
                public void transactionBegun() {}
              });
              newSession.sendCommand(new NativeMessageBuilder().buildComQuery(newSession.getSharedSendPacket(), "KILL QUERY " + origConnId), false, 0);
              
              localQueryToCancel.setCancelStatus(Query.CancelStatus.CANCELED_BY_TIMEOUT);
            }
          }
        }
        catch (Throwable t)
        {
          caughtWhileCancelling = t;
        }
        finally
        {
          setQueryToCancel(null);
        }
      }
    };
    cancelThread.start();
  }
  
  public Throwable getCaughtWhileCancelling()
  {
    return caughtWhileCancelling;
  }
  
  public void setCaughtWhileCancelling(Throwable caughtWhileCancelling)
  {
    this.caughtWhileCancelling = caughtWhileCancelling;
  }
  
  public Query getQueryToCancel()
  {
    return queryToCancel;
  }
  
  public void setQueryToCancel(Query queryToCancel)
  {
    this.queryToCancel = queryToCancel;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.CancelQueryTaskImpl
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */