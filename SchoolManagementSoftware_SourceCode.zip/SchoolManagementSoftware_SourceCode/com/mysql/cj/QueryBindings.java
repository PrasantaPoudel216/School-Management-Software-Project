package com.mysql.cj;

import com.mysql.cj.protocol.ColumnDefinition;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;

public abstract interface QueryBindings<T extends BindValue>
{
  public abstract QueryBindings<T> clone();
  
  public abstract void setColumnDefinition(ColumnDefinition paramColumnDefinition);
  
  public abstract boolean isLoadDataQuery();
  
  public abstract void setLoadDataQuery(boolean paramBoolean);
  
  public abstract T[] getBindValues();
  
  public abstract void setBindValues(T[] paramArrayOfT);
  
  public abstract boolean clearBindValues();
  
  public abstract void checkParameterSet(int paramInt);
  
  public abstract void checkAllParametersSet();
  
  public abstract int getNumberOfExecutions();
  
  public abstract void setNumberOfExecutions(int paramInt);
  
  public abstract void setValue(int paramInt, byte[] paramArrayOfByte, MysqlType paramMysqlType);
  
  public abstract void setValue(int paramInt, String paramString, MysqlType paramMysqlType);
  
  public abstract void setAsciiStream(int paramInt, InputStream paramInputStream);
  
  public abstract void setAsciiStream(int paramInt1, InputStream paramInputStream, int paramInt2);
  
  public abstract void setAsciiStream(int paramInt, InputStream paramInputStream, long paramLong);
  
  public abstract void setBigDecimal(int paramInt, BigDecimal paramBigDecimal);
  
  public abstract void setBigInteger(int paramInt, BigInteger paramBigInteger);
  
  public abstract void setBinaryStream(int paramInt, InputStream paramInputStream);
  
  public abstract void setBinaryStream(int paramInt1, InputStream paramInputStream, int paramInt2);
  
  public abstract void setBinaryStream(int paramInt, InputStream paramInputStream, long paramLong);
  
  public abstract void setBlob(int paramInt, Blob paramBlob);
  
  public abstract void setBlob(int paramInt, InputStream paramInputStream);
  
  public abstract void setBlob(int paramInt, InputStream paramInputStream, long paramLong);
  
  public abstract void setBoolean(int paramInt, boolean paramBoolean);
  
  public abstract void setByte(int paramInt, byte paramByte);
  
  public abstract void setBytes(int paramInt, byte[] paramArrayOfByte);
  
  public abstract void setBytes(int paramInt, byte[] paramArrayOfByte, boolean paramBoolean1, boolean paramBoolean2);
  
  public abstract void setBytesNoEscape(int paramInt, byte[] paramArrayOfByte);
  
  public abstract void setBytesNoEscapeNoQuotes(int paramInt, byte[] paramArrayOfByte);
  
  public abstract void setCharacterStream(int paramInt, Reader paramReader);
  
  public abstract void setCharacterStream(int paramInt1, Reader paramReader, int paramInt2);
  
  public abstract void setCharacterStream(int paramInt, Reader paramReader, long paramLong);
  
  public abstract void setClob(int paramInt, Clob paramClob);
  
  public abstract void setClob(int paramInt, Reader paramReader);
  
  public abstract void setClob(int paramInt, Reader paramReader, long paramLong);
  
  public abstract void setDate(int paramInt, Date paramDate);
  
  public abstract void setDate(int paramInt, Date paramDate, Calendar paramCalendar);
  
  public abstract void setDouble(int paramInt, double paramDouble);
  
  public abstract void setFloat(int paramInt, float paramFloat);
  
  public abstract void setInt(int paramInt1, int paramInt2);
  
  public abstract void setLong(int paramInt, long paramLong);
  
  public abstract void setNCharacterStream(int paramInt, Reader paramReader);
  
  public abstract void setNCharacterStream(int paramInt, Reader paramReader, long paramLong);
  
  public abstract void setNClob(int paramInt, Reader paramReader);
  
  public abstract void setNClob(int paramInt, Reader paramReader, long paramLong);
  
  public abstract void setNClob(int paramInt, NClob paramNClob);
  
  public abstract void setNString(int paramInt, String paramString);
  
  public abstract void setNull(int paramInt);
  
  public abstract boolean isNull(int paramInt);
  
  public abstract void setObject(int paramInt, Object paramObject);
  
  public abstract void setObject(int paramInt, Object paramObject, MysqlType paramMysqlType);
  
  public abstract void setObject(int paramInt1, Object paramObject, MysqlType paramMysqlType, int paramInt2);
  
  public abstract void setShort(int paramInt, short paramShort);
  
  public abstract void setString(int paramInt, String paramString);
  
  public abstract void setTime(int paramInt, Time paramTime);
  
  public abstract void setTime(int paramInt, Time paramTime, Calendar paramCalendar);
  
  public abstract void setTimestamp(int paramInt, Timestamp paramTimestamp, Calendar paramCalendar);
  
  public abstract void setTimestamp(int paramInt, Timestamp paramTimestamp);
  
  public abstract void setTimestamp(int paramInt1, Timestamp paramTimestamp, Calendar paramCalendar, int paramInt2);
  
  public abstract byte[] getBytesRepresentation(int paramInt);
}

/* Location:
 * Qualified Name:     com.mysql.cj.QueryBindings
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */