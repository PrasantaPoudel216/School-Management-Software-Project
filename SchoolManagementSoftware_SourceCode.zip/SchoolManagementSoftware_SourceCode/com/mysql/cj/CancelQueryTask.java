package com.mysql.cj;

public abstract interface CancelQueryTask
{
  public abstract boolean cancel();
  
  public abstract Throwable getCaughtWhileCancelling();
  
  public abstract void setCaughtWhileCancelling(Throwable paramThrowable);
  
  public abstract Query getQueryToCancel();
  
  public abstract void setQueryToCancel(Query paramQuery);
}

/* Location:
 * Qualified Name:     com.mysql.cj.CancelQueryTask
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */