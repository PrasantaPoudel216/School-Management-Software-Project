package com.mysql.cj;

import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.protocol.a.NativeConstants.IntegerDataType;
import com.mysql.cj.protocol.a.NativeConstants.StringSelfDataType;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.util.StringUtils;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class ServerPreparedQueryBindValue
  extends ClientPreparedQueryBindValue
  implements BindValue
{
  public long boundBeforeExecutionNum = 0L;
  public int bufferType;
  public Calendar calendar;
  private TimeZone defaultTimeZone;
  protected String charEncoding = null;
  
  public ServerPreparedQueryBindValue(TimeZone defaultTZ)
  {
    defaultTimeZone = defaultTZ;
  }
  
  public ServerPreparedQueryBindValue clone()
  {
    return new ServerPreparedQueryBindValue(this);
  }
  
  private ServerPreparedQueryBindValue(ServerPreparedQueryBindValue copyMe)
  {
    super(copyMe);
    
    defaultTimeZone = defaultTimeZone;
    bufferType = bufferType;
    calendar = calendar;
    charEncoding = charEncoding;
  }
  
  public void reset()
  {
    super.reset();
    calendar = null;
    charEncoding = null;
  }
  
  public boolean resetToType(int bufType, long numberOfExecutions)
  {
    boolean sendTypesToServer = false;
    
    reset();
    if ((bufType != 6) || (bufferType == 0)) {
      if (bufferType != bufType)
      {
        sendTypesToServer = true;
        bufferType = bufType;
      }
    }
    isSet = true;
    boundBeforeExecutionNum = numberOfExecutions;
    return sendTypesToServer;
  }
  
  public String toString()
  {
    return toString(false);
  }
  
  public String toString(boolean quoteIfNeeded)
  {
    if (isStream) {
      return "' STREAM DATA '";
    }
    if (isNull) {
      return "NULL";
    }
    switch (bufferType)
    {
    case 1: 
    case 2: 
    case 3: 
    case 8: 
      return String.valueOf(((Long)value).longValue());
    case 4: 
      return String.valueOf(((Float)value).floatValue());
    case 5: 
      return String.valueOf(((Double)value).doubleValue());
    case 7: 
    case 10: 
    case 11: 
    case 12: 
    case 15: 
    case 253: 
    case 254: 
      if (quoteIfNeeded) {
        return "'" + String.valueOf(value) + "'";
      }
      return String.valueOf(value);
    }
    if ((value instanceof byte[])) {
      return "byte data";
    }
    if (quoteIfNeeded) {
      return "'" + String.valueOf(value) + "'";
    }
    return String.valueOf(value);
  }
  
  public long getBoundLength()
  {
    if (isNull) {
      return 0L;
    }
    if (isStream) {
      return streamLength;
    }
    switch (bufferType)
    {
    case 1: 
      return 1L;
    case 2: 
      return 2L;
    case 3: 
      return 4L;
    case 8: 
      return 8L;
    case 4: 
      return 4L;
    case 5: 
      return 8L;
    case 11: 
      return 9L;
    case 10: 
      return 7L;
    case 7: 
    case 12: 
      return 11L;
    case 0: 
    case 15: 
    case 246: 
    case 253: 
    case 254: 
      if ((value instanceof byte[])) {
        return ((byte[])value).length;
      }
      return ((String)value).length();
    }
    return 0L;
  }
  
  public void storeBinding(NativePacketPayload intoPacket, boolean isLoadDataQuery, String characterEncoding, ExceptionInterceptor interceptor)
  {
    synchronized (this)
    {
      try
      {
        switch (bufferType)
        {
        case 1: 
          intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, ((Long)value).longValue());
          return;
        case 2: 
          intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, ((Long)value).longValue());
          return;
        case 3: 
          intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ((Long)value).longValue());
          return;
        case 8: 
          intoPacket.writeInteger(NativeConstants.IntegerDataType.INT8, ((Long)value).longValue());
          return;
        case 4: 
          intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, Float.floatToIntBits(((Float)value).floatValue()));
          return;
        case 5: 
          intoPacket.writeInteger(NativeConstants.IntegerDataType.INT8, Double.doubleToLongBits(((Double)value).doubleValue()));
          return;
        case 11: 
          storeTime(intoPacket);
          return;
        case 7: 
        case 10: 
        case 12: 
          storeDateTime(intoPacket);
          return;
        case 0: 
        case 15: 
        case 246: 
        case 253: 
        case 254: 
          if ((value instanceof byte[])) {
            intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, (byte[])value);
          } else if (!isLoadDataQuery) {
            intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes((String)value, characterEncoding));
          } else {
            intoPacket.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, StringUtils.getBytes((String)value));
          }
          return;
        }
      }
      catch (CJException uEE)
      {
        throw ExceptionFactory.createException(Messages.getString("ServerPreparedStatement.22") + characterEncoding + "'", uEE, interceptor);
      }
    }
  }
  
  private void storeTime(NativePacketPayload intoPacket)
  {
    intoPacket.ensureCapacity(9);
    intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 8L);
    intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
    intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, 0L);
    if (calendar == null) {
      calendar = Calendar.getInstance(defaultTimeZone, Locale.US);
    }
    calendar.setTime((java.util.Date)value);
    intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, calendar.get(11));
    intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, calendar.get(12));
    intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, calendar.get(13));
  }
  
  private void storeDateTime(NativePacketPayload intoPacket)
  {
    synchronized (this)
    {
      if (calendar == null) {
        calendar = Calendar.getInstance(defaultTimeZone, Locale.US);
      }
      calendar.setTime((java.util.Date)value);
      if ((value instanceof java.sql.Date))
      {
        calendar.set(11, 0);
        calendar.set(12, 0);
        calendar.set(13, 0);
      }
      byte length = 7;
      if ((value instanceof Timestamp)) {
        length = 11;
      }
      intoPacket.ensureCapacity(length);
      
      intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, length);
      
      int year = calendar.get(1);
      int month = calendar.get(2) + 1;
      int date = calendar.get(5);
      
      intoPacket.writeInteger(NativeConstants.IntegerDataType.INT2, year);
      intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, month);
      intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, date);
      if ((value instanceof java.sql.Date))
      {
        intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
        intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
        intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
      }
      else
      {
        intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, calendar.get(11));
        intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, calendar.get(12));
        intoPacket.writeInteger(NativeConstants.IntegerDataType.INT1, calendar.get(13));
      }
      if (length == 11) {
        intoPacket.writeInteger(NativeConstants.IntegerDataType.INT4, ((Timestamp)value).getNanos() / 1000);
      }
    }
  }
  
  public byte[] getByteValue()
  {
    if (!isStream) {
      return charEncoding != null ? StringUtils.getBytes(toString(), charEncoding) : toString().getBytes();
    }
    return null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.ServerPreparedQueryBindValue
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */