package com.mysql.cj.protocol;

import com.mysql.cj.exceptions.AssertionFailedException;
import java.nio.channels.CompletionHandler;

class TlsAsynchronousSocketChannel$1
  implements CompletionHandler<Integer, Void>
{
  TlsAsynchronousSocketChannel$1(TlsAsynchronousSocketChannel this$0, CompletionHandler paramCompletionHandler, int paramInt) {}
  
  public void completed(Integer result, Void attachment)
  {
    val$h.completed(Integer.valueOf(val$transferred), null);
  }
  
  public void failed(Throwable t, Void attachment)
  {
    t.printStackTrace();
    val$h.failed(AssertionFailedException.shouldNotHappen(new Exception(t)), null);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.TlsAsynchronousSocketChannel.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */