package com.mysql.cj.protocol;

import java.io.CharArrayWriter;

public class WatchableWriter
  extends CharArrayWriter
{
  private WriterWatcher watcher;
  
  public void close()
  {
    super.close();
    if (watcher != null) {
      watcher.writerClosed(this);
    }
  }
  
  public void setWatcher(WriterWatcher watcher)
  {
    this.watcher = watcher;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.WatchableWriter
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */