package com.mysql.cj.protocol;

import com.mysql.cj.conf.PropertySet;
import java.io.Closeable;
import java.io.IOException;

public abstract interface SocketFactory
  extends SocketMetadata
{
  public abstract <T extends Closeable> T connect(String paramString, int paramInt1, PropertySet paramPropertySet, int paramInt2)
    throws IOException;
  
  public void beforeHandshake()
    throws IOException
  {}
  
  public abstract <T extends Closeable> T performTlsHandshake(SocketConnection paramSocketConnection, ServerSession paramServerSession)
    throws IOException;
  
  public void afterHandshake()
    throws IOException
  {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.SocketFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */