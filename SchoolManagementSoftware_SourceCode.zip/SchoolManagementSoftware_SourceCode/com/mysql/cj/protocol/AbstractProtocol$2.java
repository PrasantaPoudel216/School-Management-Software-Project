package com.mysql.cj.protocol;

class AbstractProtocol$2
  implements PacketReceivedTimeHolder
{
  AbstractProtocol$2(AbstractProtocol this$0) {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.AbstractProtocol.2
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */