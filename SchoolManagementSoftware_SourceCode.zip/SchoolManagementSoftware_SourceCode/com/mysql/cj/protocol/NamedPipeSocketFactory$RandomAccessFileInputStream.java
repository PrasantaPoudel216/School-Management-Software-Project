package com.mysql.cj.protocol;

import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;

class NamedPipeSocketFactory$RandomAccessFileInputStream
  extends InputStream
{
  RandomAccessFile raFile;
  
  NamedPipeSocketFactory$RandomAccessFileInputStream(NamedPipeSocketFactory this$0, RandomAccessFile file)
  {
    raFile = file;
  }
  
  public int available()
    throws IOException
  {
    return -1;
  }
  
  public void close()
    throws IOException
  {
    raFile.close();
  }
  
  public int read()
    throws IOException
  {
    return raFile.read();
  }
  
  public int read(byte[] b)
    throws IOException
  {
    return raFile.read(b);
  }
  
  public int read(byte[] b, int off, int len)
    throws IOException
  {
    return raFile.read(b, off, len);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.NamedPipeSocketFactory.RandomAccessFileInputStream
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */