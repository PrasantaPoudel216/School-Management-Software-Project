package com.mysql.cj.protocol;

public abstract interface PacketSentTimeHolder
{
  public long getLastPacketSentTime()
  {
    return 0L;
  }
  
  public long getPreviousPacketSentTime()
  {
    return 0L;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.PacketSentTimeHolder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */