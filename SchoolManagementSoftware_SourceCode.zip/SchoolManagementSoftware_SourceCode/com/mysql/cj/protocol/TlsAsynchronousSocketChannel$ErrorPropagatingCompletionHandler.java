package com.mysql.cj.protocol;

import java.nio.channels.CompletionHandler;

class TlsAsynchronousSocketChannel$ErrorPropagatingCompletionHandler<V>
  implements CompletionHandler<V, Void>
{
  private CompletionHandler<Long, ?> target;
  private Runnable success;
  
  public TlsAsynchronousSocketChannel$ErrorPropagatingCompletionHandler(CompletionHandler<Long, ?> target, Runnable success)
  {
    this.target = target;
    this.success = success;
  }
  
  public void completed(V result, Void attachment)
  {
    success.run();
  }
  
  public void failed(Throwable ex, Void attachment)
  {
    target.failed(ex, null);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.TlsAsynchronousSocketChannel.ErrorPropagatingCompletionHandler
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */