package com.mysql.cj.protocol;

import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import java.io.IOException;
import java.util.Optional;

public abstract interface MessageReader<H extends MessageHeader, M extends Message>
{
  public abstract H readHeader()
    throws IOException;
  
  public abstract M readMessage(Optional<M> paramOptional, H paramH)
    throws IOException;
  
  public M readMessage(Optional<M> reuse, int expectedType)
    throws IOException
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public void pushMessageListener(MessageListener<M> l)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public byte getMessageSequence()
  {
    return 0;
  }
  
  public void resetMessageSequence() {}
  
  public MessageReader<H, M> undecorateAll()
  {
    return this;
  }
  
  public MessageReader<H, M> undecorate()
  {
    return this;
  }
  
  public void start() {}
  
  public void stopAfterNextMessage() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.MessageReader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */