package com.mysql.cj.protocol;

import java.io.ByteArrayOutputStream;
import java.io.IOException;

public class WatchableOutputStream
  extends ByteArrayOutputStream
  implements WatchableStream
{
  private OutputStreamWatcher watcher;
  
  public void close()
    throws IOException
  {
    super.close();
    if (watcher != null) {
      watcher.streamClosed(this);
    }
  }
  
  public void setWatcher(OutputStreamWatcher watcher)
  {
    this.watcher = watcher;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.WatchableOutputStream
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */