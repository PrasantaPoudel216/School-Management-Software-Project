package com.mysql.cj.protocol.result;

class AbstractResultsetRow$1 {}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.result.AbstractResultsetRow.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */