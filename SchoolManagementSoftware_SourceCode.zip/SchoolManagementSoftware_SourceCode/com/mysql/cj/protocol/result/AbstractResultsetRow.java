package com.mysql.cj.protocol.result;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.DataReadException;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ResultsetRow;
import com.mysql.cj.protocol.ValueDecoder;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.Row;
import com.mysql.cj.result.ValueFactory;

public abstract class AbstractResultsetRow
  implements ResultsetRow
{
  protected ExceptionInterceptor exceptionInterceptor;
  protected ColumnDefinition metadata;
  protected ValueDecoder valueDecoder;
  protected boolean wasNull;
  
  protected AbstractResultsetRow(ExceptionInterceptor exceptionInterceptor)
  {
    this.exceptionInterceptor = exceptionInterceptor;
  }
  
  private <T> T decodeAndCreateReturnValue(int columnIndex, byte[] bytes, int offset, int length, ValueFactory<T> vf)
  {
    Field f = metadata.getFields()[columnIndex];
    switch (f.getMysqlTypeId())
    {
    case 7: 
    case 12: 
      return (T)valueDecoder.decodeTimestamp(bytes, offset, length, vf);
    case 10: 
      return (T)valueDecoder.decodeDate(bytes, offset, length, vf);
    case 11: 
      return (T)valueDecoder.decodeTime(bytes, offset, length, vf);
    case 1: 
      return (T)(f.isUnsigned() ? valueDecoder.decodeUInt1(bytes, offset, length, vf) : valueDecoder.decodeInt1(bytes, offset, length, vf));
    case 13: 
      return (T)valueDecoder.decodeYear(bytes, offset, length, vf);
    case 2: 
      return (T)(f.isUnsigned() ? valueDecoder.decodeUInt2(bytes, offset, length, vf) : valueDecoder.decodeInt2(bytes, offset, length, vf));
    case 3: 
      return (T)(f.isUnsigned() ? valueDecoder.decodeUInt4(bytes, offset, length, vf) : valueDecoder.decodeInt4(bytes, offset, length, vf));
    case 9: 
      return (T)valueDecoder.decodeInt4(bytes, offset, length, vf);
    case 8: 
      return (T)(f.isUnsigned() ? valueDecoder.decodeUInt8(bytes, offset, length, vf) : valueDecoder.decodeInt8(bytes, offset, length, vf));
    case 4: 
      return (T)valueDecoder.decodeFloat(bytes, offset, length, vf);
    case 5: 
      return (T)valueDecoder.decodeDouble(bytes, offset, length, vf);
    case 0: 
    case 246: 
      return (T)valueDecoder.decodeDecimal(bytes, offset, length, vf);
    case 15: 
    case 245: 
    case 247: 
    case 249: 
    case 250: 
    case 251: 
    case 252: 
    case 253: 
    case 254: 
    case 255: 
      return (T)valueDecoder.decodeByteArray(bytes, offset, length, f, vf);
    case 248: 
      return (T)valueDecoder.decodeSet(bytes, offset, length, f, vf);
    case 16: 
      return (T)valueDecoder.decodeBit(bytes, offset, length, vf);
    case 6: 
      return (T)vf.createFromNull();
    }
    switch (f.getMysqlType())
    {
    case TINYINT: 
      return (T)valueDecoder.decodeInt1(bytes, offset, length, vf);
    case TINYINT_UNSIGNED: 
      return (T)valueDecoder.decodeUInt1(bytes, offset, length, vf);
    case SMALLINT: 
      return (T)valueDecoder.decodeInt2(bytes, offset, length, vf);
    case YEAR: 
      return (T)valueDecoder.decodeYear(bytes, offset, length, vf);
    case SMALLINT_UNSIGNED: 
      return (T)valueDecoder.decodeUInt2(bytes, offset, length, vf);
    case INT: 
    case MEDIUMINT: 
      return (T)valueDecoder.decodeInt4(bytes, offset, length, vf);
    case INT_UNSIGNED: 
    case MEDIUMINT_UNSIGNED: 
      return (T)valueDecoder.decodeUInt4(bytes, offset, length, vf);
    case BIGINT: 
      return (T)valueDecoder.decodeInt8(bytes, offset, length, vf);
    case BIGINT_UNSIGNED: 
      return (T)valueDecoder.decodeUInt8(bytes, offset, length, vf);
    case FLOAT: 
    case FLOAT_UNSIGNED: 
      return (T)valueDecoder.decodeFloat(bytes, offset, length, vf);
    case DOUBLE: 
    case DOUBLE_UNSIGNED: 
      return (T)valueDecoder.decodeDouble(bytes, offset, length, vf);
    case DECIMAL: 
    case DECIMAL_UNSIGNED: 
      return (T)valueDecoder.decodeDecimal(bytes, offset, length, vf);
    case BOOLEAN: 
    case VARBINARY: 
    case VARCHAR: 
    case BINARY: 
    case CHAR: 
    case TINYBLOB: 
    case BLOB: 
    case MEDIUMBLOB: 
    case LONGBLOB: 
    case TINYTEXT: 
    case TEXT: 
    case MEDIUMTEXT: 
    case LONGTEXT: 
    case JSON: 
    case ENUM: 
    case SET: 
    case GEOMETRY: 
    case UNKNOWN: 
      return (T)valueDecoder.decodeByteArray(bytes, offset, length, f, vf);
    case BIT: 
      return (T)valueDecoder.decodeBit(bytes, offset, length, vf);
    case DATETIME: 
    case TIMESTAMP: 
      return (T)valueDecoder.decodeTimestamp(bytes, offset, length, vf);
    case DATE: 
      return (T)valueDecoder.decodeDate(bytes, offset, length, vf);
    case TIME: 
      return (T)valueDecoder.decodeTime(bytes, offset, length, vf);
    case NULL: 
      return (T)vf.createFromNull();
    }
    throw new DataReadException(Messages.getString("ResultSet.UnknownSourceType"));
  }
  
  protected <T> T getValueFromBytes(int columnIndex, byte[] bytes, int offset, int length, ValueFactory<T> vf)
  {
    if (getNull(columnIndex)) {
      return (T)vf.createFromNull();
    }
    T retVal = decodeAndCreateReturnValue(columnIndex, bytes, offset, length, vf);
    wasNull = (retVal == null);
    return retVal;
  }
  
  public Row setMetadata(ColumnDefinition f)
  {
    metadata = f;
    
    return this;
  }
  
  public boolean wasNull()
  {
    return wasNull;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.result.AbstractResultsetRow
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */