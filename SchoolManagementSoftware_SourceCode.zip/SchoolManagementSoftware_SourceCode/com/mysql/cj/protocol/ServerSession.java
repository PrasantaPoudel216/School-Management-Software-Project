package com.mysql.cj.protocol;

import com.mysql.cj.ServerVersion;
import java.util.Map;
import java.util.TimeZone;

public abstract interface ServerSession
{
  public static final int TRANSACTION_NOT_STARTED = 0;
  public static final int TRANSACTION_IN_PROGRESS = 1;
  public static final int TRANSACTION_STARTED = 2;
  public static final int TRANSACTION_COMPLETED = 3;
  public static final String LOCAL_CHARACTER_SET_RESULTS = "local.character_set_results";
  
  public abstract ServerCapabilities getCapabilities();
  
  public abstract void setCapabilities(ServerCapabilities paramServerCapabilities);
  
  public abstract int getStatusFlags();
  
  public abstract void setStatusFlags(int paramInt);
  
  public abstract void setStatusFlags(int paramInt, boolean paramBoolean);
  
  public abstract int getOldStatusFlags();
  
  public abstract void setOldStatusFlags(int paramInt);
  
  public abstract int getServerDefaultCollationIndex();
  
  public abstract void setServerDefaultCollationIndex(int paramInt);
  
  public abstract int getTransactionState();
  
  public abstract boolean inTransactionOnServer();
  
  public abstract boolean cursorExists();
  
  public abstract boolean isAutocommit();
  
  public abstract boolean hasMoreResults();
  
  public abstract boolean isLastRowSent();
  
  public abstract boolean noGoodIndexUsed();
  
  public abstract boolean noIndexUsed();
  
  public abstract boolean queryWasSlow();
  
  public abstract long getClientParam();
  
  public abstract void setClientParam(long paramLong);
  
  public abstract boolean useMultiResults();
  
  public abstract boolean isEOFDeprecated();
  
  public abstract boolean hasLongColumnInfo();
  
  public abstract void setHasLongColumnInfo(boolean paramBoolean);
  
  public abstract Map<String, String> getServerVariables();
  
  public abstract String getServerVariable(String paramString);
  
  public abstract int getServerVariable(String paramString, int paramInt);
  
  public abstract void setServerVariables(Map<String, String> paramMap);
  
  public abstract boolean characterSetNamesMatches(String paramString);
  
  public abstract ServerVersion getServerVersion();
  
  public abstract boolean isVersion(ServerVersion paramServerVersion);
  
  public abstract String getServerDefaultCharset();
  
  public abstract String getErrorMessageEncoding();
  
  public abstract void setErrorMessageEncoding(String paramString);
  
  public abstract int getMaxBytesPerChar(String paramString);
  
  public abstract int getMaxBytesPerChar(Integer paramInteger, String paramString);
  
  public abstract String getEncodingForIndex(int paramInt);
  
  public abstract void configureCharacterSets();
  
  public abstract String getCharacterSetMetadata();
  
  public abstract void setCharacterSetMetadata(String paramString);
  
  public abstract int getMetadataCollationIndex();
  
  public abstract void setMetadataCollationIndex(int paramInt);
  
  public abstract String getCharacterSetResultsOnServer();
  
  public abstract void setCharacterSetResultsOnServer(String paramString);
  
  public abstract boolean isLowerCaseTableNames();
  
  public abstract boolean storesLowerCaseTableNames();
  
  public abstract boolean isQueryCacheEnabled();
  
  public abstract boolean isNoBackslashEscapesSet();
  
  public abstract boolean useAnsiQuotedIdentifiers();
  
  public abstract boolean isServerTruncatesFracSecs();
  
  public abstract long getThreadId();
  
  public abstract void setThreadId(long paramLong);
  
  public abstract boolean isAutoCommit();
  
  public abstract void setAutoCommit(boolean paramBoolean);
  
  public abstract TimeZone getServerTimeZone();
  
  public abstract void setServerTimeZone(TimeZone paramTimeZone);
  
  public abstract TimeZone getDefaultTimeZone();
  
  public abstract void setDefaultTimeZone(TimeZone paramTimeZone);
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ServerSession
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */