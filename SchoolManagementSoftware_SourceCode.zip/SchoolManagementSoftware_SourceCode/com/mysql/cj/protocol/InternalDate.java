package com.mysql.cj.protocol;

public class InternalDate
{
  protected int year = 0;
  protected int month = 0;
  protected int day = 0;
  
  public InternalDate() {}
  
  public InternalDate(int year, int month, int day)
  {
    this.year = year;
    this.month = month;
    this.day = day;
  }
  
  public int getYear()
  {
    return year;
  }
  
  public void setYear(int year)
  {
    this.year = year;
  }
  
  public int getMonth()
  {
    return month;
  }
  
  public void setMonth(int month)
  {
    this.month = month;
  }
  
  public int getDay()
  {
    return day;
  }
  
  public void setDay(int day)
  {
    this.day = day;
  }
  
  public boolean isZero()
  {
    return (year == 0) && (month == 0) && (day == 0);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.InternalDate
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */