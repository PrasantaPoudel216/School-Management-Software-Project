package com.mysql.cj.protocol;

import com.mysql.cj.Messages;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import java.io.Closeable;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;

public class StandardSocketFactory
  implements SocketFactory
{
  protected String host = null;
  protected int port = 3306;
  protected Socket rawSocket = null;
  protected Socket sslSocket = null;
  protected int loginTimeoutCountdown = 0;
  protected long loginTimeoutCheckTimestamp = System.currentTimeMillis();
  protected int socketTimeoutBackup = 0;
  
  protected Socket createSocket(PropertySet props)
  {
    return new Socket();
  }
  
  private void configureSocket(Socket sock, PropertySet pset)
    throws SocketException, IOException
  {
    sock.setTcpNoDelay(((Boolean)pset.getBooleanProperty(PropertyKey.tcpNoDelay).getValue()).booleanValue());
    sock.setKeepAlive(((Boolean)pset.getBooleanProperty(PropertyKey.tcpKeepAlive).getValue()).booleanValue());
    
    int receiveBufferSize = ((Integer)pset.getIntegerProperty(PropertyKey.tcpRcvBuf).getValue()).intValue();
    if (receiveBufferSize > 0) {
      sock.setReceiveBufferSize(receiveBufferSize);
    }
    int sendBufferSize = ((Integer)pset.getIntegerProperty(PropertyKey.tcpSndBuf).getValue()).intValue();
    if (sendBufferSize > 0) {
      sock.setSendBufferSize(sendBufferSize);
    }
    int trafficClass = ((Integer)pset.getIntegerProperty(PropertyKey.tcpTrafficClass).getValue()).intValue();
    if (trafficClass > 0) {
      sock.setTrafficClass(trafficClass);
    }
  }
  
  public <T extends Closeable> T connect(String hostname, int portNumber, PropertySet pset, int loginTimeout)
    throws IOException
  {
    loginTimeoutCountdown = loginTimeout;
    if (pset != null)
    {
      host = hostname;
      
      port = portNumber;
      
      String localSocketHostname = (String)pset.getStringProperty(PropertyKey.localSocketAddress).getValue();
      InetSocketAddress localSockAddr = null;
      if ((localSocketHostname != null) && (localSocketHostname.length() > 0)) {
        localSockAddr = new InetSocketAddress(InetAddress.getByName(localSocketHostname), 0);
      }
      int connectTimeout = ((Integer)pset.getIntegerProperty(PropertyKey.connectTimeout).getValue()).intValue();
      if (host != null)
      {
        InetAddress[] possibleAddresses = InetAddress.getAllByName(host);
        if (possibleAddresses.length == 0) {
          throw new SocketException("No addresses for host");
        }
        SocketException lastException = null;
        for (int i = 0; i < possibleAddresses.length; i++) {
          try
          {
            rawSocket = createSocket(pset);
            
            configureSocket(rawSocket, pset);
            
            InetSocketAddress sockAddr = new InetSocketAddress(possibleAddresses[i], port);
            if (localSockAddr != null) {
              rawSocket.bind(localSockAddr);
            }
            rawSocket.connect(sockAddr, getRealTimeout(connectTimeout));
          }
          catch (SocketException ex)
          {
            lastException = ex;
            resetLoginTimeCountdown();
            rawSocket = null;
          }
        }
        if ((rawSocket == null) && (lastException != null)) {
          throw lastException;
        }
        resetLoginTimeCountdown();
        
        sslSocket = rawSocket;
        return rawSocket;
      }
    }
    throw new SocketException("Unable to create socket");
  }
  
  public void beforeHandshake()
    throws IOException
  {
    resetLoginTimeCountdown();
    socketTimeoutBackup = rawSocket.getSoTimeout();
    rawSocket.setSoTimeout(getRealTimeout(socketTimeoutBackup));
  }
  
  public <T extends Closeable> T performTlsHandshake(SocketConnection socketConnection, ServerSession serverSession)
    throws IOException
  {
    sslSocket = ExportControlled.performTlsHandshake(rawSocket, socketConnection, serverSession == null ? null : serverSession
      .getServerVersion());
    return sslSocket;
  }
  
  public void afterHandshake()
    throws IOException
  {
    resetLoginTimeCountdown();
    rawSocket.setSoTimeout(socketTimeoutBackup);
  }
  
  protected void resetLoginTimeCountdown()
    throws SocketException
  {
    if (loginTimeoutCountdown > 0)
    {
      long now = System.currentTimeMillis();
      loginTimeoutCountdown = ((int)(loginTimeoutCountdown - (now - loginTimeoutCheckTimestamp)));
      if (loginTimeoutCountdown <= 0) {
        throw new SocketException(Messages.getString("Connection.LoginTimeout"));
      }
      loginTimeoutCheckTimestamp = now;
    }
  }
  
  protected int getRealTimeout(int expectedTimeout)
  {
    if ((loginTimeoutCountdown > 0) && ((expectedTimeout == 0) || (expectedTimeout > loginTimeoutCountdown))) {
      return loginTimeoutCountdown;
    }
    return expectedTimeout;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.StandardSocketFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */