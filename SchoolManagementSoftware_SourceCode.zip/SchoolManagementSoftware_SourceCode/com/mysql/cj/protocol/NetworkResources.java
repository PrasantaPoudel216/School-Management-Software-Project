package com.mysql.cj.protocol;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

public class NetworkResources
{
  private final Socket mysqlConnection;
  private final InputStream mysqlInput;
  private final OutputStream mysqlOutput;
  
  public NetworkResources(Socket mysqlConnection, InputStream mysqlInput, OutputStream mysqlOutput)
  {
    this.mysqlConnection = mysqlConnection;
    this.mysqlInput = mysqlInput;
    this.mysqlOutput = mysqlOutput;
  }
  
  /* Error */
  public final void forceClose()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   4: invokestatic 5	com/mysql/cj/protocol/ExportControlled:isSSLEstablished	(Ljava/net/Socket;)Z
    //   7: ifne +99 -> 106
    //   10: aload_0
    //   11: getfield 3	com/mysql/cj/protocol/NetworkResources:mysqlInput	Ljava/io/InputStream;
    //   14: ifnull +10 -> 24
    //   17: aload_0
    //   18: getfield 3	com/mysql/cj/protocol/NetworkResources:mysqlInput	Ljava/io/InputStream;
    //   21: invokevirtual 6	java/io/InputStream:close	()V
    //   24: aload_0
    //   25: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   28: ifnull +78 -> 106
    //   31: aload_0
    //   32: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   35: invokevirtual 7	java/net/Socket:isClosed	()Z
    //   38: ifne +68 -> 106
    //   41: aload_0
    //   42: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   45: invokevirtual 8	java/net/Socket:isInputShutdown	()Z
    //   48: ifne +58 -> 106
    //   51: aload_0
    //   52: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   55: invokevirtual 9	java/net/Socket:shutdownInput	()V
    //   58: goto +48 -> 106
    //   61: astore_1
    //   62: goto +44 -> 106
    //   65: astore_2
    //   66: aload_0
    //   67: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   70: ifnull +34 -> 104
    //   73: aload_0
    //   74: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   77: invokevirtual 7	java/net/Socket:isClosed	()Z
    //   80: ifne +24 -> 104
    //   83: aload_0
    //   84: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   87: invokevirtual 8	java/net/Socket:isInputShutdown	()Z
    //   90: ifne +14 -> 104
    //   93: aload_0
    //   94: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   97: invokevirtual 9	java/net/Socket:shutdownInput	()V
    //   100: goto +4 -> 104
    //   103: astore_3
    //   104: aload_2
    //   105: athrow
    //   106: goto +4 -> 110
    //   109: astore_1
    //   110: aload_0
    //   111: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   114: invokestatic 5	com/mysql/cj/protocol/ExportControlled:isSSLEstablished	(Ljava/net/Socket;)Z
    //   117: ifne +102 -> 219
    //   120: aload_0
    //   121: getfield 4	com/mysql/cj/protocol/NetworkResources:mysqlOutput	Ljava/io/OutputStream;
    //   124: ifnull +10 -> 134
    //   127: aload_0
    //   128: getfield 4	com/mysql/cj/protocol/NetworkResources:mysqlOutput	Ljava/io/OutputStream;
    //   131: invokevirtual 12	java/io/OutputStream:close	()V
    //   134: aload_0
    //   135: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   138: ifnull +81 -> 219
    //   141: aload_0
    //   142: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   145: invokevirtual 7	java/net/Socket:isClosed	()Z
    //   148: ifne +71 -> 219
    //   151: aload_0
    //   152: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   155: invokevirtual 13	java/net/Socket:isOutputShutdown	()Z
    //   158: ifne +61 -> 219
    //   161: aload_0
    //   162: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   165: invokevirtual 14	java/net/Socket:shutdownOutput	()V
    //   168: goto +51 -> 219
    //   171: astore_1
    //   172: goto +47 -> 219
    //   175: astore 4
    //   177: aload_0
    //   178: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   181: ifnull +35 -> 216
    //   184: aload_0
    //   185: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   188: invokevirtual 7	java/net/Socket:isClosed	()Z
    //   191: ifne +25 -> 216
    //   194: aload_0
    //   195: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   198: invokevirtual 13	java/net/Socket:isOutputShutdown	()Z
    //   201: ifne +15 -> 216
    //   204: aload_0
    //   205: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   208: invokevirtual 14	java/net/Socket:shutdownOutput	()V
    //   211: goto +5 -> 216
    //   214: astore 5
    //   216: aload 4
    //   218: athrow
    //   219: goto +4 -> 223
    //   222: astore_1
    //   223: aload_0
    //   224: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   227: ifnull +10 -> 237
    //   230: aload_0
    //   231: getfield 2	com/mysql/cj/protocol/NetworkResources:mysqlConnection	Ljava/net/Socket;
    //   234: invokevirtual 15	java/net/Socket:close	()V
    //   237: goto +4 -> 241
    //   240: astore_1
    //   241: return
    // Line number table:
    //   Java source line #53	-> byte code offset #0
    //   Java source line #55	-> byte code offset #10
    //   Java source line #56	-> byte code offset #17
    //   Java source line #59	-> byte code offset #24
    //   Java source line #61	-> byte code offset #51
    //   Java source line #64	-> byte code offset #58
    //   Java source line #62	-> byte code offset #61
    //   Java source line #64	-> byte code offset #62
    //   Java source line #59	-> byte code offset #65
    //   Java source line #61	-> byte code offset #93
    //   Java source line #64	-> byte code offset #100
    //   Java source line #62	-> byte code offset #103
    //   Java source line #66	-> byte code offset #104
    //   Java source line #70	-> byte code offset #106
    //   Java source line #68	-> byte code offset #109
    //   Java source line #73	-> byte code offset #110
    //   Java source line #75	-> byte code offset #120
    //   Java source line #76	-> byte code offset #127
    //   Java source line #79	-> byte code offset #134
    //   Java source line #81	-> byte code offset #161
    //   Java source line #84	-> byte code offset #168
    //   Java source line #82	-> byte code offset #171
    //   Java source line #84	-> byte code offset #172
    //   Java source line #79	-> byte code offset #175
    //   Java source line #81	-> byte code offset #204
    //   Java source line #84	-> byte code offset #211
    //   Java source line #82	-> byte code offset #214
    //   Java source line #86	-> byte code offset #216
    //   Java source line #90	-> byte code offset #219
    //   Java source line #88	-> byte code offset #222
    //   Java source line #93	-> byte code offset #223
    //   Java source line #94	-> byte code offset #230
    //   Java source line #98	-> byte code offset #237
    //   Java source line #96	-> byte code offset #240
    //   Java source line #99	-> byte code offset #241
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	242	0	this	NetworkResources
    //   61	1	1	localUnsupportedOperationException	UnsupportedOperationException
    //   109	1	1	localIOException	java.io.IOException
    //   171	1	1	localUnsupportedOperationException2	UnsupportedOperationException
    //   222	1	1	localIOException1	java.io.IOException
    //   240	1	1	localIOException2	java.io.IOException
    //   65	40	2	localObject1	Object
    //   103	1	3	localUnsupportedOperationException1	UnsupportedOperationException
    //   175	42	4	localObject2	Object
    //   214	1	5	localUnsupportedOperationException3	UnsupportedOperationException
    // Exception table:
    //   from	to	target	type
    //   51	58	61	java/lang/UnsupportedOperationException
    //   10	24	65	finally
    //   93	100	103	java/lang/UnsupportedOperationException
    //   0	106	109	java/io/IOException
    //   161	168	171	java/lang/UnsupportedOperationException
    //   120	134	175	finally
    //   175	177	175	finally
    //   204	211	214	java/lang/UnsupportedOperationException
    //   110	219	222	java/io/IOException
    //   223	237	240	java/io/IOException
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.NetworkResources
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */