package com.mysql.cj.protocol;

public abstract interface MessageListener<M extends Message>
  extends ProtocolEntityFactory<Boolean, M>
{
  public void error(Throwable ex)
  {
    ex.printStackTrace();
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.MessageListener
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */