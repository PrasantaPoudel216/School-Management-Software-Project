package com.mysql.cj.protocol;

public abstract interface ResultStreamer
{
  public abstract void finishStreaming();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ResultStreamer
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */