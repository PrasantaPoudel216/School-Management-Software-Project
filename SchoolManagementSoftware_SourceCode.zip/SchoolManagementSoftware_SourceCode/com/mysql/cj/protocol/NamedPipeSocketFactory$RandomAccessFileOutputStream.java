package com.mysql.cj.protocol;

import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;

class NamedPipeSocketFactory$RandomAccessFileOutputStream
  extends OutputStream
{
  RandomAccessFile raFile;
  
  NamedPipeSocketFactory$RandomAccessFileOutputStream(NamedPipeSocketFactory this$0, RandomAccessFile file)
  {
    raFile = file;
  }
  
  public void close()
    throws IOException
  {
    raFile.close();
  }
  
  public void write(byte[] b)
    throws IOException
  {
    raFile.write(b);
  }
  
  public void write(byte[] b, int off, int len)
    throws IOException
  {
    raFile.write(b, off, len);
  }
  
  public void write(int b)
    throws IOException
  {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.NamedPipeSocketFactory.RandomAccessFileOutputStream
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */