package com.mysql.cj.protocol;

import java.nio.ByteBuffer;
import java.nio.channels.CompletionHandler;

class SerializingBufferWriter$ByteBufferWrapper
{
  private ByteBuffer buffer;
  private CompletionHandler<Long, Void> handler = null;
  
  SerializingBufferWriter$ByteBufferWrapper(ByteBuffer buffer, CompletionHandler<Long, Void> completionHandler)
  {
    this.buffer = buffer;
    handler = completionHandler;
  }
  
  public ByteBuffer getBuffer()
  {
    return buffer;
  }
  
  public CompletionHandler<Long, Void> getHandler()
  {
    return handler;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.SerializingBufferWriter.ByteBufferWrapper
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */