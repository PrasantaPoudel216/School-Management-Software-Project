package com.mysql.cj.protocol;

import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import java.io.IOException;
import java.nio.channels.CompletionHandler;

public abstract interface MessageSender<M extends Message>
{
  public void send(byte[] message, int messageLen, byte messageSequence)
    throws IOException
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public void send(M message)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public void send(M message, CompletionHandler<Long, Void> callback)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public void setMaxAllowedPacket(int maxAllowedPacket)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public MessageSender<M> undecorateAll()
  {
    return this;
  }
  
  public MessageSender<M> undecorate()
  {
    return this;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.MessageSender
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */