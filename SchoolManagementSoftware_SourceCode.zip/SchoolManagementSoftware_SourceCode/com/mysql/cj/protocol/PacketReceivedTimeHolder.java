package com.mysql.cj.protocol;

public abstract interface PacketReceivedTimeHolder
{
  public long getLastPacketReceivedTime()
  {
    return 0L;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.PacketReceivedTimeHolder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */