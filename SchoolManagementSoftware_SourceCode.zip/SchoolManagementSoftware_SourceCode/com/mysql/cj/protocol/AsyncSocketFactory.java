package com.mysql.cj.protocol;

import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.CJCommunicationsException;
import java.io.Closeable;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.StandardSocketOptions;
import java.nio.channels.AsynchronousSocketChannel;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

public class AsyncSocketFactory
  implements SocketFactory
{
  AsynchronousSocketChannel channel;
  
  public <T extends Closeable> T connect(String host, int port, PropertySet props, int loginTimeout)
    throws IOException
  {
    try
    {
      channel = AsynchronousSocketChannel.open();
      
      channel.setOption(StandardSocketOptions.SO_SNDBUF, Integer.valueOf(131072));
      channel.setOption(StandardSocketOptions.SO_RCVBUF, Integer.valueOf(131072));
      
      Future<Void> connectPromise = channel.connect(new InetSocketAddress(host, port));
      connectPromise.get();
    }
    catch (CJCommunicationsException e)
    {
      throw e;
    }
    catch (IOException|InterruptedException|ExecutionException|RuntimeException ex)
    {
      throw new CJCommunicationsException(ex);
    }
    return channel;
  }
  
  public <T extends Closeable> T performTlsHandshake(SocketConnection socketConnection, ServerSession serverSession)
    throws IOException
  {
    channel = ExportControlled.startTlsOnAsynchronousChannel(channel, socketConnection);
    return channel;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.AsyncSocketFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */