package com.mysql.cj.protocol;

import java.util.List;

public abstract interface AuthenticationPlugin<M extends Message>
{
  public void init(Protocol<M> protocol) {}
  
  public void reset() {}
  
  public void destroy() {}
  
  public abstract String getProtocolPluginName();
  
  public abstract boolean requiresConfidentiality();
  
  public abstract boolean isReusable();
  
  public abstract void setAuthenticationParameters(String paramString1, String paramString2);
  
  public abstract boolean nextAuthenticationStep(M paramM, List<M> paramList);
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.AuthenticationPlugin
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */