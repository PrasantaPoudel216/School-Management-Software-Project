package com.mysql.cj.protocol;

import com.mysql.cj.result.Field;
import com.mysql.cj.result.ValueFactory;

public abstract interface ValueDecoder
{
  public abstract <T> T decodeDate(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeTime(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeTimestamp(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeInt1(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeUInt1(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeInt2(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeUInt2(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeInt4(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeUInt4(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeInt8(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeUInt8(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeFloat(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeDouble(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeDecimal(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeByteArray(byte[] paramArrayOfByte, int paramInt1, int paramInt2, Field paramField, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeBit(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeSet(byte[] paramArrayOfByte, int paramInt1, int paramInt2, Field paramField, ValueFactory<T> paramValueFactory);
  
  public abstract <T> T decodeYear(byte[] paramArrayOfByte, int paramInt1, int paramInt2, ValueFactory<T> paramValueFactory);
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ValueDecoder
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */