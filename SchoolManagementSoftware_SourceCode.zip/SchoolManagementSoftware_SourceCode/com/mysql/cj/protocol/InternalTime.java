package com.mysql.cj.protocol;

public class InternalTime
{
  private int hours = 0;
  private int minutes = 0;
  private int seconds = 0;
  private int nanos = 0;
  
  public InternalTime() {}
  
  public InternalTime(int hours, int minutes, int seconds, int nanos)
  {
    this.hours = hours;
    this.minutes = minutes;
    this.seconds = seconds;
    this.nanos = nanos;
  }
  
  public int getHours()
  {
    return hours;
  }
  
  public void setHours(int hours)
  {
    this.hours = hours;
  }
  
  public int getMinutes()
  {
    return minutes;
  }
  
  public void setMinutes(int minutes)
  {
    this.minutes = minutes;
  }
  
  public int getSeconds()
  {
    return seconds;
  }
  
  public void setSeconds(int seconds)
  {
    this.seconds = seconds;
  }
  
  public int getNanos()
  {
    return nanos;
  }
  
  public void setNanos(int nanos)
  {
    this.nanos = nanos;
  }
  
  public boolean isZero()
  {
    return (hours == 0) && (minutes == 0) && (seconds == 0) && (nanos == 0);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.InternalTime
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */