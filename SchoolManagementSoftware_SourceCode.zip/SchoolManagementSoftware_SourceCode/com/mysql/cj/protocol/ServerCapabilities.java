package com.mysql.cj.protocol;

import com.mysql.cj.ServerVersion;

public abstract interface ServerCapabilities
{
  public abstract int getCapabilityFlags();
  
  public abstract void setCapabilityFlags(int paramInt);
  
  public abstract ServerVersion getServerVersion();
  
  public abstract void setServerVersion(ServerVersion paramServerVersion);
  
  public abstract boolean serverSupportsFracSecs();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ServerCapabilities
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */