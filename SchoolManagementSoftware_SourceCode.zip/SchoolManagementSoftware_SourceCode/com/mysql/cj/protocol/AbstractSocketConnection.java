package com.mysql.cj.protocol;

import com.mysql.cj.Messages;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.UnableToConnectException;
import com.mysql.jdbc.SocketFactoryWrapper;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;

public abstract class AbstractSocketConnection
  implements SocketConnection
{
  protected String host = null;
  protected int port = 3306;
  protected SocketFactory socketFactory = null;
  protected Socket mysqlSocket = null;
  protected FullReadInputStream mysqlInput = null;
  protected BufferedOutputStream mysqlOutput = null;
  protected ExceptionInterceptor exceptionInterceptor;
  protected PropertySet propertySet;
  
  public String getHost()
  {
    return host;
  }
  
  public int getPort()
  {
    return port;
  }
  
  public Socket getMysqlSocket()
  {
    return mysqlSocket;
  }
  
  public FullReadInputStream getMysqlInput()
    throws IOException
  {
    if (mysqlInput != null) {
      return mysqlInput;
    }
    throw new IOException(Messages.getString("SocketConnection.2"));
  }
  
  public void setMysqlInput(FullReadInputStream mysqlInput)
  {
    this.mysqlInput = mysqlInput;
  }
  
  public BufferedOutputStream getMysqlOutput()
    throws IOException
  {
    if (mysqlOutput != null) {
      return mysqlOutput;
    }
    throw new IOException(Messages.getString("SocketConnection.2"));
  }
  
  public boolean isSSLEstablished()
  {
    return (ExportControlled.enabled()) && (ExportControlled.isSSLEstablished(getMysqlSocket()));
  }
  
  public SocketFactory getSocketFactory()
  {
    return socketFactory;
  }
  
  public void setSocketFactory(SocketFactory socketFactory)
  {
    this.socketFactory = socketFactory;
  }
  
  /* Error */
  public void forceClose()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 15	com/mysql/cj/protocol/AbstractSocketConnection:getNetworkResources	()Lcom/mysql/cj/protocol/NetworkResources;
    //   4: invokevirtual 16	com/mysql/cj/protocol/NetworkResources:forceClose	()V
    //   7: aload_0
    //   8: aconst_null
    //   9: putfield 5	com/mysql/cj/protocol/AbstractSocketConnection:mysqlSocket	Ljava/net/Socket;
    //   12: aload_0
    //   13: aconst_null
    //   14: putfield 6	com/mysql/cj/protocol/AbstractSocketConnection:mysqlInput	Lcom/mysql/cj/protocol/FullReadInputStream;
    //   17: aload_0
    //   18: aconst_null
    //   19: putfield 7	com/mysql/cj/protocol/AbstractSocketConnection:mysqlOutput	Ljava/io/BufferedOutputStream;
    //   22: goto +21 -> 43
    //   25: astore_1
    //   26: aload_0
    //   27: aconst_null
    //   28: putfield 5	com/mysql/cj/protocol/AbstractSocketConnection:mysqlSocket	Ljava/net/Socket;
    //   31: aload_0
    //   32: aconst_null
    //   33: putfield 6	com/mysql/cj/protocol/AbstractSocketConnection:mysqlInput	Lcom/mysql/cj/protocol/FullReadInputStream;
    //   36: aload_0
    //   37: aconst_null
    //   38: putfield 7	com/mysql/cj/protocol/AbstractSocketConnection:mysqlOutput	Ljava/io/BufferedOutputStream;
    //   41: aload_1
    //   42: athrow
    //   43: return
    // Line number table:
    //   Java source line #103	-> byte code offset #0
    //   Java source line #105	-> byte code offset #7
    //   Java source line #106	-> byte code offset #12
    //   Java source line #107	-> byte code offset #17
    //   Java source line #108	-> byte code offset #22
    //   Java source line #105	-> byte code offset #25
    //   Java source line #106	-> byte code offset #31
    //   Java source line #107	-> byte code offset #36
    //   Java source line #108	-> byte code offset #41
    //   Java source line #109	-> byte code offset #43
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	44	0	this	AbstractSocketConnection
    //   25	17	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   0	7	25	finally
  }
  
  public NetworkResources getNetworkResources()
  {
    return new NetworkResources(mysqlSocket, mysqlInput, mysqlOutput);
  }
  
  public ExceptionInterceptor getExceptionInterceptor()
  {
    return exceptionInterceptor;
  }
  
  public PropertySet getPropertySet()
  {
    return propertySet;
  }
  
  protected SocketFactory createSocketFactory(String socketFactoryClassName)
  {
    try
    {
      if (socketFactoryClassName == null) {
        throw ((UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, Messages.getString("SocketConnection.0"), getExceptionInterceptor()));
      }
      Object sf = Class.forName(socketFactoryClassName).newInstance();
      if ((sf instanceof SocketFactory)) {
        return (SocketFactory)Class.forName(socketFactoryClassName).newInstance();
      }
      return new SocketFactoryWrapper(sf);
    }
    catch (InstantiationException|IllegalAccessException|ClassNotFoundException|CJException ex)
    {
      throw ((UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, 
        Messages.getString("SocketConnection.1", new String[] { socketFactoryClassName }), getExceptionInterceptor()));
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.AbstractSocketConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */