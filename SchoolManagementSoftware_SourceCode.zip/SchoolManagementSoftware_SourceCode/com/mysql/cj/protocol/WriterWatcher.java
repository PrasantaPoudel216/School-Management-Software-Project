package com.mysql.cj.protocol;

public abstract interface WriterWatcher
{
  public abstract void writerClosed(WatchableWriter paramWatchableWriter);
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.WriterWatcher
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */