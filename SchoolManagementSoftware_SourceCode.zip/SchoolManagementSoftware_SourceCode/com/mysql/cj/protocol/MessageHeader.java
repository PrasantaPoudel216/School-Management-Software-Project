package com.mysql.cj.protocol;

import java.nio.ByteBuffer;

public abstract interface MessageHeader
{
  public abstract ByteBuffer getBuffer();
  
  public abstract int getMessageSize();
  
  public abstract byte getMessageSequence();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.MessageHeader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */