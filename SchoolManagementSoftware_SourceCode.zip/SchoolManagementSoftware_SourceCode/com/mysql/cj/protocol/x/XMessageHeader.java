package com.mysql.cj.protocol.x;

import com.mysql.cj.protocol.MessageHeader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class XMessageHeader
  implements MessageHeader
{
  private ByteBuffer headerBuf;
  private int messageType = -1;
  private int messageSize = -1;
  
  public XMessageHeader()
  {
    headerBuf = ByteBuffer.allocate(5).order(ByteOrder.LITTLE_ENDIAN);
  }
  
  public XMessageHeader(byte[] buf)
  {
    headerBuf = ByteBuffer.wrap(buf).order(ByteOrder.LITTLE_ENDIAN);
  }
  
  private void parseBuffer()
  {
    if (messageSize == -1)
    {
      headerBuf.position(0);
      messageSize = (headerBuf.getInt() - 1);
      messageType = headerBuf.get();
    }
  }
  
  public ByteBuffer getBuffer()
  {
    return headerBuf;
  }
  
  public int getMessageSize()
  {
    parseBuffer();
    return messageSize;
  }
  
  public byte getMessageSequence()
  {
    return 0;
  }
  
  public int getMessageType()
  {
    parseBuffer();
    return messageType;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XMessageHeader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */