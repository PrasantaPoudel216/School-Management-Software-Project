package com.mysql.cj.protocol.x;

import com.google.protobuf.ByteString;
import com.mysql.cj.exceptions.DataReadException;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.Row;
import com.mysql.cj.result.ValueFactory;
import com.mysql.cj.x.protobuf.MysqlxResultset.Row;

public class XProtocolRow
  implements Row
{
  private ColumnDefinition metadata;
  private MysqlxResultset.Row rowMessage;
  private boolean wasNull = false;
  
  public XProtocolRow(ColumnDefinition metadata, MysqlxResultset.Row rowMessage)
  {
    this.metadata = metadata;
    this.rowMessage = rowMessage;
  }
  
  public <T> T getValue(int columnIndex, ValueFactory<T> vf)
  {
    if (columnIndex >= metadata.getFields().length) {
      throw new DataReadException("Invalid column");
    }
    Field f = metadata.getFields()[columnIndex];
    ByteString byteString = rowMessage.getField(columnIndex);
    if (byteString.size() == 0)
    {
      T result = vf.createFromNull();
      wasNull = (result == null);
      return result;
    }
    switch (f.getMysqlTypeId())
    {
    case 16: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeBit(byteString.toByteArray(), 0, byteString.size(), vf);
    case 12: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeTimestamp(byteString.toByteArray(), 0, byteString.size(), vf);
    case 5: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeDouble(byteString.toByteArray(), 0, byteString.size(), vf);
    case 247: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeByteArray(byteString.toByteArray(), 0, byteString.size(), f, vf);
    case 4: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeFloat(byteString.toByteArray(), 0, byteString.size(), vf);
    case 245: 
      wasNull = false;
      
      return (T)XProtocolDecoder.instance.decodeByteArray(byteString.toByteArray(), 0, byteString.size(), f, vf);
    case 8: 
      wasNull = false;
      if (f.isUnsigned()) {
        return (T)XProtocolDecoder.instance.decodeUInt8(byteString.toByteArray(), 0, byteString.size(), vf);
      }
      return (T)XProtocolDecoder.instance.decodeInt8(byteString.toByteArray(), 0, byteString.size(), vf);
    case 246: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeDecimal(byteString.toByteArray(), 0, byteString.size(), vf);
    case 248: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeSet(byteString.toByteArray(), 0, byteString.size(), f, vf);
    case 11: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeTime(byteString.toByteArray(), 0, byteString.size(), vf);
    case 15: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeByteArray(byteString.toByteArray(), 0, byteString.size(), f, vf);
    case 253: 
      wasNull = false;
      return (T)XProtocolDecoder.instance.decodeByteArray(byteString.toByteArray(), 0, byteString.size(), f, vf);
    }
    throw new DataReadException("Unknown MySQL type constant: " + f.getMysqlTypeId());
  }
  
  public boolean getNull(int columnIndex)
  {
    ByteString byteString = rowMessage.getField(columnIndex);
    wasNull = (byteString.size() == 0);
    return wasNull;
  }
  
  public boolean wasNull()
  {
    return wasNull;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XProtocolRow
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */