package com.mysql.cj.protocol.x;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Scalar;
import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;
import com.mysql.cj.x.protobuf.MysqlxNotice.SessionStateChanged;
import com.mysql.cj.x.protobuf.MysqlxNotice.SessionStateChanged.Parameter;
import java.util.List;

public class Notice$XSessionStateChanged
  extends Notice
{
  private Integer paramType = null;
  private List<MysqlxDatatypes.Scalar> valueList = null;
  
  public Notice$XSessionStateChanged(MysqlxNotice.Frame frm)
  {
    super(frm);
    MysqlxNotice.SessionStateChanged ssmsg = (MysqlxNotice.SessionStateChanged)parseNotice(frm.getPayload(), MysqlxNotice.SessionStateChanged.class);
    paramType = Integer.valueOf(ssmsg.getParam().getNumber());
    valueList = ssmsg.getValueList();
  }
  
  public Integer getParamType()
  {
    return paramType;
  }
  
  public List<MysqlxDatatypes.Scalar> getValueList()
  {
    return valueList;
  }
  
  public MysqlxDatatypes.Scalar getValue()
  {
    if ((valueList != null) && (!valueList.isEmpty())) {
      return (MysqlxDatatypes.Scalar)valueList.get(0);
    }
    return null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.Notice.XSessionStateChanged
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */