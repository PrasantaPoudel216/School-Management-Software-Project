package com.mysql.cj.protocol.x;

import com.mysql.cj.protocol.Warning;
import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;
import com.mysql.cj.x.protobuf.MysqlxNotice.Warning;
import com.mysql.cj.x.protobuf.MysqlxNotice.Warning.Level;

public class Notice$XWarning
  extends Notice
  implements Warning
{
  private int level;
  private long code;
  private String message;
  
  public Notice$XWarning(MysqlxNotice.Frame frm)
  {
    super(frm);
    MysqlxNotice.Warning warn = (MysqlxNotice.Warning)parseNotice(frm.getPayload(), MysqlxNotice.Warning.class);
    level = warn.getLevel().getNumber();
    code = Integer.toUnsignedLong(warn.getCode());
    message = warn.getMsg();
  }
  
  public int getLevel()
  {
    return level;
  }
  
  public long getCode()
  {
    return code;
  }
  
  public String getMessage()
  {
    return message;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.Notice.XWarning
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */