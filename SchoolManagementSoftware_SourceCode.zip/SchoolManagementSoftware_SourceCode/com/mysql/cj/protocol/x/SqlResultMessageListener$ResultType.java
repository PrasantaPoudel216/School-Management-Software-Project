package com.mysql.cj.protocol.x;

 enum SqlResultMessageListener$ResultType
{
  UPDATE,  DATA;
  
  private SqlResultMessageListener$ResultType() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.SqlResultMessageListener.ResultType
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */