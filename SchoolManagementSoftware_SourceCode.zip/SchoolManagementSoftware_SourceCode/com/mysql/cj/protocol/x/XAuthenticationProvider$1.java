package com.mysql.cj.protocol.x;

class XAuthenticationProvider$1 {}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XAuthenticationProvider.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */