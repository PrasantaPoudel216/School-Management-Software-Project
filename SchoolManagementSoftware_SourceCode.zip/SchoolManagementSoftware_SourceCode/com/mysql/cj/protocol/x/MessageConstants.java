package com.mysql.cj.protocol.x;

import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.MessageLite;
import com.google.protobuf.Parser;
import com.mysql.cj.exceptions.AssertionFailedException;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.x.protobuf.Mysqlx.Error;
import com.mysql.cj.x.protobuf.Mysqlx.Ok;
import com.mysql.cj.x.protobuf.Mysqlx.ServerMessages.Type;
import com.mysql.cj.x.protobuf.MysqlxConnection.Capabilities;
import com.mysql.cj.x.protobuf.MysqlxConnection.CapabilitiesGet;
import com.mysql.cj.x.protobuf.MysqlxConnection.CapabilitiesSet;
import com.mysql.cj.x.protobuf.MysqlxCrud.CreateView;
import com.mysql.cj.x.protobuf.MysqlxCrud.Delete;
import com.mysql.cj.x.protobuf.MysqlxCrud.DropView;
import com.mysql.cj.x.protobuf.MysqlxCrud.Find;
import com.mysql.cj.x.protobuf.MysqlxCrud.Insert;
import com.mysql.cj.x.protobuf.MysqlxCrud.ModifyView;
import com.mysql.cj.x.protobuf.MysqlxCrud.Update;
import com.mysql.cj.x.protobuf.MysqlxExpect.Open;
import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;
import com.mysql.cj.x.protobuf.MysqlxNotice.SessionStateChanged;
import com.mysql.cj.x.protobuf.MysqlxNotice.SessionVariableChanged;
import com.mysql.cj.x.protobuf.MysqlxNotice.Warning;
import com.mysql.cj.x.protobuf.MysqlxPrepare.Deallocate;
import com.mysql.cj.x.protobuf.MysqlxPrepare.Execute;
import com.mysql.cj.x.protobuf.MysqlxPrepare.Prepare;
import com.mysql.cj.x.protobuf.MysqlxResultset.ColumnMetaData;
import com.mysql.cj.x.protobuf.MysqlxResultset.FetchDone;
import com.mysql.cj.x.protobuf.MysqlxResultset.FetchDoneMoreResultsets;
import com.mysql.cj.x.protobuf.MysqlxResultset.Row;
import com.mysql.cj.x.protobuf.MysqlxSession.AuthenticateContinue;
import com.mysql.cj.x.protobuf.MysqlxSession.AuthenticateOk;
import com.mysql.cj.x.protobuf.MysqlxSession.AuthenticateStart;
import com.mysql.cj.x.protobuf.MysqlxSession.Close;
import com.mysql.cj.x.protobuf.MysqlxSession.Reset;
import com.mysql.cj.x.protobuf.MysqlxSql.StmtExecute;
import com.mysql.cj.x.protobuf.MysqlxSql.StmtExecuteOk;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class MessageConstants
{
  public static final Map<Class<? extends GeneratedMessageV3>, Parser<? extends GeneratedMessageV3>> MESSAGE_CLASS_TO_PARSER;
  public static final Map<Class<? extends GeneratedMessageV3>, Integer> MESSAGE_CLASS_TO_TYPE;
  public static final Map<Integer, Class<? extends GeneratedMessageV3>> MESSAGE_TYPE_TO_CLASS;
  public static final Map<Class<? extends MessageLite>, Integer> MESSAGE_CLASS_TO_CLIENT_MESSAGE_TYPE;
  
  static
  {
    Map<Class<? extends GeneratedMessageV3>, Parser<? extends GeneratedMessageV3>> messageClassToParser = new HashMap();
    Map<Class<? extends GeneratedMessageV3>, Integer> messageClassToType = new HashMap();
    Map<Integer, Class<? extends GeneratedMessageV3>> messageTypeToClass = new HashMap();
    
    messageClassToParser.put(Mysqlx.Error.class, Mysqlx.Error.getDefaultInstance().getParserForType());
    messageClassToParser.put(Mysqlx.Ok.class, Mysqlx.Ok.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxSession.AuthenticateContinue.class, MysqlxSession.AuthenticateContinue.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxSession.AuthenticateOk.class, MysqlxSession.AuthenticateOk.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxConnection.Capabilities.class, MysqlxConnection.Capabilities.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxResultset.ColumnMetaData.class, MysqlxResultset.ColumnMetaData.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxResultset.FetchDone.class, MysqlxResultset.FetchDone.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxResultset.FetchDoneMoreResultsets.class, MysqlxResultset.FetchDoneMoreResultsets.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxNotice.Frame.class, MysqlxNotice.Frame.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxResultset.Row.class, MysqlxResultset.Row.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxSql.StmtExecuteOk.class, MysqlxSql.StmtExecuteOk.getDefaultInstance().getParserForType());
    
    messageClassToParser.put(MysqlxNotice.SessionStateChanged.class, MysqlxNotice.SessionStateChanged.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxNotice.SessionVariableChanged.class, MysqlxNotice.SessionVariableChanged.getDefaultInstance().getParserForType());
    messageClassToParser.put(MysqlxNotice.Warning.class, MysqlxNotice.Warning.getDefaultInstance().getParserForType());
    
    messageClassToType.put(Mysqlx.Error.class, Integer.valueOf(1));
    messageClassToType.put(Mysqlx.Ok.class, Integer.valueOf(0));
    messageClassToType.put(MysqlxSession.AuthenticateContinue.class, Integer.valueOf(3));
    messageClassToType.put(MysqlxSession.AuthenticateOk.class, Integer.valueOf(4));
    messageClassToType.put(MysqlxConnection.Capabilities.class, Integer.valueOf(2));
    messageClassToType.put(MysqlxResultset.ColumnMetaData.class, Integer.valueOf(12));
    messageClassToType.put(MysqlxResultset.FetchDone.class, Integer.valueOf(14));
    messageClassToType.put(MysqlxResultset.FetchDoneMoreResultsets.class, Integer.valueOf(16));
    messageClassToType.put(MysqlxNotice.Frame.class, Integer.valueOf(11));
    messageClassToType.put(MysqlxResultset.Row.class, Integer.valueOf(13));
    messageClassToType.put(MysqlxSql.StmtExecuteOk.class, Integer.valueOf(17));
    for (Map.Entry<Class<? extends GeneratedMessageV3>, Integer> entry : messageClassToType.entrySet()) {
      messageTypeToClass.put(entry.getValue(), entry.getKey());
    }
    MESSAGE_CLASS_TO_PARSER = Collections.unmodifiableMap(messageClassToParser);
    MESSAGE_CLASS_TO_TYPE = Collections.unmodifiableMap(messageClassToType);
    MESSAGE_TYPE_TO_CLASS = Collections.unmodifiableMap(messageTypeToClass);
    
    Object messageClassToClientMessageType = new HashMap();
    ((Map)messageClassToClientMessageType).put(MysqlxSession.AuthenticateStart.class, Integer.valueOf(4));
    ((Map)messageClassToClientMessageType).put(MysqlxSession.AuthenticateContinue.class, Integer.valueOf(5));
    ((Map)messageClassToClientMessageType).put(MysqlxConnection.CapabilitiesGet.class, Integer.valueOf(1));
    ((Map)messageClassToClientMessageType).put(MysqlxConnection.CapabilitiesSet.class, Integer.valueOf(2));
    ((Map)messageClassToClientMessageType).put(MysqlxSession.Close.class, Integer.valueOf(7));
    ((Map)messageClassToClientMessageType).put(MysqlxCrud.Delete.class, Integer.valueOf(20));
    ((Map)messageClassToClientMessageType).put(MysqlxCrud.Find.class, Integer.valueOf(17));
    ((Map)messageClassToClientMessageType).put(MysqlxCrud.Insert.class, Integer.valueOf(18));
    ((Map)messageClassToClientMessageType).put(MysqlxSession.Reset.class, Integer.valueOf(6));
    ((Map)messageClassToClientMessageType).put(MysqlxSql.StmtExecute.class, Integer.valueOf(12));
    ((Map)messageClassToClientMessageType).put(MysqlxCrud.Update.class, Integer.valueOf(19));
    ((Map)messageClassToClientMessageType).put(MysqlxCrud.CreateView.class, Integer.valueOf(30));
    ((Map)messageClassToClientMessageType).put(MysqlxCrud.ModifyView.class, Integer.valueOf(31));
    ((Map)messageClassToClientMessageType).put(MysqlxCrud.DropView.class, Integer.valueOf(32));
    ((Map)messageClassToClientMessageType).put(MysqlxExpect.Open.class, Integer.valueOf(24));
    ((Map)messageClassToClientMessageType).put(MysqlxPrepare.Prepare.class, Integer.valueOf(40));
    ((Map)messageClassToClientMessageType).put(MysqlxPrepare.Execute.class, Integer.valueOf(41));
    ((Map)messageClassToClientMessageType).put(MysqlxPrepare.Deallocate.class, Integer.valueOf(42));
    MESSAGE_CLASS_TO_CLIENT_MESSAGE_TYPE = Collections.unmodifiableMap((Map)messageClassToClientMessageType);
  }
  
  public static int getTypeForMessageClass(Class<? extends MessageLite> msgClass)
  {
    Integer tag = (Integer)MESSAGE_CLASS_TO_CLIENT_MESSAGE_TYPE.get(msgClass);
    if (tag == null) {
      throw new WrongArgumentException("No mapping to ClientMessages for message class " + msgClass.getSimpleName());
    }
    return tag.intValue();
  }
  
  public static Class<? extends GeneratedMessageV3> getMessageClassForType(int type)
  {
    Class<? extends GeneratedMessageV3> messageClass = (Class)MESSAGE_TYPE_TO_CLASS.get(Integer.valueOf(type));
    if (messageClass == null)
    {
      Mysqlx.ServerMessages.Type serverMessageMapping = Mysqlx.ServerMessages.Type.forNumber(type);
      throw AssertionFailedException.shouldNotHappen("Unknown message type: " + type + " (server messages mapping: " + serverMessageMapping + ")");
    }
    return messageClass;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.MessageConstants
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */