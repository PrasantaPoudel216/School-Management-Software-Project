package com.mysql.cj.protocol.x;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

class XMessageBuilder$2
  implements CallbackHandler
{
  XMessageBuilder$2(XMessageBuilder this$0) {}
  
  public void handle(Callback[] callbacks)
    throws UnsupportedCallbackException
  {
    Callback[] arrayOfCallback = callbacks;int i = arrayOfCallback.length;int j = 0;
    if (j < i)
    {
      Callback c = arrayOfCallback[j];
      if (NameCallback.class.isAssignableFrom(c.getClass())) {
        throw new UnsupportedCallbackException(c);
      }
      if (PasswordCallback.class.isAssignableFrom(c.getClass())) {
        throw new UnsupportedCallbackException(c);
      }
      throw new UnsupportedCallbackException(c);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XMessageBuilder.2
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */