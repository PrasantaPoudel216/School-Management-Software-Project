package com.mysql.cj.protocol.x;

import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.protocol.MessageListener;
import com.mysql.cj.protocol.SocketConnection;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousCloseException;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.CompletableFuture;

class AsyncMessageReader$HeaderCompletionHandler
  implements CompletionHandler<Integer, Void>
{
  public AsyncMessageReader$HeaderCompletionHandler(AsyncMessageReader paramAsyncMessageReader) {}
  
  public void completed(Integer bytesRead, Void attachment)
  {
    if (bytesRead.intValue() < 0)
    {
      this$0.onError(new CJCommunicationsException("Socket closed"));
      return;
    }
    try
    {
      if (this$0.currentReadResult == null)
      {
        this$0.currentReadResult = new AsyncMessageReader.CompletedRead();
        this$0.currentReadResult.header = new XMessageHeader();
      }
      if (this$0.currentReadResult.header.getBuffer().position() < 5)
      {
        this$0.sc.getAsynchronousSocketChannel().read(this$0.currentReadResult.header.getBuffer(), null, this);
        return;
      }
      this$0.messageBuf = ByteBuffer.allocate(this$0.currentReadResult.header.getMessageSize());
      if (this$0.getMessageListener(false) == null) {
        synchronized (this$0.pendingMsgMonitor)
        {
          this$0.pendingMsgHeader = CompletableFuture.completedFuture(this$0.currentReadResult.header);
          this$0.pendingMsgMonitor.notify();
        }
      }
      this$0.messageCompletionHandler.completed(Integer.valueOf(0), null);
    }
    catch (Throwable t)
    {
      this$0.onError(t);
    }
  }
  
  public void failed(Throwable exc, Void attachment)
  {
    if (this$0.getMessageListener(false) != null)
    {
      synchronized (this$0.pendingMsgMonitor)
      {
        this$0.pendingMsgMonitor.notify();
      }
      if (AsynchronousCloseException.class.equals(exc.getClass())) {
        this$0.currentMessageListener.error(new CJCommunicationsException("Socket closed", exc));
      } else {
        this$0.currentMessageListener.error(exc);
      }
    }
    this$0.currentMessageListener = null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.AsyncMessageReader.HeaderCompletionHandler
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */