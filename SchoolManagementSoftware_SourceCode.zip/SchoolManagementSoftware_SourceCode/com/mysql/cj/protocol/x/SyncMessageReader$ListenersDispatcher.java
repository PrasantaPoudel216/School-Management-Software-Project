package com.mysql.cj.protocol.x;

import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.protocol.MessageListener;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.TimeUnit;

class SyncMessageReader$ListenersDispatcher
  implements Runnable
{
  private static final long POLL_TIMEOUT = 100L;
  boolean started = false;
  
  public SyncMessageReader$ListenersDispatcher(SyncMessageReader paramSyncMessageReader) {}
  
  public void run()
  {
    synchronized (this$0.waitingSyncOperationMonitor)
    {
      started = true;
      try
      {
        for (;;)
        {
          MessageListener<XMessage> l;
          if ((l = (MessageListener)this$0.messageListenerQueue.poll(100L, TimeUnit.MILLISECONDS)) == null) {
            synchronized (this$0.dispatchingThreadMonitor)
            {
              if (this$0.messageListenerQueue.peek() == null)
              {
                this$0.dispatchingThread = null;
                break;
              }
            }
          } else {
            try
            {
              XMessage msg = null;
              do
              {
                XMessageHeader hdr = this$0.readHeader();
                msg = this$0.readMessage(null, hdr);
              } while (!((Boolean)l.createFromMessage(msg)).booleanValue());
            }
            catch (Throwable t)
            {
              l.error(t);
            }
          }
        }
      }
      catch (InterruptedException e)
      {
        throw new CJCommunicationsException("Read operation interrupted.", e);
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.SyncMessageReader.ListenersDispatcher
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */