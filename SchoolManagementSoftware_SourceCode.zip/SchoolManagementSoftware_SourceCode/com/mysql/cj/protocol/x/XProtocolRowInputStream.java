package com.mysql.cj.protocol.x;

import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.result.RowList;
import java.util.NoSuchElementException;

public class XProtocolRowInputStream
  implements RowList
{
  private ColumnDefinition metadata;
  private XProtocol protocol;
  private boolean isDone = false;
  private int position = -1;
  private XProtocolRow next;
  
  public XProtocolRowInputStream(ColumnDefinition metadata, XProtocol protocol)
  {
    this.metadata = metadata;
    this.protocol = protocol;
  }
  
  public XProtocolRow readRow()
  {
    if (!hasNext())
    {
      isDone = true;
      return null;
    }
    position += 1;
    XProtocolRow r = next;
    next = null;
    return r;
  }
  
  public XProtocolRow next()
  {
    if (!hasNext()) {
      throw new NoSuchElementException();
    }
    return readRow();
  }
  
  public boolean hasNext()
  {
    if (isDone) {
      return false;
    }
    if (next == null) {
      next = protocol.readRowOrNull(metadata);
    }
    return next != null;
  }
  
  public int getPosition()
  {
    return position;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XProtocolRowInputStream
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */