package com.mysql.cj.protocol.x;

import com.google.protobuf.CodedInputStream;
import com.google.protobuf.GeneratedMessageV3;
import com.google.protobuf.InvalidProtocolBufferException;
import com.google.protobuf.Parser;
import com.mysql.cj.exceptions.AssertionFailedException;
import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.protocol.MessageListener;
import com.mysql.cj.protocol.SocketConnection;
import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousCloseException;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.Map;
import java.util.concurrent.BlockingQueue;

class AsyncMessageReader$MessageCompletionHandler
  implements CompletionHandler<Integer, Void>
{
  public AsyncMessageReader$MessageCompletionHandler(AsyncMessageReader paramAsyncMessageReader) {}
  
  public void completed(Integer bytesRead, Void attachment)
  {
    if (bytesRead.intValue() < 0)
    {
      this$0.onError(new CJCommunicationsException("Socket closed"));
      return;
    }
    try
    {
      if (this$0.messageBuf.position() < this$0.currentReadResult.header.getMessageSize())
      {
        this$0.sc.getAsynchronousSocketChannel().read(this$0.messageBuf, null, this);
        return;
      }
      ByteBuffer buf = this$0.messageBuf;
      this$0.messageBuf = null;
      
      Class<? extends GeneratedMessageV3> messageClass = MessageConstants.getMessageClassForType(this$0.currentReadResult.header.getMessageType());
      
      boolean localStopAfterNextMessage = this$0.stopAfterNextMessage;
      
      buf.flip();
      this$0.currentReadResult.message = parseMessage(messageClass, buf);
      this$0.pendingCompletedReadQueue.add(this$0.currentReadResult);
      this$0.currentReadResult = null;
      
      this$0.dispatchMessage();
      if ((localStopAfterNextMessage) && (messageClass != MysqlxNotice.Frame.class))
      {
        this$0.stopAfterNextMessage = false;
        this$0.currentReadResult = null;
        return;
      }
      this$0.headerCompletionHandler.completed(Integer.valueOf(0), null);
    }
    catch (Throwable t)
    {
      this$0.onError(t);
    }
  }
  
  public void failed(Throwable exc, Void attachment)
  {
    if (this$0.getMessageListener(false) != null)
    {
      synchronized (this$0.pendingMsgMonitor)
      {
        this$0.pendingMsgMonitor.notify();
      }
      if (AsynchronousCloseException.class.equals(exc.getClass())) {
        this$0.currentMessageListener.error(new CJCommunicationsException("Socket closed", exc));
      } else {
        this$0.currentMessageListener.error(exc);
      }
    }
    this$0.currentMessageListener = null;
  }
  
  private GeneratedMessageV3 parseMessage(Class<? extends GeneratedMessageV3> messageClass, ByteBuffer buf)
  {
    try
    {
      Parser<? extends GeneratedMessageV3> parser = (Parser)MessageConstants.MESSAGE_CLASS_TO_PARSER.get(messageClass);
      return (GeneratedMessageV3)parser.parseFrom(CodedInputStream.newInstance(buf));
    }
    catch (InvalidProtocolBufferException ex)
    {
      throw AssertionFailedException.shouldNotHappen(ex);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.AsyncMessageReader.MessageCompletionHandler
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */