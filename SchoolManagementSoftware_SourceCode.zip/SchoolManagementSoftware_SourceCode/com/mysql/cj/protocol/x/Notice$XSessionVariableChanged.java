package com.mysql.cj.protocol.x;

import com.mysql.cj.x.protobuf.MysqlxDatatypes.Scalar;
import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;
import com.mysql.cj.x.protobuf.MysqlxNotice.SessionVariableChanged;

public class Notice$XSessionVariableChanged
  extends Notice
{
  private String paramName = null;
  private MysqlxDatatypes.Scalar value = null;
  
  public Notice$XSessionVariableChanged(MysqlxNotice.Frame frm)
  {
    super(frm);
    MysqlxNotice.SessionVariableChanged svmsg = (MysqlxNotice.SessionVariableChanged)parseNotice(frm.getPayload(), MysqlxNotice.SessionVariableChanged.class);
    paramName = svmsg.getParam();
    value = svmsg.getValue();
  }
  
  public String getParamName()
  {
    return paramName;
  }
  
  public MysqlxDatatypes.Scalar getValue()
  {
    return value;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.Notice.XSessionVariableChanged
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */