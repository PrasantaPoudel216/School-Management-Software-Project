package com.mysql.cj.protocol.x;

import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.FeatureNotAvailableException;
import com.mysql.cj.exceptions.SSLParamsException;
import com.mysql.cj.log.Log;
import com.mysql.cj.protocol.AbstractSocketConnection;
import com.mysql.cj.protocol.AsyncSocketFactory;
import com.mysql.cj.protocol.FullReadInputStream;
import com.mysql.cj.protocol.NetworkResources;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.SocketConnection;
import com.mysql.cj.protocol.SocketFactory;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.channels.AsynchronousSocketChannel;

public class XAsyncSocketConnection
  extends AbstractSocketConnection
  implements SocketConnection
{
  AsynchronousSocketChannel channel;
  
  public void connect(String hostName, int portNumber, PropertySet propSet, ExceptionInterceptor excInterceptor, Log log, int loginTimeout)
  {
    port = portNumber;
    host = hostName;
    propertySet = propSet;
    socketFactory = new AsyncSocketFactory();
    try
    {
      channel = ((AsynchronousSocketChannel)socketFactory.connect(hostName, portNumber, propSet, loginTimeout));
    }
    catch (CJCommunicationsException e)
    {
      throw e;
    }
    catch (IOException|RuntimeException ex)
    {
      throw new CJCommunicationsException(ex);
    }
  }
  
  public void performTlsHandshake(ServerSession serverSession)
    throws SSLParamsException, FeatureNotAvailableException, IOException
  {
    channel = ((AsynchronousSocketChannel)socketFactory.performTlsHandshake(this, serverSession));
  }
  
  public AsynchronousSocketChannel getAsynchronousSocketChannel()
  {
    return channel;
  }
  
  /* Error */
  public final void forceClose()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 10	com/mysql/cj/protocol/x/XAsyncSocketConnection:channel	Ljava/nio/channels/AsynchronousSocketChannel;
    //   4: ifnull +20 -> 24
    //   7: aload_0
    //   8: getfield 10	com/mysql/cj/protocol/x/XAsyncSocketConnection:channel	Ljava/nio/channels/AsynchronousSocketChannel;
    //   11: invokevirtual 16	java/nio/channels/AsynchronousSocketChannel:isOpen	()Z
    //   14: ifeq +10 -> 24
    //   17: aload_0
    //   18: getfield 10	com/mysql/cj/protocol/x/XAsyncSocketConnection:channel	Ljava/nio/channels/AsynchronousSocketChannel;
    //   21: invokevirtual 17	java/nio/channels/AsynchronousSocketChannel:close	()V
    //   24: aload_0
    //   25: aconst_null
    //   26: putfield 10	com/mysql/cj/protocol/x/XAsyncSocketConnection:channel	Ljava/nio/channels/AsynchronousSocketChannel;
    //   29: goto +20 -> 49
    //   32: astore_1
    //   33: aload_0
    //   34: aconst_null
    //   35: putfield 10	com/mysql/cj/protocol/x/XAsyncSocketConnection:channel	Ljava/nio/channels/AsynchronousSocketChannel;
    //   38: goto +11 -> 49
    //   41: astore_2
    //   42: aload_0
    //   43: aconst_null
    //   44: putfield 10	com/mysql/cj/protocol/x/XAsyncSocketConnection:channel	Ljava/nio/channels/AsynchronousSocketChannel;
    //   47: aload_2
    //   48: athrow
    //   49: return
    // Line number table:
    //   Java source line #89	-> byte code offset #0
    //   Java source line #90	-> byte code offset #17
    //   Java source line #95	-> byte code offset #24
    //   Java source line #96	-> byte code offset #29
    //   Java source line #92	-> byte code offset #32
    //   Java source line #95	-> byte code offset #33
    //   Java source line #96	-> byte code offset #38
    //   Java source line #95	-> byte code offset #41
    //   Java source line #96	-> byte code offset #47
    //   Java source line #97	-> byte code offset #49
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	50	0	this	XAsyncSocketConnection
    //   32	1	1	localIOException	IOException
    //   41	7	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   0	24	32	java/io/IOException
    //   0	24	41	finally
  }
  
  public NetworkResources getNetworkResources()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public Socket getMysqlSocket()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public FullReadInputStream getMysqlInput()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public void setMysqlInput(FullReadInputStream mysqlInput)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public BufferedOutputStream getMysqlOutput()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public boolean isSSLEstablished()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public ExceptionInterceptor getExceptionInterceptor()
  {
    return null;
  }
  
  public boolean isSynchronous()
  {
    return false;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XAsyncSocketConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */