package com.mysql.cj.protocol.x;

import javax.security.auth.callback.Callback;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.callback.NameCallback;
import javax.security.auth.callback.PasswordCallback;
import javax.security.auth.callback.UnsupportedCallbackException;

class XMessageBuilder$1
  implements CallbackHandler
{
  XMessageBuilder$1(XMessageBuilder this$0, String paramString1, String paramString2) {}
  
  public void handle(Callback[] callbacks)
    throws UnsupportedCallbackException
  {
    for (Callback c : callbacks) {
      if (NameCallback.class.isAssignableFrom(c.getClass())) {
        ((NameCallback)c).setName(val$user);
      } else if (PasswordCallback.class.isAssignableFrom(c.getClass())) {
        ((PasswordCallback)c).setPassword(val$password.toCharArray());
      } else {
        throw new UnsupportedCallbackException(c);
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XMessageBuilder.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */