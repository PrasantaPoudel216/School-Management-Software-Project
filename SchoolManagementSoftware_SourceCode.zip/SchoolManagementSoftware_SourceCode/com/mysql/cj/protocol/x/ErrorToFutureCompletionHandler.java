package com.mysql.cj.protocol.x;

import java.nio.channels.CompletionHandler;
import java.util.concurrent.CompletableFuture;

public class ErrorToFutureCompletionHandler<T>
  implements CompletionHandler<T, Void>
{
  private CompletableFuture<?> future;
  private Runnable successCallback;
  
  public ErrorToFutureCompletionHandler(CompletableFuture<?> future, Runnable successCallback)
  {
    this.future = future;
    this.successCallback = successCallback;
  }
  
  public void completed(T result, Void attachment)
  {
    successCallback.run();
  }
  
  public void failed(Throwable ex, Void attachment)
  {
    future.completeExceptionally(ex);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.ErrorToFutureCompletionHandler
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */