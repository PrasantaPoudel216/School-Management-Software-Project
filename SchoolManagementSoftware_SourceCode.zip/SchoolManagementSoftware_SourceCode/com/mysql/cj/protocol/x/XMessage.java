package com.mysql.cj.protocol.x;

import com.google.protobuf.ByteString;
import com.google.protobuf.CodedOutputStream;
import com.google.protobuf.Descriptors.Descriptor;
import com.google.protobuf.Descriptors.FieldDescriptor;
import com.google.protobuf.Descriptors.OneofDescriptor;
import com.google.protobuf.Message.Builder;
import com.google.protobuf.Parser;
import com.google.protobuf.UnknownFieldSet;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class XMessage
  implements com.mysql.cj.protocol.Message, com.google.protobuf.Message
{
  private com.google.protobuf.Message message;
  private List<Notice> notices = null;
  
  public XMessage(com.google.protobuf.Message mess)
  {
    message = mess;
  }
  
  public com.google.protobuf.Message getMessage()
  {
    return message;
  }
  
  public byte[] getByteBuffer()
  {
    return message.toByteArray();
  }
  
  public int getPosition()
  {
    return 0;
  }
  
  public int getSerializedSize()
  {
    return message.getSerializedSize();
  }
  
  public byte[] toByteArray()
  {
    return message.toByteArray();
  }
  
  public ByteString toByteString()
  {
    return message.toByteString();
  }
  
  public void writeDelimitedTo(OutputStream arg0)
    throws IOException
  {
    message.writeDelimitedTo(arg0);
  }
  
  public void writeTo(CodedOutputStream arg0)
    throws IOException
  {
    message.writeTo(arg0);
  }
  
  public void writeTo(OutputStream arg0)
    throws IOException
  {
    message.writeTo(arg0);
  }
  
  public boolean isInitialized()
  {
    return message.isInitialized();
  }
  
  public List<String> findInitializationErrors()
  {
    return message.findInitializationErrors();
  }
  
  public Map<Descriptors.FieldDescriptor, Object> getAllFields()
  {
    return message.getAllFields();
  }
  
  public com.google.protobuf.Message getDefaultInstanceForType()
  {
    return message.getDefaultInstanceForType();
  }
  
  public Descriptors.Descriptor getDescriptorForType()
  {
    return message.getDescriptorForType();
  }
  
  public Object getField(Descriptors.FieldDescriptor arg0)
  {
    return message.getField(arg0);
  }
  
  public String getInitializationErrorString()
  {
    return message.getInitializationErrorString();
  }
  
  public Descriptors.FieldDescriptor getOneofFieldDescriptor(Descriptors.OneofDescriptor arg0)
  {
    return message.getOneofFieldDescriptor(arg0);
  }
  
  public Object getRepeatedField(Descriptors.FieldDescriptor arg0, int arg1)
  {
    return message.getRepeatedField(arg0, arg1);
  }
  
  public int getRepeatedFieldCount(Descriptors.FieldDescriptor arg0)
  {
    return message.getRepeatedFieldCount(arg0);
  }
  
  public UnknownFieldSet getUnknownFields()
  {
    return message.getUnknownFields();
  }
  
  public boolean hasField(Descriptors.FieldDescriptor arg0)
  {
    return message.hasField(arg0);
  }
  
  public boolean hasOneof(Descriptors.OneofDescriptor arg0)
  {
    return message.hasOneof(arg0);
  }
  
  public Parser<? extends com.google.protobuf.Message> getParserForType()
  {
    return message.getParserForType();
  }
  
  public Message.Builder newBuilderForType()
  {
    return message.newBuilderForType();
  }
  
  public Message.Builder toBuilder()
  {
    return message.toBuilder();
  }
  
  public List<Notice> getNotices()
  {
    return notices;
  }
  
  public XMessage addNotices(List<Notice> n)
  {
    if (n != null)
    {
      if (notices == null) {
        notices = new ArrayList();
      }
      notices.addAll(n);
    }
    return this;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XMessage
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */