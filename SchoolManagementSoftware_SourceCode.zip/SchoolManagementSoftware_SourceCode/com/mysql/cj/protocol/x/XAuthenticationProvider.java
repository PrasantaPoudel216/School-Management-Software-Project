package com.mysql.cj.protocol.x;

import com.mysql.cj.conf.PropertyDefinitions.AuthMech;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.AuthenticationProvider;
import com.mysql.cj.protocol.Protocol;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.util.StringUtils;
import com.mysql.cj.xdevapi.XDevAPIError;
import java.nio.channels.ClosedChannelException;
import java.util.Arrays;
import java.util.List;

public class XAuthenticationProvider
  implements AuthenticationProvider<XMessage>
{
  XProtocol protocol;
  private PropertyDefinitions.AuthMech authMech = null;
  private XMessageBuilder messageBuilder = new XMessageBuilder();
  
  public void init(Protocol<XMessage> prot, PropertySet propertySet, ExceptionInterceptor exceptionInterceptor)
  {
    protocol = ((XProtocol)prot);
  }
  
  public void connect(ServerSession serverSession, String userName, String password, String database)
  {
    changeUser(serverSession, userName, password, database);
  }
  
  public void changeUser(ServerSession serverSession, String userName, String password, String database)
  {
    boolean overTLS = ((XServerCapabilities)protocol.getServerSession().getCapabilities()).getTls();
    RuntimeProperty<PropertyDefinitions.AuthMech> authMechProp = protocol.getPropertySet().getEnumProperty(PropertyKey.xdevapiAuth);
    List<PropertyDefinitions.AuthMech> tryAuthMech;
    List<PropertyDefinitions.AuthMech> tryAuthMech;
    if ((overTLS) || (authMechProp.isExplicitlySet())) {
      tryAuthMech = Arrays.asList(new PropertyDefinitions.AuthMech[] { (PropertyDefinitions.AuthMech)authMechProp.getValue() });
    } else {
      tryAuthMech = Arrays.asList(new PropertyDefinitions.AuthMech[] { PropertyDefinitions.AuthMech.MYSQL41, PropertyDefinitions.AuthMech.SHA256_MEMORY });
    }
    XProtocolError capturedAuthErr = null;
    for (PropertyDefinitions.AuthMech am : tryAuthMech)
    {
      authMech = am;
      try
      {
        switch (authMech)
        {
        case SHA256_MEMORY: 
          protocol.send(messageBuilder.buildSha256MemoryAuthStart(), 0);
          byte[] nonce = protocol.readAuthenticateContinue();
          protocol.send(messageBuilder.buildSha256MemoryAuthContinue(userName, password, nonce, database), 0);
          break;
        case MYSQL41: 
          protocol.send(messageBuilder.buildMysql41AuthStart(), 0);
          byte[] salt = protocol.readAuthenticateContinue();
          protocol.send(messageBuilder.buildMysql41AuthContinue(userName, password, salt, database), 0);
          break;
        case PLAIN: 
          if (overTLS) {
            protocol.send(messageBuilder.buildPlainAuthStart(userName, password, database), 0);
          } else {
            throw new XProtocolError("PLAIN authentication is not allowed via unencrypted connection.");
          }
          break;
        case EXTERNAL: 
          protocol.send(messageBuilder.buildExternalAuthStart(database), 0);
          break;
        default: 
          throw new WrongArgumentException("Unknown authentication mechanism '" + authMech + "'.");
        }
      }
      catch (CJCommunicationsException e)
      {
        if ((capturedAuthErr != null) && ((e.getCause() instanceof ClosedChannelException))) {
          throw capturedAuthErr;
        }
        throw e;
      }
      try
      {
        protocol.readAuthenticateOk();
        
        capturedAuthErr = null;
      }
      catch (XProtocolError e)
      {
        if (e.getErrorCode() != 1045) {
          throw e;
        }
        capturedAuthErr = e;
      }
    }
    if (capturedAuthErr != null)
    {
      if (tryAuthMech.size() == 1) {
        throw capturedAuthErr;
      }
      String errMsg = "Authentication failed using " + StringUtils.joinWithSerialComma(tryAuthMech) + ", check username and password or try a secure connection";
      
      XDevAPIError ex = new XDevAPIError(errMsg, capturedAuthErr);
      ex.setVendorCode(capturedAuthErr.getErrorCode());
      ex.setSQLState(capturedAuthErr.getSQLState());
      ex.initCause(capturedAuthErr);
      throw ex;
    }
    protocol.afterHandshake();
  }
  
  public String getEncodingForHandshake()
  {
    return null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.XAuthenticationProvider
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */