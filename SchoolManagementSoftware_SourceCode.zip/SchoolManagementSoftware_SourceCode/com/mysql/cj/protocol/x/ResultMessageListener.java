package com.mysql.cj.protocol.x;

import com.google.protobuf.GeneratedMessageV3;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.MessageListener;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.ResultListener;
import com.mysql.cj.result.DefaultColumnDefinition;
import com.mysql.cj.result.Field;
import com.mysql.cj.x.protobuf.Mysqlx.Error;
import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;
import com.mysql.cj.x.protobuf.MysqlxResultset.ColumnMetaData;
import com.mysql.cj.x.protobuf.MysqlxResultset.FetchDone;
import com.mysql.cj.x.protobuf.MysqlxResultset.Row;
import com.mysql.cj.x.protobuf.MysqlxSql.StmtExecuteOk;
import java.util.ArrayList;

public class ResultMessageListener
  implements MessageListener<XMessage>
{
  private ResultListener<StatementExecuteOk> callbacks;
  private ProtocolEntityFactory<Field, XMessage> fieldFactory;
  private ArrayList<Field> fields = new ArrayList();
  private ColumnDefinition metadata = null;
  private boolean metadataSent = false;
  private StatementExecuteOkBuilder okBuilder = new StatementExecuteOkBuilder();
  
  public ResultMessageListener(ProtocolEntityFactory<Field, XMessage> colToField, ResultListener<StatementExecuteOk> callbacks)
  {
    this.callbacks = callbacks;
    fieldFactory = colToField;
  }
  
  public Boolean createFromMessage(XMessage message)
  {
    Class<? extends GeneratedMessageV3> msgClass = message.getMessage().getClass();
    if (MysqlxResultset.ColumnMetaData.class.equals(msgClass))
    {
      Field f = (Field)fieldFactory.createFromMessage(message);
      fields.add(f);
      return Boolean.valueOf(false);
    }
    if (!metadataSent)
    {
      if (metadata == null) {
        metadata = new DefaultColumnDefinition((Field[])fields.toArray(new Field[0]));
      }
      callbacks.onMetadata(metadata);
      metadataSent = true;
    }
    if (MysqlxSql.StmtExecuteOk.class.equals(msgClass))
    {
      callbacks.onComplete(okBuilder.build());
      return Boolean.valueOf(true);
    }
    if (MysqlxResultset.FetchDone.class.equals(msgClass)) {
      return Boolean.valueOf(false);
    }
    if (MysqlxResultset.Row.class.equals(msgClass))
    {
      if (metadata == null) {
        metadata = new DefaultColumnDefinition((Field[])fields.toArray(new Field[0]));
      }
      XProtocolRow row = new XProtocolRow(metadata, (MysqlxResultset.Row)MysqlxResultset.Row.class.cast(message.getMessage()));
      callbacks.onRow(row);
      return Boolean.valueOf(false);
    }
    if (Mysqlx.Error.class.equals(msgClass))
    {
      XProtocolError e = new XProtocolError((Mysqlx.Error)Mysqlx.Error.class.cast(message.getMessage()));
      callbacks.onException(e);
      return Boolean.valueOf(true);
    }
    if (MysqlxNotice.Frame.class.equals(msgClass))
    {
      okBuilder.addNotice(Notice.getInstance(message));
      return Boolean.valueOf(false);
    }
    callbacks.onException(new WrongArgumentException("Unhandled msg class (" + msgClass + ") + msg=" + message.getMessage()));
    return Boolean.valueOf(false);
  }
  
  public void error(Throwable ex)
  {
    callbacks.onException(ex);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.ResultMessageListener
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */