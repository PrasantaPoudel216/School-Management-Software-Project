package com.mysql.cj.protocol.x;

import com.google.protobuf.MessageLite;
import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.CJCommunicationsException;
import com.mysql.cj.exceptions.CJPacketTooBigException;
import com.mysql.cj.protocol.MessageSender;
import com.mysql.cj.protocol.PacketSentTimeHolder;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.CompletionHandler;

public class SyncMessageSender
  implements MessageSender<XMessage>, PacketSentTimeHolder
{
  static final int HEADER_LEN = 5;
  private BufferedOutputStream outputStream;
  private long lastPacketSentTime = 0L;
  private long previousPacketSentTime = 0L;
  private int maxAllowedPacket = -1;
  Object waitingAsyncOperationMonitor = new Object();
  
  public SyncMessageSender(BufferedOutputStream os)
  {
    outputStream = os;
  }
  
  public void send(XMessage message)
  {
    synchronized (waitingAsyncOperationMonitor)
    {
      MessageLite msg = message.getMessage();
      try
      {
        int type = MessageConstants.getTypeForMessageClass(msg.getClass());
        int size = 1 + msg.getSerializedSize();
        if ((maxAllowedPacket > 0) && (size > maxAllowedPacket)) {
          throw new CJPacketTooBigException(Messages.getString("PacketTooBigException.1", new Object[] { Integer.valueOf(size), Integer.valueOf(maxAllowedPacket) }));
        }
        byte[] sizeHeader = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(size).array();
        outputStream.write(sizeHeader);
        outputStream.write(type);
        msg.writeTo(outputStream);
        outputStream.flush();
        previousPacketSentTime = lastPacketSentTime;
        lastPacketSentTime = System.currentTimeMillis();
      }
      catch (IOException ex)
      {
        throw new CJCommunicationsException("Unable to write message", ex);
      }
    }
  }
  
  public void send(XMessage message, CompletionHandler<Long, Void> callback)
  {
    synchronized (waitingAsyncOperationMonitor)
    {
      MessageLite msg = message.getMessage();
      try
      {
        send(message);
        long result = 5 + msg.getSerializedSize();
        callback.completed(Long.valueOf(result), null);
      }
      catch (Throwable t)
      {
        callback.failed(t, null);
      }
    }
  }
  
  public long getLastPacketSentTime()
  {
    return lastPacketSentTime;
  }
  
  public long getPreviousPacketSentTime()
  {
    return previousPacketSentTime;
  }
  
  public void setMaxAllowedPacket(int maxAllowedPacket)
  {
    this.maxAllowedPacket = maxAllowedPacket;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.SyncMessageSender
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */