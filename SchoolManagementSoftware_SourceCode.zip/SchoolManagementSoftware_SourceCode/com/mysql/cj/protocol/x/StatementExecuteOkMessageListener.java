package com.mysql.cj.protocol.x;

import com.google.protobuf.GeneratedMessageV3;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.MessageListener;
import com.mysql.cj.x.protobuf.Mysqlx.Error;
import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;
import com.mysql.cj.x.protobuf.MysqlxResultset.FetchDone;
import com.mysql.cj.x.protobuf.MysqlxSql.StmtExecuteOk;
import java.util.concurrent.CompletableFuture;

public class StatementExecuteOkMessageListener
  implements MessageListener<XMessage>
{
  private StatementExecuteOkBuilder builder = new StatementExecuteOkBuilder();
  private CompletableFuture<StatementExecuteOk> future = new CompletableFuture();
  
  public StatementExecuteOkMessageListener(CompletableFuture<StatementExecuteOk> future)
  {
    this.future = future;
  }
  
  public Boolean createFromMessage(XMessage message)
  {
    Class<? extends GeneratedMessageV3> msgClass = message.getMessage().getClass();
    if (MysqlxNotice.Frame.class.equals(msgClass))
    {
      builder.addNotice(Notice.getInstance(message));
      return Boolean.valueOf(false);
    }
    if (MysqlxSql.StmtExecuteOk.class.equals(msgClass))
    {
      future.complete(builder.build());
      return Boolean.valueOf(true);
    }
    if (Mysqlx.Error.class.equals(msgClass))
    {
      future.completeExceptionally(new XProtocolError((Mysqlx.Error)Mysqlx.Error.class.cast(message.getMessage())));
      return Boolean.valueOf(true);
    }
    if (MysqlxResultset.FetchDone.class.equals(msgClass)) {
      return Boolean.valueOf(false);
    }
    future.completeExceptionally(new WrongArgumentException("Unhandled msg class (" + msgClass + ") + msg=" + message.getMessage()));
    return Boolean.valueOf(true);
  }
  
  public void error(Throwable ex)
  {
    future.completeExceptionally(ex);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.StatementExecuteOkMessageListener
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */