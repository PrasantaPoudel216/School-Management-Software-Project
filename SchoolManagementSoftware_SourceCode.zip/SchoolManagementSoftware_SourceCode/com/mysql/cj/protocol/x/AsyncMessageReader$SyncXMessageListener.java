package com.mysql.cj.protocol.x;

import com.google.protobuf.GeneratedMessageV3;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.MessageListener;
import com.mysql.cj.x.protobuf.Mysqlx.Error;
import com.mysql.cj.x.protobuf.MysqlxNotice.Frame;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CompletableFuture;

final class AsyncMessageReader$SyncXMessageListener<T extends GeneratedMessageV3>
  implements MessageListener<XMessage>
{
  private CompletableFuture<XMessage> future;
  private Class<T> expectedClass;
  List<Notice> notices = null;
  
  public AsyncMessageReader$SyncXMessageListener(CompletableFuture<XMessage> future, Class<T> expectedClass)
  {
    this.future = future;
    this.expectedClass = expectedClass;
  }
  
  public Boolean createFromMessage(XMessage msg)
  {
    Class<? extends GeneratedMessageV3> msgClass = msg.getMessage().getClass();
    if (Mysqlx.Error.class.equals(msgClass))
    {
      future.completeExceptionally(new XProtocolError((Mysqlx.Error)Mysqlx.Error.class.cast(msg.getMessage())));
      return Boolean.valueOf(true);
    }
    if (expectedClass.equals(msgClass))
    {
      future.complete(msg.addNotices(notices));
      notices = null;
      return Boolean.valueOf(true);
    }
    if (MysqlxNotice.Frame.class.equals(msgClass))
    {
      if (notices == null) {
        notices = new ArrayList();
      }
      notices.add(Notice.getInstance(msg));
      return Boolean.valueOf(false);
    }
    future.completeExceptionally(new WrongArgumentException("Unhandled msg class (" + msgClass + ") + msg=" + msg.getMessage()));
    return Boolean.valueOf(true);
  }
  
  public void error(Throwable ex)
  {
    future.completeExceptionally(ex);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.AsyncMessageReader.SyncXMessageListener
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */