package com.mysql.cj.protocol.x;

import com.google.protobuf.GeneratedMessageV3;

class AsyncMessageReader$CompletedRead
{
  public XMessageHeader header = null;
  public GeneratedMessageV3 message = null;
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.x.AsyncMessageReader.CompletedRead
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */