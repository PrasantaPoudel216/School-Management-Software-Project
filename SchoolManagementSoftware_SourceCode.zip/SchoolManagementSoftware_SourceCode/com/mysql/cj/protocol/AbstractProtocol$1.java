package com.mysql.cj.protocol;

class AbstractProtocol$1
  implements PacketSentTimeHolder
{
  AbstractProtocol$1(AbstractProtocol this$0) {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.AbstractProtocol.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */