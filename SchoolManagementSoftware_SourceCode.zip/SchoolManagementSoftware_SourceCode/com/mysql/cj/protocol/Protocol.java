package com.mysql.cj.protocol;

import com.mysql.cj.MessageBuilder;
import com.mysql.cj.QueryResult;
import com.mysql.cj.Session;
import com.mysql.cj.TransactionEventHandler;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.result.RowList;
import java.io.IOException;
import java.io.InputStream;
import java.util.concurrent.CompletableFuture;

public abstract interface Protocol<M extends Message>
{
  public abstract void init(Session paramSession, SocketConnection paramSocketConnection, PropertySet paramPropertySet, TransactionEventHandler paramTransactionEventHandler);
  
  public abstract PropertySet getPropertySet();
  
  public abstract void setPropertySet(PropertySet paramPropertySet);
  
  public abstract MessageBuilder<M> getMessageBuilder();
  
  public abstract ServerCapabilities readServerCapabilities();
  
  public abstract ServerSession getServerSession();
  
  public abstract SocketConnection getSocketConnection();
  
  public abstract AuthenticationProvider<M> getAuthenticationProvider();
  
  public abstract ExceptionInterceptor getExceptionInterceptor();
  
  public abstract PacketSentTimeHolder getPacketSentTimeHolder();
  
  public abstract void setPacketSentTimeHolder(PacketSentTimeHolder paramPacketSentTimeHolder);
  
  public abstract PacketReceivedTimeHolder getPacketReceivedTimeHolder();
  
  public abstract void setPacketReceivedTimeHolder(PacketReceivedTimeHolder paramPacketReceivedTimeHolder);
  
  public abstract void connect(String paramString1, String paramString2, String paramString3);
  
  public abstract void negotiateSSLConnection(int paramInt);
  
  public abstract void beforeHandshake();
  
  public abstract void afterHandshake();
  
  public abstract void changeDatabase(String paramString);
  
  public abstract void changeUser(String paramString1, String paramString2, String paramString3);
  
  public abstract String getPasswordCharacterEncoding();
  
  public abstract boolean versionMeetsMinimum(int paramInt1, int paramInt2, int paramInt3);
  
  public abstract M readMessage(M paramM);
  
  public abstract M checkErrorMessage();
  
  public abstract void send(Message paramMessage, int paramInt);
  
  public abstract <RES extends QueryResult> CompletableFuture<RES> sendAsync(Message paramMessage);
  
  public abstract ColumnDefinition readMetadata();
  
  public abstract RowList getRowInputStream(ColumnDefinition paramColumnDefinition);
  
  public abstract M sendCommand(Message paramMessage, boolean paramBoolean, int paramInt);
  
  public abstract <T extends ProtocolEntity> T read(Class<T> paramClass, ProtocolEntityFactory<T, M> paramProtocolEntityFactory)
    throws IOException;
  
  public abstract <T extends ProtocolEntity> T read(Class<Resultset> paramClass, int paramInt, boolean paramBoolean1, M paramM, boolean paramBoolean2, ColumnDefinition paramColumnDefinition, ProtocolEntityFactory<T, M> paramProtocolEntityFactory)
    throws IOException;
  
  public abstract void setLocalInfileInputStream(InputStream paramInputStream);
  
  public abstract InputStream getLocalInfileInputStream();
  
  public abstract String getQueryComment();
  
  public abstract void setQueryComment(String paramString);
  
  public abstract <QR extends QueryResult> QR readQueryResult();
  
  public abstract void close()
    throws IOException;
  
  public abstract void setCurrentResultStreamer(ResultStreamer paramResultStreamer);
  
  public abstract void configureTimezone();
  
  public abstract void initServerSession();
  
  public abstract void reset();
  
  public abstract String getQueryTimingUnits();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.Protocol
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */