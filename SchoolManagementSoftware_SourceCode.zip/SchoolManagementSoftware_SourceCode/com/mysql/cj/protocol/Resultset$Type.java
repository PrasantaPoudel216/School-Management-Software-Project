package com.mysql.cj.protocol;

public enum Resultset$Type
{
  FORWARD_ONLY(1003),  SCROLL_INSENSITIVE(1004),  SCROLL_SENSITIVE(1005);
  
  private int value;
  
  private Resultset$Type(int jdbcRsType)
  {
    value = jdbcRsType;
  }
  
  public int getIntValue()
  {
    return value;
  }
  
  public static Type fromValue(int rsType, Type backupValue)
  {
    for (Type t : ) {
      if (t.getIntValue() == rsType) {
        return t;
      }
    }
    return backupValue;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.Resultset.Type
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */