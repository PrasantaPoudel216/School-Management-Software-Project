package com.mysql.cj.protocol;

public abstract interface WatchableStream
{
  public abstract void setWatcher(OutputStreamWatcher paramOutputStreamWatcher);
  
  public abstract int size();
  
  public abstract byte[] toByteArray();
  
  public abstract void write(byte[] paramArrayOfByte, int paramInt1, int paramInt2);
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.WatchableStream
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */