package com.mysql.cj.protocol;

import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.CompletableFuture;

final class ExportControlled$1
  implements CompletionHandler<Integer, Void>
{
  ExportControlled$1(int paramInt, AsynchronousSocketChannel paramAsynchronousSocketChannel, ByteBuffer paramByteBuffer, CompletableFuture paramCompletableFuture) {}
  
  public void completed(Integer bytesWritten, Void nothing)
  {
    if (bytesWritten.intValue() < val$bytesToWrite) {
      val$channel.write(val$data, null, this);
    } else {
      val$f.complete(null);
    }
  }
  
  public void failed(Throwable exc, Void nothing)
  {
    val$f.completeExceptionally(exc);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ExportControlled.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */