package com.mysql.cj.protocol;

import com.mysql.cj.MysqlConnection;
import com.mysql.cj.Query;
import com.mysql.cj.Session;

public abstract interface ResultsetRowsOwner
{
  public abstract void closeOwner(boolean paramBoolean);
  
  public abstract MysqlConnection getConnection();
  
  public abstract Session getSession();
  
  public abstract Object getSyncMutex();
  
  public abstract String getPointOfOrigin();
  
  public abstract int getOwnerFetchSize();
  
  public abstract Query getOwningQuery();
  
  public abstract int getOwningStatementMaxRows();
  
  public abstract int getOwningStatementFetchSize();
  
  public abstract long getOwningStatementServerId();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ResultsetRowsOwner
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */