package com.mysql.cj.protocol;

public abstract interface Resultset
  extends ProtocolEntity
{
  public abstract void setColumnDefinition(ColumnDefinition paramColumnDefinition);
  
  public abstract ColumnDefinition getColumnDefinition();
  
  public abstract boolean hasRows();
  
  public abstract ResultsetRows getRows();
  
  public abstract void initRowsWithMetadata();
  
  public abstract int getResultId();
  
  public abstract void setNextResultset(Resultset paramResultset);
  
  public abstract Resultset getNextResultset();
  
  public abstract void clearNextResultset();
  
  public abstract long getUpdateCount();
  
  public abstract long getUpdateID();
  
  public abstract String getServerInfo();
  
  public static enum Concurrency
  {
    READ_ONLY(1007),  UPDATABLE(1008);
    
    private int value;
    
    private Concurrency(int jdbcRsConcur)
    {
      value = jdbcRsConcur;
    }
    
    public int getIntValue()
    {
      return value;
    }
    
    public static Concurrency fromValue(int concurMode, Concurrency backupValue)
    {
      for (Concurrency c : ) {
        if (c.getIntValue() == concurMode) {
          return c;
        }
      }
      return backupValue;
    }
  }
  
  public static enum Type
  {
    FORWARD_ONLY(1003),  SCROLL_INSENSITIVE(1004),  SCROLL_SENSITIVE(1005);
    
    private int value;
    
    private Type(int jdbcRsType)
    {
      value = jdbcRsType;
    }
    
    public int getIntValue()
    {
      return value;
    }
    
    public static Type fromValue(int rsType, Type backupValue)
    {
      for (Type t : ) {
        if (t.getIntValue() == rsType) {
          return t;
        }
      }
      return backupValue;
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.Resultset
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */