package com.mysql.cj.protocol;

import com.mysql.cj.MessageBuilder;
import com.mysql.cj.Messages;
import com.mysql.cj.Session;
import com.mysql.cj.TransactionEventHandler;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.log.Log;
import com.mysql.cj.util.TimeUtil;
import java.util.LinkedList;

public abstract class AbstractProtocol<M extends Message>
  implements Protocol<M>
{
  protected Session session;
  protected SocketConnection socketConnection;
  protected PropertySet propertySet;
  protected TransactionEventHandler transactionManager;
  protected transient Log log;
  protected ExceptionInterceptor exceptionInterceptor;
  protected AuthenticationProvider<M> authProvider;
  protected MessageBuilder<M> messageBuilder;
  private PacketSentTimeHolder packetSentTimeHolder = new PacketSentTimeHolder() {};
  private PacketReceivedTimeHolder packetReceivedTimeHolder = new PacketReceivedTimeHolder() {};
  protected LinkedList<StringBuilder> packetDebugRingBuffer = null;
  protected boolean useNanosForElapsedTime;
  protected String queryTimingUnits;
  
  public void init(Session sess, SocketConnection phConnection, PropertySet propSet, TransactionEventHandler trManager)
  {
    session = sess;
    propertySet = propSet;
    
    socketConnection = phConnection;
    exceptionInterceptor = socketConnection.getExceptionInterceptor();
    
    transactionManager = trManager;
    
    useNanosForElapsedTime = ((((Boolean)propertySet.getBooleanProperty(PropertyKey.useNanosForElapsedTime).getValue()).booleanValue()) && (TimeUtil.nanoTimeAvailable()));
    queryTimingUnits = (useNanosForElapsedTime ? Messages.getString("Nanoseconds") : Messages.getString("Milliseconds"));
  }
  
  public SocketConnection getSocketConnection()
  {
    return socketConnection;
  }
  
  public AuthenticationProvider<M> getAuthenticationProvider()
  {
    return authProvider;
  }
  
  public ExceptionInterceptor getExceptionInterceptor()
  {
    return exceptionInterceptor;
  }
  
  public PacketSentTimeHolder getPacketSentTimeHolder()
  {
    return packetSentTimeHolder;
  }
  
  public void setPacketSentTimeHolder(PacketSentTimeHolder packetSentTimeHolder)
  {
    this.packetSentTimeHolder = packetSentTimeHolder;
  }
  
  public PacketReceivedTimeHolder getPacketReceivedTimeHolder()
  {
    return packetReceivedTimeHolder;
  }
  
  public void setPacketReceivedTimeHolder(PacketReceivedTimeHolder packetReceivedTimeHolder)
  {
    this.packetReceivedTimeHolder = packetReceivedTimeHolder;
  }
  
  public PropertySet getPropertySet()
  {
    return propertySet;
  }
  
  public void setPropertySet(PropertySet propertySet)
  {
    this.propertySet = propertySet;
  }
  
  public MessageBuilder<M> getMessageBuilder()
  {
    return messageBuilder;
  }
  
  public void reset() {}
  
  public String getQueryTimingUnits()
  {
    return queryTimingUnits;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.AbstractProtocol
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */