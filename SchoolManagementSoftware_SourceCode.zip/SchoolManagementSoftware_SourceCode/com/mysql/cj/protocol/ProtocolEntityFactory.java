package com.mysql.cj.protocol;

import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ExceptionFactory;

public abstract interface ProtocolEntityFactory<T, M extends Message>
{
  public T createFromMessage(M message)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not allowed"));
  }
  
  public Resultset.Type getResultSetType()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not allowed"));
  }
  
  public Resultset.Concurrency getResultSetConcurrency()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not allowed"));
  }
  
  public int getFetchSize()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not allowed"));
  }
  
  public T createFromProtocolEntity(ProtocolEntity protocolEntity)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not allowed"));
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ProtocolEntityFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */