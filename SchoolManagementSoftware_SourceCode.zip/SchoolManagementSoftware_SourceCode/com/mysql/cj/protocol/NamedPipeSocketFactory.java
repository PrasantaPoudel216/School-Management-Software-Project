package com.mysql.cj.protocol;

import com.mysql.cj.Messages;
import com.mysql.cj.Session;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.Socket;
import java.net.SocketException;

public class NamedPipeSocketFactory
  implements SocketFactory
{
  private Socket namedPipeSocket;
  
  class NamedPipeSocket
    extends Socket
  {
    private boolean isClosed = false;
    private RandomAccessFile namedPipeFile;
    
    NamedPipeSocket(String filePath)
      throws IOException
    {
      if ((filePath == null) || (filePath.length() == 0)) {
        throw new IOException(Messages.getString("NamedPipeSocketFactory.4"));
      }
      namedPipeFile = new RandomAccessFile(filePath, "rw");
    }
    
    public synchronized void close()
      throws IOException
    {
      namedPipeFile.close();
      isClosed = true;
    }
    
    public InputStream getInputStream()
      throws IOException
    {
      return new NamedPipeSocketFactory.RandomAccessFileInputStream(NamedPipeSocketFactory.this, namedPipeFile);
    }
    
    public OutputStream getOutputStream()
      throws IOException
    {
      return new NamedPipeSocketFactory.RandomAccessFileOutputStream(NamedPipeSocketFactory.this, namedPipeFile);
    }
    
    public boolean isClosed()
    {
      return isClosed;
    }
    
    public void shutdownInput()
      throws IOException
    {}
  }
  
  class RandomAccessFileInputStream
    extends InputStream
  {
    RandomAccessFile raFile;
    
    RandomAccessFileInputStream(RandomAccessFile file)
    {
      raFile = file;
    }
    
    public int available()
      throws IOException
    {
      return -1;
    }
    
    public void close()
      throws IOException
    {
      raFile.close();
    }
    
    public int read()
      throws IOException
    {
      return raFile.read();
    }
    
    public int read(byte[] b)
      throws IOException
    {
      return raFile.read(b);
    }
    
    public int read(byte[] b, int off, int len)
      throws IOException
    {
      return raFile.read(b, off, len);
    }
  }
  
  class RandomAccessFileOutputStream
    extends OutputStream
  {
    RandomAccessFile raFile;
    
    RandomAccessFileOutputStream(RandomAccessFile file)
    {
      raFile = file;
    }
    
    public void close()
      throws IOException
    {
      raFile.close();
    }
    
    public void write(byte[] b)
      throws IOException
    {
      raFile.write(b);
    }
    
    public void write(byte[] b, int off, int len)
      throws IOException
    {
      raFile.write(b, off, len);
    }
    
    public void write(int b)
      throws IOException
    {}
  }
  
  public <T extends Closeable> T performTlsHandshake(SocketConnection socketConnection, ServerSession serverSession)
    throws IOException
  {
    return namedPipeSocket;
  }
  
  public <T extends Closeable> T connect(String host, int portNumber, PropertySet props, int loginTimeout)
    throws IOException
  {
    String namedPipePath = null;
    
    RuntimeProperty<String> path = props.getStringProperty(PropertyKey.PATH);
    if (path != null) {
      namedPipePath = (String)path.getValue();
    }
    if (namedPipePath == null) {
      namedPipePath = "\\\\.\\pipe\\MySQL";
    } else if (namedPipePath.length() == 0) {
      throw new SocketException(Messages.getString("NamedPipeSocketFactory.2") + PropertyKey.PATH.getCcAlias() + Messages.getString("NamedPipeSocketFactory.3"));
    }
    namedPipeSocket = new NamedPipeSocket(namedPipePath);
    
    return namedPipeSocket;
  }
  
  public boolean isLocallyConnected(Session sess)
  {
    return true;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.NamedPipeSocketFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */