package com.mysql.cj.protocol;

import com.mysql.cj.log.Log;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Arrays;

public class ReadAheadInputStream
  extends InputStream
{
  private static final int DEFAULT_BUFFER_SIZE = 4096;
  private InputStream underlyingStream;
  private byte[] buf;
  protected int endOfCurrentData;
  protected int currentPosition;
  protected boolean doDebug = false;
  protected Log log;
  
  private void fill(int readAtLeastTheseManyBytes)
    throws IOException
  {
    checkClosed();
    
    currentPosition = 0;
    
    endOfCurrentData = currentPosition;
    
    int bytesToRead = Math.min(buf.length - currentPosition, readAtLeastTheseManyBytes);
    
    int bytesAvailable = underlyingStream.available();
    if (bytesAvailable > bytesToRead) {
      bytesToRead = Math.min(buf.length - currentPosition, bytesAvailable);
    }
    if (doDebug)
    {
      StringBuilder debugBuf = new StringBuilder();
      debugBuf.append("  ReadAheadInputStream.fill(");
      debugBuf.append(readAtLeastTheseManyBytes);
      debugBuf.append("), buffer_size=");
      debugBuf.append(buf.length);
      debugBuf.append(", current_position=");
      debugBuf.append(currentPosition);
      debugBuf.append(", need to read ");
      debugBuf.append(Math.min(buf.length - currentPosition, readAtLeastTheseManyBytes));
      debugBuf.append(" bytes to fill request,");
      if (bytesAvailable > 0)
      {
        debugBuf.append(" underlying InputStream reports ");
        debugBuf.append(bytesAvailable);
        
        debugBuf.append(" total bytes available,");
      }
      debugBuf.append(" attempting to read ");
      debugBuf.append(bytesToRead);
      debugBuf.append(" bytes.");
      if (log != null) {
        log.logTrace(debugBuf.toString());
      } else {
        System.err.println(debugBuf.toString());
      }
    }
    int n = underlyingStream.read(buf, currentPosition, bytesToRead);
    if (n > 0) {
      endOfCurrentData = (n + currentPosition);
    }
  }
  
  private int readFromUnderlyingStreamIfNecessary(byte[] b, int off, int len)
    throws IOException
  {
    checkClosed();
    
    int avail = endOfCurrentData - currentPosition;
    if (doDebug)
    {
      StringBuilder debugBuf = new StringBuilder();
      debugBuf.append("ReadAheadInputStream.readIfNecessary(");
      debugBuf.append(Arrays.toString(b));
      debugBuf.append(",");
      debugBuf.append(off);
      debugBuf.append(",");
      debugBuf.append(len);
      debugBuf.append(")");
      if (avail <= 0)
      {
        debugBuf.append(" not all data available in buffer, must read from stream");
        if (len >= buf.length) {
          debugBuf.append(", amount requested > buffer, returning direct read() from stream");
        }
      }
      if (log != null) {
        log.logTrace(debugBuf.toString());
      } else {
        System.err.println(debugBuf.toString());
      }
    }
    if (avail <= 0)
    {
      if (len >= buf.length) {
        return underlyingStream.read(b, off, len);
      }
      fill(len);
      
      avail = endOfCurrentData - currentPosition;
      if (avail <= 0) {
        return -1;
      }
    }
    int bytesActuallyRead = avail < len ? avail : len;
    
    System.arraycopy(buf, currentPosition, b, off, bytesActuallyRead);
    
    currentPosition += bytesActuallyRead;
    
    return bytesActuallyRead;
  }
  
  public synchronized int read(byte[] b, int off, int len)
    throws IOException
  {
    checkClosed();
    if ((off | len | off + len | b.length - (off + len)) < 0) {
      throw new IndexOutOfBoundsException();
    }
    if (len == 0) {
      return 0;
    }
    int totalBytesRead = 0;
    for (;;)
    {
      int bytesReadThisRound = readFromUnderlyingStreamIfNecessary(b, off + totalBytesRead, len - totalBytesRead);
      if (bytesReadThisRound <= 0)
      {
        if (totalBytesRead == 0) {
          totalBytesRead = bytesReadThisRound;
        }
      }
      else
      {
        totalBytesRead += bytesReadThisRound;
        if (totalBytesRead < len) {
          if (underlyingStream.available() <= 0) {
            break;
          }
        }
      }
    }
    return totalBytesRead;
  }
  
  public int read()
    throws IOException
  {
    checkClosed();
    if (currentPosition >= endOfCurrentData)
    {
      fill(1);
      if (currentPosition >= endOfCurrentData) {
        return -1;
      }
    }
    return buf[(currentPosition++)] & 0xFF;
  }
  
  public int available()
    throws IOException
  {
    checkClosed();
    
    return underlyingStream.available() + (endOfCurrentData - currentPosition);
  }
  
  private void checkClosed()
    throws IOException
  {
    if (buf == null) {
      throw new IOException("Stream closed");
    }
  }
  
  public ReadAheadInputStream(InputStream toBuffer, boolean debug, Log logTo)
  {
    this(toBuffer, 4096, debug, logTo);
  }
  
  public ReadAheadInputStream(InputStream toBuffer, int bufferSize, boolean debug, Log logTo)
  {
    underlyingStream = toBuffer;
    buf = new byte[bufferSize];
    doDebug = debug;
    log = logTo;
  }
  
  /* Error */
  public void close()
    throws IOException
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 6	com/mysql/cj/protocol/ReadAheadInputStream:underlyingStream	Ljava/io/InputStream;
    //   4: ifnull +46 -> 50
    //   7: aload_0
    //   8: getfield 6	com/mysql/cj/protocol/ReadAheadInputStream:underlyingStream	Ljava/io/InputStream;
    //   11: invokevirtual 45	java/io/InputStream:close	()V
    //   14: aload_0
    //   15: aconst_null
    //   16: putfield 6	com/mysql/cj/protocol/ReadAheadInputStream:underlyingStream	Ljava/io/InputStream;
    //   19: aload_0
    //   20: aconst_null
    //   21: putfield 4	com/mysql/cj/protocol/ReadAheadInputStream:buf	[B
    //   24: aload_0
    //   25: aconst_null
    //   26: putfield 22	com/mysql/cj/protocol/ReadAheadInputStream:log	Lcom/mysql/cj/log/Log;
    //   29: goto +21 -> 50
    //   32: astore_1
    //   33: aload_0
    //   34: aconst_null
    //   35: putfield 6	com/mysql/cj/protocol/ReadAheadInputStream:underlyingStream	Ljava/io/InputStream;
    //   38: aload_0
    //   39: aconst_null
    //   40: putfield 4	com/mysql/cj/protocol/ReadAheadInputStream:buf	[B
    //   43: aload_0
    //   44: aconst_null
    //   45: putfield 22	com/mysql/cj/protocol/ReadAheadInputStream:log	Lcom/mysql/cj/log/Log;
    //   48: aload_1
    //   49: athrow
    //   50: return
    // Line number table:
    //   Java source line #248	-> byte code offset #0
    //   Java source line #250	-> byte code offset #7
    //   Java source line #252	-> byte code offset #14
    //   Java source line #253	-> byte code offset #19
    //   Java source line #254	-> byte code offset #24
    //   Java source line #255	-> byte code offset #29
    //   Java source line #252	-> byte code offset #32
    //   Java source line #253	-> byte code offset #38
    //   Java source line #254	-> byte code offset #43
    //   Java source line #255	-> byte code offset #48
    //   Java source line #257	-> byte code offset #50
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	51	0	this	ReadAheadInputStream
    //   32	17	1	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   7	14	32	finally
  }
  
  public boolean markSupported()
  {
    return false;
  }
  
  public long skip(long n)
    throws IOException
  {
    checkClosed();
    if (n <= 0L) {
      return 0L;
    }
    long bytesAvailInBuffer = endOfCurrentData - currentPosition;
    if (bytesAvailInBuffer <= 0L)
    {
      fill((int)n);
      bytesAvailInBuffer = endOfCurrentData - currentPosition;
      if (bytesAvailInBuffer <= 0L) {
        return 0L;
      }
    }
    long bytesSkipped = bytesAvailInBuffer < n ? bytesAvailInBuffer : n;
    currentPosition = ((int)(currentPosition + bytesSkipped));
    return bytesSkipped;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ReadAheadInputStream
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */