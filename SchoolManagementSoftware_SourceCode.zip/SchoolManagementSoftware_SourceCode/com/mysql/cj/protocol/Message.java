package com.mysql.cj.protocol;

public abstract interface Message
{
  public abstract byte[] getByteBuffer();
  
  public abstract int getPosition();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.Message
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */