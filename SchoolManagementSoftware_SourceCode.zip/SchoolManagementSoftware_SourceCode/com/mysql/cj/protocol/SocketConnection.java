package com.mysql.cj.protocol;

import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.FeatureNotAvailableException;
import com.mysql.cj.exceptions.SSLParamsException;
import com.mysql.cj.log.Log;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.channels.AsynchronousSocketChannel;

public abstract interface SocketConnection
{
  public abstract void connect(String paramString, int paramInt1, PropertySet paramPropertySet, ExceptionInterceptor paramExceptionInterceptor, Log paramLog, int paramInt2);
  
  public abstract void performTlsHandshake(ServerSession paramServerSession)
    throws SSLParamsException, FeatureNotAvailableException, IOException;
  
  public abstract void forceClose();
  
  public abstract NetworkResources getNetworkResources();
  
  public abstract String getHost();
  
  public abstract int getPort();
  
  public abstract Socket getMysqlSocket()
    throws IOException;
  
  public abstract FullReadInputStream getMysqlInput()
    throws IOException;
  
  public abstract void setMysqlInput(FullReadInputStream paramFullReadInputStream);
  
  public abstract BufferedOutputStream getMysqlOutput()
    throws IOException;
  
  public abstract boolean isSSLEstablished();
  
  public abstract SocketFactory getSocketFactory();
  
  public abstract void setSocketFactory(SocketFactory paramSocketFactory);
  
  public abstract ExceptionInterceptor getExceptionInterceptor();
  
  public abstract PropertySet getPropertySet();
  
  public boolean isSynchronous()
  {
    return true;
  }
  
  public abstract AsynchronousSocketChannel getAsynchronousSocketChannel();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.SocketConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */