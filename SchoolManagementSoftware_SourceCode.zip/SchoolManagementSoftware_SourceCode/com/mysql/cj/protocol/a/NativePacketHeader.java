package com.mysql.cj.protocol.a;

import com.mysql.cj.protocol.MessageHeader;
import java.nio.ByteBuffer;

public class NativePacketHeader
  implements MessageHeader
{
  protected ByteBuffer packetHeaderBuf;
  
  public NativePacketHeader()
  {
    packetHeaderBuf = ByteBuffer.allocate(4);
  }
  
  public NativePacketHeader(byte[] buf)
  {
    packetHeaderBuf = ByteBuffer.wrap(buf);
  }
  
  public ByteBuffer getBuffer()
  {
    return packetHeaderBuf;
  }
  
  public int getMessageSize()
  {
    return (packetHeaderBuf.array()[0] & 0xFF) + ((packetHeaderBuf.array()[1] & 0xFF) << 8) + ((packetHeaderBuf.array()[2] & 0xFF) << 16);
  }
  
  public byte getMessageSequence()
  {
    return packetHeaderBuf.array()[3];
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativePacketHeader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */