package com.mysql.cj.protocol.a;

import com.mysql.cj.Constants;
import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.util.StringUtils;

public class NativePacketPayload
  implements Message
{
  static final int NO_LENGTH_LIMIT = -1;
  public static final long NULL_LENGTH = -1L;
  public static final short TYPE_ID_ERROR = 255;
  public static final short TYPE_ID_EOF = 254;
  public static final short TYPE_ID_AUTH_SWITCH = 254;
  public static final short TYPE_ID_LOCAL_INFILE = 251;
  public static final short TYPE_ID_OK = 0;
  private int payloadLength = 0;
  private byte[] byteBuffer;
  private int position = 0;
  static final int MAX_BYTES_TO_DUMP = 1024;
  
  public String toString()
  {
    int numBytes = position <= payloadLength ? position : payloadLength;
    int numBytesToDump = numBytes < 1024 ? numBytes : 1024;
    
    position = 0;
    String dumped = StringUtils.dumpAsHex(readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, numBytesToDump), numBytesToDump);
    if (numBytesToDump < numBytes) {
      return dumped + " ....(packet exceeds max. dump length)";
    }
    return dumped;
  }
  
  public String toSuperString()
  {
    return super.toString();
  }
  
  public NativePacketPayload(byte[] buf)
  {
    byteBuffer = buf;
    payloadLength = buf.length;
  }
  
  public NativePacketPayload(int size)
  {
    byteBuffer = new byte[size];
    payloadLength = size;
  }
  
  public int getCapacity()
  {
    return byteBuffer.length;
  }
  
  public final void ensureCapacity(int additionalData)
  {
    if (position + additionalData > byteBuffer.length)
    {
      int newLength = (int)(byteBuffer.length * 1.25D);
      if (newLength < byteBuffer.length + additionalData) {
        newLength = byteBuffer.length + (int)(additionalData * 1.25D);
      }
      if (newLength < byteBuffer.length) {
        newLength = byteBuffer.length + additionalData;
      }
      byte[] newBytes = new byte[newLength];
      
      System.arraycopy(byteBuffer, 0, newBytes, 0, byteBuffer.length);
      byteBuffer = newBytes;
    }
  }
  
  public byte[] getByteBuffer()
  {
    return byteBuffer;
  }
  
  public void setByteBuffer(byte[] byteBufferToSet)
  {
    byteBuffer = byteBufferToSet;
  }
  
  public int getPayloadLength()
  {
    return payloadLength;
  }
  
  public void setPayloadLength(int bufLengthToSet)
  {
    if (bufLengthToSet > byteBuffer.length) {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Buffer.0")));
    }
    payloadLength = bufLengthToSet;
  }
  
  private void adjustPayloadLength()
  {
    if (position > payloadLength) {
      payloadLength = position;
    }
  }
  
  public int getPosition()
  {
    return position;
  }
  
  public void setPosition(int positionToSet)
  {
    position = positionToSet;
  }
  
  public boolean isErrorPacket()
  {
    return (byteBuffer[0] & 0xFF) == 255;
  }
  
  public final boolean isEOFPacket()
  {
    return ((byteBuffer[0] & 0xFF) == 254) && (getPayloadLength() <= 5);
  }
  
  public final boolean isAuthMethodSwitchRequestPacket()
  {
    return (byteBuffer[0] & 0xFF) == 254;
  }
  
  public final boolean isOKPacket()
  {
    return (byteBuffer[0] & 0xFF) == 0;
  }
  
  public final boolean isResultSetOKPacket()
  {
    return ((byteBuffer[0] & 0xFF) == 254) && (getPayloadLength() < 16777215);
  }
  
  public final boolean isAuthMoreData()
  {
    return (byteBuffer[0] & 0xFF) == 1;
  }
  
  public void writeInteger(NativeConstants.IntegerDataType type, long l)
  {
    switch (type)
    {
    case INT1: 
      ensureCapacity(1);
      byte[] b = byteBuffer;
      b[(position++)] = ((byte)(int)(l & 0xFF));
      break;
    case INT2: 
      ensureCapacity(2);
      byte[] b = byteBuffer;
      b[(position++)] = ((byte)(int)(l & 0xFF));
      b[(position++)] = ((byte)(int)(l >>> 8));
      break;
    case INT3: 
      ensureCapacity(3);
      byte[] b = byteBuffer;
      b[(position++)] = ((byte)(int)(l & 0xFF));
      b[(position++)] = ((byte)(int)(l >>> 8));
      b[(position++)] = ((byte)(int)(l >>> 16));
      break;
    case INT4: 
      ensureCapacity(4);
      byte[] b = byteBuffer;
      b[(position++)] = ((byte)(int)(l & 0xFF));
      b[(position++)] = ((byte)(int)(l >>> 8));
      b[(position++)] = ((byte)(int)(l >>> 16));
      b[(position++)] = ((byte)(int)(l >>> 24));
      break;
    case INT6: 
      ensureCapacity(6);
      byte[] b = byteBuffer;
      b[(position++)] = ((byte)(int)(l & 0xFF));
      b[(position++)] = ((byte)(int)(l >>> 8));
      b[(position++)] = ((byte)(int)(l >>> 16));
      b[(position++)] = ((byte)(int)(l >>> 24));
      b[(position++)] = ((byte)(int)(l >>> 32));
      b[(position++)] = ((byte)(int)(l >>> 40));
      break;
    case INT8: 
      ensureCapacity(8);
      byte[] b = byteBuffer;
      b[(position++)] = ((byte)(int)(l & 0xFF));
      b[(position++)] = ((byte)(int)(l >>> 8));
      b[(position++)] = ((byte)(int)(l >>> 16));
      b[(position++)] = ((byte)(int)(l >>> 24));
      b[(position++)] = ((byte)(int)(l >>> 32));
      b[(position++)] = ((byte)(int)(l >>> 40));
      b[(position++)] = ((byte)(int)(l >>> 48));
      b[(position++)] = ((byte)(int)(l >>> 56));
      break;
    case INT_LENENC: 
      if (l < 251L)
      {
        ensureCapacity(1);
        writeInteger(NativeConstants.IntegerDataType.INT1, l);
      }
      else if (l < 65536L)
      {
        ensureCapacity(3);
        writeInteger(NativeConstants.IntegerDataType.INT1, 252L);
        writeInteger(NativeConstants.IntegerDataType.INT2, l);
      }
      else if (l < 16777216L)
      {
        ensureCapacity(4);
        writeInteger(NativeConstants.IntegerDataType.INT1, 253L);
        writeInteger(NativeConstants.IntegerDataType.INT3, l);
      }
      else
      {
        ensureCapacity(9);
        writeInteger(NativeConstants.IntegerDataType.INT1, 254L);
        writeInteger(NativeConstants.IntegerDataType.INT8, l);
      }
      break;
    }
    adjustPayloadLength();
  }
  
  public final long readInteger(NativeConstants.IntegerDataType type)
  {
    byte[] b = byteBuffer;
    switch (type)
    {
    case INT1: 
      return b[(position++)] & 0xFF;
    case INT2: 
      return b[(position++)] & 0xFF | (b[(position++)] & 0xFF) << 8;
    case INT3: 
      return b[(position++)] & 0xFF | (b[(position++)] & 0xFF) << 8 | (b[(position++)] & 0xFF) << 16;
    case INT4: 
      return b[(position++)] & 0xFF | (b[(position++)] & 0xFF) << 8 | (b[(position++)] & 0xFF) << 16 | (b[(position++)] & 0xFF) << 24;
    case INT6: 
      return b[(position++)] & 0xFF | (b[(position++)] & 0xFF) << 8 | (b[(position++)] & 0xFF) << 16 | (b[(position++)] & 0xFF) << 24 | (b[(position++)] & 0xFF) << 32 | (b[(position++)] & 0xFF) << 40;
    case INT8: 
      return b[(position++)] & 0xFF | (b[(position++)] & 0xFF) << 8 | (b[(position++)] & 0xFF) << 16 | (b[(position++)] & 0xFF) << 24 | (b[(position++)] & 0xFF) << 32 | (b[(position++)] & 0xFF) << 40 | (b[(position++)] & 0xFF) << 48 | (b[(position++)] & 0xFF) << 56;
    case INT_LENENC: 
      int sw = b[(position++)] & 0xFF;
      switch (sw)
      {
      case 251: 
        return -1L;
      case 252: 
        return readInteger(NativeConstants.IntegerDataType.INT2);
      case 253: 
        return readInteger(NativeConstants.IntegerDataType.INT3);
      case 254: 
        return readInteger(NativeConstants.IntegerDataType.INT8);
      }
      return sw;
    }
    return b[(position++)] & 0xFF;
  }
  
  public final void writeBytes(NativeConstants.StringSelfDataType type, byte[] b)
  {
    writeBytes(type, b, 0, b.length);
  }
  
  public final void writeBytes(NativeConstants.StringLengthDataType type, byte[] b)
  {
    writeBytes(type, b, 0, b.length);
  }
  
  public void writeBytes(NativeConstants.StringSelfDataType type, byte[] b, int offset, int len)
  {
    switch (type)
    {
    case STRING_EOF: 
      writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, b, offset, len);
      break;
    case STRING_TERM: 
      ensureCapacity(len + 1);
      writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, b, offset, len);
      byteBuffer[(position++)] = 0;
      break;
    case STRING_LENENC: 
      ensureCapacity(len + 9);
      writeInteger(NativeConstants.IntegerDataType.INT_LENENC, len);
      writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, b, offset, len);
    }
    adjustPayloadLength();
  }
  
  public void writeBytes(NativeConstants.StringLengthDataType type, byte[] b, int offset, int len)
  {
    switch (type)
    {
    case STRING_FIXED: 
    case STRING_VAR: 
      ensureCapacity(len);
      System.arraycopy(b, offset, byteBuffer, position, len);
      position += len;
    }
    adjustPayloadLength();
  }
  
  public byte[] readBytes(NativeConstants.StringSelfDataType type)
  {
    switch (type)
    {
    case STRING_TERM: 
      int i = position;
      while ((i < payloadLength) && (byteBuffer[i] != 0)) {
        i++;
      }
      byte[] b = readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, i - position);
      position += 1;
      return b;
    case STRING_LENENC: 
      long l = readInteger(NativeConstants.IntegerDataType.INT_LENENC);
      return l == 0L ? Constants.EMPTY_BYTE_ARRAY : l == -1L ? null : readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, (int)l);
    case STRING_EOF: 
      return readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, payloadLength - position);
    }
    return null;
  }
  
  public void skipBytes(NativeConstants.StringSelfDataType type)
  {
    switch (type)
    {
    case STRING_TERM: 
      while ((position < payloadLength) && (byteBuffer[position] != 0)) {
        position += 1;
      }
      position += 1;
      break;
    case STRING_LENENC: 
      long len = readInteger(NativeConstants.IntegerDataType.INT_LENENC);
      if ((len != -1L) && (len != 0L)) {
        position += (int)len;
      }
      break;
    case STRING_EOF: 
      position = payloadLength;
    }
  }
  
  public byte[] readBytes(NativeConstants.StringLengthDataType type, int len)
  {
    switch (type)
    {
    case STRING_FIXED: 
    case STRING_VAR: 
      byte[] b = new byte[len];
      System.arraycopy(byteBuffer, position, b, 0, len);
      position += len;
      return b;
    }
    return null;
  }
  
  public String readString(NativeConstants.StringSelfDataType type, String encoding)
  {
    String res = null;
    switch (type)
    {
    case STRING_TERM: 
      int i = position;
      while ((i < payloadLength) && (byteBuffer[i] != 0)) {
        i++;
      }
      res = readString(NativeConstants.StringLengthDataType.STRING_FIXED, encoding, i - position);
      position += 1;
      break;
    case STRING_LENENC: 
      long l = readInteger(NativeConstants.IntegerDataType.INT_LENENC);
      return l == 0L ? "" : l == -1L ? null : readString(NativeConstants.StringLengthDataType.STRING_FIXED, encoding, (int)l);
    case STRING_EOF: 
      return readString(NativeConstants.StringLengthDataType.STRING_FIXED, encoding, payloadLength - position);
    }
    return res;
  }
  
  public String readString(NativeConstants.StringLengthDataType type, String encoding, int len)
  {
    String res = null;
    switch (type)
    {
    case STRING_FIXED: 
    case STRING_VAR: 
      if (position + len > payloadLength) {
        throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Buffer.1")));
      }
      res = StringUtils.toString(byteBuffer, position, len, encoding);
      position += len;
    }
    return res;
  }
  
  public static String extractSqlFromPacket(String possibleSqlQuery, NativePacketPayload packet, int endOfQueryPacketPosition, int maxQuerySizeToLog)
  {
    String extractedSql = null;
    if (possibleSqlQuery != null) {
      if (possibleSqlQuery.length() > maxQuerySizeToLog)
      {
        StringBuilder truncatedQueryBuf = new StringBuilder(possibleSqlQuery.substring(0, maxQuerySizeToLog));
        truncatedQueryBuf.append(Messages.getString("MysqlIO.25"));
        extractedSql = truncatedQueryBuf.toString();
      }
      else
      {
        extractedSql = possibleSqlQuery;
      }
    }
    if (extractedSql == null)
    {
      int extractPosition = endOfQueryPacketPosition;
      
      boolean truncated = false;
      if (endOfQueryPacketPosition > maxQuerySizeToLog)
      {
        extractPosition = maxQuerySizeToLog;
        truncated = true;
      }
      extractedSql = StringUtils.toString(packet.getByteBuffer(), 1, extractPosition - 1);
      if (truncated) {
        extractedSql = extractedSql + Messages.getString("MysqlIO.25");
      }
    }
    return extractedSql;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativePacketPayload
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */