package com.mysql.cj.protocol.a;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.ProtocolEntityReader;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.Resultset.Type;
import com.mysql.cj.protocol.ResultsetRow;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.a.result.OkPacket;
import com.mysql.cj.protocol.a.result.ResultsetRowsCursor;
import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
import com.mysql.cj.protocol.a.result.ResultsetRowsStreaming;
import java.io.IOException;
import java.util.ArrayList;

public class BinaryResultsetReader
  implements ProtocolEntityReader<Resultset, NativePacketPayload>
{
  protected NativeProtocol protocol;
  
  public BinaryResultsetReader(NativeProtocol prot)
  {
    protocol = prot;
  }
  
  public Resultset read(int maxRows, boolean streamResults, NativePacketPayload resultPacket, ColumnDefinition metadata, ProtocolEntityFactory<Resultset, NativePacketPayload> resultSetFactory)
    throws IOException
  {
    Resultset rs = null;
    
    long columnCount = resultPacket.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
    if (columnCount > 0L)
    {
      ColumnDefinition cdef = (ColumnDefinition)protocol.read(ColumnDefinition.class, new MergingColumnDefinitionFactory(columnCount, metadata));
      
      boolean isCursorPosible = (((Boolean)protocol.getPropertySet().getBooleanProperty(PropertyKey.useCursorFetch).getValue()).booleanValue()) && (resultSetFactory.getResultSetType() == Resultset.Type.FORWARD_ONLY) && (resultSetFactory.getFetchSize() > 0);
      if ((isCursorPosible) || (!protocol.getServerSession().isEOFDeprecated())) {
        protocol.readServerStatusForResultSets(protocol.readMessage(protocol.getReusablePacket()), true);
      }
      ResultsetRows rows = null;
      if ((isCursorPosible) && (protocol.getServerSession().cursorExists()))
      {
        rows = new ResultsetRowsCursor(protocol, cdef);
      }
      else if (!streamResults)
      {
        BinaryRowFactory brf = new BinaryRowFactory(protocol, cdef, resultSetFactory.getResultSetConcurrency(), false);
        
        ArrayList<ResultsetRow> rowList = new ArrayList();
        ResultsetRow row = (ResultsetRow)protocol.read(ResultsetRow.class, brf);
        while (row != null)
        {
          if ((maxRows == -1) || (rowList.size() < maxRows)) {
            rowList.add(row);
          }
          row = (ResultsetRow)protocol.read(ResultsetRow.class, brf);
        }
        rows = new ResultsetRowsStatic(rowList, cdef);
      }
      else
      {
        rows = new ResultsetRowsStreaming(protocol, cdef, true, resultSetFactory);
        protocol.setStreamingData(rows);
      }
      rs = (Resultset)resultSetFactory.createFromProtocolEntity(rows);
    }
    else
    {
      if (columnCount == -1L)
      {
        String charEncoding = (String)protocol.getPropertySet().getStringProperty(PropertyKey.characterEncoding).getValue();
        String fileName = resultPacket.readString(NativeConstants.StringSelfDataType.STRING_TERM, protocol.doesPlatformDbCharsetMatches() ? charEncoding : null);
        resultPacket = protocol.sendFileToServer(fileName);
      }
      OkPacket ok = (OkPacket)protocol.readServerStatusForResultSets(resultPacket, false);
      
      rs = (Resultset)resultSetFactory.createFromProtocolEntity(ok);
    }
    return rs;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.BinaryResultsetReader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */