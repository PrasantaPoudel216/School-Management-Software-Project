package com.mysql.cj.protocol.a.result;

import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ValueDecoder;
import com.mysql.cj.protocol.a.NativeConstants.IntegerDataType;
import com.mysql.cj.protocol.a.NativeConstants.StringSelfDataType;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.result.Row;
import com.mysql.cj.result.ValueFactory;

public class TextBufferRow
  extends AbstractBufferRow
{
  public TextBufferRow(NativePacketPayload buf, ColumnDefinition cd, ExceptionInterceptor exceptionInterceptor, ValueDecoder valueDecoder)
  {
    super(exceptionInterceptor);
    
    rowFromServer = buf;
    homePosition = rowFromServer.getPosition();
    this.valueDecoder = valueDecoder;
    if (cd.getFields() != null) {
      setMetadata(cd);
    }
  }
  
  protected int findAndSeekToOffset(int index)
  {
    if (index == 0)
    {
      lastRequestedIndex = 0;
      lastRequestedPos = homePosition;
      rowFromServer.setPosition(homePosition);
      
      return 0;
    }
    if (index == lastRequestedIndex)
    {
      rowFromServer.setPosition(lastRequestedPos);
      
      return lastRequestedPos;
    }
    int startingIndex = 0;
    if (index > lastRequestedIndex)
    {
      if (lastRequestedIndex >= 0) {
        startingIndex = lastRequestedIndex;
      } else {
        startingIndex = 0;
      }
      rowFromServer.setPosition(lastRequestedPos);
    }
    else
    {
      rowFromServer.setPosition(homePosition);
    }
    for (int i = startingIndex; i < index; i++) {
      rowFromServer.skipBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
    }
    lastRequestedIndex = index;
    lastRequestedPos = rowFromServer.getPosition();
    
    return lastRequestedPos;
  }
  
  public byte[] getBytes(int index)
  {
    if (getNull(index)) {
      return null;
    }
    findAndSeekToOffset(index);
    return rowFromServer.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
  }
  
  public boolean getNull(int columnIndex)
  {
    findAndSeekToOffset(columnIndex);
    wasNull = (rowFromServer.readInteger(NativeConstants.IntegerDataType.INT_LENENC) == -1L);
    return wasNull;
  }
  
  public Row setMetadata(ColumnDefinition f)
  {
    super.setMetadata(f);
    return this;
  }
  
  public <T> T getValue(int columnIndex, ValueFactory<T> vf)
  {
    findAndSeekToOffset(columnIndex);
    int length = (int)rowFromServer.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
    return (T)getValueFromBytes(columnIndex, rowFromServer.getByteBuffer(), rowFromServer.getPosition(), length, vf);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.result.TextBufferRow
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */