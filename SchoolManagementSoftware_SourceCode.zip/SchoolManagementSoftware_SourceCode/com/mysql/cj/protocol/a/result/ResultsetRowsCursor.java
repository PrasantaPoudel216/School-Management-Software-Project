package com.mysql.cj.protocol.a.result;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.Resultset.Concurrency;
import com.mysql.cj.protocol.ResultsetRow;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.ResultsetRowsOwner;
import com.mysql.cj.protocol.a.BinaryRowFactory;
import com.mysql.cj.protocol.a.NativeMessageBuilder;
import com.mysql.cj.protocol.a.NativeProtocol;
import com.mysql.cj.protocol.a.NativeServerSession;
import com.mysql.cj.result.Row;
import java.util.ArrayList;
import java.util.List;

public class ResultsetRowsCursor
  extends AbstractResultsetRows
  implements ResultsetRows
{
  private List<Row> fetchedRows;
  private int currentPositionInEntireResult = -1;
  private boolean lastRowFetched = false;
  private NativeProtocol protocol;
  private boolean firstFetchCompleted = false;
  protected NativeMessageBuilder commandBuilder = new NativeMessageBuilder();
  
  public ResultsetRowsCursor(NativeProtocol ioChannel, ColumnDefinition columnDefinition)
  {
    currentPositionInEntireResult = -1;
    metadata = columnDefinition;
    protocol = ioChannel;
    rowFactory = new BinaryRowFactory(protocol, metadata, Resultset.Concurrency.READ_ONLY, false);
  }
  
  public boolean isAfterLast()
  {
    return (lastRowFetched) && (currentPositionInFetchedRows > fetchedRows.size());
  }
  
  public boolean isBeforeFirst()
  {
    return currentPositionInEntireResult < 0;
  }
  
  public int getPosition()
  {
    return currentPositionInEntireResult + 1;
  }
  
  public boolean isEmpty()
  {
    return (isBeforeFirst()) && (isAfterLast());
  }
  
  public boolean isFirst()
  {
    return currentPositionInEntireResult == 0;
  }
  
  public boolean isLast()
  {
    return (lastRowFetched) && (currentPositionInFetchedRows == fetchedRows.size() - 1);
  }
  
  public void close()
  {
    metadata = null;
    owner = null;
  }
  
  public boolean hasNext()
  {
    if ((fetchedRows != null) && (fetchedRows.size() == 0)) {
      return false;
    }
    if (owner != null)
    {
      int maxRows = owner.getOwningStatementMaxRows();
      if ((maxRows != -1) && (currentPositionInEntireResult + 1 > maxRows)) {
        return false;
      }
    }
    if (currentPositionInEntireResult != -1)
    {
      if (currentPositionInFetchedRows < fetchedRows.size() - 1) {
        return true;
      }
      if ((currentPositionInFetchedRows == fetchedRows.size()) && (lastRowFetched)) {
        return false;
      }
      fetchMoreRows();
      
      return fetchedRows.size() > 0;
    }
    fetchMoreRows();
    
    return fetchedRows.size() > 0;
  }
  
  public Row next()
  {
    if ((fetchedRows == null) && (currentPositionInEntireResult != -1)) {
      throw ExceptionFactory.createException(Messages.getString("ResultSet.Operation_not_allowed_after_ResultSet_closed_144"), protocol
        .getExceptionInterceptor());
    }
    if (!hasNext()) {
      return null;
    }
    currentPositionInEntireResult += 1;
    currentPositionInFetchedRows += 1;
    if ((fetchedRows != null) && (fetchedRows.size() == 0)) {
      return null;
    }
    if ((fetchedRows == null) || (currentPositionInFetchedRows > fetchedRows.size() - 1))
    {
      fetchMoreRows();
      currentPositionInFetchedRows = 0;
    }
    Row row = (Row)fetchedRows.get(currentPositionInFetchedRows);
    
    row.setMetadata(metadata);
    
    return row;
  }
  
  private void fetchMoreRows()
  {
    if (lastRowFetched)
    {
      fetchedRows = new ArrayList(0);
      return;
    }
    synchronized (owner.getSyncMutex())
    {
      try
      {
        boolean oldFirstFetchCompleted = firstFetchCompleted;
        if (!firstFetchCompleted) {
          firstFetchCompleted = true;
        }
        int numRowsToFetch = owner.getOwnerFetchSize();
        if (numRowsToFetch == 0) {
          numRowsToFetch = owner.getOwningStatementFetchSize();
        }
        if (numRowsToFetch == Integer.MIN_VALUE) {
          numRowsToFetch = 1;
        }
        if (fetchedRows == null) {
          fetchedRows = new ArrayList(numRowsToFetch);
        } else {
          fetchedRows.clear();
        }
        protocol.sendCommand(commandBuilder
          .buildComStmtFetch(protocol.getSharedSendPacket(), owner.getOwningStatementServerId(), numRowsToFetch), true, 0);
        
        Row row = null;
        while ((row = (Row)protocol.read(ResultsetRow.class, rowFactory)) != null) {
          fetchedRows.add(row);
        }
        currentPositionInFetchedRows = -1;
        if (protocol.getServerSession().isLastRowSent())
        {
          lastRowFetched = true;
          if ((!oldFirstFetchCompleted) && (fetchedRows.size() == 0)) {
            wasEmpty = true;
          }
        }
      }
      catch (Exception ex)
      {
        throw ExceptionFactory.createException(ex.getMessage(), ex);
      }
    }
  }
  
  public void addRow(Row row) {}
  
  public void afterLast()
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
  
  public void beforeFirst()
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
  
  public void beforeLast()
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
  
  public void moveRowRelative(int rows)
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
  
  public void setCurrentRow(int rowNumber)
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.result.ResultsetRowsCursor
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */