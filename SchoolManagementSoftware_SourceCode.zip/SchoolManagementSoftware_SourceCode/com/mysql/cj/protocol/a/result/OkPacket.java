package com.mysql.cj.protocol.a.result;

import com.mysql.cj.protocol.ProtocolEntity;
import com.mysql.cj.protocol.a.NativeConstants.IntegerDataType;
import com.mysql.cj.protocol.a.NativeConstants.StringSelfDataType;
import com.mysql.cj.protocol.a.NativePacketPayload;

public class OkPacket
  implements ProtocolEntity
{
  private long updateCount = -1L;
  private long updateID = -1L;
  private int statusFlags = 0;
  private int warningCount = 0;
  private String info = null;
  
  public static OkPacket parse(NativePacketPayload buf, String errorMessageEncoding)
  {
    OkPacket ok = new OkPacket();
    
    buf.setPosition(1);
    
    ok.setUpdateCount(buf.readInteger(NativeConstants.IntegerDataType.INT_LENENC));
    ok.setUpdateID(buf.readInteger(NativeConstants.IntegerDataType.INT_LENENC));
    ok.setStatusFlags((int)buf.readInteger(NativeConstants.IntegerDataType.INT2));
    ok.setWarningCount((int)buf.readInteger(NativeConstants.IntegerDataType.INT2));
    ok.setInfo(buf.readString(NativeConstants.StringSelfDataType.STRING_TERM, errorMessageEncoding));
    return ok;
  }
  
  public long getUpdateCount()
  {
    return updateCount;
  }
  
  public void setUpdateCount(long updateCount)
  {
    this.updateCount = updateCount;
  }
  
  public long getUpdateID()
  {
    return updateID;
  }
  
  public void setUpdateID(long updateID)
  {
    this.updateID = updateID;
  }
  
  public String getInfo()
  {
    return info;
  }
  
  public void setInfo(String info)
  {
    this.info = info;
  }
  
  public int getStatusFlags()
  {
    return statusFlags;
  }
  
  public void setStatusFlags(int statusFlags)
  {
    this.statusFlags = statusFlags;
  }
  
  public int getWarningCount()
  {
    return warningCount;
  }
  
  public void setWarningCount(int warningCount)
  {
    this.warningCount = warningCount;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.result.OkPacket
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */