package com.mysql.cj.protocol.a.result;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ValueDecoder;
import com.mysql.cj.protocol.a.NativeConstants.IntegerDataType;
import com.mysql.cj.protocol.a.NativeConstants.StringLengthDataType;
import com.mysql.cj.protocol.a.NativeConstants.StringSelfDataType;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.protocol.a.NativeUtils;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.Row;
import com.mysql.cj.result.ValueFactory;

public class BinaryBufferRow
  extends AbstractBufferRow
{
  private int preNullBitmaskHomePosition = 0;
  private boolean[] isNull;
  
  public BinaryBufferRow(NativePacketPayload buf, ColumnDefinition cd, ExceptionInterceptor exceptionInterceptor, ValueDecoder valueDecoder)
  {
    super(exceptionInterceptor);
    
    rowFromServer = buf;
    homePosition = rowFromServer.getPosition();
    preNullBitmaskHomePosition = homePosition;
    this.valueDecoder = valueDecoder;
    if (cd.getFields() != null) {
      setMetadata(cd);
    }
  }
  
  public boolean isBinaryEncoded()
  {
    return true;
  }
  
  protected int findAndSeekToOffset(int index)
  {
    if (index == 0)
    {
      lastRequestedIndex = 0;
      lastRequestedPos = homePosition;
      rowFromServer.setPosition(homePosition);
      
      return 0;
    }
    if (index == lastRequestedIndex)
    {
      rowFromServer.setPosition(lastRequestedPos);
      
      return lastRequestedPos;
    }
    int startingIndex = 0;
    if (index > lastRequestedIndex)
    {
      if (lastRequestedIndex >= 0)
      {
        startingIndex = lastRequestedIndex;
      }
      else
      {
        startingIndex = 0;
        lastRequestedPos = homePosition;
      }
      rowFromServer.setPosition(lastRequestedPos);
    }
    else
    {
      rowFromServer.setPosition(homePosition);
    }
    for (int i = startingIndex; i < index; i++) {
      if (isNull[i] == 0)
      {
        int type = metadata.getFields()[i].getMysqlTypeId();
        if (type != 6)
        {
          int length = NativeUtils.getBinaryEncodedLength(metadata.getFields()[i].getMysqlTypeId());
          if (length == 0)
          {
            rowFromServer.skipBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
          }
          else
          {
            if (length == -1) {
              throw ExceptionFactory.createException(Messages.getString("MysqlIO.97", new Object[] { Integer.valueOf(type), Integer.valueOf(i + 1), Integer.valueOf(metadata.getFields().length) }), exceptionInterceptor);
            }
            int curPosition = rowFromServer.getPosition();
            rowFromServer.setPosition(curPosition + length);
          }
        }
      }
    }
    lastRequestedIndex = index;
    lastRequestedPos = rowFromServer.getPosition();
    
    return lastRequestedPos;
  }
  
  public byte[] getBytes(int index)
  {
    findAndSeekToOffset(index);
    if (getNull(index)) {
      return null;
    }
    int type = metadata.getFields()[index].getMysqlTypeId();
    switch (type)
    {
    case 6: 
      return null;
    case 1: 
      return rowFromServer.readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, 1);
    }
    int length = NativeUtils.getBinaryEncodedLength(type);
    if (length == 0) {
      return rowFromServer.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
    }
    if (length == -1) {
      throw ExceptionFactory.createException(Messages.getString("MysqlIO.97", new Object[] { Integer.valueOf(type), Integer.valueOf(index + 1), Integer.valueOf(metadata.getFields().length) }), exceptionInterceptor);
    }
    return rowFromServer.readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, length);
  }
  
  public boolean getNull(int columnIndex)
  {
    wasNull = isNull[columnIndex];
    return wasNull;
  }
  
  public Row setMetadata(ColumnDefinition f)
  {
    super.setMetadata(f);
    setupIsNullBitmask();
    return this;
  }
  
  private void setupIsNullBitmask()
  {
    if (isNull != null) {
      return;
    }
    rowFromServer.setPosition(preNullBitmaskHomePosition);
    
    int len = metadata.getFields().length;
    int nullCount = (len + 9) / 8;
    
    byte[] nullBitMask = rowFromServer.readBytes(NativeConstants.StringLengthDataType.STRING_FIXED, nullCount);
    
    homePosition = rowFromServer.getPosition();
    
    isNull = new boolean[len];
    
    int nullMaskPos = 0;
    int bit = 4;
    for (int i = 0; i < len; i++)
    {
      isNull[i] = ((nullBitMask[nullMaskPos] & bit) != 0 ? 1 : false);
      if ((bit <<= 1 & 0xFF) == 0)
      {
        bit = 1;
        
        nullMaskPos++;
      }
    }
  }
  
  public <T> T getValue(int columnIndex, ValueFactory<T> vf)
  {
    findAndSeekToOffset(columnIndex);
    
    int type = metadata.getFields()[columnIndex].getMysqlTypeId();
    int length = NativeUtils.getBinaryEncodedLength(type);
    if (!getNull(columnIndex)) {
      if (length == 0) {
        length = (int)rowFromServer.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
      } else if (length == -1) {
        throw ExceptionFactory.createException(
          Messages.getString("MysqlIO.97", new Object[] {Integer.valueOf(type), Integer.valueOf(columnIndex + 1), Integer.valueOf(metadata.getFields().length) }), exceptionInterceptor);
      }
    }
    return (T)getValueFromBytes(columnIndex, rowFromServer.getByteBuffer(), rowFromServer.getPosition(), length, vf);
  }
  
  public void setBytes(int columnIndex, byte[] value)
  {
    byte[] backup = null;
    int backupLength = 0;
    if (columnIndex + 1 < metadata.getFields().length)
    {
      findAndSeekToOffset(columnIndex + 1);
      backupLength = rowFromServer.getPayloadLength() - rowFromServer.getPosition();
      backup = new byte[backupLength];
      System.arraycopy(rowFromServer.getByteBuffer(), rowFromServer.getPosition(), backup, 0, backupLength);
    }
    findAndSeekToOffset(columnIndex);
    rowFromServer.setPayloadLength(rowFromServer.getPosition());
    if (value == null)
    {
      metadata.getFields()[columnIndex].setMysqlTypeId(6);
    }
    else
    {
      int type = metadata.getFields()[columnIndex].getMysqlTypeId();
      
      int length = NativeUtils.getBinaryEncodedLength(type);
      if (length == 0)
      {
        rowFromServer.writeBytes(NativeConstants.StringSelfDataType.STRING_LENENC, value);
      }
      else
      {
        if (length == -1) {
          throw ExceptionFactory.createException(
            Messages.getString("MysqlIO.97", new Object[] {Integer.valueOf(type), Integer.valueOf(columnIndex + 1), Integer.valueOf(metadata.getFields().length) }), exceptionInterceptor);
        }
        if (length != value.length) {
          throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, "Value length doesn't match the expected one for type " + type, exceptionInterceptor));
        }
        rowFromServer.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, value);
      }
    }
    if (backup != null) {
      rowFromServer.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, backup);
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.result.BinaryBufferRow
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */