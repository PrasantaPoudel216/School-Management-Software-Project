package com.mysql.cj.protocol.a.result;

import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.result.DefaultColumnDefinition;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.Row;
import java.util.HashMap;

public class NativeResultset
  implements Resultset
{
  protected ColumnDefinition columnDefinition;
  protected ResultsetRows rowData;
  protected Resultset nextResultset = null;
  protected int resultId;
  protected long updateCount;
  protected long updateId = -1L;
  protected String serverInfo = null;
  protected Row thisRow = null;
  
  public NativeResultset() {}
  
  public NativeResultset(OkPacket ok)
  {
    updateCount = ok.getUpdateCount();
    updateId = ok.getUpdateID();
    serverInfo = ok.getInfo();
    columnDefinition = new DefaultColumnDefinition(new Field[0]);
  }
  
  public NativeResultset(ResultsetRows rows)
  {
    columnDefinition = rows.getMetadata();
    rowData = rows;
    updateCount = rowData.size();
    if (rowData.size() > 0)
    {
      if ((updateCount == 1L) && 
        (thisRow == null))
      {
        rowData.close();
        updateCount = -1L;
      }
    }
    else {
      thisRow = null;
    }
  }
  
  public void setColumnDefinition(ColumnDefinition metadata)
  {
    columnDefinition = metadata;
  }
  
  public ColumnDefinition getColumnDefinition()
  {
    return columnDefinition;
  }
  
  public boolean hasRows()
  {
    return rowData != null;
  }
  
  public int getResultId()
  {
    return resultId;
  }
  
  public void initRowsWithMetadata()
  {
    rowData.setMetadata(columnDefinition);
    columnDefinition.setColumnToIndexCache(new HashMap());
  }
  
  public synchronized void setNextResultset(Resultset nextResultset)
  {
    this.nextResultset = nextResultset;
  }
  
  public synchronized Resultset getNextResultset()
  {
    return nextResultset;
  }
  
  public synchronized void clearNextResultset()
  {
    nextResultset = null;
  }
  
  public long getUpdateCount()
  {
    return updateCount;
  }
  
  public long getUpdateID()
  {
    return updateId;
  }
  
  public String getServerInfo()
  {
    return serverInfo;
  }
  
  public ResultsetRows getRows()
  {
    return rowData;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.result.NativeResultset
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */