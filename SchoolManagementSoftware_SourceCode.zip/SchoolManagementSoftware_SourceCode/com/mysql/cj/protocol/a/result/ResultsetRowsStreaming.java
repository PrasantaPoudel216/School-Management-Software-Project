package com.mysql.cj.protocol.a.result;

import com.mysql.cj.Messages;
import com.mysql.cj.Session;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.StreamingNotifiable;
import com.mysql.cj.log.ProfilerEventHandler;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ProtocolEntity;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.Resultset.Concurrency;
import com.mysql.cj.protocol.ResultsetRow;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.ResultsetRowsOwner;
import com.mysql.cj.protocol.a.BinaryRowFactory;
import com.mysql.cj.protocol.a.NativeMessageBuilder;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.protocol.a.NativeProtocol;
import com.mysql.cj.protocol.a.NativeServerSession;
import com.mysql.cj.protocol.a.TextRowFactory;
import com.mysql.cj.result.Row;
import com.mysql.cj.util.Util;

public class ResultsetRowsStreaming<T extends ProtocolEntity>
  extends AbstractResultsetRows
  implements ResultsetRows
{
  private NativeProtocol protocol;
  private boolean isAfterEnd = false;
  private boolean noMoreRows = false;
  private boolean isBinaryEncoded = false;
  private Row nextRow;
  private boolean streamerClosed = false;
  private ExceptionInterceptor exceptionInterceptor;
  private ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory;
  private NativeMessageBuilder commandBuilder = new NativeMessageBuilder();
  
  public ResultsetRowsStreaming(NativeProtocol io, ColumnDefinition columnDefinition, boolean isBinaryEncoded, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory)
  {
    protocol = io;
    this.isBinaryEncoded = isBinaryEncoded;
    metadata = columnDefinition;
    exceptionInterceptor = protocol.getExceptionInterceptor();
    this.resultSetFactory = resultSetFactory;
    rowFactory = (this.isBinaryEncoded ? new BinaryRowFactory(protocol, metadata, Resultset.Concurrency.READ_ONLY, true) : new TextRowFactory(protocol, metadata, Resultset.Concurrency.READ_ONLY, true));
  }
  
  public void close()
  {
    Object mutex = (owner != null) && (owner.getSyncMutex() != null) ? owner.getSyncMutex() : this;
    
    boolean hadMore = false;
    int howMuchMore = 0;
    synchronized (mutex)
    {
      while (next() != null)
      {
        hadMore = true;
        howMuchMore++;
        if (howMuchMore % 100 == 0) {
          Thread.yield();
        }
      }
      if ((!((Boolean)protocol.getPropertySet().getBooleanProperty(PropertyKey.clobberStreamingResults).getValue()).booleanValue()) && 
        (((Integer)protocol.getPropertySet().getIntegerProperty(PropertyKey.netTimeoutForStreamingResults).getValue()).intValue() > 0))
      {
        int oldValue = protocol.getServerSession().getServerVariable("net_write_timeout", 60);
        
        protocol.clearInputStream();
        try
        {
          protocol.sendCommand(commandBuilder.buildComQuery(protocol.getSharedSendPacket(), "SET net_write_timeout=" + oldValue, 
            (String)protocol.getPropertySet().getStringProperty(PropertyKey.characterEncoding).getValue()), false, 0);
        }
        catch (Exception ex)
        {
          throw ExceptionFactory.createException(ex.getMessage(), ex, exceptionInterceptor);
        }
      }
      if ((((Boolean)protocol.getPropertySet().getBooleanProperty(PropertyKey.useUsageAdvisor).getValue()).booleanValue()) && 
        (hadMore)) {
        owner.getSession().getProfilerEventHandler().processEvent((byte)0, owner.getSession(), owner
          .getOwningQuery(), null, 0L, new Throwable(), 
          Messages.getString("RowDataDynamic.1", new String[] {String.valueOf(howMuchMore), owner.getPointOfOrigin() }));
      }
    }
    metadata = null;
    owner = null;
  }
  
  public boolean hasNext()
  {
    boolean hasNext = nextRow != null;
    if ((!hasNext) && (!streamerClosed))
    {
      protocol.closeStreamer(this);
      streamerClosed = true;
    }
    return hasNext;
  }
  
  public boolean isAfterLast()
  {
    return isAfterEnd;
  }
  
  public boolean isBeforeFirst()
  {
    return currentPositionInFetchedRows < 0;
  }
  
  public boolean isEmpty()
  {
    return wasEmpty;
  }
  
  public boolean isFirst()
  {
    return currentPositionInFetchedRows == 0;
  }
  
  public boolean isLast()
  {
    return (!isBeforeFirst()) && (!isAfterLast()) && (noMoreRows);
  }
  
  public Row next()
  {
    try
    {
      if (!noMoreRows)
      {
        nextRow = ((Row)protocol.read(ResultsetRow.class, rowFactory));
        if (nextRow == null)
        {
          noMoreRows = true;
          isAfterEnd = true;
          if (currentPositionInFetchedRows == -1) {
            wasEmpty = true;
          }
        }
      }
      else
      {
        nextRow = null;
        isAfterEnd = true;
      }
      if ((nextRow == null) && (!streamerClosed)) {
        if (protocol.getServerSession().hasMoreResults())
        {
          protocol.readNextResultset((ProtocolEntity)owner, owner.getOwningStatementMaxRows(), true, isBinaryEncoded, resultSetFactory);
        }
        else
        {
          protocol.closeStreamer(this);
          streamerClosed = true;
        }
      }
      if ((nextRow != null) && 
        (currentPositionInFetchedRows != Integer.MAX_VALUE)) {
        currentPositionInFetchedRows += 1;
      }
      return nextRow;
    }
    catch (CJException sqlEx)
    {
      if ((sqlEx instanceof StreamingNotifiable)) {
        ((StreamingNotifiable)sqlEx).setWasStreamingResults();
      }
      noMoreRows = true;
      
      throw sqlEx;
    }
    catch (Exception ex)
    {
      CJException cjEx = ExceptionFactory.createException(
        Messages.getString("RowDataDynamic.2", new String[] {ex.getClass().getName(), ex.getMessage(), Util.stackTraceToString(ex) }), ex, exceptionInterceptor);
      
      throw cjEx;
    }
  }
  
  public void afterLast()
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
  
  public void beforeFirst()
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
  
  public void beforeLast()
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
  
  public void moveRowRelative(int rows)
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
  
  public void setCurrentRow(int rowNumber)
  {
    throw ExceptionFactory.createException(Messages.getString("ResultSet.ForwardOnly"));
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.result.ResultsetRowsStreaming
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */