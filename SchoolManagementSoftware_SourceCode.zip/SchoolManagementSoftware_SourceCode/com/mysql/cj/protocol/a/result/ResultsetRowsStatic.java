package com.mysql.cj.protocol.a.result;

import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.result.Row;
import java.util.List;

public class ResultsetRowsStatic
  extends AbstractResultsetRows
  implements ResultsetRows
{
  private List<Row> rows;
  
  public ResultsetRowsStatic(List<? extends Row> rows, ColumnDefinition columnDefinition)
  {
    currentPositionInFetchedRows = -1;
    this.rows = rows;
    metadata = columnDefinition;
  }
  
  public void addRow(Row row)
  {
    rows.add(row);
  }
  
  public void afterLast()
  {
    if (rows.size() > 0) {
      currentPositionInFetchedRows = rows.size();
    }
  }
  
  public void beforeFirst()
  {
    if (rows.size() > 0) {
      currentPositionInFetchedRows = -1;
    }
  }
  
  public void beforeLast()
  {
    if (rows.size() > 0) {
      currentPositionInFetchedRows = (rows.size() - 2);
    }
  }
  
  public Row get(int atIndex)
  {
    if ((atIndex < 0) || (atIndex >= rows.size())) {
      return null;
    }
    return ((Row)rows.get(atIndex)).setMetadata(metadata);
  }
  
  public int getPosition()
  {
    return currentPositionInFetchedRows;
  }
  
  public boolean hasNext()
  {
    boolean hasMore = currentPositionInFetchedRows + 1 < rows.size();
    
    return hasMore;
  }
  
  public boolean isAfterLast()
  {
    return (currentPositionInFetchedRows >= rows.size()) && (rows.size() != 0);
  }
  
  public boolean isBeforeFirst()
  {
    return (currentPositionInFetchedRows == -1) && (rows.size() != 0);
  }
  
  public boolean isDynamic()
  {
    return false;
  }
  
  public boolean isEmpty()
  {
    return rows.size() == 0;
  }
  
  public boolean isFirst()
  {
    return currentPositionInFetchedRows == 0;
  }
  
  public boolean isLast()
  {
    if (rows.size() == 0) {
      return false;
    }
    return currentPositionInFetchedRows == rows.size() - 1;
  }
  
  public void moveRowRelative(int rowsToMove)
  {
    if (rows.size() > 0)
    {
      currentPositionInFetchedRows += rowsToMove;
      if (currentPositionInFetchedRows < -1) {
        beforeFirst();
      } else if (currentPositionInFetchedRows > rows.size()) {
        afterLast();
      }
    }
  }
  
  public Row next()
  {
    currentPositionInFetchedRows += 1;
    if (currentPositionInFetchedRows > rows.size())
    {
      afterLast();
    }
    else if (currentPositionInFetchedRows < rows.size())
    {
      Row row = (Row)rows.get(currentPositionInFetchedRows);
      
      return row.setMetadata(metadata);
    }
    return null;
  }
  
  public void remove()
  {
    rows.remove(getPosition());
  }
  
  public void setCurrentRow(int newIndex)
  {
    currentPositionInFetchedRows = newIndex;
  }
  
  public int size()
  {
    return rows.size();
  }
  
  public boolean wasEmpty()
  {
    return (rows != null) && (rows.size() == 0);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.result.ResultsetRowsStatic
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */