package com.mysql.cj.protocol.a.result;

import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.protocol.ValueDecoder;
import com.mysql.cj.protocol.a.MysqlBinaryValueDecoder;
import com.mysql.cj.protocol.a.MysqlTextValueDecoder;
import com.mysql.cj.protocol.result.AbstractResultsetRow;
import com.mysql.cj.result.ValueFactory;

public class ByteArrayRow
  extends AbstractResultsetRow
{
  byte[][] internalRowData;
  
  public ByteArrayRow(byte[][] internalRowData, ExceptionInterceptor exceptionInterceptor, ValueDecoder valueDecoder)
  {
    super(exceptionInterceptor);
    
    this.internalRowData = internalRowData;
    this.valueDecoder = valueDecoder;
  }
  
  public ByteArrayRow(byte[][] internalRowData, ExceptionInterceptor exceptionInterceptor)
  {
    super(exceptionInterceptor);
    
    this.internalRowData = internalRowData;
    valueDecoder = new MysqlTextValueDecoder();
  }
  
  public boolean isBinaryEncoded()
  {
    return valueDecoder instanceof MysqlBinaryValueDecoder;
  }
  
  public byte[] getBytes(int index)
  {
    if (getNull(index)) {
      return null;
    }
    return internalRowData[index];
  }
  
  public void setBytes(int index, byte[] value)
  {
    internalRowData[index] = value;
  }
  
  public boolean getNull(int columnIndex)
  {
    wasNull = (internalRowData[columnIndex] == null);
    return wasNull;
  }
  
  public <T> T getValue(int columnIndex, ValueFactory<T> vf)
  {
    byte[] columnData = internalRowData[columnIndex];
    int length = columnData == null ? 0 : columnData.length;
    return (T)getValueFromBytes(columnIndex, columnData, 0, length, vf);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.result.ByteArrayRow
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */