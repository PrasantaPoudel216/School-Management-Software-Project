package com.mysql.cj.protocol.a;

import com.mysql.cj.Messages;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJPacketTooBigException;
import com.mysql.cj.protocol.FullReadInputStream;
import com.mysql.cj.protocol.MessageReader;
import com.mysql.cj.protocol.SocketConnection;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Optional;

public class SimplePacketReader
  implements MessageReader<NativePacketHeader, NativePacketPayload>
{
  protected SocketConnection socketConnection;
  protected RuntimeProperty<Integer> maxAllowedPacket;
  private byte readPacketSequence = -1;
  
  public SimplePacketReader(SocketConnection socketConnection, RuntimeProperty<Integer> maxAllowedPacket)
  {
    this.socketConnection = socketConnection;
    this.maxAllowedPacket = maxAllowedPacket;
  }
  
  public NativePacketHeader readHeader()
    throws IOException
  {
    NativePacketHeader hdr = new NativePacketHeader();
    try
    {
      socketConnection.getMysqlInput().readFully(hdr.getBuffer().array(), 0, 4);
      
      int packetLength = hdr.getMessageSize();
      if (packetLength > ((Integer)maxAllowedPacket.getValue()).intValue()) {
        throw new CJPacketTooBigException(packetLength, ((Integer)maxAllowedPacket.getValue()).intValue());
      }
    }
    catch (IOException|CJPacketTooBigException e)
    {
      try
      {
        socketConnection.forceClose();
      }
      catch (Exception localException1) {}
      throw e;
    }
    readPacketSequence = hdr.getMessageSequence();
    
    return hdr;
  }
  
  public NativePacketPayload readMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header)
    throws IOException
  {
    try
    {
      int packetLength = header.getMessageSize();
      NativePacketPayload buf;
      if (reuse.isPresent())
      {
        NativePacketPayload buf = (NativePacketPayload)reuse.get();
        
        buf.setPosition(0);
        if (buf.getByteBuffer().length < packetLength) {
          buf.setByteBuffer(new byte[packetLength]);
        }
        buf.setPayloadLength(packetLength);
      }
      else
      {
        buf = new NativePacketPayload(new byte[packetLength]);
      }
      int numBytesRead = socketConnection.getMysqlInput().readFully(buf.getByteBuffer(), 0, packetLength);
      if (numBytesRead != packetLength) {
        throw new IOException(Messages.getString("PacketReader.1", new Object[] { Integer.valueOf(packetLength), Integer.valueOf(numBytesRead) }));
      }
      return buf;
    }
    catch (IOException e)
    {
      try
      {
        socketConnection.forceClose();
      }
      catch (Exception localException) {}
      throw e;
    }
  }
  
  public byte getMessageSequence()
  {
    return readPacketSequence;
  }
  
  public void resetMessageSequence()
  {
    readPacketSequence = 0;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.SimplePacketReader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */