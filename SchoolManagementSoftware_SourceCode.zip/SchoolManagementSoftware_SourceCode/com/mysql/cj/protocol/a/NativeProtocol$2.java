package com.mysql.cj.protocol.a;

import com.mysql.cj.protocol.PacketReceivedTimeHolder;

class NativeProtocol$2
  implements PacketReceivedTimeHolder
{
  NativeProtocol$2(NativeProtocol this$0) {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeProtocol.2
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */