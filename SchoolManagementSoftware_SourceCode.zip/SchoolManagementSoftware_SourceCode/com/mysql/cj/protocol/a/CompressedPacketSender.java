package com.mysql.cj.protocol.a;

import com.mysql.cj.protocol.MessageSender;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.util.zip.Deflater;

public class CompressedPacketSender
  implements MessageSender<NativePacketPayload>
{
  private BufferedOutputStream outputStream;
  private Deflater deflater = new Deflater();
  private byte[] compressedPacket;
  private byte compressedSequenceId = 0;
  private int compressedPayloadLen = 0;
  public static final int COMP_HEADER_LENGTH = 7;
  public static final int MIN_COMPRESS_LEN = 50;
  
  public CompressedPacketSender(BufferedOutputStream outputStream)
  {
    this.outputStream = outputStream;
  }
  
  public void stop()
  {
    deflater.end();
    deflater = null;
  }
  
  private void resetPacket()
  {
    compressedPayloadLen = 0;
    deflater.reset();
  }
  
  private void addUncompressedHeader(byte packetSequence, int uncompressedPacketLen)
  {
    byte[] uncompressedHeader = new byte[4];
    NativeUtils.encodeMysqlThreeByteInteger(uncompressedPacketLen, uncompressedHeader, 0);
    uncompressedHeader[3] = packetSequence;
    deflater.setInput(uncompressedHeader);
    compressedPayloadLen += deflater.deflate(compressedPacket, compressedPayloadLen, compressedPacket.length - compressedPayloadLen);
  }
  
  private void addPayload(byte[] payload, int payloadOffset, int payloadLen)
  {
    deflater.setInput(payload, payloadOffset, payloadLen);
    compressedPayloadLen += deflater.deflate(compressedPacket, compressedPayloadLen, compressedPacket.length - compressedPayloadLen);
  }
  
  private void completeCompression()
  {
    deflater.finish();
    compressedPayloadLen += deflater.deflate(compressedPacket, compressedPayloadLen, compressedPacket.length - compressedPayloadLen);
  }
  
  private void writeCompressedHeader(int compLen, byte seq, int uncompLen)
    throws IOException
  {
    outputStream.write(NativeUtils.encodeMysqlThreeByteInteger(compLen));
    outputStream.write(seq);
    outputStream.write(NativeUtils.encodeMysqlThreeByteInteger(uncompLen));
  }
  
  private void writeUncompressedHeader(int packetLen, byte packetSequence)
    throws IOException
  {
    outputStream.write(NativeUtils.encodeMysqlThreeByteInteger(packetLen));
    outputStream.write(packetSequence);
  }
  
  private void sendCompressedPacket(int uncompressedPayloadLen)
    throws IOException
  {
    writeCompressedHeader(compressedPayloadLen, compressedSequenceId++, uncompressedPayloadLen);
    
    outputStream.write(compressedPacket, 0, compressedPayloadLen);
  }
  
  public void send(byte[] packet, int packetLen, byte packetSequence)
    throws IOException
  {
    compressedSequenceId = packetSequence;
    if (packetLen < 50)
    {
      writeCompressedHeader(packetLen + 4, compressedSequenceId, 0);
      writeUncompressedHeader(packetLen, packetSequence);
      outputStream.write(packet, 0, packetLen);
      outputStream.flush();
      return;
    }
    if (packetLen + 4 > 16777215) {
      compressedPacket = new byte[16777215];
    } else {
      compressedPacket = new byte[4 + packetLen];
    }
    PacketSplitter packetSplitter = new PacketSplitter(packetLen);
    
    int unsentPayloadLen = 0;
    int unsentOffset = 0;
    for (;;)
    {
      compressedPayloadLen = 0;
      if (!packetSplitter.nextPacket()) {
        break;
      }
      if (unsentPayloadLen > 0) {
        addPayload(packet, unsentOffset, unsentPayloadLen);
      }
      int remaining = 16777215 - unsentPayloadLen;
      
      int len = Math.min(remaining, 4 + packetSplitter.getPacketLen());
      int lenNoHdr = len - 4;
      addUncompressedHeader(packetSequence, packetSplitter.getPacketLen());
      addPayload(packet, packetSplitter.getOffset(), lenNoHdr);
      
      completeCompression();
      if (compressedPayloadLen >= len)
      {
        writeCompressedHeader(unsentPayloadLen + len, compressedSequenceId++, 0);
        outputStream.write(packet, unsentOffset, unsentPayloadLen);
        writeUncompressedHeader(lenNoHdr, packetSequence);
        outputStream.write(packet, packetSplitter.getOffset(), lenNoHdr);
      }
      else
      {
        sendCompressedPacket(len + unsentPayloadLen);
      }
      packetSequence = (byte)(packetSequence + 1);
      unsentPayloadLen = packetSplitter.getPacketLen() - lenNoHdr;
      unsentOffset = packetSplitter.getOffset() + lenNoHdr;
      resetPacket();
    }
    if (unsentPayloadLen > 0)
    {
      addPayload(packet, unsentOffset, unsentPayloadLen);
      completeCompression();
      if (compressedPayloadLen >= unsentPayloadLen)
      {
        writeCompressedHeader(unsentPayloadLen, compressedSequenceId, 0);
        outputStream.write(packet, unsentOffset, unsentPayloadLen);
      }
      else
      {
        sendCompressedPacket(unsentPayloadLen);
      }
      resetPacket();
    }
    outputStream.flush();
    
    compressedPacket = null;
  }
  
  public MessageSender<NativePacketPayload> undecorateAll()
  {
    return this;
  }
  
  public MessageSender<NativePacketPayload> undecorate()
  {
    return this;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.CompressedPacketSender
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */