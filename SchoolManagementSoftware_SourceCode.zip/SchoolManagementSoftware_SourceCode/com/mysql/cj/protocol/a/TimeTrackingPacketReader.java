package com.mysql.cj.protocol.a;

import com.mysql.cj.protocol.MessageReader;
import com.mysql.cj.protocol.PacketReceivedTimeHolder;
import java.io.IOException;
import java.util.Optional;

public class TimeTrackingPacketReader
  implements MessageReader<NativePacketHeader, NativePacketPayload>, PacketReceivedTimeHolder
{
  private MessageReader<NativePacketHeader, NativePacketPayload> packetReader;
  private long lastPacketReceivedTimeMs = 0L;
  
  public TimeTrackingPacketReader(MessageReader<NativePacketHeader, NativePacketPayload> messageReader)
  {
    packetReader = messageReader;
  }
  
  public NativePacketHeader readHeader()
    throws IOException
  {
    return (NativePacketHeader)packetReader.readHeader();
  }
  
  public NativePacketPayload readMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header)
    throws IOException
  {
    NativePacketPayload buf = (NativePacketPayload)packetReader.readMessage(reuse, header);
    lastPacketReceivedTimeMs = System.currentTimeMillis();
    return buf;
  }
  
  public long getLastPacketReceivedTime()
  {
    return lastPacketReceivedTimeMs;
  }
  
  public byte getMessageSequence()
  {
    return packetReader.getMessageSequence();
  }
  
  public void resetMessageSequence()
  {
    packetReader.resetMessageSequence();
  }
  
  public MessageReader<NativePacketHeader, NativePacketPayload> undecorateAll()
  {
    return packetReader.undecorateAll();
  }
  
  public MessageReader<NativePacketHeader, NativePacketPayload> undecorate()
  {
    return packetReader;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.TimeTrackingPacketReader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */