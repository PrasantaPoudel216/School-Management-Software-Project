package com.mysql.cj.protocol.a;

class NativeProtocol$3 {}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeProtocol.3
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */