package com.mysql.cj.protocol.a;

import com.mysql.cj.protocol.PacketSentTimeHolder;

class NativeSocketConnection$1
  implements PacketSentTimeHolder
{
  NativeSocketConnection$1(NativeSocketConnection this$0) {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeSocketConnection.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */