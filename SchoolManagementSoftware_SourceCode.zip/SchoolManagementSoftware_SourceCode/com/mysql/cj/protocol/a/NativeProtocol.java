package com.mysql.cj.protocol.a;

import com.mysql.cj.Constants;
import com.mysql.cj.MessageBuilder;
import com.mysql.cj.Messages;
import com.mysql.cj.MysqlType;
import com.mysql.cj.Query;
import com.mysql.cj.QueryResult;
import com.mysql.cj.ServerVersion;
import com.mysql.cj.Session;
import com.mysql.cj.TransactionEventHandler;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.conf.RuntimeProperty.RuntimePropertyListener;
import com.mysql.cj.exceptions.CJConnectionFeatureNotAvailableException;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.CJPacketTooBigException;
import com.mysql.cj.exceptions.ClosedOnExpiredPasswordException;
import com.mysql.cj.exceptions.DataTruncationException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.FeatureNotAvailableException;
import com.mysql.cj.exceptions.MysqlErrorNumbers;
import com.mysql.cj.exceptions.PasswordExpiredException;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.interceptors.QueryInterceptor;
import com.mysql.cj.jdbc.exceptions.MysqlDataTruncation;
import com.mysql.cj.log.BaseMetricsHolder;
import com.mysql.cj.log.Log;
import com.mysql.cj.log.ProfilerEventHandler;
import com.mysql.cj.protocol.AbstractProtocol;
import com.mysql.cj.protocol.AuthenticationProvider;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ExportControlled;
import com.mysql.cj.protocol.FullReadInputStream;
import com.mysql.cj.protocol.Message;
import com.mysql.cj.protocol.MessageReader;
import com.mysql.cj.protocol.MessageSender;
import com.mysql.cj.protocol.PacketReceivedTimeHolder;
import com.mysql.cj.protocol.PacketSentTimeHolder;
import com.mysql.cj.protocol.Protocol;
import com.mysql.cj.protocol.ProtocolEntity;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.ProtocolEntityReader;
import com.mysql.cj.protocol.ResultStreamer;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.Resultset.Concurrency;
import com.mysql.cj.protocol.Resultset.Type;
import com.mysql.cj.protocol.ResultsetRow;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.ResultsetRowsOwner;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.SocketConnection;
import com.mysql.cj.protocol.SocketFactory;
import com.mysql.cj.protocol.a.result.OkPacket;
import com.mysql.cj.result.Field;
import com.mysql.cj.result.IntegerValueFactory;
import com.mysql.cj.result.Row;
import com.mysql.cj.result.RowList;
import com.mysql.cj.result.StringValueFactory;
import com.mysql.cj.result.ValueFactory;
import com.mysql.cj.util.LazyString;
import com.mysql.cj.util.StringUtils;
import com.mysql.cj.util.TestUtils;
import com.mysql.cj.util.TimeUtil;
import com.mysql.cj.util.Util;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadInfo;
import java.lang.management.ThreadMXBean;
import java.lang.ref.SoftReference;
import java.net.MalformedURLException;
import java.net.Socket;
import java.net.URL;
import java.sql.DataTruncation;
import java.sql.SQLWarning;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TimeZone;
import java.util.concurrent.CompletableFuture;
import java.util.function.Supplier;

public class NativeProtocol
  extends AbstractProtocol<NativePacketPayload>
  implements Protocol<NativePacketPayload>, RuntimeProperty.RuntimePropertyListener
{
  protected static final int INITIAL_PACKET_SIZE = 1024;
  protected static final int COMP_HEADER_LENGTH = 3;
  protected static final int MAX_QUERY_SIZE_TO_EXPLAIN = 1048576;
  private static final String EXPLAINABLE_STATEMENT = "SELECT";
  private static final String[] EXPLAINABLE_STATEMENT_EXTENSION;
  protected MessageSender<NativePacketPayload> packetSender;
  protected MessageReader<NativePacketHeader, NativePacketPayload> packetReader;
  protected NativeServerSession serverSession;
  protected CompressedPacketSender compressedPacketSender;
  protected NativePacketPayload sharedSendPacket = null;
  protected NativePacketPayload reusablePacket = null;
  private SoftReference<NativePacketPayload> loadFileBufRef;
  protected byte packetSequence = 0;
  protected boolean useCompression = false;
  private RuntimeProperty<Integer> maxAllowedPacket;
  private RuntimeProperty<Boolean> useServerPrepStmts;
  private boolean autoGenerateTestcaseScript;
  private boolean logSlowQueries = false;
  private boolean useAutoSlowLog;
  private boolean profileSQL = false;
  private long slowQueryThreshold;
  private int commandCount = 0;
  protected boolean hadWarnings = false;
  private int warningCount = 0;
  protected Map<Class<? extends ProtocolEntity>, ProtocolEntityReader<? extends ProtocolEntity, ? extends Message>> PROTOCOL_ENTITY_CLASS_TO_TEXT_READER;
  protected Map<Class<? extends ProtocolEntity>, ProtocolEntityReader<? extends ProtocolEntity, ? extends Message>> PROTOCOL_ENTITY_CLASS_TO_BINARY_READER;
  protected boolean platformDbCharsetMatches = true;
  private int statementExecutionDepth = 0;
  private List<QueryInterceptor> queryInterceptors;
  private RuntimeProperty<Boolean> maintainTimeStats;
  private RuntimeProperty<Integer> maxQuerySizeToLog;
  private InputStream localInfileInputStream;
  private BaseMetricsHolder metricsHolder;
  private String queryComment = null;
  private static String jvmPlatformCharset;
  private NativeMessageBuilder commandBuilder = new NativeMessageBuilder();
  
  public static NativeProtocol getInstance(Session session, SocketConnection socketConnection, PropertySet propertySet, Log log, TransactionEventHandler transactionManager)
  {
    NativeProtocol protocol = new NativeProtocol(log);
    protocol.init(session, socketConnection, propertySet, transactionManager);
    return protocol;
  }
  
  public NativeProtocol(Log logger)
  {
    log = logger;
    metricsHolder = new BaseMetricsHolder();
  }
  
  public void init(Session sess, SocketConnection phConnection, PropertySet propSet, TransactionEventHandler trManager)
  {
    super.init(sess, phConnection, propSet, trManager);
    
    maintainTimeStats = propertySet.getBooleanProperty(PropertyKey.maintainTimeStats);
    maxQuerySizeToLog = propertySet.getIntegerProperty(PropertyKey.maxQuerySizeToLog);
    useAutoSlowLog = ((Boolean)propertySet.getBooleanProperty(PropertyKey.autoSlowLog).getValue()).booleanValue();
    logSlowQueries = ((Boolean)propertySet.getBooleanProperty(PropertyKey.logSlowQueries).getValue()).booleanValue();
    maxAllowedPacket = propertySet.getIntegerProperty(PropertyKey.maxAllowedPacket);
    profileSQL = ((Boolean)propertySet.getBooleanProperty(PropertyKey.profileSQL).getValue()).booleanValue();
    autoGenerateTestcaseScript = ((Boolean)propertySet.getBooleanProperty(PropertyKey.autoGenerateTestcaseScript).getValue()).booleanValue();
    useServerPrepStmts = propertySet.getBooleanProperty(PropertyKey.useServerPrepStmts);
    
    reusablePacket = new NativePacketPayload(1024);
    try
    {
      packetSender = new SimplePacketSender(socketConnection.getMysqlOutput());
      packetReader = new SimplePacketReader(socketConnection, maxAllowedPacket);
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
    if (((Boolean)propertySet.getBooleanProperty(PropertyKey.logSlowQueries).getValue()).booleanValue()) {
      calculateSlowQueryThreshold();
    }
    authProvider = new NativeAuthenticationProvider();
    authProvider.init(this, getPropertySet(), socketConnection.getExceptionInterceptor());
    
    Map<Class<? extends ProtocolEntity>, ProtocolEntityReader<? extends ProtocolEntity, NativePacketPayload>> protocolEntityClassToTextReader = new HashMap();
    protocolEntityClassToTextReader.put(ColumnDefinition.class, new ColumnDefinitionReader(this));
    protocolEntityClassToTextReader.put(ResultsetRow.class, new ResultsetRowReader(this));
    protocolEntityClassToTextReader.put(Resultset.class, new TextResultsetReader(this));
    PROTOCOL_ENTITY_CLASS_TO_TEXT_READER = Collections.unmodifiableMap(protocolEntityClassToTextReader);
    
    Map<Class<? extends ProtocolEntity>, ProtocolEntityReader<? extends ProtocolEntity, NativePacketPayload>> protocolEntityClassToBinaryReader = new HashMap();
    protocolEntityClassToBinaryReader.put(ColumnDefinition.class, new ColumnDefinitionReader(this));
    protocolEntityClassToBinaryReader.put(Resultset.class, new BinaryResultsetReader(this));
    PROTOCOL_ENTITY_CLASS_TO_BINARY_READER = Collections.unmodifiableMap(protocolEntityClassToBinaryReader);
  }
  
  public MessageBuilder<NativePacketPayload> getMessageBuilder()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public MessageSender<NativePacketPayload> getPacketSender()
  {
    return packetSender;
  }
  
  public MessageReader<NativePacketHeader, NativePacketPayload> getPacketReader()
  {
    return packetReader;
  }
  
  public void negotiateSSLConnection(int packLength)
  {
    if (!ExportControlled.enabled()) {
      throw new CJConnectionFeatureNotAvailableException(getPropertySet(), serverSession, getPacketSentTimeHolder(), null);
    }
    long clientParam = serverSession.getClientParam();
    clientParam |= 0x800;
    serverSession.setClientParam(clientParam);
    
    NativePacketPayload packet = new NativePacketPayload(packLength);
    packet.writeInteger(NativeConstants.IntegerDataType.INT4, clientParam);
    packet.writeInteger(NativeConstants.IntegerDataType.INT4, 16777215L);
    packet.writeInteger(NativeConstants.IntegerDataType.INT1, AuthenticationProvider.getCharsetForHandshake(authProvider.getEncodingForHandshake(), serverSession
      .getCapabilities().getServerVersion()));
    packet.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, new byte[23]);
    
    send(packet, packet.getPosition());
    try
    {
      socketConnection.performTlsHandshake(serverSession);
      
      packetSender = new SimplePacketSender(socketConnection.getMysqlOutput());
      packetReader = new SimplePacketReader(socketConnection, maxAllowedPacket);
    }
    catch (FeatureNotAvailableException nae)
    {
      throw new CJConnectionFeatureNotAvailableException(getPropertySet(), serverSession, getPacketSentTimeHolder(), nae);
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
  }
  
  public void rejectProtocol(NativePacketPayload msg)
  {
    try
    {
      socketConnection.getMysqlSocket().close();
    }
    catch (Exception localException) {}
    int errno = 2000;
    
    NativePacketPayload buf = msg;
    buf.setPosition(1);
    errno = (int)buf.readInteger(NativeConstants.IntegerDataType.INT2);
    
    String serverErrorMessage = "";
    try
    {
      serverErrorMessage = buf.readString(NativeConstants.StringSelfDataType.STRING_TERM, "ASCII");
    }
    catch (Exception localException1) {}
    StringBuilder errorBuf = new StringBuilder(Messages.getString("Protocol.0"));
    errorBuf.append(serverErrorMessage);
    errorBuf.append("\"");
    
    String xOpen = MysqlErrorNumbers.mysqlToSqlState(errno);
    
    throw ExceptionFactory.createException(MysqlErrorNumbers.get(xOpen) + ", " + errorBuf.toString(), xOpen, errno, false, null, getExceptionInterceptor());
  }
  
  public void beforeHandshake()
  {
    packetReader.resetMessageSequence();
    
    serverSession = new NativeServerSession(propertySet);
    
    NativeCapabilities capabilities = readServerCapabilities();
    serverSession.setCapabilities(capabilities);
  }
  
  public void afterHandshake()
  {
    checkTransactionState();
    
    PropertySet pset = getPropertySet();
    try
    {
      if (((serverSession.getCapabilities().getCapabilityFlags() & 0x20) != 0) && 
        (((Boolean)pset.getBooleanProperty(PropertyKey.useCompression).getValue()).booleanValue()) && 
        (!(socketConnection.getMysqlInput().getUnderlyingStream() instanceof CompressedInputStream)))
      {
        useCompression = true;
        socketConnection.setMysqlInput(new FullReadInputStream(new CompressedInputStream(socketConnection
          .getMysqlInput(), pset.getBooleanProperty(PropertyKey.traceProtocol), log)));
        compressedPacketSender = new CompressedPacketSender(socketConnection.getMysqlOutput());
        packetSender = compressedPacketSender;
      }
      applyPacketDecorators(packetSender, packetReader);
      
      socketConnection.getSocketFactory().afterHandshake();
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(getPropertySet(), serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
    maintainTimeStats.addListener(this);
    pset.getBooleanProperty(PropertyKey.traceProtocol).addListener(this);
    pset.getBooleanProperty(PropertyKey.enablePacketDebug).addListener(this);
  }
  
  public void handlePropertyChange(RuntimeProperty<?> prop)
  {
    switch (prop.getPropertyDefinition().getPropertyKey())
    {
    case maintainTimeStats: 
    case traceProtocol: 
    case enablePacketDebug: 
      applyPacketDecorators(packetSender.undecorateAll(), packetReader.undecorateAll());
      
      break;
    }
  }
  
  public void applyPacketDecorators(MessageSender<NativePacketPayload> sender, MessageReader<NativePacketHeader, NativePacketPayload> messageReader)
  {
    TimeTrackingPacketSender ttSender = null;
    TimeTrackingPacketReader ttReader = null;
    LinkedList<StringBuilder> debugRingBuffer = null;
    if (((Boolean)maintainTimeStats.getValue()).booleanValue())
    {
      ttSender = new TimeTrackingPacketSender(sender);
      sender = ttSender;
      
      ttReader = new TimeTrackingPacketReader(messageReader);
      messageReader = ttReader;
    }
    if (((Boolean)propertySet.getBooleanProperty(PropertyKey.traceProtocol).getValue()).booleanValue())
    {
      sender = new TracingPacketSender(sender, log, socketConnection.getHost(), getServerSession().getCapabilities().getThreadId());
      messageReader = new TracingPacketReader(messageReader, log);
    }
    if (((Boolean)getPropertySet().getBooleanProperty(PropertyKey.enablePacketDebug).getValue()).booleanValue())
    {
      debugRingBuffer = new LinkedList();
      
      sender = new DebugBufferingPacketSender(sender, debugRingBuffer, propertySet.getIntegerProperty(PropertyKey.packetDebugBufferSize));
      
      messageReader = new DebugBufferingPacketReader(messageReader, debugRingBuffer, propertySet.getIntegerProperty(PropertyKey.packetDebugBufferSize));
    }
    messageReader = new MultiPacketReader(messageReader);
    synchronized (packetReader)
    {
      packetReader = messageReader;
      packetDebugRingBuffer = debugRingBuffer;
      setPacketSentTimeHolder(ttSender != null ? ttSender : new PacketSentTimeHolder() {});
    }
    synchronized (packetSender)
    {
      packetSender = sender;
      setPacketReceivedTimeHolder(ttReader != null ? ttReader : new PacketReceivedTimeHolder() {});
    }
  }
  
  public NativeCapabilities readServerCapabilities()
  {
    NativePacketPayload buf = readMessage(null);
    if (buf.isErrorPacket()) {
      rejectProtocol(buf);
    }
    NativeCapabilities serverCapabilities = new NativeCapabilities();
    serverCapabilities.setInitialHandshakePacket(buf);
    
    return serverCapabilities;
  }
  
  public NativeServerSession getServerSession()
  {
    return serverSession;
  }
  
  public void changeDatabase(String database)
  {
    if ((database == null) || (database.length() == 0)) {
      return;
    }
    try
    {
      sendCommand(commandBuilder.buildComInitDb(getSharedSendPacket(), database), false, 0);
    }
    catch (CJException ex)
    {
      if (((Boolean)getPropertySet().getBooleanProperty(PropertyKey.createDatabaseIfNotExist).getValue()).booleanValue())
      {
        sendCommand(commandBuilder.buildComQuery(getSharedSendPacket(), "CREATE DATABASE IF NOT EXISTS " + database), false, 0);
        
        sendCommand(commandBuilder.buildComInitDb(getSharedSendPacket(), database), false, 0);
      }
      else
      {
        throw ExceptionFactory.createCommunicationsException(getPropertySet(), serverSession, getPacketSentTimeHolder(), 
          getPacketReceivedTimeHolder(), ex, getExceptionInterceptor());
      }
    }
  }
  
  public final NativePacketPayload readMessage(NativePacketPayload reuse)
  {
    try
    {
      NativePacketHeader header = (NativePacketHeader)packetReader.readHeader();
      NativePacketPayload buf = (NativePacketPayload)packetReader.readMessage(Optional.ofNullable(reuse), header);
      packetSequence = header.getMessageSequence();
      return buf;
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
    catch (OutOfMemoryError oom)
    {
      throw ExceptionFactory.createException(oom.getMessage(), "HY001", 0, false, oom, exceptionInterceptor);
    }
  }
  
  public final void send(Message packet, int packetLen)
  {
    try
    {
      if ((((Integer)maxAllowedPacket.getValue()).intValue() > 0) && (packetLen > ((Integer)maxAllowedPacket.getValue()).intValue())) {
        throw new CJPacketTooBigException(packetLen, ((Integer)maxAllowedPacket.getValue()).intValue());
      }
      packetSequence = ((byte)(packetSequence + 1));
      packetSender.send(packet.getByteBuffer(), packetLen, packetSequence);
      if (packet == sharedSendPacket) {
        reclaimLargeSharedSendPacket();
      }
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(getPropertySet(), serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
  }
  
  public <RES extends QueryResult> CompletableFuture<RES> sendAsync(Message message)
  {
    return null;
  }
  
  public final NativePacketPayload sendCommand(Message queryPacket, boolean skipCheck, int timeoutMillis)
  {
    int command = queryPacket.getByteBuffer()[0];
    commandCount += 1;
    if (queryInterceptors != null)
    {
      NativePacketPayload interceptedPacketPayload = (NativePacketPayload)invokeQueryInterceptorsPre(queryPacket, false);
      if (interceptedPacketPayload != null) {
        return interceptedPacketPayload;
      }
    }
    packetReader.resetMessageSequence();
    
    int oldTimeout = 0;
    if (timeoutMillis != 0) {
      try
      {
        oldTimeout = socketConnection.getMysqlSocket().getSoTimeout();
        socketConnection.getMysqlSocket().setSoTimeout(timeoutMillis);
      }
      catch (IOException e)
      {
        throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
          getPacketReceivedTimeHolder(), e, getExceptionInterceptor());
      }
    }
    try
    {
      checkForOutstandingStreamingData();
      
      serverSession.setStatusFlags(0, true);
      hadWarnings = false;
      setWarningCount(0);
      if (useCompression)
      {
        int bytesLeft = socketConnection.getMysqlInput().available();
        if (bytesLeft > 0) {
          socketConnection.getMysqlInput().skip(bytesLeft);
        }
      }
      try
      {
        clearInputStream();
        packetSequence = -1;
        send(queryPacket, queryPacket.getPosition());
      }
      catch (CJException ex)
      {
        throw ex;
      }
      catch (Exception ex)
      {
        throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
          getPacketReceivedTimeHolder(), ex, getExceptionInterceptor());
      }
      NativePacketPayload returnPacket = null;
      if (!skipCheck)
      {
        if ((command == 23) || (command == 26)) {
          packetReader.resetMessageSequence();
        }
        returnPacket = checkErrorMessage(command);
        if (queryInterceptors != null) {
          returnPacket = (NativePacketPayload)invokeQueryInterceptorsPost(queryPacket, returnPacket, false);
        }
      }
      return returnPacket;
    }
    catch (IOException ioEx)
    {
      serverSession.preserveOldTransactionState();
      throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
    catch (CJException e)
    {
      serverSession.preserveOldTransactionState();
      throw e;
    }
    finally
    {
      if (timeoutMillis != 0) {
        try
        {
          socketConnection.getMysqlSocket().setSoTimeout(oldTimeout);
        }
        catch (IOException e)
        {
          throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
            getPacketReceivedTimeHolder(), e, getExceptionInterceptor());
        }
      }
    }
  }
  
  public void checkTransactionState()
  {
    int transState = serverSession.getTransactionState();
    if (transState == 3) {
      transactionManager.transactionCompleted();
    } else if (transState == 2) {
      transactionManager.transactionBegun();
    }
  }
  
  public NativePacketPayload checkErrorMessage()
  {
    return checkErrorMessage(-1);
  }
  
  private NativePacketPayload checkErrorMessage(int command)
  {
    NativePacketPayload resultPacket = null;
    serverSession.setStatusFlags(0);
    try
    {
      resultPacket = readMessage(reusablePacket);
    }
    catch (CJException ex)
    {
      throw ex;
    }
    catch (Exception fallThru)
    {
      throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), fallThru, getExceptionInterceptor());
    }
    checkErrorMessage(resultPacket);
    
    return resultPacket;
  }
  
  public void checkErrorMessage(NativePacketPayload resultPacket)
  {
    resultPacket.setPosition(0);
    byte statusCode = (byte)(int)resultPacket.readInteger(NativeConstants.IntegerDataType.INT1);
    if (statusCode == -1)
    {
      int errno = 2000;
      
      errno = (int)resultPacket.readInteger(NativeConstants.IntegerDataType.INT2);
      
      String xOpen = null;
      
      String serverErrorMessage = resultPacket.readString(NativeConstants.StringSelfDataType.STRING_TERM, serverSession.getErrorMessageEncoding());
      if (serverErrorMessage.charAt(0) == '#')
      {
        if (serverErrorMessage.length() > 6)
        {
          xOpen = serverErrorMessage.substring(1, 6);
          serverErrorMessage = serverErrorMessage.substring(6);
          if (xOpen.equals("HY000")) {
            xOpen = MysqlErrorNumbers.mysqlToSqlState(errno);
          }
        }
        else
        {
          xOpen = MysqlErrorNumbers.mysqlToSqlState(errno);
        }
      }
      else {
        xOpen = MysqlErrorNumbers.mysqlToSqlState(errno);
      }
      clearInputStream();
      
      StringBuilder errorBuf = new StringBuilder();
      
      String xOpenErrorMessage = MysqlErrorNumbers.get(xOpen);
      
      boolean useOnlyServerErrorMessages = ((Boolean)propertySet.getBooleanProperty(PropertyKey.useOnlyServerErrorMessages).getValue()).booleanValue();
      if ((!useOnlyServerErrorMessages) && 
        (xOpenErrorMessage != null))
      {
        errorBuf.append(xOpenErrorMessage);
        errorBuf.append(Messages.getString("Protocol.0"));
      }
      errorBuf.append(serverErrorMessage);
      if ((!useOnlyServerErrorMessages) && 
        (xOpenErrorMessage != null)) {
        errorBuf.append("\"");
      }
      appendDeadlockStatusInformation(session, xOpen, errorBuf);
      if (xOpen != null)
      {
        if (xOpen.startsWith("22")) {
          throw new DataTruncationException(errorBuf.toString(), 0, true, false, 0, 0, errno);
        }
        if (errno == 1820) {
          throw ((PasswordExpiredException)ExceptionFactory.createException(PasswordExpiredException.class, errorBuf.toString(), getExceptionInterceptor()));
        }
        if (errno == 1862) {
          throw ((ClosedOnExpiredPasswordException)ExceptionFactory.createException(ClosedOnExpiredPasswordException.class, errorBuf.toString(), getExceptionInterceptor()));
        }
      }
      throw ExceptionFactory.createException(errorBuf.toString(), xOpen, errno, false, null, getExceptionInterceptor());
    }
  }
  
  private void reclaimLargeSharedSendPacket()
  {
    if ((sharedSendPacket != null) && (sharedSendPacket.getCapacity() > 1048576)) {
      sharedSendPacket = new NativePacketPayload(1024);
    }
  }
  
  public void clearInputStream()
  {
    try
    {
      int len;
      while (((len = socketConnection.getMysqlInput().available()) > 0) && (socketConnection.getMysqlInput().skip(len) > 0L)) {}
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
  }
  
  public void reclaimLargeReusablePacket()
  {
    if ((reusablePacket != null) && (reusablePacket.getCapacity() > 1048576)) {
      reusablePacket = new NativePacketPayload(1024);
    }
  }
  
  public final <T extends Resultset> T sendQueryString(Query callingQuery, String query, String characterEncoding, int maxRows, boolean streamResults, ColumnDefinition cachedMetadata, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory)
    throws IOException
  {
    String statementComment = queryComment;
    if (((Boolean)propertySet.getBooleanProperty(PropertyKey.includeThreadNamesAsStatementComment).getValue()).booleanValue()) {
      statementComment = (statementComment != null ? statementComment + ", " : "") + "java thread: " + Thread.currentThread().getName();
    }
    int packLength = 1 + query.length() * 4 + 2;
    
    byte[] commentAsBytes = null;
    if (statementComment != null)
    {
      commentAsBytes = StringUtils.getBytes(statementComment, characterEncoding);
      
      packLength += commentAsBytes.length;
      packLength += 6;
    }
    NativePacketPayload sendPacket = new NativePacketPayload(packLength);
    
    sendPacket.setPosition(0);
    
    sendPacket.writeInteger(NativeConstants.IntegerDataType.INT1, 3L);
    if (commentAsBytes != null)
    {
      sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, Constants.SLASH_STAR_SPACE_AS_BYTES);
      sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, commentAsBytes);
      sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, Constants.SPACE_STAR_SLASH_SPACE_AS_BYTES);
    }
    if ((!platformDbCharsetMatches) && (StringUtils.startsWithIgnoreCaseAndWs(query, "LOAD DATA"))) {
      sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, StringUtils.getBytes(query));
    } else {
      sendPacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, StringUtils.getBytes(query, characterEncoding));
    }
    return sendQueryPacket(callingQuery, sendPacket, maxRows, streamResults, cachedMetadata, resultSetFactory);
  }
  
  public final <T extends Resultset> T sendQueryPacket(Query callingQuery, NativePacketPayload queryPacket, int maxRows, boolean streamResults, ColumnDefinition cachedMetadata, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory)
    throws IOException
  {
    long queryStartTime = (profileSQL) || (logSlowQueries) ? getCurrentTimeNanosOrMillis() : 0L;
    
    statementExecutionDepth += 1;
    
    byte[] queryBuf = queryPacket.getByteBuffer();
    int oldPacketPosition = queryPacket.getPosition();
    
    LazyString query = new LazyString(queryBuf, 1, oldPacketPosition - 1);
    try
    {
      if (queryInterceptors != null)
      {
        T interceptedResults = invokeQueryInterceptorsPre(query, callingQuery, false);
        if (interceptedResults != null) {
          return interceptedResults;
        }
      }
      if (autoGenerateTestcaseScript)
      {
        StringBuilder debugBuf = new StringBuilder(query.length() + 32);
        generateQueryCommentBlock(debugBuf);
        debugBuf.append(query);
        debugBuf.append(';');
        TestUtils.dumpTestcaseQuery(debugBuf.toString());
      }
      NativePacketPayload resultPacket = sendCommand(queryPacket, false, 0);
      
      long queryEndTime = (profileSQL) || (logSlowQueries) ? getCurrentTimeNanosOrMillis() : 0L;
      long queryDuration = (profileSQL) || (logSlowQueries) ? queryEndTime - queryStartTime : 0L;
      
      boolean queryWasSlow = (logSlowQueries) && (useAutoSlowLog ? metricsHolder.checkAbonormallyLongQuery(queryDuration) : queryDuration > ((Integer)propertySet.getIntegerProperty(PropertyKey.slowQueryThresholdMillis).getValue()).intValue());
      
      long fetchBeginTime = profileSQL ? getCurrentTimeNanosOrMillis() : 0L;
      
      T rs = readAllResults(maxRows, streamResults, resultPacket, false, cachedMetadata, resultSetFactory);
      long fetchEndTime;
      if ((profileSQL) || (queryWasSlow))
      {
        fetchEndTime = profileSQL ? getCurrentTimeNanosOrMillis() : 0L;
        
        boolean truncated = oldPacketPosition > ((Integer)maxQuerySizeToLog.getValue()).intValue();
        int extractPosition = truncated ? ((Integer)maxQuerySizeToLog.getValue()).intValue() + 1 : oldPacketPosition;
        String extractedQuery = StringUtils.toString(queryBuf, 1, extractPosition - 1);
        if (truncated) {
          extractedQuery = extractedQuery + Messages.getString("Protocol.2");
        }
        ProfilerEventHandler eventSink = session.getProfilerEventHandler();
        if (logSlowQueries)
        {
          if (queryWasSlow)
          {
            eventSink.processEvent((byte)6, session, callingQuery, rs, queryDuration, new Throwable(), 
              Messages.getString("Protocol.SlowQuery", new Object[] { useAutoSlowLog ? " 95% of all queries " : 
              String.valueOf(slowQueryThreshold), queryTimingUnits, 
              Long.valueOf(queryDuration), extractedQuery }));
            if (((Boolean)propertySet.getBooleanProperty(PropertyKey.explainSlowQueries).getValue()).booleanValue()) {
              if (oldPacketPosition < 1048576)
              {
                queryPacket.setPosition(1);
                explainSlowQuery(query.toString(), extractedQuery);
              }
              else
              {
                log.logWarn(Messages.getString("Protocol.3", new Object[] { Integer.valueOf(1048576) }));
              }
            }
          }
          if (serverSession.noGoodIndexUsed()) {
            eventSink.processEvent((byte)6, session, callingQuery, rs, queryDuration, new Throwable(), 
              Messages.getString("Protocol.4") + extractedQuery);
          }
          if (serverSession.noIndexUsed()) {
            eventSink.processEvent((byte)6, session, callingQuery, rs, queryDuration, new Throwable(), 
              Messages.getString("Protocol.5") + extractedQuery);
          }
          if (serverSession.queryWasSlow()) {
            eventSink.processEvent((byte)6, session, callingQuery, rs, queryDuration, new Throwable(), 
              Messages.getString("Protocol.ServerSlowQuery") + extractedQuery);
          }
        }
        if (profileSQL)
        {
          eventSink.processEvent((byte)3, session, callingQuery, rs, queryDuration, new Throwable(), extractedQuery);
          eventSink.processEvent((byte)5, session, callingQuery, rs, fetchEndTime - fetchBeginTime, new Throwable(), null);
        }
      }
      if (hadWarnings) {
        scanForAndThrowDataTruncation();
      }
      if (queryInterceptors != null) {
        rs = invokeQueryInterceptorsPost(query, callingQuery, rs, false);
      }
      return rs;
    }
    catch (CJException sqlEx)
    {
      if (queryInterceptors != null) {
        invokeQueryInterceptorsPost(query, callingQuery, null, false);
      }
      if (callingQuery != null) {
        callingQuery.checkCancelTimeout();
      }
      throw sqlEx;
    }
    finally
    {
      statementExecutionDepth -= 1;
    }
  }
  
  public <T extends Resultset> T invokeQueryInterceptorsPre(Supplier<String> sql, Query interceptedQuery, boolean forceExecute)
  {
    T previousResultSet = null;
    
    int i = 0;
    for (int s = queryInterceptors.size(); i < s; i++)
    {
      QueryInterceptor interceptor = (QueryInterceptor)queryInterceptors.get(i);
      
      boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
      boolean shouldExecute = ((executeTopLevelOnly) && ((statementExecutionDepth == 1) || (forceExecute))) || (!executeTopLevelOnly);
      if (shouldExecute)
      {
        T interceptedResultSet = interceptor.preProcess(sql, interceptedQuery);
        if (interceptedResultSet != null) {
          previousResultSet = interceptedResultSet;
        }
      }
    }
    return previousResultSet;
  }
  
  public <M extends Message> M invokeQueryInterceptorsPre(M queryPacket, boolean forceExecute)
  {
    M previousPacketPayload = null;
    
    int i = 0;
    for (int s = queryInterceptors.size(); i < s; i++)
    {
      QueryInterceptor interceptor = (QueryInterceptor)queryInterceptors.get(i);
      
      M interceptedPacketPayload = interceptor.preProcess(queryPacket);
      if (interceptedPacketPayload != null) {
        previousPacketPayload = interceptedPacketPayload;
      }
    }
    return previousPacketPayload;
  }
  
  public <T extends Resultset> T invokeQueryInterceptorsPost(Supplier<String> sql, Query interceptedQuery, T originalResultSet, boolean forceExecute)
  {
    int i = 0;
    for (int s = queryInterceptors.size(); i < s; i++)
    {
      QueryInterceptor interceptor = (QueryInterceptor)queryInterceptors.get(i);
      
      boolean executeTopLevelOnly = interceptor.executeTopLevelOnly();
      boolean shouldExecute = ((executeTopLevelOnly) && ((statementExecutionDepth == 1) || (forceExecute))) || (!executeTopLevelOnly);
      if (shouldExecute)
      {
        T interceptedResultSet = interceptor.postProcess(sql, interceptedQuery, originalResultSet, serverSession);
        if (interceptedResultSet != null) {
          originalResultSet = interceptedResultSet;
        }
      }
    }
    return originalResultSet;
  }
  
  public <M extends Message> M invokeQueryInterceptorsPost(M queryPacket, M originalResponsePacket, boolean forceExecute)
  {
    int i = 0;
    for (int s = queryInterceptors.size(); i < s; i++)
    {
      QueryInterceptor interceptor = (QueryInterceptor)queryInterceptors.get(i);
      
      M interceptedPacketPayload = interceptor.postProcess(queryPacket, originalResponsePacket);
      if (interceptedPacketPayload != null) {
        originalResponsePacket = interceptedPacketPayload;
      }
    }
    return originalResponsePacket;
  }
  
  public long getCurrentTimeNanosOrMillis()
  {
    return useNanosForElapsedTime ? TimeUtil.getCurrentTimeNanosOrMillis() : System.currentTimeMillis();
  }
  
  public boolean hadWarnings()
  {
    return hadWarnings;
  }
  
  public void setHadWarnings(boolean hadWarnings)
  {
    this.hadWarnings = hadWarnings;
  }
  
  public void explainSlowQuery(String query, String truncatedQuery)
  {
    if ((StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, "SELECT")) || (
      (versionMeetsMinimum(5, 6, 3)) && (StringUtils.startsWithIgnoreCaseAndWs(truncatedQuery, EXPLAINABLE_STATEMENT_EXTENSION) != -1))) {
      try
      {
        NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(getSharedSendPacket(), "EXPLAIN " + query), false, 0);
        
        Resultset rs = readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
        
        StringBuilder explainResults = new StringBuilder(Messages.getString("Protocol.6"));
        explainResults.append(truncatedQuery);
        explainResults.append(Messages.getString("Protocol.7"));
        
        appendResultSetSlashGStyle(explainResults, rs);
        
        log.logWarn(explainResults.toString());
      }
      catch (CJException sqlEx)
      {
        throw sqlEx;
      }
      catch (Exception ex)
      {
        throw ExceptionFactory.createException(ex.getMessage(), ex, getExceptionInterceptor());
      }
    }
  }
  
  public final void skipPacket()
  {
    try
    {
      int packetLength = ((NativePacketHeader)packetReader.readHeader()).getMessageSize();
      
      socketConnection.getMysqlInput().skipFully(packetLength);
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
  }
  
  /* Error */
  public final void quit()
  {
    // Byte code:
    //   0: aload_0
    //   1: getfield 49	com/mysql/cj/protocol/a/NativeProtocol:socketConnection	Lcom/mysql/cj/protocol/SocketConnection;
    //   4: invokeinterface 113 1 0
    //   9: invokestatic 344	com/mysql/cj/protocol/ExportControlled:isSSLEstablished	(Ljava/net/Socket;)Z
    //   12: ifne +34 -> 46
    //   15: aload_0
    //   16: getfield 49	com/mysql/cj/protocol/a/NativeProtocol:socketConnection	Lcom/mysql/cj/protocol/SocketConnection;
    //   19: invokeinterface 113 1 0
    //   24: invokevirtual 345	java/net/Socket:isClosed	()Z
    //   27: ifne +19 -> 46
    //   30: aload_0
    //   31: getfield 49	com/mysql/cj/protocol/a/NativeProtocol:socketConnection	Lcom/mysql/cj/protocol/SocketConnection;
    //   34: invokeinterface 113 1 0
    //   39: invokevirtual 346	java/net/Socket:shutdownInput	()V
    //   42: goto +4 -> 46
    //   45: astore_1
    //   46: goto +4 -> 50
    //   49: astore_1
    //   50: aload_0
    //   51: iconst_m1
    //   52: putfield 7	com/mysql/cj/protocol/a/NativeProtocol:packetSequence	B
    //   55: new 46	com/mysql/cj/protocol/a/NativePacketPayload
    //   58: dup
    //   59: iconst_1
    //   60: invokespecial 47	com/mysql/cj/protocol/a/NativePacketPayload:<init>	(I)V
    //   63: astore_1
    //   64: aload_0
    //   65: aload_0
    //   66: getfield 19	com/mysql/cj/protocol/a/NativeProtocol:commandBuilder	Lcom/mysql/cj/protocol/a/NativeMessageBuilder;
    //   69: aload_1
    //   70: invokevirtual 348	com/mysql/cj/protocol/a/NativeMessageBuilder:buildComQuit	(Lcom/mysql/cj/protocol/a/NativePacketPayload;)Lcom/mysql/cj/protocol/a/NativePacketPayload;
    //   73: aload_1
    //   74: invokevirtual 109	com/mysql/cj/protocol/a/NativePacketPayload:getPosition	()I
    //   77: invokevirtual 110	com/mysql/cj/protocol/a/NativeProtocol:send	(Lcom/mysql/cj/protocol/Message;I)V
    //   80: aload_0
    //   81: getfield 49	com/mysql/cj/protocol/a/NativeProtocol:socketConnection	Lcom/mysql/cj/protocol/SocketConnection;
    //   84: invokeinterface 349 1 0
    //   89: aload_0
    //   90: aconst_null
    //   91: putfield 350	com/mysql/cj/protocol/a/NativeProtocol:localInfileInputStream	Ljava/io/InputStream;
    //   94: goto +20 -> 114
    //   97: astore_2
    //   98: aload_0
    //   99: getfield 49	com/mysql/cj/protocol/a/NativeProtocol:socketConnection	Lcom/mysql/cj/protocol/SocketConnection;
    //   102: invokeinterface 349 1 0
    //   107: aload_0
    //   108: aconst_null
    //   109: putfield 350	com/mysql/cj/protocol/a/NativeProtocol:localInfileInputStream	Ljava/io/InputStream;
    //   112: aload_2
    //   113: athrow
    //   114: return
    // Line number table:
    //   Java source line #1215	-> byte code offset #0
    //   Java source line #1216	-> byte code offset #15
    //   Java source line #1219	-> byte code offset #30
    //   Java source line #1222	-> byte code offset #42
    //   Java source line #1220	-> byte code offset #45
    //   Java source line #1227	-> byte code offset #46
    //   Java source line #1225	-> byte code offset #49
    //   Java source line #1229	-> byte code offset #50
    //   Java source line #1230	-> byte code offset #55
    //   Java source line #1231	-> byte code offset #64
    //   Java source line #1233	-> byte code offset #80
    //   Java source line #1234	-> byte code offset #89
    //   Java source line #1235	-> byte code offset #94
    //   Java source line #1233	-> byte code offset #97
    //   Java source line #1234	-> byte code offset #107
    //   Java source line #1235	-> byte code offset #112
    //   Java source line #1236	-> byte code offset #114
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	115	0	this	NativeProtocol
    //   45	1	1	localUnsupportedOperationException	UnsupportedOperationException
    //   49	1	1	localIOException	IOException
    //   63	11	1	packet	NativePacketPayload
    //   97	16	2	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   30	42	45	java/lang/UnsupportedOperationException
    //   0	46	49	java/io/IOException
    //   0	80	97	finally
  }
  
  public NativePacketPayload getSharedSendPacket()
  {
    if (sharedSendPacket == null) {
      sharedSendPacket = new NativePacketPayload(1024);
    }
    sharedSendPacket.setPosition(0);
    
    return sharedSendPacket;
  }
  
  private void calculateSlowQueryThreshold()
  {
    slowQueryThreshold = ((Integer)propertySet.getIntegerProperty(PropertyKey.slowQueryThresholdMillis).getValue()).intValue();
    if (((Boolean)propertySet.getBooleanProperty(PropertyKey.useNanosForElapsedTime).getValue()).booleanValue())
    {
      long nanosThreshold = ((Long)propertySet.getLongProperty(PropertyKey.slowQueryThresholdNanos).getValue()).longValue();
      if (nanosThreshold != 0L) {
        slowQueryThreshold = nanosThreshold;
      } else {
        slowQueryThreshold *= 1000000L;
      }
    }
  }
  
  public void changeUser(String user, String password, String database)
  {
    packetSequence = -1;
    packetSender = packetSender.undecorateAll();
    packetReader = packetReader.undecorateAll();
    
    authProvider.changeUser(serverSession, user, password, database);
  }
  
  public void checkForCharsetMismatch()
  {
    String characterEncoding = (String)propertySet.getStringProperty(PropertyKey.characterEncoding).getValue();
    if (characterEncoding != null)
    {
      String encodingToCheck = jvmPlatformCharset;
      if (encodingToCheck == null) {
        encodingToCheck = Constants.PLATFORM_ENCODING;
      }
      if (encodingToCheck == null) {
        platformDbCharsetMatches = false;
      } else {
        platformDbCharsetMatches = encodingToCheck.equals(characterEncoding);
      }
    }
  }
  
  protected boolean useNanosForElapsedTime()
  {
    return useNanosForElapsedTime;
  }
  
  public long getSlowQueryThreshold()
  {
    return slowQueryThreshold;
  }
  
  public int getCommandCount()
  {
    return commandCount;
  }
  
  public void setQueryInterceptors(List<QueryInterceptor> queryInterceptors)
  {
    this.queryInterceptors = (queryInterceptors.isEmpty() ? null : queryInterceptors);
  }
  
  public List<QueryInterceptor> getQueryInterceptors()
  {
    return queryInterceptors;
  }
  
  public void setSocketTimeout(int milliseconds)
  {
    try
    {
      Socket soc = socketConnection.getMysqlSocket();
      if (soc != null) {
        soc.setSoTimeout(milliseconds);
      }
    }
    catch (IOException e)
    {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Protocol.8"), e, getExceptionInterceptor()));
    }
  }
  
  public void releaseResources()
  {
    if (compressedPacketSender != null) {
      compressedPacketSender.stop();
    }
  }
  
  public void connect(String user, String password, String database)
  {
    beforeHandshake();
    
    authProvider.connect(serverSession, user, password, database);
  }
  
  protected boolean isDataAvailable()
  {
    try
    {
      return socketConnection.getMysqlInput().available() > 0;
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(propertySet, serverSession, getPacketSentTimeHolder(), 
        getPacketReceivedTimeHolder(), ioEx, getExceptionInterceptor());
    }
  }
  
  public NativePacketPayload getReusablePacket()
  {
    return reusablePacket;
  }
  
  public int getWarningCount()
  {
    return warningCount;
  }
  
  public void setWarningCount(int warningCount)
  {
    this.warningCount = warningCount;
  }
  
  public void dumpPacketRingBuffer()
  {
    LinkedList<StringBuilder> localPacketDebugRingBuffer = packetDebugRingBuffer;
    if (localPacketDebugRingBuffer != null)
    {
      StringBuilder dumpBuffer = new StringBuilder();
      
      dumpBuffer.append("Last " + localPacketDebugRingBuffer.size() + " packets received from server, from oldest->newest:\n");
      dumpBuffer.append("\n");
      for (Iterator<StringBuilder> ringBufIter = localPacketDebugRingBuffer.iterator(); ringBufIter.hasNext();)
      {
        dumpBuffer.append((CharSequence)ringBufIter.next());
        dumpBuffer.append("\n");
      }
      log.logTrace(dumpBuffer.toString());
    }
  }
  
  public boolean doesPlatformDbCharsetMatches()
  {
    return platformDbCharsetMatches;
  }
  
  public String getPasswordCharacterEncoding()
  {
    String encoding;
    if ((encoding = propertySet.getStringProperty(PropertyKey.passwordCharacterEncoding).getStringValue()) != null) {
      return encoding;
    }
    if ((encoding = (String)propertySet.getStringProperty(PropertyKey.characterEncoding).getValue()) != null) {
      return encoding;
    }
    return "UTF-8";
  }
  
  public boolean versionMeetsMinimum(int major, int minor, int subminor)
  {
    return serverSession.getServerVersion().meetsMinimum(new ServerVersion(major, minor, subminor));
  }
  
  public static MysqlType findMysqlType(PropertySet propertySet, int mysqlTypeId, short colFlag, long length, LazyString tableName, LazyString originalTableName, int collationIndex, String encoding)
  {
    boolean isUnsigned = (colFlag & 0x20) > 0;
    boolean isFromFunction = originalTableName.length() == 0;
    boolean isBinary = (colFlag & 0x80) > 0;
    
    boolean isImplicitTemporaryTable = (tableName.length() > 0) && (tableName.toString().startsWith("#sql_"));
    
    boolean isOpaqueBinary = (isBinary) && (collationIndex == 63) && ((mysqlTypeId == 254) || (mysqlTypeId == 253) || (mysqlTypeId == 15)) ? false : !isImplicitTemporaryTable ? true : "binary".equalsIgnoreCase(encoding);
    switch (mysqlTypeId)
    {
    case 0: 
    case 246: 
      return isUnsigned ? MysqlType.DECIMAL_UNSIGNED : MysqlType.DECIMAL;
    case 1: 
      if (length == 1L)
      {
        if (((Boolean)propertySet.getBooleanProperty(PropertyKey.transformedBitIsBoolean).getValue()).booleanValue()) {
          return MysqlType.BOOLEAN;
        }
        if (((Boolean)propertySet.getBooleanProperty(PropertyKey.tinyInt1isBit).getValue()).booleanValue()) {
          return MysqlType.BIT;
        }
      }
      return isUnsigned ? MysqlType.TINYINT_UNSIGNED : MysqlType.TINYINT;
    case 2: 
      return isUnsigned ? MysqlType.SMALLINT_UNSIGNED : MysqlType.SMALLINT;
    case 3: 
      return isUnsigned ? MysqlType.INT_UNSIGNED : MysqlType.INT;
    case 4: 
      return isUnsigned ? MysqlType.FLOAT_UNSIGNED : MysqlType.FLOAT;
    case 5: 
      return isUnsigned ? MysqlType.DOUBLE_UNSIGNED : MysqlType.DOUBLE;
    case 6: 
      return MysqlType.NULL;
    case 7: 
      return MysqlType.TIMESTAMP;
    case 8: 
      return isUnsigned ? MysqlType.BIGINT_UNSIGNED : MysqlType.BIGINT;
    case 9: 
      return isUnsigned ? MysqlType.MEDIUMINT_UNSIGNED : MysqlType.MEDIUMINT;
    case 10: 
      return MysqlType.DATE;
    case 11: 
      return MysqlType.TIME;
    case 12: 
      return MysqlType.DATETIME;
    case 13: 
      return MysqlType.YEAR;
    case 15: 
    case 253: 
      if ((isOpaqueBinary) && ((!isFromFunction) || (!((Boolean)propertySet.getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue()))) {
        return MysqlType.VARBINARY;
      }
      return MysqlType.VARCHAR;
    case 16: 
      return MysqlType.BIT;
    case 245: 
      return MysqlType.JSON;
    case 247: 
      return MysqlType.ENUM;
    case 248: 
      return MysqlType.SET;
    case 249: 
      if ((!isBinary) || (collationIndex != 63) || 
        (((Boolean)propertySet.getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue()) || ((isFromFunction) && 
        (((Boolean)propertySet.getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue()))) {
        return MysqlType.TINYTEXT;
      }
      return MysqlType.TINYBLOB;
    case 250: 
      if ((!isBinary) || (collationIndex != 63) || 
        (((Boolean)propertySet.getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue()) || ((isFromFunction) && 
        (((Boolean)propertySet.getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue()))) {
        return MysqlType.MEDIUMTEXT;
      }
      return MysqlType.MEDIUMBLOB;
    case 251: 
      if ((!isBinary) || (collationIndex != 63) || 
        (((Boolean)propertySet.getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue()) || ((isFromFunction) && 
        (((Boolean)propertySet.getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue()))) {
        return MysqlType.LONGTEXT;
      }
      return MysqlType.LONGBLOB;
    case 252: 
      int newMysqlTypeId = mysqlTypeId;
      if (length <= MysqlType.TINYBLOB.getPrecision().longValue())
      {
        newMysqlTypeId = 249;
      }
      else
      {
        if (length <= MysqlType.BLOB.getPrecision().longValue())
        {
          if ((!isBinary) || (collationIndex != 63) || 
            (((Boolean)propertySet.getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue()) || ((isFromFunction) && 
            (((Boolean)propertySet.getBooleanProperty(PropertyKey.functionsNeverReturnBlobs).getValue()).booleanValue())))
          {
            newMysqlTypeId = 15;
            return MysqlType.TEXT;
          }
          return MysqlType.BLOB;
        }
        if (length <= MysqlType.MEDIUMBLOB.getPrecision().longValue()) {
          newMysqlTypeId = 250;
        } else {
          newMysqlTypeId = 251;
        }
      }
      return findMysqlType(propertySet, newMysqlTypeId, colFlag, length, tableName, originalTableName, collationIndex, encoding);
    case 254: 
      if ((isOpaqueBinary) && (!((Boolean)propertySet.getBooleanProperty(PropertyKey.blobsAreStrings).getValue()).booleanValue())) {
        return MysqlType.BINARY;
      }
      return MysqlType.CHAR;
    case 255: 
      return MysqlType.GEOMETRY;
    }
    return MysqlType.UNKNOWN;
  }
  
  public <T extends ProtocolEntity> T read(Class<T> requiredClass, ProtocolEntityFactory<T, NativePacketPayload> protocolEntityFactory)
    throws IOException
  {
    ProtocolEntityReader<T, NativePacketPayload> sr = (ProtocolEntityReader)PROTOCOL_ENTITY_CLASS_TO_TEXT_READER.get(requiredClass);
    if (sr == null) {
      throw ((FeatureNotAvailableException)ExceptionFactory.createException(FeatureNotAvailableException.class, "ProtocolEntityReader isn't available for class " + requiredClass));
    }
    return sr.read(protocolEntityFactory);
  }
  
  public <T extends ProtocolEntity> T read(Class<Resultset> requiredClass, int maxRows, boolean streamResults, NativePacketPayload resultPacket, boolean isBinaryEncoded, ColumnDefinition metadata, ProtocolEntityFactory<T, NativePacketPayload> protocolEntityFactory)
    throws IOException
  {
    ProtocolEntityReader<T, NativePacketPayload> sr = isBinaryEncoded ? (ProtocolEntityReader)PROTOCOL_ENTITY_CLASS_TO_BINARY_READER.get(requiredClass) : (ProtocolEntityReader)PROTOCOL_ENTITY_CLASS_TO_TEXT_READER.get(requiredClass);
    if (sr == null) {
      throw ((FeatureNotAvailableException)ExceptionFactory.createException(FeatureNotAvailableException.class, "ProtocolEntityReader isn't available for class " + requiredClass));
    }
    return sr.read(maxRows, streamResults, resultPacket, metadata, protocolEntityFactory);
  }
  
  public <T extends ProtocolEntity> T readNextResultset(T currentProtocolEntity, int maxRows, boolean streamResults, boolean isBinaryEncoded, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory)
    throws IOException
  {
    T result = null;
    if ((Resultset.class.isAssignableFrom(currentProtocolEntity.getClass())) && (serverSession.useMultiResults()) && 
      (serverSession.hasMoreResults()))
    {
      T currentResultSet = currentProtocolEntity;
      do
      {
        NativePacketPayload fieldPacket = checkErrorMessage();
        fieldPacket.setPosition(0);
        T newResultSet = read(Resultset.class, maxRows, streamResults, fieldPacket, isBinaryEncoded, null, resultSetFactory);
        ((Resultset)currentResultSet).setNextResultset((Resultset)newResultSet);
        currentResultSet = newResultSet;
        if (result == null) {
          result = currentResultSet;
        }
      } while ((streamResults) && (serverSession.hasMoreResults()) && 
        (!((Resultset)currentResultSet).hasRows()));
    }
    return result;
  }
  
  public <T extends Resultset> T readAllResults(int maxRows, boolean streamResults, NativePacketPayload resultPacket, boolean isBinaryEncoded, ColumnDefinition metadata, ProtocolEntityFactory<T, NativePacketPayload> resultSetFactory)
    throws IOException
  {
    resultPacket.setPosition(0);
    T topLevelResultSet = (Resultset)read(Resultset.class, maxRows, streamResults, resultPacket, isBinaryEncoded, metadata, resultSetFactory);
    if (serverSession.hasMoreResults())
    {
      T currentResultSet = topLevelResultSet;
      if (streamResults)
      {
        currentResultSet = (Resultset)readNextResultset(currentResultSet, maxRows, true, isBinaryEncoded, resultSetFactory);
      }
      else
      {
        while (serverSession.hasMoreResults()) {
          currentResultSet = (Resultset)readNextResultset(currentResultSet, maxRows, false, isBinaryEncoded, resultSetFactory);
        }
        clearInputStream();
      }
    }
    if (hadWarnings) {
      scanForAndThrowDataTruncation();
    }
    reclaimLargeReusablePacket();
    return topLevelResultSet;
  }
  
  public final <T> T readServerStatusForResultSets(NativePacketPayload rowPacket, boolean saveOldStatus)
  {
    T result = null;
    if (rowPacket.isEOFPacket())
    {
      rowPacket.readInteger(NativeConstants.IntegerDataType.INT1);
      warningCount = ((int)rowPacket.readInteger(NativeConstants.IntegerDataType.INT2));
      if (warningCount > 0) {
        hadWarnings = true;
      }
      serverSession.setStatusFlags((int)rowPacket.readInteger(NativeConstants.IntegerDataType.INT2), saveOldStatus);
      checkTransactionState();
    }
    else
    {
      OkPacket ok = OkPacket.parse(rowPacket, serverSession.getErrorMessageEncoding());
      result = ok;
      
      serverSession.setStatusFlags(ok.getStatusFlags(), saveOldStatus);
      checkTransactionState();
      
      warningCount = ok.getWarningCount();
      if (warningCount > 0) {
        hadWarnings = true;
      }
    }
    return result;
  }
  
  public <QR extends QueryResult> QR readQueryResult()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public InputStream getLocalInfileInputStream()
  {
    return localInfileInputStream;
  }
  
  public void setLocalInfileInputStream(InputStream stream)
  {
    localInfileInputStream = stream;
  }
  
  public final NativePacketPayload sendFileToServer(String fileName)
  {
    NativePacketPayload filePacket = loadFileBufRef == null ? null : (NativePacketPayload)loadFileBufRef.get();
    
    int bigPacketLength = Math.min(((Integer)maxAllowedPacket.getValue()).intValue() - 12, 
      alignPacketSize(((Integer)maxAllowedPacket.getValue()).intValue() - 16, 4096) - 12);
    
    int oneMeg = 1048576;
    
    int smallerPacketSizeAligned = Math.min(oneMeg - 12, 
      alignPacketSize(oneMeg - 16, 4096) - 12);
    
    int packetLength = Math.min(smallerPacketSizeAligned, bigPacketLength);
    if (filePacket == null) {
      try
      {
        filePacket = new NativePacketPayload(packetLength);
        loadFileBufRef = new SoftReference(filePacket);
      }
      catch (OutOfMemoryError oom)
      {
        throw ExceptionFactory.createException(Messages.getString("MysqlIO.111", new Object[] { Integer.valueOf(packetLength) }), "HY001", 0, false, oom, exceptionInterceptor);
      }
    }
    filePacket.setPosition(0);
    
    byte[] fileBuf = new byte[packetLength];
    
    BufferedInputStream fileIn = null;
    try
    {
      if (!((Boolean)propertySet.getBooleanProperty(PropertyKey.allowLoadLocalInfile).getValue()).booleanValue()) {
        throw ExceptionFactory.createException(Messages.getString("MysqlIO.LoadDataLocalNotAllowed"), exceptionInterceptor);
      }
      InputStream hookedStream = null;
      
      hookedStream = getLocalInfileInputStream();
      if (hookedStream != null) {
        fileIn = new BufferedInputStream(hookedStream);
      } else if (!((Boolean)propertySet.getBooleanProperty(PropertyKey.allowUrlInLocalInfile).getValue()).booleanValue()) {
        fileIn = new BufferedInputStream(new FileInputStream(fileName));
      } else if (fileName.indexOf(':') != -1) {
        try
        {
          URL urlFromFileName = new URL(fileName);
          fileIn = new BufferedInputStream(urlFromFileName.openStream());
        }
        catch (MalformedURLException badUrlEx)
        {
          fileIn = new BufferedInputStream(new FileInputStream(fileName));
        }
      } else {
        fileIn = new BufferedInputStream(new FileInputStream(fileName));
      }
      int bytesRead = 0;
      while ((bytesRead = fileIn.read(fileBuf)) != -1)
      {
        filePacket.setPosition(0);
        filePacket.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, fileBuf, 0, bytesRead);
        send(filePacket, filePacket.getPosition());
      }
    }
    catch (IOException ioEx)
    {
      StringBuilder messageBuf = new StringBuilder(Messages.getString("MysqlIO.60"));
      
      boolean isParanoid = ((Boolean)propertySet.getBooleanProperty(PropertyKey.paranoid).getValue()).booleanValue();
      if ((fileName != null) && (!isParanoid))
      {
        messageBuf.append("'");
        messageBuf.append(fileName);
        messageBuf.append("'");
      }
      messageBuf.append(Messages.getString("MysqlIO.63"));
      if (!isParanoid)
      {
        messageBuf.append(Messages.getString("MysqlIO.64"));
        messageBuf.append(Util.stackTraceToString(ioEx));
      }
      throw ExceptionFactory.createException(messageBuf.toString(), ioEx, exceptionInterceptor);
    }
    finally
    {
      if (fileIn != null)
      {
        try
        {
          fileIn.close();
        }
        catch (Exception ex)
        {
          throw ExceptionFactory.createException(Messages.getString("MysqlIO.65"), ex, exceptionInterceptor);
        }
        fileIn = null;
      }
      else
      {
        filePacket.setPosition(0);
        send(filePacket, filePacket.getPosition());
        checkErrorMessage();
      }
    }
    filePacket.setPosition(0);
    send(filePacket, filePacket.getPosition());
    
    return checkErrorMessage();
  }
  
  private int alignPacketSize(int a, int l)
  {
    return a + l - 1 & (l - 1 ^ 0xFFFFFFFF);
  }
  
  private ResultsetRows streamingData = null;
  
  public ResultsetRows getStreamingData()
  {
    return streamingData;
  }
  
  public void setStreamingData(ResultsetRows streamingData)
  {
    this.streamingData = streamingData;
  }
  
  public void checkForOutstandingStreamingData()
  {
    if (streamingData != null)
    {
      boolean shouldClobber = ((Boolean)propertySet.getBooleanProperty(PropertyKey.clobberStreamingResults).getValue()).booleanValue();
      if (!shouldClobber) {
        throw ExceptionFactory.createException(Messages.getString("MysqlIO.39") + streamingData + Messages.getString("MysqlIO.40") + 
          Messages.getString("MysqlIO.41") + Messages.getString("MysqlIO.42"), exceptionInterceptor);
      }
      streamingData.getOwner().closeOwner(false);
      
      clearInputStream();
    }
  }
  
  public void closeStreamer(ResultsetRows streamer)
  {
    if (streamingData == null) {
      throw ExceptionFactory.createException(Messages.getString("MysqlIO.17") + streamer + Messages.getString("MysqlIO.18"), exceptionInterceptor);
    }
    if (streamer != streamingData) {
      throw ExceptionFactory.createException(Messages.getString("MysqlIO.19") + streamer + Messages.getString("MysqlIO.20") + 
        Messages.getString("MysqlIO.21") + Messages.getString("MysqlIO.22"), exceptionInterceptor);
    }
    streamingData = null;
  }
  
  public void scanForAndThrowDataTruncation()
  {
    if ((streamingData == null) && (((Boolean)propertySet.getBooleanProperty(PropertyKey.jdbcCompliantTruncation).getValue()).booleanValue()) && (getWarningCount() > 0))
    {
      int warningCountOld = getWarningCount();
      convertShowWarningsToSQLWarnings(getWarningCount(), true);
      setWarningCount(warningCountOld);
    }
  }
  
  public StringBuilder generateQueryCommentBlock(StringBuilder buf)
  {
    buf.append("/* conn id ");
    buf.append(getServerSession().getCapabilities().getThreadId());
    buf.append(" clock: ");
    buf.append(System.currentTimeMillis());
    buf.append(" */ ");
    
    return buf;
  }
  
  public BaseMetricsHolder getMetricsHolder()
  {
    return metricsHolder;
  }
  
  public String getQueryComment()
  {
    return queryComment;
  }
  
  public void setQueryComment(String comment)
  {
    queryComment = comment;
  }
  
  private void appendDeadlockStatusInformation(Session sess, String xOpen, StringBuilder errorBuf)
  {
    ValueFactory<String> vf;
    Row r;
    if ((((Boolean)sess.getPropertySet().getBooleanProperty(PropertyKey.includeInnodbStatusInDeadlockExceptions).getValue()).booleanValue()) && (xOpen != null) && 
      ((xOpen.startsWith("40")) || (xOpen.startsWith("41"))) && (getStreamingData() == null)) {
      try
      {
        NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(getSharedSendPacket(), "SHOW ENGINE INNODB STATUS"), false, 0);
        
        Resultset rs = readAllResults(-1, false, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, null));
        
        int colIndex = 0;
        Field f = null;
        for (int i = 0; i < rs.getColumnDefinition().getFields().length; i++)
        {
          f = rs.getColumnDefinition().getFields()[i];
          if ("Status".equals(f.getName()))
          {
            colIndex = i;
            break;
          }
        }
        vf = new StringValueFactory(propertySet);
        if ((r = (Row)rs.getRows().next()) != null) {
          errorBuf.append("\n\n").append((String)r.getValue(colIndex, vf));
        } else {
          errorBuf.append("\n\n").append(Messages.getString("MysqlIO.NoInnoDBStatusFound"));
        }
      }
      catch (IOException|CJException ex)
      {
        errorBuf.append("\n\n").append(Messages.getString("MysqlIO.InnoDBStatusFailed")).append("\n\n").append(Util.stackTraceToString(ex));
      }
    }
    if (((Boolean)sess.getPropertySet().getBooleanProperty(PropertyKey.includeThreadDumpInDeadlockExceptions).getValue()).booleanValue())
    {
      errorBuf.append("\n\n*** Java threads running at time of deadlock ***\n\n");
      
      ThreadMXBean threadMBean = ManagementFactory.getThreadMXBean();
      long[] threadIds = threadMBean.getAllThreadIds();
      
      ThreadInfo[] threads = threadMBean.getThreadInfo(threadIds, Integer.MAX_VALUE);
      List<ThreadInfo> activeThreads = new ArrayList();
      
      vf = threads;r = vf.length;
      for (Row localRow1 = 0; localRow1 < r; localRow1++)
      {
        ThreadInfo info = vf[localRow1];
        if (info != null) {
          activeThreads.add(info);
        }
      }
      for (ThreadInfo threadInfo : activeThreads)
      {
        errorBuf.append('"').append(threadInfo.getThreadName()).append("\" tid=").append(threadInfo.getThreadId()).append(" ").append(threadInfo.getThreadState());
        if (threadInfo.getLockName() != null) {
          errorBuf.append(" on lock=").append(threadInfo.getLockName());
        }
        if (threadInfo.isSuspended()) {
          errorBuf.append(" (suspended)");
        }
        if (threadInfo.isInNative()) {
          errorBuf.append(" (running in native)");
        }
        StackTraceElement[] stackTrace = threadInfo.getStackTrace();
        if (stackTrace.length > 0)
        {
          errorBuf.append(" in ");
          errorBuf.append(stackTrace[0].getClassName()).append(".");
          errorBuf.append(stackTrace[0].getMethodName()).append("()");
        }
        errorBuf.append("\n");
        if (threadInfo.getLockOwnerName() != null) {
          errorBuf.append("\t owned by ").append(threadInfo.getLockOwnerName()).append(" Id=").append(threadInfo.getLockOwnerId()).append("\n");
        }
        for (int j = 0; j < stackTrace.length; j++)
        {
          StackTraceElement ste = stackTrace[j];
          errorBuf.append("\tat ").append(ste.toString()).append("\n");
        }
      }
    }
  }
  
  private StringBuilder appendResultSetSlashGStyle(StringBuilder appendTo, Resultset rs)
  {
    Field[] fields = rs.getColumnDefinition().getFields();
    int maxWidth = 0;
    for (int i = 0; i < fields.length; i++) {
      if (fields[i].getColumnLabel().length() > maxWidth) {
        maxWidth = fields[i].getColumnLabel().length();
      }
    }
    int rowCount = 1;
    Row r;
    while ((r = (Row)rs.getRows().next()) != null)
    {
      appendTo.append("*************************** ");
      appendTo.append(rowCount++);
      appendTo.append(". row ***************************\n");
      for (int i = 0; i < fields.length; i++)
      {
        int leftPad = maxWidth - fields[i].getColumnLabel().length();
        for (int j = 0; j < leftPad; j++) {
          appendTo.append(" ");
        }
        appendTo.append(fields[i].getColumnLabel()).append(": ");
        String stringVal = (String)r.getValue(i, new StringValueFactory(propertySet));
        appendTo.append(stringVal != null ? stringVal : "NULL").append("\n");
      }
      appendTo.append("\n");
    }
    return appendTo;
  }
  
  public SQLWarning convertShowWarningsToSQLWarnings(int warningCountIfKnown, boolean forTruncationOnly)
  {
    SQLWarning currentWarning = null;
    ResultsetRows rows = null;
    try
    {
      NativePacketPayload resultPacket = sendCommand(commandBuilder.buildComQuery(getSharedSendPacket(), "SHOW WARNINGS"), false, 0);
      
      Resultset warnRs = readAllResults(-1, warningCountIfKnown > 99, resultPacket, false, null, new ResultsetFactory(Resultset.Type.FORWARD_ONLY, Resultset.Concurrency.READ_ONLY));
      
      int codeFieldIndex = warnRs.getColumnDefinition().findColumn("Code", false, 1) - 1;
      int messageFieldIndex = warnRs.getColumnDefinition().findColumn("Message", false, 1) - 1;
      
      ValueFactory<String> svf = new StringValueFactory(propertySet);
      ValueFactory<Integer> ivf = new IntegerValueFactory(propertySet);
      
      rows = warnRs.getRows();
      Row r;
      int code;
      while ((r = (Row)rows.next()) != null)
      {
        code = ((Integer)r.getValue(codeFieldIndex, ivf)).intValue();
        if (forTruncationOnly)
        {
          if ((code == 1265) || (code == 1264))
          {
            DataTruncation newTruncation = new MysqlDataTruncation((String)r.getValue(messageFieldIndex, svf), 0, false, false, 0, 0, code);
            if (currentWarning == null) {
              currentWarning = newTruncation;
            } else {
              currentWarning.setNextWarning(newTruncation);
            }
          }
        }
        else
        {
          String message = (String)r.getValue(messageFieldIndex, svf);
          
          SQLWarning newWarning = new SQLWarning(message, MysqlErrorNumbers.mysqlToSqlState(code), code);
          if (currentWarning == null) {
            currentWarning = newWarning;
          } else {
            currentWarning.setNextWarning(newWarning);
          }
        }
      }
      if ((forTruncationOnly) && (currentWarning != null)) {
        throw ExceptionFactory.createException(currentWarning.getMessage(), currentWarning);
      }
      return currentWarning;
    }
    catch (IOException ex)
    {
      throw ExceptionFactory.createException(ex.getMessage(), ex);
    }
    finally
    {
      if (rows != null) {
        rows.close();
      }
    }
  }
  
  public ColumnDefinition readMetadata()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public RowList getRowInputStream(ColumnDefinition metadata)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public void close()
    throws IOException
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public void setCurrentResultStreamer(ResultStreamer currentResultStreamer)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
  
  public void configureTimezone()
  {
    String configuredTimeZoneOnServer = serverSession.getServerVariable("time_zone");
    if ("SYSTEM".equalsIgnoreCase(configuredTimeZoneOnServer)) {
      configuredTimeZoneOnServer = serverSession.getServerVariable("system_time_zone");
    }
    String canonicalTimezone = (String)getPropertySet().getStringProperty(PropertyKey.serverTimezone).getValue();
    if (configuredTimeZoneOnServer != null) {
      if ((canonicalTimezone == null) || (StringUtils.isEmptyOrWhitespaceOnly(canonicalTimezone))) {
        try
        {
          canonicalTimezone = TimeUtil.getCanonicalTimezone(configuredTimeZoneOnServer, getExceptionInterceptor());
        }
        catch (IllegalArgumentException iae)
        {
          throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, iae.getMessage(), getExceptionInterceptor()));
        }
      }
    }
    if ((canonicalTimezone != null) && (canonicalTimezone.length() > 0))
    {
      serverSession.setServerTimeZone(TimeZone.getTimeZone(canonicalTimezone));
      if ((!canonicalTimezone.equalsIgnoreCase("GMT")) && (serverSession.getServerTimeZone().getID().equals("GMT"))) {
        throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("Connection.9", new Object[] { canonicalTimezone }), 
          getExceptionInterceptor()));
      }
    }
    serverSession.setDefaultTimeZone(serverSession.getServerTimeZone());
  }
  
  public void initServerSession()
  {
    configureTimezone();
    if (session.getServerSession().getServerVariables().containsKey("max_allowed_packet"))
    {
      int serverMaxAllowedPacket = session.getServerSession().getServerVariable("max_allowed_packet", -1);
      if ((serverMaxAllowedPacket != -1) && ((!maxAllowedPacket.isExplicitlySet()) || (serverMaxAllowedPacket < ((Integer)maxAllowedPacket.getValue()).intValue()))) {
        maxAllowedPacket.setValue(Integer.valueOf(serverMaxAllowedPacket));
      }
      if (((Boolean)useServerPrepStmts.getValue()).booleanValue())
      {
        RuntimeProperty<Integer> blobSendChunkSize = propertySet.getProperty(PropertyKey.blobSendChunkSize);
        int preferredBlobSendChunkSize = ((Integer)blobSendChunkSize.getValue()).intValue();
        
        int packetHeaderSize = 8203;
        int allowedBlobSendChunkSize = Math.min(preferredBlobSendChunkSize, ((Integer)maxAllowedPacket.getValue()).intValue()) - packetHeaderSize;
        if (allowedBlobSendChunkSize <= 0) {
          throw ExceptionFactory.createException(Messages.getString("Connection.15", new Object[] { Integer.valueOf(packetHeaderSize) }), "01S00", 0, false, null, exceptionInterceptor);
        }
        blobSendChunkSize.setValue(Integer.valueOf(allowedBlobSendChunkSize));
      }
    }
  }
  
  /* Error */
  static
  {
    // Byte code:
    //   0: iconst_4
    //   1: anewarray 361	java/lang/String
    //   4: dup
    //   5: iconst_0
    //   6: ldc_w 614
    //   9: aastore
    //   10: dup
    //   11: iconst_1
    //   12: ldc_w 615
    //   15: aastore
    //   16: dup
    //   17: iconst_2
    //   18: ldc_w 616
    //   21: aastore
    //   22: dup
    //   23: iconst_3
    //   24: ldc_w 617
    //   27: aastore
    //   28: putstatic 331	com/mysql/cj/protocol/a/NativeProtocol:EXPLAINABLE_STATEMENT_EXTENSION	[Ljava/lang/String;
    //   31: aconst_null
    //   32: putstatic 362	com/mysql/cj/protocol/a/NativeProtocol:jvmPlatformCharset	Ljava/lang/String;
    //   35: aconst_null
    //   36: astore_0
    //   37: new 618	java/io/OutputStreamWriter
    //   40: dup
    //   41: new 619	java/io/ByteArrayOutputStream
    //   44: dup
    //   45: invokespecial 620	java/io/ByteArrayOutputStream:<init>	()V
    //   48: invokespecial 621	java/io/OutputStreamWriter:<init>	(Ljava/io/OutputStream;)V
    //   51: astore_0
    //   52: aload_0
    //   53: invokevirtual 622	java/io/OutputStreamWriter:getEncoding	()Ljava/lang/String;
    //   56: putstatic 362	com/mysql/cj/protocol/a/NativeProtocol:jvmPlatformCharset	Ljava/lang/String;
    //   59: aload_0
    //   60: ifnull +7 -> 67
    //   63: aload_0
    //   64: invokevirtual 623	java/io/OutputStreamWriter:close	()V
    //   67: goto +22 -> 89
    //   70: astore_1
    //   71: goto +18 -> 89
    //   74: astore_2
    //   75: aload_0
    //   76: ifnull +7 -> 83
    //   79: aload_0
    //   80: invokevirtual 623	java/io/OutputStreamWriter:close	()V
    //   83: goto +4 -> 87
    //   86: astore_3
    //   87: aload_2
    //   88: athrow
    //   89: return
    // Line number table:
    //   Java source line #136	-> byte code offset #0
    //   Java source line #208	-> byte code offset #31
    //   Java source line #213	-> byte code offset #35
    //   Java source line #220	-> byte code offset #37
    //   Java source line #221	-> byte code offset #52
    //   Java source line #224	-> byte code offset #59
    //   Java source line #225	-> byte code offset #63
    //   Java source line #229	-> byte code offset #67
    //   Java source line #227	-> byte code offset #70
    //   Java source line #230	-> byte code offset #71
    //   Java source line #223	-> byte code offset #74
    //   Java source line #224	-> byte code offset #75
    //   Java source line #225	-> byte code offset #79
    //   Java source line #229	-> byte code offset #83
    //   Java source line #227	-> byte code offset #86
    //   Java source line #230	-> byte code offset #87
    //   Java source line #231	-> byte code offset #89
    // Local variable table:
    //   start	length	slot	name	signature
    //   36	44	0	outWriter	java.io.OutputStreamWriter
    //   70	1	1	localIOException	IOException
    //   74	14	2	localObject	Object
    //   86	1	3	localIOException1	IOException
    // Exception table:
    //   from	to	target	type
    //   59	67	70	java/io/IOException
    //   37	59	74	finally
    //   75	83	86	java/io/IOException
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeProtocol
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */