package com.mysql.cj.protocol.a;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.Resultset.Concurrency;
import com.mysql.cj.protocol.ResultsetRow;
import com.mysql.cj.protocol.a.result.ByteArrayRow;
import com.mysql.cj.protocol.a.result.TextBufferRow;

public class TextRowFactory
  extends AbstractRowFactory
  implements ProtocolEntityFactory<ResultsetRow, NativePacketPayload>
{
  public TextRowFactory(NativeProtocol protocol, ColumnDefinition colDefinition, Resultset.Concurrency resultSetConcurrency, boolean canReuseRowPacketForBufferRow)
  {
    columnDefinition = colDefinition;
    this.resultSetConcurrency = resultSetConcurrency;
    this.canReuseRowPacketForBufferRow = canReuseRowPacketForBufferRow;
    useBufferRowSizeThreshold = protocol.getPropertySet().getMemorySizeProperty(PropertyKey.largeRowSizeThreshold);
    exceptionInterceptor = protocol.getExceptionInterceptor();
    valueDecoder = new MysqlTextValueDecoder();
  }
  
  public ResultsetRow createFromMessage(NativePacketPayload rowPacket)
  {
    boolean useBufferRow = (canReuseRowPacketForBufferRow) || (columnDefinition.hasLargeFields()) || (rowPacket.getPayloadLength() >= ((Integer)useBufferRowSizeThreshold.getValue()).intValue());
    if ((resultSetConcurrency == Resultset.Concurrency.UPDATABLE) || (!useBufferRow))
    {
      byte[][] rowBytes = new byte[columnDefinition.getFields().length][];
      for (int i = 0; i < columnDefinition.getFields().length; i++) {
        rowBytes[i] = rowPacket.readBytes(NativeConstants.StringSelfDataType.STRING_LENENC);
      }
      return new ByteArrayRow(rowBytes, exceptionInterceptor);
    }
    return new TextBufferRow(rowPacket, columnDefinition, exceptionInterceptor, valueDecoder);
  }
  
  public boolean canReuseRowPacketForBufferRow()
  {
    return canReuseRowPacketForBufferRow;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.TextRowFactory
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */