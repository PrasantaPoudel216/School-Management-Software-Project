package com.mysql.cj.protocol.a.authentication;

public enum CachingSha2PasswordPlugin$AuthStage
{
  FAST_AUTH_SEND_SCRAMBLE,  FAST_AUTH_READ_RESULT,  FAST_AUTH_COMPLETE,  FULL_AUTH;
  
  private CachingSha2PasswordPlugin$AuthStage() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.authentication.CachingSha2PasswordPlugin.AuthStage
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */