package com.mysql.cj.protocol.a.authentication;

import com.mysql.cj.Messages;
import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.UnableToConnectException;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.AuthenticationPlugin;
import com.mysql.cj.protocol.ExportControlled;
import com.mysql.cj.protocol.Protocol;
import com.mysql.cj.protocol.Security;
import com.mysql.cj.protocol.SocketConnection;
import com.mysql.cj.protocol.a.NativeConstants.IntegerDataType;
import com.mysql.cj.protocol.a.NativeConstants.StringSelfDataType;
import com.mysql.cj.protocol.a.NativePacketPayload;
import com.mysql.cj.util.StringUtils;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

public class Sha256PasswordPlugin
  implements AuthenticationPlugin<NativePacketPayload>
{
  public static String PLUGIN_NAME = "sha256_password";
  protected Protocol<NativePacketPayload> protocol;
  protected String password = null;
  protected String seed = null;
  protected boolean publicKeyRequested = false;
  protected String publicKeyString = null;
  protected RuntimeProperty<String> serverRSAPublicKeyFile = null;
  
  public void init(Protocol<NativePacketPayload> prot)
  {
    protocol = prot;
    serverRSAPublicKeyFile = protocol.getPropertySet().getStringProperty(PropertyKey.serverRSAPublicKeyFile);
    
    String pkURL = (String)serverRSAPublicKeyFile.getValue();
    if (pkURL != null) {
      publicKeyString = readRSAKey(pkURL, protocol.getPropertySet(), protocol.getExceptionInterceptor());
    }
  }
  
  public void destroy()
  {
    password = null;
    seed = null;
    publicKeyRequested = false;
  }
  
  public String getProtocolPluginName()
  {
    return PLUGIN_NAME;
  }
  
  public boolean requiresConfidentiality()
  {
    return false;
  }
  
  public boolean isReusable()
  {
    return true;
  }
  
  public void setAuthenticationParameters(String user, String password)
  {
    this.password = password;
  }
  
  public boolean nextAuthenticationStep(NativePacketPayload fromServer, List<NativePacketPayload> toServer)
  {
    toServer.clear();
    if ((password == null) || (password.length() == 0) || (fromServer == null))
    {
      NativePacketPayload bresp = new NativePacketPayload(new byte[] { 0 });
      toServer.add(bresp);
    }
    else
    {
      try
      {
        if (protocol.getSocketConnection().isSSLEstablished())
        {
          NativePacketPayload bresp = new NativePacketPayload(StringUtils.getBytes(password, protocol.getPasswordCharacterEncoding()));
          bresp.setPosition(bresp.getPayloadLength());
          bresp.writeInteger(NativeConstants.IntegerDataType.INT1, 0L);
          bresp.setPosition(0);
          toServer.add(bresp);
        }
        else if (serverRSAPublicKeyFile.getValue() != null)
        {
          seed = fromServer.readString(NativeConstants.StringSelfDataType.STRING_TERM, null);
          NativePacketPayload bresp = new NativePacketPayload(encryptPassword());
          toServer.add(bresp);
        }
        else
        {
          if (!((Boolean)protocol.getPropertySet().getBooleanProperty(PropertyKey.allowPublicKeyRetrieval).getValue()).booleanValue()) {
            throw ((UnableToConnectException)ExceptionFactory.createException(UnableToConnectException.class, Messages.getString("Sha256PasswordPlugin.2"), protocol
              .getExceptionInterceptor()));
          }
          if ((publicKeyRequested) && (fromServer.getPayloadLength() > 20))
          {
            publicKeyString = fromServer.readString(NativeConstants.StringSelfDataType.STRING_TERM, null);
            NativePacketPayload bresp = new NativePacketPayload(encryptPassword());
            toServer.add(bresp);
            publicKeyRequested = false;
          }
          else
          {
            seed = fromServer.readString(NativeConstants.StringSelfDataType.STRING_TERM, null);
            NativePacketPayload bresp = new NativePacketPayload(new byte[] { 1 });
            toServer.add(bresp);
            publicKeyRequested = true;
          }
        }
      }
      catch (CJException e)
      {
        throw ExceptionFactory.createException(e.getMessage(), e, protocol.getExceptionInterceptor());
      }
    }
    return true;
  }
  
  protected byte[] encryptPassword()
  {
    return encryptPassword("RSA/ECB/OAEPWithSHA-1AndMGF1Padding");
  }
  
  protected byte[] encryptPassword(String transformation)
  {
    byte[] input = null;
    input = new byte[] { password != null ? StringUtils.getBytesNullTerminated(password, protocol.getPasswordCharacterEncoding()) : 0 };
    byte[] mysqlScrambleBuff = new byte[input.length];
    Security.xorString(input, mysqlScrambleBuff, seed.getBytes(), input.length);
    return ExportControlled.encryptWithRSAPublicKey(mysqlScrambleBuff, ExportControlled.decodeRSAPublicKey(publicKeyString), transformation);
  }
  
  protected static String readRSAKey(String pkPath, PropertySet propertySet, ExceptionInterceptor exceptionInterceptor)
  {
    res = null;
    byte[] fileBuf = new byte['?'];
    
    BufferedInputStream fileIn = null;
    try
    {
      File f = new File(pkPath);
      String canonicalPath = f.getCanonicalPath();
      fileIn = new BufferedInputStream(new FileInputStream(canonicalPath));
      
      int bytesRead = 0;
      
      StringBuilder sb = new StringBuilder();
      while ((bytesRead = fileIn.read(fileBuf)) != -1) {
        sb.append(StringUtils.toAsciiString(fileBuf, 0, bytesRead));
      }
      return sb.toString();
    }
    catch (IOException ioEx)
    {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
        Messages.getString("Sha256PasswordPlugin.0", 
        new Object[] { "'" + pkPath + "'" }), exceptionInterceptor));
    }
    finally
    {
      if (fileIn != null) {
        try
        {
          fileIn.close();
        }
        catch (IOException e)
        {
          throw ExceptionFactory.createException(Messages.getString("Sha256PasswordPlugin.1"), e, exceptionInterceptor);
        }
      }
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.authentication.Sha256PasswordPlugin
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */