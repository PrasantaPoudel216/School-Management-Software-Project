package com.mysql.cj.protocol.a;

import com.mysql.cj.Messages;
import com.mysql.cj.protocol.MessageReader;
import java.io.IOException;
import java.util.Optional;

public class MultiPacketReader
  implements MessageReader<NativePacketHeader, NativePacketPayload>
{
  private MessageReader<NativePacketHeader, NativePacketPayload> packetReader;
  
  public MultiPacketReader(MessageReader<NativePacketHeader, NativePacketPayload> packetReader)
  {
    this.packetReader = packetReader;
  }
  
  public NativePacketHeader readHeader()
    throws IOException
  {
    return (NativePacketHeader)packetReader.readHeader();
  }
  
  public NativePacketPayload readMessage(Optional<NativePacketPayload> reuse, NativePacketHeader header)
    throws IOException
  {
    int packetLength = header.getMessageSize();
    NativePacketPayload buf = (NativePacketPayload)packetReader.readMessage(reuse, header);
    if (packetLength == 16777215)
    {
      buf.setPosition(16777215);
      
      NativePacketPayload multiPacket = null;
      int multiPacketLength = -1;
      byte multiPacketSeq = getMessageSequence();
      do
      {
        NativePacketHeader hdr = readHeader();
        multiPacketLength = hdr.getMessageSize();
        if (multiPacket == null) {
          multiPacket = new NativePacketPayload(multiPacketLength);
        }
        multiPacketSeq = (byte)(multiPacketSeq + 1);
        if (multiPacketSeq != hdr.getMessageSequence()) {
          throw new IOException(Messages.getString("PacketReader.10"));
        }
        packetReader.readMessage(Optional.of(multiPacket), hdr);
        
        buf.writeBytes(NativeConstants.StringLengthDataType.STRING_FIXED, multiPacket.getByteBuffer(), 0, multiPacketLength);
      } while (multiPacketLength == 16777215);
      buf.setPosition(0);
    }
    return buf;
  }
  
  public byte getMessageSequence()
  {
    return packetReader.getMessageSequence();
  }
  
  public void resetMessageSequence()
  {
    packetReader.resetMessageSequence();
  }
  
  public MessageReader<NativePacketHeader, NativePacketPayload> undecorateAll()
  {
    return packetReader.undecorateAll();
  }
  
  public MessageReader<NativePacketHeader, NativePacketPayload> undecorate()
  {
    return packetReader;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.MultiPacketReader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */