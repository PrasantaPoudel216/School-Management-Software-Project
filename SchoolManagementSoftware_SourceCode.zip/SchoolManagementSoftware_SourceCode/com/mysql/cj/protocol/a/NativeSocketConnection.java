package com.mysql.cj.protocol.a;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.exceptions.FeatureNotAvailableException;
import com.mysql.cj.exceptions.SSLParamsException;
import com.mysql.cj.log.Log;
import com.mysql.cj.protocol.AbstractSocketConnection;
import com.mysql.cj.protocol.FullReadInputStream;
import com.mysql.cj.protocol.PacketSentTimeHolder;
import com.mysql.cj.protocol.ReadAheadInputStream;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.protocol.SocketConnection;
import com.mysql.cj.protocol.SocketFactory;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.Socket;
import java.nio.channels.AsynchronousSocketChannel;

public class NativeSocketConnection
  extends AbstractSocketConnection
  implements SocketConnection
{
  public void connect(String hostName, int portNumber, PropertySet propSet, ExceptionInterceptor excInterceptor, Log log, int loginTimeout)
  {
    try
    {
      port = portNumber;
      host = hostName;
      propertySet = propSet;
      exceptionInterceptor = excInterceptor;
      
      socketFactory = createSocketFactory(propSet.getStringProperty(PropertyKey.socketFactory).getStringValue());
      mysqlSocket = ((Socket)socketFactory.connect(host, port, propSet, loginTimeout));
      
      int socketTimeout = ((Integer)propSet.getIntegerProperty(PropertyKey.socketTimeout).getValue()).intValue();
      if (socketTimeout != 0) {
        try
        {
          mysqlSocket.setSoTimeout(socketTimeout);
        }
        catch (Exception localException) {}
      }
      socketFactory.beforeHandshake();
      InputStream rawInputStream;
      InputStream rawInputStream;
      if (((Boolean)propSet.getBooleanProperty(PropertyKey.useReadAheadInput).getValue()).booleanValue())
      {
        rawInputStream = new ReadAheadInputStream(mysqlSocket.getInputStream(), 16384, ((Boolean)propSet.getBooleanProperty(PropertyKey.traceProtocol).getValue()).booleanValue(), log);
      }
      else
      {
        InputStream rawInputStream;
        if (((Boolean)propSet.getBooleanProperty(PropertyKey.useUnbufferedInput).getValue()).booleanValue()) {
          rawInputStream = mysqlSocket.getInputStream();
        } else {
          rawInputStream = new BufferedInputStream(mysqlSocket.getInputStream(), 16384);
        }
      }
      mysqlInput = new FullReadInputStream(rawInputStream);
      mysqlOutput = new BufferedOutputStream(mysqlSocket.getOutputStream(), 16384);
    }
    catch (IOException ioEx)
    {
      throw ExceptionFactory.createCommunicationsException(propSet, null, new PacketSentTimeHolder() {}, null, ioEx, 
        getExceptionInterceptor());
    }
  }
  
  public void performTlsHandshake(ServerSession serverSession)
    throws SSLParamsException, FeatureNotAvailableException, IOException
  {
    mysqlSocket = ((Socket)socketFactory.performTlsHandshake(this, serverSession));
    
    mysqlInput = new FullReadInputStream(((Boolean)propertySet.getBooleanProperty(PropertyKey.useUnbufferedInput).getValue()).booleanValue() ? getMysqlSocket().getInputStream() : new BufferedInputStream(getMysqlSocket().getInputStream(), 16384));
    
    mysqlOutput = new BufferedOutputStream(getMysqlSocket().getOutputStream(), 16384);
    mysqlOutput.flush();
  }
  
  public AsynchronousSocketChannel getAsynchronousSocketChannel()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, "Not supported"));
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeSocketConnection
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */