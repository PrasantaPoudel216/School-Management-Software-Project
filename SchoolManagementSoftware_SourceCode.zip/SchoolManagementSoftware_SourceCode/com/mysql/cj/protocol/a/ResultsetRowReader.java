package com.mysql.cj.protocol.a;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.protocol.MessageReader;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.ProtocolEntityReader;
import com.mysql.cj.protocol.ResultsetRow;
import java.io.IOException;
import java.util.Optional;

public class ResultsetRowReader
  implements ProtocolEntityReader<ResultsetRow, NativePacketPayload>
{
  protected NativeProtocol protocol;
  protected PropertySet propertySet;
  protected RuntimeProperty<Integer> useBufferRowSizeThreshold;
  
  public ResultsetRowReader(NativeProtocol prot)
  {
    protocol = prot;
    
    propertySet = protocol.getPropertySet();
    useBufferRowSizeThreshold = propertySet.getMemorySizeProperty(PropertyKey.largeRowSizeThreshold);
  }
  
  public ResultsetRow read(ProtocolEntityFactory<ResultsetRow, NativePacketPayload> sf)
    throws IOException
  {
    AbstractRowFactory rf = (AbstractRowFactory)sf;
    NativePacketPayload rowPacket = null;
    NativePacketHeader hdr = (NativePacketHeader)protocol.getPacketReader().readHeader();
    
    rowPacket = (NativePacketPayload)protocol.getPacketReader().readMessage(rf.canReuseRowPacketForBufferRow() ? Optional.ofNullable(protocol.getReusablePacket()) : Optional.empty(), hdr);
    protocol.checkErrorMessage(rowPacket);
    
    rowPacket.setPosition(rowPacket.getPosition() - 1);
    if (((!protocol.getServerSession().isEOFDeprecated()) && (rowPacket.isEOFPacket())) || (
      (protocol.getServerSession().isEOFDeprecated()) && (rowPacket.isResultSetOKPacket())))
    {
      protocol.readServerStatusForResultSets(rowPacket, true);
      return null;
    }
    return (ResultsetRow)sf.createFromMessage(rowPacket);
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.ResultsetRowReader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */