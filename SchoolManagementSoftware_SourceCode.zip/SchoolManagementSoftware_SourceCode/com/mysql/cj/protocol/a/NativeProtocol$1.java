package com.mysql.cj.protocol.a;

import com.mysql.cj.protocol.PacketSentTimeHolder;

class NativeProtocol$1
  implements PacketSentTimeHolder
{
  NativeProtocol$1(NativeProtocol this$0) {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeProtocol.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */