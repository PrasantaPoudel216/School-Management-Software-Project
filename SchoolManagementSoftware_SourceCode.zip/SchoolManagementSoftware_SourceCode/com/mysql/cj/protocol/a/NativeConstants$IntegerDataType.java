package com.mysql.cj.protocol.a;

public enum NativeConstants$IntegerDataType
{
  INT1,  INT2,  INT3,  INT4,  INT6,  INT8,  INT_LENENC;
  
  private NativeConstants$IntegerDataType() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeConstants.IntegerDataType
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */