package com.mysql.cj.protocol.a;

public enum NativeConstants$StringSelfDataType
{
  STRING_TERM,  STRING_LENENC,  STRING_EOF;
  
  private NativeConstants$StringSelfDataType() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeConstants.StringSelfDataType
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */