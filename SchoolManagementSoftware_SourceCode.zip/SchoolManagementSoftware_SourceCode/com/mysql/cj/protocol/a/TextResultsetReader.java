package com.mysql.cj.protocol.a;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ProtocolEntityFactory;
import com.mysql.cj.protocol.ProtocolEntityReader;
import com.mysql.cj.protocol.Resultset;
import com.mysql.cj.protocol.ResultsetRow;
import com.mysql.cj.protocol.ResultsetRows;
import com.mysql.cj.protocol.a.result.OkPacket;
import com.mysql.cj.protocol.a.result.ResultsetRowsStatic;
import com.mysql.cj.protocol.a.result.ResultsetRowsStreaming;
import java.io.IOException;
import java.util.ArrayList;

public class TextResultsetReader
  implements ProtocolEntityReader<Resultset, NativePacketPayload>
{
  protected NativeProtocol protocol;
  
  public TextResultsetReader(NativeProtocol prot)
  {
    protocol = prot;
  }
  
  public Resultset read(int maxRows, boolean streamResults, NativePacketPayload resultPacket, ColumnDefinition metadata, ProtocolEntityFactory<Resultset, NativePacketPayload> resultSetFactory)
    throws IOException
  {
    Resultset rs = null;
    
    long columnCount = resultPacket.readInteger(NativeConstants.IntegerDataType.INT_LENENC);
    if (columnCount > 0L)
    {
      ColumnDefinition cdef = (ColumnDefinition)protocol.read(ColumnDefinition.class, new ColumnDefinitionFactory(columnCount, metadata));
      if (!protocol.getServerSession().isEOFDeprecated()) {
        protocol.skipPacket();
      }
      ResultsetRows rows = null;
      if (!streamResults)
      {
        TextRowFactory trf = new TextRowFactory(protocol, cdef, resultSetFactory.getResultSetConcurrency(), false);
        ArrayList<ResultsetRow> rowList = new ArrayList();
        
        ResultsetRow row = (ResultsetRow)protocol.read(ResultsetRow.class, trf);
        while (row != null)
        {
          if ((maxRows == -1) || (rowList.size() < maxRows)) {
            rowList.add(row);
          }
          row = (ResultsetRow)protocol.read(ResultsetRow.class, trf);
        }
        rows = new ResultsetRowsStatic(rowList, cdef);
      }
      else
      {
        rows = new ResultsetRowsStreaming(protocol, cdef, false, resultSetFactory);
        protocol.setStreamingData(rows);
      }
      rs = (Resultset)resultSetFactory.createFromProtocolEntity(rows);
    }
    else
    {
      if (columnCount == -1L)
      {
        String charEncoding = (String)protocol.getPropertySet().getStringProperty(PropertyKey.characterEncoding).getValue();
        String fileName = resultPacket.readString(NativeConstants.StringSelfDataType.STRING_TERM, protocol.doesPlatformDbCharsetMatches() ? charEncoding : null);
        resultPacket = protocol.sendFileToServer(fileName);
      }
      OkPacket ok = (OkPacket)protocol.readServerStatusForResultSets(resultPacket, false);
      
      rs = (Resultset)resultSetFactory.createFromProtocolEntity(ok);
    }
    return rs;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.TextResultsetReader
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */