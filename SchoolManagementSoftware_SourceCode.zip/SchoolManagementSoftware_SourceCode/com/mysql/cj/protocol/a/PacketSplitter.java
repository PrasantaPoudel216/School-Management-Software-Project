package com.mysql.cj.protocol.a;

public class PacketSplitter
{
  private int totalSize;
  private int currentPacketLen = 0;
  private int offset = 0;
  
  public PacketSplitter(int totalSize)
  {
    this.totalSize = totalSize;
  }
  
  public int getPacketLen()
  {
    return currentPacketLen;
  }
  
  public int getOffset()
  {
    return offset;
  }
  
  public boolean nextPacket()
  {
    offset += currentPacketLen;
    if ((currentPacketLen == 16777215) && (offset == totalSize))
    {
      currentPacketLen = 0;
      return true;
    }
    if (totalSize == 0)
    {
      totalSize = -1;
      return true;
    }
    currentPacketLen = (totalSize - offset);
    if (currentPacketLen > 16777215) {
      currentPacketLen = 16777215;
    }
    return offset < totalSize;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.PacketSplitter
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */