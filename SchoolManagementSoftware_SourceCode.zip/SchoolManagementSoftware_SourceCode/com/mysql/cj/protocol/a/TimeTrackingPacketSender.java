package com.mysql.cj.protocol.a;

import com.mysql.cj.protocol.MessageSender;
import com.mysql.cj.protocol.PacketSentTimeHolder;
import java.io.IOException;

public class TimeTrackingPacketSender
  implements MessageSender<NativePacketPayload>, PacketSentTimeHolder
{
  private MessageSender<NativePacketPayload> packetSender;
  private long lastPacketSentTime = 0L;
  private long previousPacketSentTime = 0L;
  
  public TimeTrackingPacketSender(MessageSender<NativePacketPayload> packetSender)
  {
    this.packetSender = packetSender;
  }
  
  public void send(byte[] packet, int packetLen, byte packetSequence)
    throws IOException
  {
    packetSender.send(packet, packetLen, packetSequence);
    
    previousPacketSentTime = lastPacketSentTime;
    lastPacketSentTime = System.currentTimeMillis();
  }
  
  public long getLastPacketSentTime()
  {
    return lastPacketSentTime;
  }
  
  public long getPreviousPacketSentTime()
  {
    return previousPacketSentTime;
  }
  
  public MessageSender<NativePacketPayload> undecorateAll()
  {
    return packetSender.undecorateAll();
  }
  
  public MessageSender<NativePacketPayload> undecorate()
  {
    return packetSender;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.TimeTrackingPacketSender
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */