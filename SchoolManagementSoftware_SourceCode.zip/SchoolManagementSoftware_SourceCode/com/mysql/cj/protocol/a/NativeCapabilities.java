package com.mysql.cj.protocol.a;

import com.mysql.cj.ServerVersion;
import com.mysql.cj.protocol.ServerCapabilities;

public class NativeCapabilities
  implements ServerCapabilities
{
  private NativePacketPayload initialHandshakePacket;
  private byte protocolVersion = 0;
  private ServerVersion serverVersion;
  private long threadId = -1L;
  private String seed;
  private int capabilityFlags;
  private int serverDefaultCollationIndex;
  private int statusFlags = 0;
  private int authPluginDataLength = 0;
  private boolean serverHasFracSecsSupport = true;
  
  public NativePacketPayload getInitialHandshakePacket()
  {
    return initialHandshakePacket;
  }
  
  public void setInitialHandshakePacket(NativePacketPayload initialHandshakePacket)
  {
    this.initialHandshakePacket = initialHandshakePacket;
    
    setProtocolVersion((byte)(int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1));
    
    setServerVersion(ServerVersion.parseVersion(initialHandshakePacket.readString(NativeConstants.StringSelfDataType.STRING_TERM, "ASCII")));
    
    setThreadId(initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT4));
    
    setSeed(initialHandshakePacket.readString(NativeConstants.StringLengthDataType.STRING_FIXED, "ASCII", 8));
    
    initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1);
    
    int flags = 0;
    if (initialHandshakePacket.getPosition() < initialHandshakePacket.getPayloadLength()) {
      flags = (int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT2);
    }
    setServerDefaultCollationIndex((int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1));
    
    setStatusFlags((int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT2));
    
    flags |= (int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT2) << 16;
    
    setCapabilityFlags(flags);
    if ((flags & 0x80000) != 0) {
      authPluginDataLength = ((int)initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1));
    } else {
      initialHandshakePacket.readInteger(NativeConstants.IntegerDataType.INT1);
    }
    initialHandshakePacket.setPosition(initialHandshakePacket.getPosition() + 10);
    
    serverHasFracSecsSupport = serverVersion.meetsMinimum(new ServerVersion(5, 6, 4));
  }
  
  public int getCapabilityFlags()
  {
    return capabilityFlags;
  }
  
  public void setCapabilityFlags(int capabilityFlags)
  {
    this.capabilityFlags = capabilityFlags;
  }
  
  public byte getProtocolVersion()
  {
    return protocolVersion;
  }
  
  public void setProtocolVersion(byte protocolVersion)
  {
    this.protocolVersion = protocolVersion;
  }
  
  public ServerVersion getServerVersion()
  {
    return serverVersion;
  }
  
  public void setServerVersion(ServerVersion serverVersion)
  {
    this.serverVersion = serverVersion;
  }
  
  public long getThreadId()
  {
    return threadId;
  }
  
  public void setThreadId(long threadId)
  {
    this.threadId = threadId;
  }
  
  public String getSeed()
  {
    return seed;
  }
  
  public void setSeed(String seed)
  {
    this.seed = seed;
  }
  
  public int getServerDefaultCollationIndex()
  {
    return serverDefaultCollationIndex;
  }
  
  public void setServerDefaultCollationIndex(int serverDefaultCollationIndex)
  {
    this.serverDefaultCollationIndex = serverDefaultCollationIndex;
  }
  
  public int getStatusFlags()
  {
    return statusFlags;
  }
  
  public void setStatusFlags(int statusFlags)
  {
    this.statusFlags = statusFlags;
  }
  
  public int getAuthPluginDataLength()
  {
    return authPluginDataLength;
  }
  
  public void setAuthPluginDataLength(int authPluginDataLength)
  {
    this.authPluginDataLength = authPluginDataLength;
  }
  
  public boolean serverSupportsFracSecs()
  {
    return serverHasFracSecsSupport;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeCapabilities
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */