package com.mysql.cj.protocol.a;

public enum NativeConstants$StringLengthDataType
{
  STRING_FIXED,  STRING_VAR;
  
  private NativeConstants$StringLengthDataType() {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.a.NativeConstants.StringLengthDataType
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */