package com.mysql.cj.protocol;

class ExportControlled$KeyStoreConf
{
  public String keyStoreUrl = null;
  public String keyStorePassword = null;
  public String keyStoreType = "JKS";
  
  public ExportControlled$KeyStoreConf() {}
  
  public ExportControlled$KeyStoreConf(String keyStoreUrl, String keyStorePassword, String keyStoreType)
  {
    this.keyStoreUrl = keyStoreUrl;
    this.keyStorePassword = keyStorePassword;
    this.keyStoreType = keyStoreType;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ExportControlled.KeyStoreConf
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */