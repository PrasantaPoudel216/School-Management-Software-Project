package com.mysql.cj.protocol;

import com.mysql.cj.Messages;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.net.Socket;

class NamedPipeSocketFactory$NamedPipeSocket
  extends Socket
{
  private boolean isClosed = false;
  private RandomAccessFile namedPipeFile;
  
  NamedPipeSocketFactory$NamedPipeSocket(NamedPipeSocketFactory this$0, String filePath)
    throws IOException
  {
    if ((filePath == null) || (filePath.length() == 0)) {
      throw new IOException(Messages.getString("NamedPipeSocketFactory.4"));
    }
    namedPipeFile = new RandomAccessFile(filePath, "rw");
  }
  
  public synchronized void close()
    throws IOException
  {
    namedPipeFile.close();
    isClosed = true;
  }
  
  public InputStream getInputStream()
    throws IOException
  {
    return new NamedPipeSocketFactory.RandomAccessFileInputStream(this$0, namedPipeFile);
  }
  
  public OutputStream getOutputStream()
    throws IOException
  {
    return new NamedPipeSocketFactory.RandomAccessFileOutputStream(this$0, namedPipeFile);
  }
  
  public boolean isClosed()
  {
    return isClosed;
  }
  
  public void shutdownInput()
    throws IOException
  {}
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.NamedPipeSocketFactory.NamedPipeSocket
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */