package com.mysql.cj.protocol;

public abstract interface OutputStreamWatcher
{
  public abstract void streamClosed(WatchableStream paramWatchableStream);
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.OutputStreamWatcher
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */