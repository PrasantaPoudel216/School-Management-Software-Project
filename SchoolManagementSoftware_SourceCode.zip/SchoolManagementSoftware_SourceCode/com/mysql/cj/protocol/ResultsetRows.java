package com.mysql.cj.protocol;

import com.mysql.cj.Messages;
import com.mysql.cj.exceptions.CJOperationNotSupportedException;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.result.Row;
import com.mysql.cj.result.RowList;

public abstract interface ResultsetRows
  extends RowList, ProtocolEntity
{
  public void addRow(Row row)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public void afterLast()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public void beforeFirst()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public void beforeLast()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public void close() {}
  
  public abstract ResultsetRowsOwner getOwner();
  
  public abstract boolean isAfterLast();
  
  public abstract boolean isBeforeFirst();
  
  public boolean isDynamic()
  {
    return true;
  }
  
  public boolean isEmpty()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public boolean isFirst()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public boolean isLast()
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public void moveRowRelative(int rows)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public void setCurrentRow(int rowNumber)
  {
    throw ((CJOperationNotSupportedException)ExceptionFactory.createException(CJOperationNotSupportedException.class, Messages.getString("OperationNotSupportedException.0")));
  }
  
  public abstract void setOwner(ResultsetRowsOwner paramResultsetRowsOwner);
  
  public abstract boolean wasEmpty();
  
  public abstract void setMetadata(ColumnDefinition paramColumnDefinition);
  
  public abstract ColumnDefinition getMetadata();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ResultsetRows
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */