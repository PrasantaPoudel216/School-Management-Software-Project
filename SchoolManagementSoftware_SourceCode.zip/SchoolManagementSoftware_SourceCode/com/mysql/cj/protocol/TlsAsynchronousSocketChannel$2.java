package com.mysql.cj.protocol;

class TlsAsynchronousSocketChannel$2 {}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.TlsAsynchronousSocketChannel.2
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */