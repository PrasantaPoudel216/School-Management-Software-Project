package com.mysql.cj.protocol;

import com.mysql.cj.result.Row;

public abstract interface ResultListener<OK extends ProtocolEntity>
{
  public abstract void onMetadata(ColumnDefinition paramColumnDefinition);
  
  public abstract void onRow(Row paramRow);
  
  public abstract void onComplete(OK paramOK);
  
  public abstract void onException(Throwable paramThrowable);
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ResultListener
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */