package com.mysql.cj.protocol;

import com.mysql.cj.result.Field;
import java.util.Map;

public abstract interface ColumnDefinition
  extends ProtocolEntity
{
  public abstract Field[] getFields();
  
  public abstract void setFields(Field[] paramArrayOfField);
  
  public abstract void buildIndexMapping();
  
  public abstract boolean hasBuiltIndexMapping();
  
  public abstract Map<String, Integer> getColumnLabelToIndex();
  
  public abstract void setColumnLabelToIndex(Map<String, Integer> paramMap);
  
  public abstract Map<String, Integer> getFullColumnNameToIndex();
  
  public abstract void setFullColumnNameToIndex(Map<String, Integer> paramMap);
  
  public abstract Map<String, Integer> getColumnNameToIndex();
  
  public abstract void setColumnNameToIndex(Map<String, Integer> paramMap);
  
  public abstract Map<String, Integer> getColumnToIndexCache();
  
  public abstract void setColumnToIndexCache(Map<String, Integer> paramMap);
  
  public abstract void initializeFrom(ColumnDefinition paramColumnDefinition);
  
  public abstract void exportTo(ColumnDefinition paramColumnDefinition);
  
  public abstract int findColumn(String paramString, boolean paramBoolean, int paramInt);
  
  public abstract boolean hasLargeFields();
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ColumnDefinition
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */