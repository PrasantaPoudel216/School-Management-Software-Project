package com.mysql.cj.protocol;

public enum Resultset$Concurrency
{
  READ_ONLY(1007),  UPDATABLE(1008);
  
  private int value;
  
  private Resultset$Concurrency(int jdbcRsConcur)
  {
    value = jdbcRsConcur;
  }
  
  public int getIntValue()
  {
    return value;
  }
  
  public static Concurrency fromValue(int concurMode, Concurrency backupValue)
  {
    for (Concurrency c : ) {
      if (c.getIntValue() == concurMode) {
        return c;
      }
    }
    return backupValue;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.Resultset.Concurrency
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */