package com.mysql.cj.protocol;

import com.mysql.cj.result.Row;

public abstract interface ResultsetRow
  extends Row, ProtocolEntity
{
  public boolean isBinaryEncoded()
  {
    return false;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.protocol.ResultsetRow
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */