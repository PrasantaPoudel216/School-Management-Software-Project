package com.mysql.cj;

import com.mysql.cj.conf.PropertyKey;
import com.mysql.cj.conf.PropertySet;
import com.mysql.cj.conf.RuntimeProperty;
import com.mysql.cj.exceptions.ExceptionFactory;
import com.mysql.cj.exceptions.WrongArgumentException;
import com.mysql.cj.protocol.ColumnDefinition;
import com.mysql.cj.protocol.ServerCapabilities;
import com.mysql.cj.protocol.ServerSession;
import com.mysql.cj.result.Field;
import com.mysql.cj.util.StringUtils;
import com.mysql.cj.util.TimeUtil;
import java.io.InputStream;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.Date;
import java.sql.NClob;
import java.sql.Time;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.concurrent.atomic.AtomicBoolean;

public class ServerPreparedQueryBindings
  extends AbstractQueryBindings<ServerPreparedQueryBindValue>
{
  private AtomicBoolean sendTypesToServer = new AtomicBoolean(false);
  private boolean longParameterSwitchDetected = false;
  
  public ServerPreparedQueryBindings(int parameterCount, Session sess)
  {
    super(parameterCount, sess);
  }
  
  protected void initBindValues(int parameterCount)
  {
    bindValues = new ServerPreparedQueryBindValue[parameterCount];
    for (int i = 0; i < parameterCount; i++) {
      ((ServerPreparedQueryBindValue[])bindValues)[i] = new ServerPreparedQueryBindValue(session.getServerSession().getDefaultTimeZone());
    }
  }
  
  public ServerPreparedQueryBindings clone()
  {
    ServerPreparedQueryBindings newBindings = new ServerPreparedQueryBindings(((ServerPreparedQueryBindValue[])bindValues).length, session);
    ServerPreparedQueryBindValue[] bvs = new ServerPreparedQueryBindValue[((ServerPreparedQueryBindValue[])bindValues).length];
    for (int i = 0; i < ((ServerPreparedQueryBindValue[])bindValues).length; i++) {
      bvs[i] = ((ServerPreparedQueryBindValue[])bindValues)[i].clone();
    }
    bindValues = bvs;
    sendTypesToServer = sendTypesToServer;
    longParameterSwitchDetected = longParameterSwitchDetected;
    isLoadDataQuery = isLoadDataQuery;
    return newBindings;
  }
  
  public ServerPreparedQueryBindValue getBinding(int parameterIndex, boolean forLongData)
  {
    if (((ServerPreparedQueryBindValue[])bindValues)[parameterIndex] != null) {
      if ((bindValues)[parameterIndex].isStream) && (!forLongData)) {
        longParameterSwitchDetected = true;
      }
    }
    return ((ServerPreparedQueryBindValue[])bindValues)[parameterIndex];
  }
  
  public void checkParameterSet(int columnIndex)
  {
    if (!((ServerPreparedQueryBindValue[])bindValues)[columnIndex].isSet()) {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, 
        Messages.getString("ServerPreparedStatement.13") + (columnIndex + 1) + Messages.getString("ServerPreparedStatement.14")));
    }
  }
  
  public AtomicBoolean getSendTypesToServer()
  {
    return sendTypesToServer;
  }
  
  public boolean isLongParameterSwitchDetected()
  {
    return longParameterSwitchDetected;
  }
  
  public void setLongParameterSwitchDetected(boolean longParameterSwitchDetected)
  {
    this.longParameterSwitchDetected = longParameterSwitchDetected;
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x)
  {
    setAsciiStream(parameterIndex, x, -1);
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x, int length)
  {
    if (x == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, true);
      sendTypesToServer.compareAndSet(false, binding.resetToType(252, numberOfExecutions));
      value = x;
      isStream = true;
      streamLength = (((Boolean)useStreamLengthsInPrepStmts.getValue()).booleanValue() ? length : -1L);
    }
  }
  
  public void setAsciiStream(int parameterIndex, InputStream x, long length)
  {
    setAsciiStream(parameterIndex, x, (int)length);
    ((ServerPreparedQueryBindValue[])bindValues)[parameterIndex].setMysqlType(MysqlType.TEXT);
  }
  
  public void setBigDecimal(int parameterIndex, BigDecimal x)
  {
    if (x == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
      sendTypesToServer.compareAndSet(false, binding.resetToType(246, numberOfExecutions));
      value = StringUtils.fixDecimalExponent(x.toPlainString());
      parameterType = MysqlType.DECIMAL;
    }
  }
  
  public void setBigInteger(int parameterIndex, BigInteger x)
  {
    setValue(parameterIndex, x.toString(), MysqlType.BIGINT_UNSIGNED);
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x)
  {
    setBinaryStream(parameterIndex, x, -1);
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x, int length)
  {
    if (x == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, true);
      sendTypesToServer.compareAndSet(false, binding.resetToType(252, numberOfExecutions));
      value = x;
      isStream = true;
      streamLength = (((Boolean)useStreamLengthsInPrepStmts.getValue()).booleanValue() ? length : -1L);
      parameterType = MysqlType.BLOB;
    }
  }
  
  public void setBinaryStream(int parameterIndex, InputStream x, long length)
  {
    setBinaryStream(parameterIndex, x, (int)length);
  }
  
  public void setBlob(int parameterIndex, InputStream inputStream)
  {
    setBinaryStream(parameterIndex, inputStream);
  }
  
  public void setBlob(int parameterIndex, InputStream inputStream, long length)
  {
    setBinaryStream(parameterIndex, inputStream, (int)length);
  }
  
  public void setBlob(int parameterIndex, Blob x)
  {
    if (x == null) {
      setNull(parameterIndex);
    } else {
      try
      {
        ServerPreparedQueryBindValue binding = getBinding(parameterIndex, true);
        sendTypesToServer.compareAndSet(false, binding.resetToType(252, numberOfExecutions));
        value = x;
        isStream = true;
        streamLength = (((Boolean)useStreamLengthsInPrepStmts.getValue()).booleanValue() ? x.length() : -1L);
        parameterType = MysqlType.BLOB;
      }
      catch (Throwable t)
      {
        throw ExceptionFactory.createException(t.getMessage(), t);
      }
    }
  }
  
  public void setBoolean(int parameterIndex, boolean x)
  {
    ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
    sendTypesToServer.compareAndSet(false, binding.resetToType(1, numberOfExecutions));
    value = Long.valueOf(x ? 1L : 0L);
    parameterType = MysqlType.BOOLEAN;
  }
  
  public void setByte(int parameterIndex, byte x)
  {
    ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
    sendTypesToServer.compareAndSet(false, binding.resetToType(1, numberOfExecutions));
    value = Long.valueOf(x);
    parameterType = MysqlType.TINYINT;
  }
  
  public void setBytes(int parameterIndex, byte[] x)
  {
    if (x == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
      sendTypesToServer.compareAndSet(false, binding.resetToType(253, numberOfExecutions));
      value = x;
      parameterType = MysqlType.BINARY;
    }
  }
  
  public void setBytes(int parameterIndex, byte[] x, boolean checkForIntroducer, boolean escapeForMBChars)
  {
    setBytes(parameterIndex, x);
  }
  
  public void setBytesNoEscape(int parameterIndex, byte[] parameterAsBytes)
  {
    setBytes(parameterIndex, parameterAsBytes);
  }
  
  public void setBytesNoEscapeNoQuotes(int parameterIndex, byte[] parameterAsBytes)
  {
    setBytes(parameterIndex, parameterAsBytes);
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader)
  {
    setCharacterStream(parameterIndex, reader, -1);
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader, int length)
  {
    if (reader == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, true);
      sendTypesToServer.compareAndSet(false, binding.resetToType(252, numberOfExecutions));
      value = reader;
      isStream = true;
      streamLength = (((Boolean)useStreamLengthsInPrepStmts.getValue()).booleanValue() ? length : -1L);
      parameterType = MysqlType.TEXT;
    }
  }
  
  public void setCharacterStream(int parameterIndex, Reader reader, long length)
  {
    setCharacterStream(parameterIndex, reader, (int)length);
  }
  
  public void setClob(int parameterIndex, Reader reader)
  {
    setCharacterStream(parameterIndex, reader);
  }
  
  public void setClob(int parameterIndex, Reader reader, long length)
  {
    setCharacterStream(parameterIndex, reader, length);
  }
  
  public void setClob(int parameterIndex, Clob x)
  {
    if (x == null) {
      setNull(parameterIndex);
    } else {
      try
      {
        ServerPreparedQueryBindValue binding = getBinding(parameterIndex, true);
        sendTypesToServer.compareAndSet(false, binding.resetToType(252, numberOfExecutions));
        value = x.getCharacterStream();
        isStream = true;
        streamLength = (((Boolean)useStreamLengthsInPrepStmts.getValue()).booleanValue() ? x.length() : -1L);
        parameterType = MysqlType.TEXT;
      }
      catch (Throwable t)
      {
        throw ExceptionFactory.createException(t.getMessage(), t);
      }
    }
  }
  
  public void setDate(int parameterIndex, Date x)
  {
    setDate(parameterIndex, x, null);
  }
  
  public void setDate(int parameterIndex, Date x, Calendar cal)
  {
    if (x == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
      sendTypesToServer.compareAndSet(false, binding.resetToType(10, numberOfExecutions));
      value = x;
      calendar = (cal == null ? null : (Calendar)cal.clone());
      parameterType = MysqlType.DATE;
    }
  }
  
  public void setDouble(int parameterIndex, double x)
  {
    if ((!((Boolean)session.getPropertySet().getBooleanProperty(PropertyKey.allowNanAndInf).getValue()).booleanValue()) && ((x == Double.POSITIVE_INFINITY) || (x == Double.NEGATIVE_INFINITY) || 
      (Double.isNaN(x)))) {
      throw ((WrongArgumentException)ExceptionFactory.createException(WrongArgumentException.class, Messages.getString("PreparedStatement.64", new Object[] { Double.valueOf(x) }), session
        .getExceptionInterceptor()));
    }
    ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
    sendTypesToServer.compareAndSet(false, binding.resetToType(5, numberOfExecutions));
    value = Double.valueOf(x);
    parameterType = MysqlType.DOUBLE;
  }
  
  public void setFloat(int parameterIndex, float x)
  {
    ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
    sendTypesToServer.compareAndSet(false, binding.resetToType(4, numberOfExecutions));
    value = Float.valueOf(x);
    parameterType = MysqlType.FLOAT;
  }
  
  public void setInt(int parameterIndex, int x)
  {
    ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
    sendTypesToServer.compareAndSet(false, binding.resetToType(3, numberOfExecutions));
    value = Long.valueOf(x);
    parameterType = MysqlType.INT;
  }
  
  public void setLong(int parameterIndex, long x)
  {
    ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
    sendTypesToServer.compareAndSet(false, binding.resetToType(8, numberOfExecutions));
    value = Long.valueOf(x);
    parameterType = MysqlType.BIGINT;
  }
  
  public void setNCharacterStream(int parameterIndex, Reader value)
  {
    setNCharacterStream(parameterIndex, value, -1L);
  }
  
  public void setNCharacterStream(int parameterIndex, Reader reader, long length)
  {
    if ((!charEncoding.equalsIgnoreCase("UTF-8")) && (!charEncoding.equalsIgnoreCase("utf8"))) {
      throw ExceptionFactory.createException(Messages.getString("ServerPreparedStatement.28"), session.getExceptionInterceptor());
    }
    if (reader == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, true);
      sendTypesToServer.compareAndSet(false, binding.resetToType(252, numberOfExecutions));
      value = reader;
      isStream = true;
      streamLength = (((Boolean)useStreamLengthsInPrepStmts.getValue()).booleanValue() ? length : -1L);
      parameterType = MysqlType.TEXT;
    }
  }
  
  public void setNClob(int parameterIndex, Reader reader)
  {
    setNCharacterStream(parameterIndex, reader);
  }
  
  public void setNClob(int parameterIndex, Reader reader, long length)
  {
    if ((!charEncoding.equalsIgnoreCase("UTF-8")) && (!charEncoding.equalsIgnoreCase("utf8"))) {
      throw ExceptionFactory.createException(Messages.getString("ServerPreparedStatement.29"), session.getExceptionInterceptor());
    }
    setNCharacterStream(parameterIndex, reader, length);
  }
  
  public void setNClob(int parameterIndex, NClob value)
  {
    try
    {
      setNClob(parameterIndex, value.getCharacterStream(), ((Boolean)useStreamLengthsInPrepStmts.getValue()).booleanValue() ? value.length() : -1L);
    }
    catch (Throwable t)
    {
      throw ExceptionFactory.createException(t.getMessage(), t, session.getExceptionInterceptor());
    }
  }
  
  public void setNString(int parameterIndex, String x)
  {
    if ((charEncoding.equalsIgnoreCase("UTF-8")) || (charEncoding.equalsIgnoreCase("utf8"))) {
      setString(parameterIndex, x);
    } else {
      throw ExceptionFactory.createException(Messages.getString("ServerPreparedStatement.30"), session.getExceptionInterceptor());
    }
  }
  
  public void setNull(int parameterIndex)
  {
    ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
    sendTypesToServer.compareAndSet(false, binding.resetToType(6, numberOfExecutions));
    binding.setNull(true);
  }
  
  public void setShort(int parameterIndex, short x)
  {
    ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
    sendTypesToServer.compareAndSet(false, binding.resetToType(2, numberOfExecutions));
    value = Long.valueOf(x);
    parameterType = MysqlType.SMALLINT;
  }
  
  public void setString(int parameterIndex, String x)
  {
    if (x == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
      sendTypesToServer.compareAndSet(false, binding.resetToType(253, numberOfExecutions));
      value = x;
      charEncoding = charEncoding;
      parameterType = MysqlType.VARCHAR;
    }
  }
  
  public void setTime(int parameterIndex, Time x, Calendar cal)
  {
    if (x == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
      sendTypesToServer.compareAndSet(false, binding.resetToType(11, numberOfExecutions));
      value = x;
      calendar = (cal == null ? null : (Calendar)cal.clone());
      parameterType = MysqlType.TIME;
    }
  }
  
  public void setTime(int parameterIndex, Time x)
  {
    setTime(parameterIndex, x, null);
  }
  
  public void setTimestamp(int parameterIndex, Timestamp x)
  {
    int fractLen = -1;
    if ((!((Boolean)sendFractionalSeconds.getValue()).booleanValue()) || (!session.getServerSession().getCapabilities().serverSupportsFracSecs())) {
      fractLen = 0;
    } else if ((columnDefinition != null) && (parameterIndex <= columnDefinition.getFields().length) && (parameterIndex >= 0)) {
      fractLen = columnDefinition.getFields()[parameterIndex].getDecimals();
    }
    setTimestamp(parameterIndex, x, null, fractLen);
  }
  
  public void setTimestamp(int parameterIndex, Timestamp x, Calendar cal)
  {
    int fractLen = -1;
    if ((!((Boolean)sendFractionalSeconds.getValue()).booleanValue()) || (!session.getServerSession().getCapabilities().serverSupportsFracSecs())) {
      fractLen = 0;
    } else if ((columnDefinition != null) && (parameterIndex <= columnDefinition.getFields().length) && (parameterIndex >= 0) && 
      (columnDefinition.getFields()[parameterIndex].getDecimals() > 0)) {
      fractLen = columnDefinition.getFields()[parameterIndex].getDecimals();
    }
    setTimestamp(parameterIndex, x, cal, fractLen);
  }
  
  public void setTimestamp(int parameterIndex, Timestamp x, Calendar targetCalendar, int fractionalLength)
  {
    if (x == null)
    {
      setNull(parameterIndex);
    }
    else
    {
      ServerPreparedQueryBindValue binding = getBinding(parameterIndex, false);
      sendTypesToServer.compareAndSet(false, binding.resetToType(12, numberOfExecutions));
      
      x = (Timestamp)x.clone();
      if ((!session.getServerSession().getCapabilities().serverSupportsFracSecs()) || (
        (!((Boolean)sendFractionalSeconds.getValue()).booleanValue()) && (fractionalLength == 0))) {
        x = TimeUtil.truncateFractionalSeconds(x);
      }
      if (fractionalLength < 0) {
        fractionalLength = 6;
      }
      x = TimeUtil.adjustTimestampNanosPrecision(x, fractionalLength, !session.getServerSession().isServerTruncatesFracSecs());
      
      value = x;
      calendar = (targetCalendar == null ? null : (Calendar)targetCalendar.clone());
      parameterType = MysqlType.TIMESTAMP;
    }
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.ServerPreparedQueryBindings
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */