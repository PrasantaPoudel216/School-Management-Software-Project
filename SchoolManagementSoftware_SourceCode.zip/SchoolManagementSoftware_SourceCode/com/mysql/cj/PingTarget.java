package com.mysql.cj;

public abstract interface PingTarget
{
  public abstract void doPing()
    throws Exception;
}

/* Location:
 * Qualified Name:     com.mysql.cj.PingTarget
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */