package com.mysql.cj;

import com.mysql.cj.conf.HostInfo;
import com.mysql.cj.exceptions.ExceptionInterceptor;
import com.mysql.cj.log.Log;
import java.sql.SQLException;
import java.util.Properties;

class NativeSession$1
  implements ExceptionInterceptor
{
  NativeSession$1(NativeSession this$0) {}
  
  public ExceptionInterceptor init(Properties config, Log log1)
  {
    return this;
  }
  
  public void destroy() {}
  
  public Exception interceptException(Exception sqlEx)
  {
    if (((sqlEx instanceof SQLException)) && (((SQLException)sqlEx).getSQLState() != null) && 
      (((SQLException)sqlEx).getSQLState().startsWith("08"))) {
      NativeSession.access$000(this$0).invalidate(this$0.hostInfo.getDatabaseUrl());
    }
    return null;
  }
}

/* Location:
 * Qualified Name:     com.mysql.cj.NativeSession.1
 * Java Class Version: 8 (52.0)
 * JD-Core Version:    0.7.1
 */